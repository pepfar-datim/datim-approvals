var dhis2 = dhis2 || {};
dhis2["util"] = dhis2["util"] || {};
dhis2.util.namespace = function(path) {
  var parts = path.split(".");
  var parent = window;
  var currentPart = "";
  for (var i2 = 0, length = parts.length; i2 < length; i2++) {
    currentPart = parts[i2];
    parent[currentPart] = parent[currentPart] || {};
    parent = parent[currentPart];
  }
  return parent;
};
dhis2.util.escape = function(text) {
  return text.replace(/[-[\]{}()*+?.,\/\\^$|#\s]/g, "\\$&");
};
dhis2.util.parseJavaProperties = function(javaProperties) {
  var obj = {}, lines;
  if (typeof javaProperties !== "string") {
    return obj;
  }
  lines = javaProperties.split(/\n/);
  for (var i = 0, a; i < lines.length; i++) {
    if (!!(typeof lines[i] === "string" && lines[i].length && lines[i].indexOf("=") !== -1)) {
      a = lines[i].split("=");
      obj[a[0].trim()] = eval('"' + a[1].trim().replace(/"/g, "'") + '"');
    }
  }
  return obj;
};
dhis2.util.jqTextFilterCaseSensitive = function(key, not) {
  key = dhis2.util.escape(key);
  not = not || false;
  if (not) {
    return function(i2, el) {
      return !!!$(el).text().match("" + key);
    };
  } else {
    return function(i2, el) {
      return !!$(el).text().match("" + key);
    };
  }
};
dhis2.util.jqTextFilter = function(key, not) {
  key = dhis2.util.escape(key).toLowerCase();
  not = not || false;
  if (not) {
    return function(i2, el) {
      return !!!$(el).text().toLowerCase().match("" + key);
    };
  } else {
    return function(i2, el) {
      return !!$(el).text().toLowerCase().match("" + key);
    };
  }
};
dhis2.util.uuid = function() {
  var S4 = function() {
    return ((1 + Math.random()) * 65536 | 0).toString(16).substring(1);
  };
  return S4() + S4() + "-" + S4() + "-" + S4() + "-" + S4() + "-" + S4() + S4() + S4();
};
dhis2.util.uid = function() {
  var letters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
  var allowedChars = "0123456789" + letters;
  var NUMBER_OF_CODEPOINTS = allowedChars.length;
  var CODESIZE = 11;
  var uid;
  uid = letters.charAt(Math.random() * letters.length);
  for (var i2 = 1; i2 < CODESIZE; ++i2) {
    uid += allowedChars.charAt(Math.random() * NUMBER_OF_CODEPOINTS);
  }
  return uid;
};
dhis2.util.normalizeArguments = function(args) {
  if (!args || !args.length || !args[0]) {
    return void 0;
  }
  if ($.isArray(args[0])) {
    return args;
  } else {
    var arr = [];
    arr[0] = args;
    return arr;
  }
};
dhis2.util.on = function(event, fn) {
  $(document).off(event).on(event, fn);
};
dhis2.util.cacheBust = function() {
  return "_=" + (/* @__PURE__ */ new Date()).getTime();
};
dhis2.util.nameSort = function(a2, b) {
  return a2.name > b.name ? 1 : a2.name < b.name ? -1 : 0;
};
$.expr.pseudos.containsNC = function(a2, i2, m, r) {
  var search = dhis2.util.escape(m[3]);
  return jQuery(a2).text().toUpperCase().indexOf(m[search].toUpperCase()) >= 0;
};
$.expr.pseudos.regex = function(a2, i2, m, r) {
  var re = new RegExp(m[3], "i");
  return re.test(jQuery(a2).text());
};
$.expr.pseudos.regexCS = function(a2, i2, m, r) {
  var re = new RegExp(m[3]);
  return re.test(jQuery(a2).text());
};
if (!Object.keys) {
  Object.keys = function(obj2) {
    var keys = [];
    for (var k in obj2)
      if (obj2.hasOwnProperty(k))
        keys.push(k);
    return keys;
  };
}
(function() {
  var method;
  var noop = function() {
  };
  var methods = [
    "assert",
    "clear",
    "count",
    "debug",
    "dir",
    "dirxml",
    "error",
    "exception",
    "group",
    "groupCollapsed",
    "groupEnd",
    "info",
    "log",
    "markTimeline",
    "profile",
    "profileEnd",
    "table",
    "time",
    "timeEnd",
    "timeStamp",
    "trace",
    "warn"
  ];
  var length = methods.length;
  var console2 = window.console = window.console || {};
  while (length--) {
    method = methods[length];
    if (!console2[method]) {
      console2[method] = noop;
    }
  }
  window.log = function(msg) {
    console2.log(msg);
  };
})();
(function createDataEntryEvents() {
  try {
    window.dhis2 = window.dhis2 || {};
    dhis2.de = dhis2.de || {};
    dhis2.de.event = {
      // Fired
      formLoaded: "dhis2.de.event.formLoaded",
      dataValuesLoaded: "dhis2.de.event.dataValuesLoaded",
      formReady: "dhis2.de.event.formReady",
      // Never fired in approvals (but can be subscribed to in custom form)
      dataValueSaved: "dhis2.de.event.dataValueSaved",
      completed: "dhis2.de.event.completed",
      uncompleted: "dhis2.de.event.uncompleted",
      validationSucces: "dhis2.de.event.validationSuccess",
      validationError: "dhis2.de.event.validationError"
    };
    window.dhis2 = dhis2;
  } catch (e) {
    console.error(`dhis2.de.js ERROR`);
    console.error(e);
  }
})();
