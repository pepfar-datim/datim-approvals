import { R as ReactDOM, a as React, r as reactExports, g as getDefaultExportFromCjs, c as commonjsGlobal, b as reactDomExports, j as jsxRuntimeExports } from "./index-BthshU0p.js";
function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf2(o2, p2) {
    o2.__proto__ = p2;
    return o2;
  };
  return _setPrototypeOf(o, p);
}
function _inheritsLoose(subClass, superClass) {
  subClass.prototype = Object.create(superClass.prototype);
  subClass.prototype.constructor = subClass;
  _setPrototypeOf(subClass, superClass);
}
var Subscribable = /* @__PURE__ */ function() {
  function Subscribable2() {
    this.listeners = [];
  }
  var _proto = Subscribable2.prototype;
  _proto.subscribe = function subscribe(listener) {
    var _this = this;
    var callback = listener || function() {
      return void 0;
    };
    this.listeners.push(callback);
    this.onSubscribe();
    return function() {
      _this.listeners = _this.listeners.filter(function(x) {
        return x !== callback;
      });
      _this.onUnsubscribe();
    };
  };
  _proto.hasListeners = function hasListeners() {
    return this.listeners.length > 0;
  };
  _proto.onSubscribe = function onSubscribe() {
  };
  _proto.onUnsubscribe = function onUnsubscribe() {
  };
  return Subscribable2;
}();
function _extends$8() {
  _extends$8 = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$8.apply(this, arguments);
}
var isServer = typeof window === "undefined";
function noop$2() {
  return void 0;
}
function functionalUpdate(updater, input) {
  return typeof updater === "function" ? updater(input) : updater;
}
function isValidTimeout(value) {
  return typeof value === "number" && value >= 0 && value !== Infinity;
}
function ensureQueryKeyArray(value) {
  return Array.isArray(value) ? value : [value];
}
function timeUntilStale(updatedAt, staleTime) {
  return Math.max(updatedAt + (staleTime || 0) - Date.now(), 0);
}
function parseQueryArgs(arg1, arg2, arg3) {
  if (!isQueryKey(arg1)) {
    return arg1;
  }
  if (typeof arg2 === "function") {
    return _extends$8({}, arg3, {
      queryKey: arg1,
      queryFn: arg2
    });
  }
  return _extends$8({}, arg2, {
    queryKey: arg1
  });
}
function parseFilterArgs(arg1, arg2, arg3) {
  return isQueryKey(arg1) ? [_extends$8({}, arg2, {
    queryKey: arg1
  }), arg3] : [arg1 || {}, arg2];
}
function mapQueryStatusFilter(active, inactive) {
  if (active === true && inactive === true || active == null && inactive == null) {
    return "all";
  } else if (active === false && inactive === false) {
    return "none";
  } else {
    var isActive = active != null ? active : !inactive;
    return isActive ? "active" : "inactive";
  }
}
function matchQuery(filters, query2) {
  var active = filters.active, exact = filters.exact, fetching = filters.fetching, inactive = filters.inactive, predicate = filters.predicate, queryKey = filters.queryKey, stale = filters.stale;
  if (isQueryKey(queryKey)) {
    if (exact) {
      if (query2.queryHash !== hashQueryKeyByOptions(queryKey, query2.options)) {
        return false;
      }
    } else if (!partialMatchKey(query2.queryKey, queryKey)) {
      return false;
    }
  }
  var queryStatusFilter = mapQueryStatusFilter(active, inactive);
  if (queryStatusFilter === "none") {
    return false;
  } else if (queryStatusFilter !== "all") {
    var isActive = query2.isActive();
    if (queryStatusFilter === "active" && !isActive) {
      return false;
    }
    if (queryStatusFilter === "inactive" && isActive) {
      return false;
    }
  }
  if (typeof stale === "boolean" && query2.isStale() !== stale) {
    return false;
  }
  if (typeof fetching === "boolean" && query2.isFetching() !== fetching) {
    return false;
  }
  if (predicate && !predicate(query2)) {
    return false;
  }
  return true;
}
function matchMutation(filters, mutation) {
  var exact = filters.exact, fetching = filters.fetching, predicate = filters.predicate, mutationKey = filters.mutationKey;
  if (isQueryKey(mutationKey)) {
    if (!mutation.options.mutationKey) {
      return false;
    }
    if (exact) {
      if (hashQueryKey(mutation.options.mutationKey) !== hashQueryKey(mutationKey)) {
        return false;
      }
    } else if (!partialMatchKey(mutation.options.mutationKey, mutationKey)) {
      return false;
    }
  }
  if (typeof fetching === "boolean" && mutation.state.status === "loading" !== fetching) {
    return false;
  }
  if (predicate && !predicate(mutation)) {
    return false;
  }
  return true;
}
function hashQueryKeyByOptions(queryKey, options) {
  var hashFn = (options == null ? void 0 : options.queryKeyHashFn) || hashQueryKey;
  return hashFn(queryKey);
}
function hashQueryKey(queryKey) {
  var asArray = ensureQueryKeyArray(queryKey);
  return stableValueHash(asArray);
}
function stableValueHash(value) {
  return JSON.stringify(value, function(_22, val) {
    return isPlainObject$1(val) ? Object.keys(val).sort().reduce(function(result, key) {
      result[key] = val[key];
      return result;
    }, {}) : val;
  });
}
function partialMatchKey(a, b) {
  return partialDeepEqual(ensureQueryKeyArray(a), ensureQueryKeyArray(b));
}
function partialDeepEqual(a, b) {
  if (a === b) {
    return true;
  }
  if (typeof a !== typeof b) {
    return false;
  }
  if (a && b && typeof a === "object" && typeof b === "object") {
    return !Object.keys(b).some(function(key) {
      return !partialDeepEqual(a[key], b[key]);
    });
  }
  return false;
}
function replaceEqualDeep(a, b) {
  if (a === b) {
    return a;
  }
  var array = Array.isArray(a) && Array.isArray(b);
  if (array || isPlainObject$1(a) && isPlainObject$1(b)) {
    var aSize = array ? a.length : Object.keys(a).length;
    var bItems = array ? b : Object.keys(b);
    var bSize = bItems.length;
    var copy2 = array ? [] : {};
    var equalItems = 0;
    for (var i = 0; i < bSize; i++) {
      var key = array ? i : bItems[i];
      copy2[key] = replaceEqualDeep(a[key], b[key]);
      if (copy2[key] === a[key]) {
        equalItems++;
      }
    }
    return aSize === bSize && equalItems === aSize ? a : copy2;
  }
  return b;
}
function shallowEqualObjects(a, b) {
  if (a && !b || b && !a) {
    return false;
  }
  for (var key in a) {
    if (a[key] !== b[key]) {
      return false;
    }
  }
  return true;
}
function isPlainObject$1(o) {
  if (!hasObjectPrototype$1(o)) {
    return false;
  }
  var ctor = o.constructor;
  if (typeof ctor === "undefined") {
    return true;
  }
  var prot = ctor.prototype;
  if (!hasObjectPrototype$1(prot)) {
    return false;
  }
  if (!prot.hasOwnProperty("isPrototypeOf")) {
    return false;
  }
  return true;
}
function hasObjectPrototype$1(o) {
  return Object.prototype.toString.call(o) === "[object Object]";
}
function isQueryKey(value) {
  return typeof value === "string" || Array.isArray(value);
}
function sleep(timeout) {
  return new Promise(function(resolve) {
    setTimeout(resolve, timeout);
  });
}
function scheduleMicrotask(callback) {
  Promise.resolve().then(callback).catch(function(error2) {
    return setTimeout(function() {
      throw error2;
    });
  });
}
function getAbortController() {
  if (typeof AbortController === "function") {
    return new AbortController();
  }
}
var FocusManager = /* @__PURE__ */ function(_Subscribable) {
  _inheritsLoose(FocusManager2, _Subscribable);
  function FocusManager2() {
    var _this;
    _this = _Subscribable.call(this) || this;
    _this.setup = function(onFocus) {
      var _window;
      if (!isServer && ((_window = window) == null ? void 0 : _window.addEventListener)) {
        var listener = function listener2() {
          return onFocus();
        };
        window.addEventListener("visibilitychange", listener, false);
        window.addEventListener("focus", listener, false);
        return function() {
          window.removeEventListener("visibilitychange", listener);
          window.removeEventListener("focus", listener);
        };
      }
    };
    return _this;
  }
  var _proto = FocusManager2.prototype;
  _proto.onSubscribe = function onSubscribe() {
    if (!this.cleanup) {
      this.setEventListener(this.setup);
    }
  };
  _proto.onUnsubscribe = function onUnsubscribe() {
    if (!this.hasListeners()) {
      var _this$cleanup;
      (_this$cleanup = this.cleanup) == null ? void 0 : _this$cleanup.call(this);
      this.cleanup = void 0;
    }
  };
  _proto.setEventListener = function setEventListener(setup) {
    var _this$cleanup2, _this2 = this;
    this.setup = setup;
    (_this$cleanup2 = this.cleanup) == null ? void 0 : _this$cleanup2.call(this);
    this.cleanup = setup(function(focused) {
      if (typeof focused === "boolean") {
        _this2.setFocused(focused);
      } else {
        _this2.onFocus();
      }
    });
  };
  _proto.setFocused = function setFocused(focused) {
    this.focused = focused;
    if (focused) {
      this.onFocus();
    }
  };
  _proto.onFocus = function onFocus() {
    this.listeners.forEach(function(listener) {
      listener();
    });
  };
  _proto.isFocused = function isFocused() {
    if (typeof this.focused === "boolean") {
      return this.focused;
    }
    if (typeof document === "undefined") {
      return true;
    }
    return [void 0, "visible", "prerender"].includes(document.visibilityState);
  };
  return FocusManager2;
}(Subscribable);
var focusManager = new FocusManager();
var OnlineManager = /* @__PURE__ */ function(_Subscribable) {
  _inheritsLoose(OnlineManager2, _Subscribable);
  function OnlineManager2() {
    var _this;
    _this = _Subscribable.call(this) || this;
    _this.setup = function(onOnline) {
      var _window;
      if (!isServer && ((_window = window) == null ? void 0 : _window.addEventListener)) {
        var listener = function listener2() {
          return onOnline();
        };
        window.addEventListener("online", listener, false);
        window.addEventListener("offline", listener, false);
        return function() {
          window.removeEventListener("online", listener);
          window.removeEventListener("offline", listener);
        };
      }
    };
    return _this;
  }
  var _proto = OnlineManager2.prototype;
  _proto.onSubscribe = function onSubscribe() {
    if (!this.cleanup) {
      this.setEventListener(this.setup);
    }
  };
  _proto.onUnsubscribe = function onUnsubscribe() {
    if (!this.hasListeners()) {
      var _this$cleanup;
      (_this$cleanup = this.cleanup) == null ? void 0 : _this$cleanup.call(this);
      this.cleanup = void 0;
    }
  };
  _proto.setEventListener = function setEventListener(setup) {
    var _this$cleanup2, _this2 = this;
    this.setup = setup;
    (_this$cleanup2 = this.cleanup) == null ? void 0 : _this$cleanup2.call(this);
    this.cleanup = setup(function(online) {
      if (typeof online === "boolean") {
        _this2.setOnline(online);
      } else {
        _this2.onOnline();
      }
    });
  };
  _proto.setOnline = function setOnline(online) {
    this.online = online;
    if (online) {
      this.onOnline();
    }
  };
  _proto.onOnline = function onOnline() {
    this.listeners.forEach(function(listener) {
      listener();
    });
  };
  _proto.isOnline = function isOnline() {
    if (typeof this.online === "boolean") {
      return this.online;
    }
    if (typeof navigator === "undefined" || typeof navigator.onLine === "undefined") {
      return true;
    }
    return navigator.onLine;
  };
  return OnlineManager2;
}(Subscribable);
var onlineManager = new OnlineManager();
function defaultRetryDelay(failureCount) {
  return Math.min(1e3 * Math.pow(2, failureCount), 3e4);
}
function isCancelable(value) {
  return typeof (value == null ? void 0 : value.cancel) === "function";
}
var CancelledError = function CancelledError2(options) {
  this.revert = options == null ? void 0 : options.revert;
  this.silent = options == null ? void 0 : options.silent;
};
function isCancelledError(value) {
  return value instanceof CancelledError;
}
var Retryer = function Retryer2(config) {
  var _this = this;
  var cancelRetry = false;
  var cancelFn;
  var continueFn;
  var promiseResolve;
  var promiseReject;
  this.abort = config.abort;
  this.cancel = function(cancelOptions) {
    return cancelFn == null ? void 0 : cancelFn(cancelOptions);
  };
  this.cancelRetry = function() {
    cancelRetry = true;
  };
  this.continueRetry = function() {
    cancelRetry = false;
  };
  this.continue = function() {
    return continueFn == null ? void 0 : continueFn();
  };
  this.failureCount = 0;
  this.isPaused = false;
  this.isResolved = false;
  this.isTransportCancelable = false;
  this.promise = new Promise(function(outerResolve, outerReject) {
    promiseResolve = outerResolve;
    promiseReject = outerReject;
  });
  var resolve = function resolve2(value) {
    if (!_this.isResolved) {
      _this.isResolved = true;
      config.onSuccess == null ? void 0 : config.onSuccess(value);
      continueFn == null ? void 0 : continueFn();
      promiseResolve(value);
    }
  };
  var reject = function reject2(value) {
    if (!_this.isResolved) {
      _this.isResolved = true;
      config.onError == null ? void 0 : config.onError(value);
      continueFn == null ? void 0 : continueFn();
      promiseReject(value);
    }
  };
  var pause = function pause2() {
    return new Promise(function(continueResolve) {
      continueFn = continueResolve;
      _this.isPaused = true;
      config.onPause == null ? void 0 : config.onPause();
    }).then(function() {
      continueFn = void 0;
      _this.isPaused = false;
      config.onContinue == null ? void 0 : config.onContinue();
    });
  };
  var run = function run2() {
    if (_this.isResolved) {
      return;
    }
    var promiseOrValue;
    try {
      promiseOrValue = config.fn();
    } catch (error2) {
      promiseOrValue = Promise.reject(error2);
    }
    cancelFn = function cancelFn2(cancelOptions) {
      if (!_this.isResolved) {
        reject(new CancelledError(cancelOptions));
        _this.abort == null ? void 0 : _this.abort();
        if (isCancelable(promiseOrValue)) {
          try {
            promiseOrValue.cancel();
          } catch (_unused) {
          }
        }
      }
    };
    _this.isTransportCancelable = isCancelable(promiseOrValue);
    Promise.resolve(promiseOrValue).then(resolve).catch(function(error2) {
      var _config$retry, _config$retryDelay;
      if (_this.isResolved) {
        return;
      }
      var retry = (_config$retry = config.retry) != null ? _config$retry : 3;
      var retryDelay = (_config$retryDelay = config.retryDelay) != null ? _config$retryDelay : defaultRetryDelay;
      var delay = typeof retryDelay === "function" ? retryDelay(_this.failureCount, error2) : retryDelay;
      var shouldRetry = retry === true || typeof retry === "number" && _this.failureCount < retry || typeof retry === "function" && retry(_this.failureCount, error2);
      if (cancelRetry || !shouldRetry) {
        reject(error2);
        return;
      }
      _this.failureCount++;
      config.onFail == null ? void 0 : config.onFail(_this.failureCount, error2);
      sleep(delay).then(function() {
        if (!focusManager.isFocused() || !onlineManager.isOnline()) {
          return pause();
        }
      }).then(function() {
        if (cancelRetry) {
          reject(error2);
        } else {
          run2();
        }
      });
    });
  };
  run();
};
var NotifyManager = /* @__PURE__ */ function() {
  function NotifyManager2() {
    this.queue = [];
    this.transactions = 0;
    this.notifyFn = function(callback) {
      callback();
    };
    this.batchNotifyFn = function(callback) {
      callback();
    };
  }
  var _proto = NotifyManager2.prototype;
  _proto.batch = function batch(callback) {
    var result;
    this.transactions++;
    try {
      result = callback();
    } finally {
      this.transactions--;
      if (!this.transactions) {
        this.flush();
      }
    }
    return result;
  };
  _proto.schedule = function schedule(callback) {
    var _this = this;
    if (this.transactions) {
      this.queue.push(callback);
    } else {
      scheduleMicrotask(function() {
        _this.notifyFn(callback);
      });
    }
  };
  _proto.batchCalls = function batchCalls(callback) {
    var _this2 = this;
    return function() {
      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }
      _this2.schedule(function() {
        callback.apply(void 0, args);
      });
    };
  };
  _proto.flush = function flush() {
    var _this3 = this;
    var queue = this.queue;
    this.queue = [];
    if (queue.length) {
      scheduleMicrotask(function() {
        _this3.batchNotifyFn(function() {
          queue.forEach(function(callback) {
            _this3.notifyFn(callback);
          });
        });
      });
    }
  };
  _proto.setNotifyFunction = function setNotifyFunction(fn2) {
    this.notifyFn = fn2;
  };
  _proto.setBatchNotifyFunction = function setBatchNotifyFunction(fn2) {
    this.batchNotifyFn = fn2;
  };
  return NotifyManager2;
}();
var notifyManager = new NotifyManager();
var logger$1 = console;
function getLogger() {
  return logger$1;
}
function setLogger(newLogger) {
  logger$1 = newLogger;
}
var Query = /* @__PURE__ */ function() {
  function Query2(config) {
    this.abortSignalConsumed = false;
    this.hadObservers = false;
    this.defaultOptions = config.defaultOptions;
    this.setOptions(config.options);
    this.observers = [];
    this.cache = config.cache;
    this.queryKey = config.queryKey;
    this.queryHash = config.queryHash;
    this.initialState = config.state || this.getDefaultState(this.options);
    this.state = this.initialState;
    this.meta = config.meta;
    this.scheduleGc();
  }
  var _proto = Query2.prototype;
  _proto.setOptions = function setOptions(options) {
    var _this$options$cacheTi;
    this.options = _extends$8({}, this.defaultOptions, options);
    this.meta = options == null ? void 0 : options.meta;
    this.cacheTime = Math.max(this.cacheTime || 0, (_this$options$cacheTi = this.options.cacheTime) != null ? _this$options$cacheTi : 5 * 60 * 1e3);
  };
  _proto.setDefaultOptions = function setDefaultOptions(options) {
    this.defaultOptions = options;
  };
  _proto.scheduleGc = function scheduleGc() {
    var _this = this;
    this.clearGcTimeout();
    if (isValidTimeout(this.cacheTime)) {
      this.gcTimeout = setTimeout(function() {
        _this.optionalRemove();
      }, this.cacheTime);
    }
  };
  _proto.clearGcTimeout = function clearGcTimeout() {
    if (this.gcTimeout) {
      clearTimeout(this.gcTimeout);
      this.gcTimeout = void 0;
    }
  };
  _proto.optionalRemove = function optionalRemove() {
    if (!this.observers.length) {
      if (this.state.isFetching) {
        if (this.hadObservers) {
          this.scheduleGc();
        }
      } else {
        this.cache.remove(this);
      }
    }
  };
  _proto.setData = function setData(updater, options) {
    var _this$options$isDataE, _this$options;
    var prevData = this.state.data;
    var data = functionalUpdate(updater, prevData);
    if ((_this$options$isDataE = (_this$options = this.options).isDataEqual) == null ? void 0 : _this$options$isDataE.call(_this$options, prevData, data)) {
      data = prevData;
    } else if (this.options.structuralSharing !== false) {
      data = replaceEqualDeep(prevData, data);
    }
    this.dispatch({
      data,
      type: "success",
      dataUpdatedAt: options == null ? void 0 : options.updatedAt
    });
    return data;
  };
  _proto.setState = function setState(state, setStateOptions) {
    this.dispatch({
      type: "setState",
      state,
      setStateOptions
    });
  };
  _proto.cancel = function cancel(options) {
    var _this$retryer;
    var promise = this.promise;
    (_this$retryer = this.retryer) == null ? void 0 : _this$retryer.cancel(options);
    return promise ? promise.then(noop$2).catch(noop$2) : Promise.resolve();
  };
  _proto.destroy = function destroy() {
    this.clearGcTimeout();
    this.cancel({
      silent: true
    });
  };
  _proto.reset = function reset() {
    this.destroy();
    this.setState(this.initialState);
  };
  _proto.isActive = function isActive() {
    return this.observers.some(function(observer) {
      return observer.options.enabled !== false;
    });
  };
  _proto.isFetching = function isFetching() {
    return this.state.isFetching;
  };
  _proto.isStale = function isStale2() {
    return this.state.isInvalidated || !this.state.dataUpdatedAt || this.observers.some(function(observer) {
      return observer.getCurrentResult().isStale;
    });
  };
  _proto.isStaleByTime = function isStaleByTime(staleTime) {
    if (staleTime === void 0) {
      staleTime = 0;
    }
    return this.state.isInvalidated || !this.state.dataUpdatedAt || !timeUntilStale(this.state.dataUpdatedAt, staleTime);
  };
  _proto.onFocus = function onFocus() {
    var _this$retryer2;
    var observer = this.observers.find(function(x) {
      return x.shouldFetchOnWindowFocus();
    });
    if (observer) {
      observer.refetch();
    }
    (_this$retryer2 = this.retryer) == null ? void 0 : _this$retryer2.continue();
  };
  _proto.onOnline = function onOnline() {
    var _this$retryer3;
    var observer = this.observers.find(function(x) {
      return x.shouldFetchOnReconnect();
    });
    if (observer) {
      observer.refetch();
    }
    (_this$retryer3 = this.retryer) == null ? void 0 : _this$retryer3.continue();
  };
  _proto.addObserver = function addObserver(observer) {
    if (this.observers.indexOf(observer) === -1) {
      this.observers.push(observer);
      this.hadObservers = true;
      this.clearGcTimeout();
      this.cache.notify({
        type: "observerAdded",
        query: this,
        observer
      });
    }
  };
  _proto.removeObserver = function removeObserver(observer) {
    if (this.observers.indexOf(observer) !== -1) {
      this.observers = this.observers.filter(function(x) {
        return x !== observer;
      });
      if (!this.observers.length) {
        if (this.retryer) {
          if (this.retryer.isTransportCancelable || this.abortSignalConsumed) {
            this.retryer.cancel({
              revert: true
            });
          } else {
            this.retryer.cancelRetry();
          }
        }
        if (this.cacheTime) {
          this.scheduleGc();
        } else {
          this.cache.remove(this);
        }
      }
      this.cache.notify({
        type: "observerRemoved",
        query: this,
        observer
      });
    }
  };
  _proto.getObserversCount = function getObserversCount() {
    return this.observers.length;
  };
  _proto.invalidate = function invalidate() {
    if (!this.state.isInvalidated) {
      this.dispatch({
        type: "invalidate"
      });
    }
  };
  _proto.fetch = function fetch2(options, fetchOptions) {
    var _this2 = this, _this$options$behavio, _context$fetchOptions, _abortController$abor;
    if (this.state.isFetching) {
      if (this.state.dataUpdatedAt && (fetchOptions == null ? void 0 : fetchOptions.cancelRefetch)) {
        this.cancel({
          silent: true
        });
      } else if (this.promise) {
        var _this$retryer4;
        (_this$retryer4 = this.retryer) == null ? void 0 : _this$retryer4.continueRetry();
        return this.promise;
      }
    }
    if (options) {
      this.setOptions(options);
    }
    if (!this.options.queryFn) {
      var observer = this.observers.find(function(x) {
        return x.options.queryFn;
      });
      if (observer) {
        this.setOptions(observer.options);
      }
    }
    var queryKey = ensureQueryKeyArray(this.queryKey);
    var abortController = getAbortController();
    var queryFnContext = {
      queryKey,
      pageParam: void 0,
      meta: this.meta
    };
    Object.defineProperty(queryFnContext, "signal", {
      enumerable: true,
      get: function get2() {
        if (abortController) {
          _this2.abortSignalConsumed = true;
          return abortController.signal;
        }
        return void 0;
      }
    });
    var fetchFn = function fetchFn2() {
      if (!_this2.options.queryFn) {
        return Promise.reject("Missing queryFn");
      }
      _this2.abortSignalConsumed = false;
      return _this2.options.queryFn(queryFnContext);
    };
    var context = {
      fetchOptions,
      options: this.options,
      queryKey,
      state: this.state,
      fetchFn,
      meta: this.meta
    };
    if ((_this$options$behavio = this.options.behavior) == null ? void 0 : _this$options$behavio.onFetch) {
      var _this$options$behavio2;
      (_this$options$behavio2 = this.options.behavior) == null ? void 0 : _this$options$behavio2.onFetch(context);
    }
    this.revertState = this.state;
    if (!this.state.isFetching || this.state.fetchMeta !== ((_context$fetchOptions = context.fetchOptions) == null ? void 0 : _context$fetchOptions.meta)) {
      var _context$fetchOptions2;
      this.dispatch({
        type: "fetch",
        meta: (_context$fetchOptions2 = context.fetchOptions) == null ? void 0 : _context$fetchOptions2.meta
      });
    }
    this.retryer = new Retryer({
      fn: context.fetchFn,
      abort: abortController == null ? void 0 : (_abortController$abor = abortController.abort) == null ? void 0 : _abortController$abor.bind(abortController),
      onSuccess: function onSuccess(data) {
        _this2.setData(data);
        _this2.cache.config.onSuccess == null ? void 0 : _this2.cache.config.onSuccess(data, _this2);
        if (_this2.cacheTime === 0) {
          _this2.optionalRemove();
        }
      },
      onError: function onError(error2) {
        if (!(isCancelledError(error2) && error2.silent)) {
          _this2.dispatch({
            type: "error",
            error: error2
          });
        }
        if (!isCancelledError(error2)) {
          _this2.cache.config.onError == null ? void 0 : _this2.cache.config.onError(error2, _this2);
          getLogger().error(error2);
        }
        if (_this2.cacheTime === 0) {
          _this2.optionalRemove();
        }
      },
      onFail: function onFail() {
        _this2.dispatch({
          type: "failed"
        });
      },
      onPause: function onPause() {
        _this2.dispatch({
          type: "pause"
        });
      },
      onContinue: function onContinue() {
        _this2.dispatch({
          type: "continue"
        });
      },
      retry: context.options.retry,
      retryDelay: context.options.retryDelay
    });
    this.promise = this.retryer.promise;
    return this.promise;
  };
  _proto.dispatch = function dispatch(action) {
    var _this3 = this;
    this.state = this.reducer(this.state, action);
    notifyManager.batch(function() {
      _this3.observers.forEach(function(observer) {
        observer.onQueryUpdate(action);
      });
      _this3.cache.notify({
        query: _this3,
        type: "queryUpdated",
        action
      });
    });
  };
  _proto.getDefaultState = function getDefaultState2(options) {
    var data = typeof options.initialData === "function" ? options.initialData() : options.initialData;
    var hasInitialData = typeof options.initialData !== "undefined";
    var initialDataUpdatedAt = hasInitialData ? typeof options.initialDataUpdatedAt === "function" ? options.initialDataUpdatedAt() : options.initialDataUpdatedAt : 0;
    var hasData = typeof data !== "undefined";
    return {
      data,
      dataUpdateCount: 0,
      dataUpdatedAt: hasData ? initialDataUpdatedAt != null ? initialDataUpdatedAt : Date.now() : 0,
      error: null,
      errorUpdateCount: 0,
      errorUpdatedAt: 0,
      fetchFailureCount: 0,
      fetchMeta: null,
      isFetching: false,
      isInvalidated: false,
      isPaused: false,
      status: hasData ? "success" : "idle"
    };
  };
  _proto.reducer = function reducer2(state, action) {
    var _action$meta, _action$dataUpdatedAt;
    switch (action.type) {
      case "failed":
        return _extends$8({}, state, {
          fetchFailureCount: state.fetchFailureCount + 1
        });
      case "pause":
        return _extends$8({}, state, {
          isPaused: true
        });
      case "continue":
        return _extends$8({}, state, {
          isPaused: false
        });
      case "fetch":
        return _extends$8({}, state, {
          fetchFailureCount: 0,
          fetchMeta: (_action$meta = action.meta) != null ? _action$meta : null,
          isFetching: true,
          isPaused: false
        }, !state.dataUpdatedAt && {
          error: null,
          status: "loading"
        });
      case "success":
        return _extends$8({}, state, {
          data: action.data,
          dataUpdateCount: state.dataUpdateCount + 1,
          dataUpdatedAt: (_action$dataUpdatedAt = action.dataUpdatedAt) != null ? _action$dataUpdatedAt : Date.now(),
          error: null,
          fetchFailureCount: 0,
          isFetching: false,
          isInvalidated: false,
          isPaused: false,
          status: "success"
        });
      case "error":
        var error2 = action.error;
        if (isCancelledError(error2) && error2.revert && this.revertState) {
          return _extends$8({}, this.revertState);
        }
        return _extends$8({}, state, {
          error: error2,
          errorUpdateCount: state.errorUpdateCount + 1,
          errorUpdatedAt: Date.now(),
          fetchFailureCount: state.fetchFailureCount + 1,
          isFetching: false,
          isPaused: false,
          status: "error"
        });
      case "invalidate":
        return _extends$8({}, state, {
          isInvalidated: true
        });
      case "setState":
        return _extends$8({}, state, action.state);
      default:
        return state;
    }
  };
  return Query2;
}();
var QueryCache = /* @__PURE__ */ function(_Subscribable) {
  _inheritsLoose(QueryCache2, _Subscribable);
  function QueryCache2(config) {
    var _this;
    _this = _Subscribable.call(this) || this;
    _this.config = config || {};
    _this.queries = [];
    _this.queriesMap = {};
    return _this;
  }
  var _proto = QueryCache2.prototype;
  _proto.build = function build(client, options, state) {
    var _options$queryHash;
    var queryKey = options.queryKey;
    var queryHash = (_options$queryHash = options.queryHash) != null ? _options$queryHash : hashQueryKeyByOptions(queryKey, options);
    var query2 = this.get(queryHash);
    if (!query2) {
      query2 = new Query({
        cache: this,
        queryKey,
        queryHash,
        options: client.defaultQueryOptions(options),
        state,
        defaultOptions: client.getQueryDefaults(queryKey),
        meta: options.meta
      });
      this.add(query2);
    }
    return query2;
  };
  _proto.add = function add(query2) {
    if (!this.queriesMap[query2.queryHash]) {
      this.queriesMap[query2.queryHash] = query2;
      this.queries.push(query2);
      this.notify({
        type: "queryAdded",
        query: query2
      });
    }
  };
  _proto.remove = function remove2(query2) {
    var queryInMap = this.queriesMap[query2.queryHash];
    if (queryInMap) {
      query2.destroy();
      this.queries = this.queries.filter(function(x) {
        return x !== query2;
      });
      if (queryInMap === query2) {
        delete this.queriesMap[query2.queryHash];
      }
      this.notify({
        type: "queryRemoved",
        query: query2
      });
    }
  };
  _proto.clear = function clear() {
    var _this2 = this;
    notifyManager.batch(function() {
      _this2.queries.forEach(function(query2) {
        _this2.remove(query2);
      });
    });
  };
  _proto.get = function get2(queryHash) {
    return this.queriesMap[queryHash];
  };
  _proto.getAll = function getAll() {
    return this.queries;
  };
  _proto.find = function find(arg1, arg2) {
    var _parseFilterArgs = parseFilterArgs(arg1, arg2), filters = _parseFilterArgs[0];
    if (typeof filters.exact === "undefined") {
      filters.exact = true;
    }
    return this.queries.find(function(query2) {
      return matchQuery(filters, query2);
    });
  };
  _proto.findAll = function findAll(arg1, arg2) {
    var _parseFilterArgs2 = parseFilterArgs(arg1, arg2), filters = _parseFilterArgs2[0];
    return Object.keys(filters).length > 0 ? this.queries.filter(function(query2) {
      return matchQuery(filters, query2);
    }) : this.queries;
  };
  _proto.notify = function notify(event) {
    var _this3 = this;
    notifyManager.batch(function() {
      _this3.listeners.forEach(function(listener) {
        listener(event);
      });
    });
  };
  _proto.onFocus = function onFocus() {
    var _this4 = this;
    notifyManager.batch(function() {
      _this4.queries.forEach(function(query2) {
        query2.onFocus();
      });
    });
  };
  _proto.onOnline = function onOnline() {
    var _this5 = this;
    notifyManager.batch(function() {
      _this5.queries.forEach(function(query2) {
        query2.onOnline();
      });
    });
  };
  return QueryCache2;
}(Subscribable);
var Mutation = /* @__PURE__ */ function() {
  function Mutation2(config) {
    this.options = _extends$8({}, config.defaultOptions, config.options);
    this.mutationId = config.mutationId;
    this.mutationCache = config.mutationCache;
    this.observers = [];
    this.state = config.state || getDefaultState();
    this.meta = config.meta;
  }
  var _proto = Mutation2.prototype;
  _proto.setState = function setState(state) {
    this.dispatch({
      type: "setState",
      state
    });
  };
  _proto.addObserver = function addObserver(observer) {
    if (this.observers.indexOf(observer) === -1) {
      this.observers.push(observer);
    }
  };
  _proto.removeObserver = function removeObserver(observer) {
    this.observers = this.observers.filter(function(x) {
      return x !== observer;
    });
  };
  _proto.cancel = function cancel() {
    if (this.retryer) {
      this.retryer.cancel();
      return this.retryer.promise.then(noop$2).catch(noop$2);
    }
    return Promise.resolve();
  };
  _proto.continue = function _continue() {
    if (this.retryer) {
      this.retryer.continue();
      return this.retryer.promise;
    }
    return this.execute();
  };
  _proto.execute = function execute() {
    var _this = this;
    var data;
    var restored = this.state.status === "loading";
    var promise = Promise.resolve();
    if (!restored) {
      this.dispatch({
        type: "loading",
        variables: this.options.variables
      });
      promise = promise.then(function() {
        _this.mutationCache.config.onMutate == null ? void 0 : _this.mutationCache.config.onMutate(_this.state.variables, _this);
      }).then(function() {
        return _this.options.onMutate == null ? void 0 : _this.options.onMutate(_this.state.variables);
      }).then(function(context) {
        if (context !== _this.state.context) {
          _this.dispatch({
            type: "loading",
            context,
            variables: _this.state.variables
          });
        }
      });
    }
    return promise.then(function() {
      return _this.executeMutation();
    }).then(function(result) {
      data = result;
      _this.mutationCache.config.onSuccess == null ? void 0 : _this.mutationCache.config.onSuccess(data, _this.state.variables, _this.state.context, _this);
    }).then(function() {
      return _this.options.onSuccess == null ? void 0 : _this.options.onSuccess(data, _this.state.variables, _this.state.context);
    }).then(function() {
      return _this.options.onSettled == null ? void 0 : _this.options.onSettled(data, null, _this.state.variables, _this.state.context);
    }).then(function() {
      _this.dispatch({
        type: "success",
        data
      });
      return data;
    }).catch(function(error2) {
      _this.mutationCache.config.onError == null ? void 0 : _this.mutationCache.config.onError(error2, _this.state.variables, _this.state.context, _this);
      getLogger().error(error2);
      return Promise.resolve().then(function() {
        return _this.options.onError == null ? void 0 : _this.options.onError(error2, _this.state.variables, _this.state.context);
      }).then(function() {
        return _this.options.onSettled == null ? void 0 : _this.options.onSettled(void 0, error2, _this.state.variables, _this.state.context);
      }).then(function() {
        _this.dispatch({
          type: "error",
          error: error2
        });
        throw error2;
      });
    });
  };
  _proto.executeMutation = function executeMutation() {
    var _this2 = this, _this$options$retry;
    this.retryer = new Retryer({
      fn: function fn2() {
        if (!_this2.options.mutationFn) {
          return Promise.reject("No mutationFn found");
        }
        return _this2.options.mutationFn(_this2.state.variables);
      },
      onFail: function onFail() {
        _this2.dispatch({
          type: "failed"
        });
      },
      onPause: function onPause() {
        _this2.dispatch({
          type: "pause"
        });
      },
      onContinue: function onContinue() {
        _this2.dispatch({
          type: "continue"
        });
      },
      retry: (_this$options$retry = this.options.retry) != null ? _this$options$retry : 0,
      retryDelay: this.options.retryDelay
    });
    return this.retryer.promise;
  };
  _proto.dispatch = function dispatch(action) {
    var _this3 = this;
    this.state = reducer(this.state, action);
    notifyManager.batch(function() {
      _this3.observers.forEach(function(observer) {
        observer.onMutationUpdate(action);
      });
      _this3.mutationCache.notify(_this3);
    });
  };
  return Mutation2;
}();
function getDefaultState() {
  return {
    context: void 0,
    data: void 0,
    error: null,
    failureCount: 0,
    isPaused: false,
    status: "idle",
    variables: void 0
  };
}
function reducer(state, action) {
  switch (action.type) {
    case "failed":
      return _extends$8({}, state, {
        failureCount: state.failureCount + 1
      });
    case "pause":
      return _extends$8({}, state, {
        isPaused: true
      });
    case "continue":
      return _extends$8({}, state, {
        isPaused: false
      });
    case "loading":
      return _extends$8({}, state, {
        context: action.context,
        data: void 0,
        error: null,
        isPaused: false,
        status: "loading",
        variables: action.variables
      });
    case "success":
      return _extends$8({}, state, {
        data: action.data,
        error: null,
        status: "success",
        isPaused: false
      });
    case "error":
      return _extends$8({}, state, {
        data: void 0,
        error: action.error,
        failureCount: state.failureCount + 1,
        isPaused: false,
        status: "error"
      });
    case "setState":
      return _extends$8({}, state, action.state);
    default:
      return state;
  }
}
var MutationCache = /* @__PURE__ */ function(_Subscribable) {
  _inheritsLoose(MutationCache2, _Subscribable);
  function MutationCache2(config) {
    var _this;
    _this = _Subscribable.call(this) || this;
    _this.config = config || {};
    _this.mutations = [];
    _this.mutationId = 0;
    return _this;
  }
  var _proto = MutationCache2.prototype;
  _proto.build = function build(client, options, state) {
    var mutation = new Mutation({
      mutationCache: this,
      mutationId: ++this.mutationId,
      options: client.defaultMutationOptions(options),
      state,
      defaultOptions: options.mutationKey ? client.getMutationDefaults(options.mutationKey) : void 0,
      meta: options.meta
    });
    this.add(mutation);
    return mutation;
  };
  _proto.add = function add(mutation) {
    this.mutations.push(mutation);
    this.notify(mutation);
  };
  _proto.remove = function remove2(mutation) {
    this.mutations = this.mutations.filter(function(x) {
      return x !== mutation;
    });
    mutation.cancel();
    this.notify(mutation);
  };
  _proto.clear = function clear() {
    var _this2 = this;
    notifyManager.batch(function() {
      _this2.mutations.forEach(function(mutation) {
        _this2.remove(mutation);
      });
    });
  };
  _proto.getAll = function getAll() {
    return this.mutations;
  };
  _proto.find = function find(filters) {
    if (typeof filters.exact === "undefined") {
      filters.exact = true;
    }
    return this.mutations.find(function(mutation) {
      return matchMutation(filters, mutation);
    });
  };
  _proto.findAll = function findAll(filters) {
    return this.mutations.filter(function(mutation) {
      return matchMutation(filters, mutation);
    });
  };
  _proto.notify = function notify(mutation) {
    var _this3 = this;
    notifyManager.batch(function() {
      _this3.listeners.forEach(function(listener) {
        listener(mutation);
      });
    });
  };
  _proto.onFocus = function onFocus() {
    this.resumePausedMutations();
  };
  _proto.onOnline = function onOnline() {
    this.resumePausedMutations();
  };
  _proto.resumePausedMutations = function resumePausedMutations() {
    var pausedMutations = this.mutations.filter(function(x) {
      return x.state.isPaused;
    });
    return notifyManager.batch(function() {
      return pausedMutations.reduce(function(promise, mutation) {
        return promise.then(function() {
          return mutation.continue().catch(noop$2);
        });
      }, Promise.resolve());
    });
  };
  return MutationCache2;
}(Subscribable);
function infiniteQueryBehavior() {
  return {
    onFetch: function onFetch(context) {
      context.fetchFn = function() {
        var _context$fetchOptions, _context$fetchOptions2, _context$fetchOptions3, _context$fetchOptions4, _context$state$data, _context$state$data2;
        var refetchPage = (_context$fetchOptions = context.fetchOptions) == null ? void 0 : (_context$fetchOptions2 = _context$fetchOptions.meta) == null ? void 0 : _context$fetchOptions2.refetchPage;
        var fetchMore = (_context$fetchOptions3 = context.fetchOptions) == null ? void 0 : (_context$fetchOptions4 = _context$fetchOptions3.meta) == null ? void 0 : _context$fetchOptions4.fetchMore;
        var pageParam = fetchMore == null ? void 0 : fetchMore.pageParam;
        var isFetchingNextPage = (fetchMore == null ? void 0 : fetchMore.direction) === "forward";
        var isFetchingPreviousPage = (fetchMore == null ? void 0 : fetchMore.direction) === "backward";
        var oldPages = ((_context$state$data = context.state.data) == null ? void 0 : _context$state$data.pages) || [];
        var oldPageParams = ((_context$state$data2 = context.state.data) == null ? void 0 : _context$state$data2.pageParams) || [];
        var abortController = getAbortController();
        var abortSignal = abortController == null ? void 0 : abortController.signal;
        var newPageParams = oldPageParams;
        var cancelled = false;
        var queryFn = context.options.queryFn || function() {
          return Promise.reject("Missing queryFn");
        };
        var buildNewPages = function buildNewPages2(pages, param2, page, previous) {
          newPageParams = previous ? [param2].concat(newPageParams) : [].concat(newPageParams, [param2]);
          return previous ? [page].concat(pages) : [].concat(pages, [page]);
        };
        var fetchPage = function fetchPage2(pages, manual2, param2, previous) {
          if (cancelled) {
            return Promise.reject("Cancelled");
          }
          if (typeof param2 === "undefined" && !manual2 && pages.length) {
            return Promise.resolve(pages);
          }
          var queryFnContext = {
            queryKey: context.queryKey,
            signal: abortSignal,
            pageParam: param2,
            meta: context.meta
          };
          var queryFnResult = queryFn(queryFnContext);
          var promise2 = Promise.resolve(queryFnResult).then(function(page) {
            return buildNewPages(pages, param2, page, previous);
          });
          if (isCancelable(queryFnResult)) {
            var promiseAsAny = promise2;
            promiseAsAny.cancel = queryFnResult.cancel;
          }
          return promise2;
        };
        var promise;
        if (!oldPages.length) {
          promise = fetchPage([]);
        } else if (isFetchingNextPage) {
          var manual = typeof pageParam !== "undefined";
          var param = manual ? pageParam : getNextPageParam(context.options, oldPages);
          promise = fetchPage(oldPages, manual, param);
        } else if (isFetchingPreviousPage) {
          var _manual = typeof pageParam !== "undefined";
          var _param = _manual ? pageParam : getPreviousPageParam(context.options, oldPages);
          promise = fetchPage(oldPages, _manual, _param, true);
        } else {
          (function() {
            newPageParams = [];
            var manual2 = typeof context.options.getNextPageParam === "undefined";
            var shouldFetchFirstPage = refetchPage && oldPages[0] ? refetchPage(oldPages[0], 0, oldPages) : true;
            promise = shouldFetchFirstPage ? fetchPage([], manual2, oldPageParams[0]) : Promise.resolve(buildNewPages([], oldPageParams[0], oldPages[0]));
            var _loop = function _loop2(i2) {
              promise = promise.then(function(pages) {
                var shouldFetchNextPage = refetchPage && oldPages[i2] ? refetchPage(oldPages[i2], i2, oldPages) : true;
                if (shouldFetchNextPage) {
                  var _param2 = manual2 ? oldPageParams[i2] : getNextPageParam(context.options, pages);
                  return fetchPage(pages, manual2, _param2);
                }
                return Promise.resolve(buildNewPages(pages, oldPageParams[i2], oldPages[i2]));
              });
            };
            for (var i = 1; i < oldPages.length; i++) {
              _loop(i);
            }
          })();
        }
        var finalPromise = promise.then(function(pages) {
          return {
            pages,
            pageParams: newPageParams
          };
        });
        var finalPromiseAsAny = finalPromise;
        finalPromiseAsAny.cancel = function() {
          cancelled = true;
          abortController == null ? void 0 : abortController.abort();
          if (isCancelable(promise)) {
            promise.cancel();
          }
        };
        return finalPromise;
      };
    }
  };
}
function getNextPageParam(options, pages) {
  return options.getNextPageParam == null ? void 0 : options.getNextPageParam(pages[pages.length - 1], pages);
}
function getPreviousPageParam(options, pages) {
  return options.getPreviousPageParam == null ? void 0 : options.getPreviousPageParam(pages[0], pages);
}
var QueryClient = /* @__PURE__ */ function() {
  function QueryClient2(config) {
    if (config === void 0) {
      config = {};
    }
    this.queryCache = config.queryCache || new QueryCache();
    this.mutationCache = config.mutationCache || new MutationCache();
    this.defaultOptions = config.defaultOptions || {};
    this.queryDefaults = [];
    this.mutationDefaults = [];
  }
  var _proto = QueryClient2.prototype;
  _proto.mount = function mount() {
    var _this = this;
    this.unsubscribeFocus = focusManager.subscribe(function() {
      if (focusManager.isFocused() && onlineManager.isOnline()) {
        _this.mutationCache.onFocus();
        _this.queryCache.onFocus();
      }
    });
    this.unsubscribeOnline = onlineManager.subscribe(function() {
      if (focusManager.isFocused() && onlineManager.isOnline()) {
        _this.mutationCache.onOnline();
        _this.queryCache.onOnline();
      }
    });
  };
  _proto.unmount = function unmount() {
    var _this$unsubscribeFocu, _this$unsubscribeOnli;
    (_this$unsubscribeFocu = this.unsubscribeFocus) == null ? void 0 : _this$unsubscribeFocu.call(this);
    (_this$unsubscribeOnli = this.unsubscribeOnline) == null ? void 0 : _this$unsubscribeOnli.call(this);
  };
  _proto.isFetching = function isFetching(arg1, arg2) {
    var _parseFilterArgs = parseFilterArgs(arg1, arg2), filters = _parseFilterArgs[0];
    filters.fetching = true;
    return this.queryCache.findAll(filters).length;
  };
  _proto.isMutating = function isMutating(filters) {
    return this.mutationCache.findAll(_extends$8({}, filters, {
      fetching: true
    })).length;
  };
  _proto.getQueryData = function getQueryData(queryKey, filters) {
    var _this$queryCache$find;
    return (_this$queryCache$find = this.queryCache.find(queryKey, filters)) == null ? void 0 : _this$queryCache$find.state.data;
  };
  _proto.getQueriesData = function getQueriesData(queryKeyOrFilters) {
    return this.getQueryCache().findAll(queryKeyOrFilters).map(function(_ref) {
      var queryKey = _ref.queryKey, state = _ref.state;
      var data = state.data;
      return [queryKey, data];
    });
  };
  _proto.setQueryData = function setQueryData(queryKey, updater, options) {
    var parsedOptions = parseQueryArgs(queryKey);
    var defaultedOptions = this.defaultQueryOptions(parsedOptions);
    return this.queryCache.build(this, defaultedOptions).setData(updater, options);
  };
  _proto.setQueriesData = function setQueriesData(queryKeyOrFilters, updater, options) {
    var _this2 = this;
    return notifyManager.batch(function() {
      return _this2.getQueryCache().findAll(queryKeyOrFilters).map(function(_ref2) {
        var queryKey = _ref2.queryKey;
        return [queryKey, _this2.setQueryData(queryKey, updater, options)];
      });
    });
  };
  _proto.getQueryState = function getQueryState(queryKey, filters) {
    var _this$queryCache$find2;
    return (_this$queryCache$find2 = this.queryCache.find(queryKey, filters)) == null ? void 0 : _this$queryCache$find2.state;
  };
  _proto.removeQueries = function removeQueries(arg1, arg2) {
    var _parseFilterArgs2 = parseFilterArgs(arg1, arg2), filters = _parseFilterArgs2[0];
    var queryCache = this.queryCache;
    notifyManager.batch(function() {
      queryCache.findAll(filters).forEach(function(query2) {
        queryCache.remove(query2);
      });
    });
  };
  _proto.resetQueries = function resetQueries(arg1, arg2, arg3) {
    var _this3 = this;
    var _parseFilterArgs3 = parseFilterArgs(arg1, arg2, arg3), filters = _parseFilterArgs3[0], options = _parseFilterArgs3[1];
    var queryCache = this.queryCache;
    var refetchFilters = _extends$8({}, filters, {
      active: true
    });
    return notifyManager.batch(function() {
      queryCache.findAll(filters).forEach(function(query2) {
        query2.reset();
      });
      return _this3.refetchQueries(refetchFilters, options);
    });
  };
  _proto.cancelQueries = function cancelQueries(arg1, arg2, arg3) {
    var _this4 = this;
    var _parseFilterArgs4 = parseFilterArgs(arg1, arg2, arg3), filters = _parseFilterArgs4[0], _parseFilterArgs4$ = _parseFilterArgs4[1], cancelOptions = _parseFilterArgs4$ === void 0 ? {} : _parseFilterArgs4$;
    if (typeof cancelOptions.revert === "undefined") {
      cancelOptions.revert = true;
    }
    var promises = notifyManager.batch(function() {
      return _this4.queryCache.findAll(filters).map(function(query2) {
        return query2.cancel(cancelOptions);
      });
    });
    return Promise.all(promises).then(noop$2).catch(noop$2);
  };
  _proto.invalidateQueries = function invalidateQueries(arg1, arg2, arg3) {
    var _ref3, _filters$refetchActiv, _filters$refetchInact, _this5 = this;
    var _parseFilterArgs5 = parseFilterArgs(arg1, arg2, arg3), filters = _parseFilterArgs5[0], options = _parseFilterArgs5[1];
    var refetchFilters = _extends$8({}, filters, {
      // if filters.refetchActive is not provided and filters.active is explicitly false,
      // e.g. invalidateQueries({ active: false }), we don't want to refetch active queries
      active: (_ref3 = (_filters$refetchActiv = filters.refetchActive) != null ? _filters$refetchActiv : filters.active) != null ? _ref3 : true,
      inactive: (_filters$refetchInact = filters.refetchInactive) != null ? _filters$refetchInact : false
    });
    return notifyManager.batch(function() {
      _this5.queryCache.findAll(filters).forEach(function(query2) {
        query2.invalidate();
      });
      return _this5.refetchQueries(refetchFilters, options);
    });
  };
  _proto.refetchQueries = function refetchQueries(arg1, arg2, arg3) {
    var _this6 = this;
    var _parseFilterArgs6 = parseFilterArgs(arg1, arg2, arg3), filters = _parseFilterArgs6[0], options = _parseFilterArgs6[1];
    var promises = notifyManager.batch(function() {
      return _this6.queryCache.findAll(filters).map(function(query2) {
        return query2.fetch(void 0, _extends$8({}, options, {
          meta: {
            refetchPage: filters == null ? void 0 : filters.refetchPage
          }
        }));
      });
    });
    var promise = Promise.all(promises).then(noop$2);
    if (!(options == null ? void 0 : options.throwOnError)) {
      promise = promise.catch(noop$2);
    }
    return promise;
  };
  _proto.fetchQuery = function fetchQuery(arg1, arg2, arg3) {
    var parsedOptions = parseQueryArgs(arg1, arg2, arg3);
    var defaultedOptions = this.defaultQueryOptions(parsedOptions);
    if (typeof defaultedOptions.retry === "undefined") {
      defaultedOptions.retry = false;
    }
    var query2 = this.queryCache.build(this, defaultedOptions);
    return query2.isStaleByTime(defaultedOptions.staleTime) ? query2.fetch(defaultedOptions) : Promise.resolve(query2.state.data);
  };
  _proto.prefetchQuery = function prefetchQuery(arg1, arg2, arg3) {
    return this.fetchQuery(arg1, arg2, arg3).then(noop$2).catch(noop$2);
  };
  _proto.fetchInfiniteQuery = function fetchInfiniteQuery(arg1, arg2, arg3) {
    var parsedOptions = parseQueryArgs(arg1, arg2, arg3);
    parsedOptions.behavior = infiniteQueryBehavior();
    return this.fetchQuery(parsedOptions);
  };
  _proto.prefetchInfiniteQuery = function prefetchInfiniteQuery(arg1, arg2, arg3) {
    return this.fetchInfiniteQuery(arg1, arg2, arg3).then(noop$2).catch(noop$2);
  };
  _proto.cancelMutations = function cancelMutations() {
    var _this7 = this;
    var promises = notifyManager.batch(function() {
      return _this7.mutationCache.getAll().map(function(mutation) {
        return mutation.cancel();
      });
    });
    return Promise.all(promises).then(noop$2).catch(noop$2);
  };
  _proto.resumePausedMutations = function resumePausedMutations() {
    return this.getMutationCache().resumePausedMutations();
  };
  _proto.executeMutation = function executeMutation(options) {
    return this.mutationCache.build(this, options).execute();
  };
  _proto.getQueryCache = function getQueryCache() {
    return this.queryCache;
  };
  _proto.getMutationCache = function getMutationCache() {
    return this.mutationCache;
  };
  _proto.getDefaultOptions = function getDefaultOptions() {
    return this.defaultOptions;
  };
  _proto.setDefaultOptions = function setDefaultOptions(options) {
    this.defaultOptions = options;
  };
  _proto.setQueryDefaults = function setQueryDefaults(queryKey, options) {
    var result = this.queryDefaults.find(function(x) {
      return hashQueryKey(queryKey) === hashQueryKey(x.queryKey);
    });
    if (result) {
      result.defaultOptions = options;
    } else {
      this.queryDefaults.push({
        queryKey,
        defaultOptions: options
      });
    }
  };
  _proto.getQueryDefaults = function getQueryDefaults(queryKey) {
    var _this$queryDefaults$f;
    return queryKey ? (_this$queryDefaults$f = this.queryDefaults.find(function(x) {
      return partialMatchKey(queryKey, x.queryKey);
    })) == null ? void 0 : _this$queryDefaults$f.defaultOptions : void 0;
  };
  _proto.setMutationDefaults = function setMutationDefaults(mutationKey, options) {
    var result = this.mutationDefaults.find(function(x) {
      return hashQueryKey(mutationKey) === hashQueryKey(x.mutationKey);
    });
    if (result) {
      result.defaultOptions = options;
    } else {
      this.mutationDefaults.push({
        mutationKey,
        defaultOptions: options
      });
    }
  };
  _proto.getMutationDefaults = function getMutationDefaults(mutationKey) {
    var _this$mutationDefault;
    return mutationKey ? (_this$mutationDefault = this.mutationDefaults.find(function(x) {
      return partialMatchKey(mutationKey, x.mutationKey);
    })) == null ? void 0 : _this$mutationDefault.defaultOptions : void 0;
  };
  _proto.defaultQueryOptions = function defaultQueryOptions(options) {
    if (options == null ? void 0 : options._defaulted) {
      return options;
    }
    var defaultedOptions = _extends$8({}, this.defaultOptions.queries, this.getQueryDefaults(options == null ? void 0 : options.queryKey), options, {
      _defaulted: true
    });
    if (!defaultedOptions.queryHash && defaultedOptions.queryKey) {
      defaultedOptions.queryHash = hashQueryKeyByOptions(defaultedOptions.queryKey, defaultedOptions);
    }
    return defaultedOptions;
  };
  _proto.defaultQueryObserverOptions = function defaultQueryObserverOptions(options) {
    return this.defaultQueryOptions(options);
  };
  _proto.defaultMutationOptions = function defaultMutationOptions(options) {
    if (options == null ? void 0 : options._defaulted) {
      return options;
    }
    return _extends$8({}, this.defaultOptions.mutations, this.getMutationDefaults(options == null ? void 0 : options.mutationKey), options, {
      _defaulted: true
    });
  };
  _proto.clear = function clear() {
    this.queryCache.clear();
    this.mutationCache.clear();
  };
  return QueryClient2;
}();
var QueryObserver = /* @__PURE__ */ function(_Subscribable) {
  _inheritsLoose(QueryObserver2, _Subscribable);
  function QueryObserver2(client, options) {
    var _this;
    _this = _Subscribable.call(this) || this;
    _this.client = client;
    _this.options = options;
    _this.trackedProps = [];
    _this.selectError = null;
    _this.bindMethods();
    _this.setOptions(options);
    return _this;
  }
  var _proto = QueryObserver2.prototype;
  _proto.bindMethods = function bindMethods() {
    this.remove = this.remove.bind(this);
    this.refetch = this.refetch.bind(this);
  };
  _proto.onSubscribe = function onSubscribe() {
    if (this.listeners.length === 1) {
      this.currentQuery.addObserver(this);
      if (shouldFetchOnMount(this.currentQuery, this.options)) {
        this.executeFetch();
      }
      this.updateTimers();
    }
  };
  _proto.onUnsubscribe = function onUnsubscribe() {
    if (!this.listeners.length) {
      this.destroy();
    }
  };
  _proto.shouldFetchOnReconnect = function shouldFetchOnReconnect() {
    return shouldFetchOn(this.currentQuery, this.options, this.options.refetchOnReconnect);
  };
  _proto.shouldFetchOnWindowFocus = function shouldFetchOnWindowFocus() {
    return shouldFetchOn(this.currentQuery, this.options, this.options.refetchOnWindowFocus);
  };
  _proto.destroy = function destroy() {
    this.listeners = [];
    this.clearTimers();
    this.currentQuery.removeObserver(this);
  };
  _proto.setOptions = function setOptions(options, notifyOptions) {
    var prevOptions = this.options;
    var prevQuery = this.currentQuery;
    this.options = this.client.defaultQueryObserverOptions(options);
    if (typeof this.options.enabled !== "undefined" && typeof this.options.enabled !== "boolean") {
      throw new Error("Expected enabled to be a boolean");
    }
    if (!this.options.queryKey) {
      this.options.queryKey = prevOptions.queryKey;
    }
    this.updateQuery();
    var mounted = this.hasListeners();
    if (mounted && shouldFetchOptionally(this.currentQuery, prevQuery, this.options, prevOptions)) {
      this.executeFetch();
    }
    this.updateResult(notifyOptions);
    if (mounted && (this.currentQuery !== prevQuery || this.options.enabled !== prevOptions.enabled || this.options.staleTime !== prevOptions.staleTime)) {
      this.updateStaleTimeout();
    }
    var nextRefetchInterval = this.computeRefetchInterval();
    if (mounted && (this.currentQuery !== prevQuery || this.options.enabled !== prevOptions.enabled || nextRefetchInterval !== this.currentRefetchInterval)) {
      this.updateRefetchInterval(nextRefetchInterval);
    }
  };
  _proto.getOptimisticResult = function getOptimisticResult(options) {
    var defaultedOptions = this.client.defaultQueryObserverOptions(options);
    var query2 = this.client.getQueryCache().build(this.client, defaultedOptions);
    return this.createResult(query2, defaultedOptions);
  };
  _proto.getCurrentResult = function getCurrentResult() {
    return this.currentResult;
  };
  _proto.trackResult = function trackResult(result, defaultedOptions) {
    var _this2 = this;
    var trackedResult = {};
    var trackProp = function trackProp2(key) {
      if (!_this2.trackedProps.includes(key)) {
        _this2.trackedProps.push(key);
      }
    };
    Object.keys(result).forEach(function(key) {
      Object.defineProperty(trackedResult, key, {
        configurable: false,
        enumerable: true,
        get: function get2() {
          trackProp(key);
          return result[key];
        }
      });
    });
    if (defaultedOptions.useErrorBoundary || defaultedOptions.suspense) {
      trackProp("error");
    }
    return trackedResult;
  };
  _proto.getNextResult = function getNextResult(options) {
    var _this3 = this;
    return new Promise(function(resolve, reject) {
      var unsubscribe = _this3.subscribe(function(result) {
        if (!result.isFetching) {
          unsubscribe();
          if (result.isError && (options == null ? void 0 : options.throwOnError)) {
            reject(result.error);
          } else {
            resolve(result);
          }
        }
      });
    });
  };
  _proto.getCurrentQuery = function getCurrentQuery() {
    return this.currentQuery;
  };
  _proto.remove = function remove2() {
    this.client.getQueryCache().remove(this.currentQuery);
  };
  _proto.refetch = function refetch(options) {
    return this.fetch(_extends$8({}, options, {
      meta: {
        refetchPage: options == null ? void 0 : options.refetchPage
      }
    }));
  };
  _proto.fetchOptimistic = function fetchOptimistic(options) {
    var _this4 = this;
    var defaultedOptions = this.client.defaultQueryObserverOptions(options);
    var query2 = this.client.getQueryCache().build(this.client, defaultedOptions);
    return query2.fetch().then(function() {
      return _this4.createResult(query2, defaultedOptions);
    });
  };
  _proto.fetch = function fetch2(fetchOptions) {
    var _this5 = this;
    return this.executeFetch(fetchOptions).then(function() {
      _this5.updateResult();
      return _this5.currentResult;
    });
  };
  _proto.executeFetch = function executeFetch(fetchOptions) {
    this.updateQuery();
    var promise = this.currentQuery.fetch(this.options, fetchOptions);
    if (!(fetchOptions == null ? void 0 : fetchOptions.throwOnError)) {
      promise = promise.catch(noop$2);
    }
    return promise;
  };
  _proto.updateStaleTimeout = function updateStaleTimeout() {
    var _this6 = this;
    this.clearStaleTimeout();
    if (isServer || this.currentResult.isStale || !isValidTimeout(this.options.staleTime)) {
      return;
    }
    var time = timeUntilStale(this.currentResult.dataUpdatedAt, this.options.staleTime);
    var timeout = time + 1;
    this.staleTimeoutId = setTimeout(function() {
      if (!_this6.currentResult.isStale) {
        _this6.updateResult();
      }
    }, timeout);
  };
  _proto.computeRefetchInterval = function computeRefetchInterval() {
    var _this$options$refetch;
    return typeof this.options.refetchInterval === "function" ? this.options.refetchInterval(this.currentResult.data, this.currentQuery) : (_this$options$refetch = this.options.refetchInterval) != null ? _this$options$refetch : false;
  };
  _proto.updateRefetchInterval = function updateRefetchInterval(nextInterval) {
    var _this7 = this;
    this.clearRefetchInterval();
    this.currentRefetchInterval = nextInterval;
    if (isServer || this.options.enabled === false || !isValidTimeout(this.currentRefetchInterval) || this.currentRefetchInterval === 0) {
      return;
    }
    this.refetchIntervalId = setInterval(function() {
      if (_this7.options.refetchIntervalInBackground || focusManager.isFocused()) {
        _this7.executeFetch();
      }
    }, this.currentRefetchInterval);
  };
  _proto.updateTimers = function updateTimers() {
    this.updateStaleTimeout();
    this.updateRefetchInterval(this.computeRefetchInterval());
  };
  _proto.clearTimers = function clearTimers() {
    this.clearStaleTimeout();
    this.clearRefetchInterval();
  };
  _proto.clearStaleTimeout = function clearStaleTimeout() {
    if (this.staleTimeoutId) {
      clearTimeout(this.staleTimeoutId);
      this.staleTimeoutId = void 0;
    }
  };
  _proto.clearRefetchInterval = function clearRefetchInterval() {
    if (this.refetchIntervalId) {
      clearInterval(this.refetchIntervalId);
      this.refetchIntervalId = void 0;
    }
  };
  _proto.createResult = function createResult(query2, options) {
    var prevQuery = this.currentQuery;
    var prevOptions = this.options;
    var prevResult = this.currentResult;
    var prevResultState = this.currentResultState;
    var prevResultOptions = this.currentResultOptions;
    var queryChange = query2 !== prevQuery;
    var queryInitialState = queryChange ? query2.state : this.currentQueryInitialState;
    var prevQueryResult = queryChange ? this.currentResult : this.previousQueryResult;
    var state = query2.state;
    var dataUpdatedAt = state.dataUpdatedAt, error2 = state.error, errorUpdatedAt = state.errorUpdatedAt, isFetching = state.isFetching, status = state.status;
    var isPreviousData = false;
    var isPlaceholderData = false;
    var data;
    if (options.optimisticResults) {
      var mounted = this.hasListeners();
      var fetchOnMount = !mounted && shouldFetchOnMount(query2, options);
      var fetchOptionally = mounted && shouldFetchOptionally(query2, prevQuery, options, prevOptions);
      if (fetchOnMount || fetchOptionally) {
        isFetching = true;
        if (!dataUpdatedAt) {
          status = "loading";
        }
      }
    }
    if (options.keepPreviousData && !state.dataUpdateCount && (prevQueryResult == null ? void 0 : prevQueryResult.isSuccess) && status !== "error") {
      data = prevQueryResult.data;
      dataUpdatedAt = prevQueryResult.dataUpdatedAt;
      status = prevQueryResult.status;
      isPreviousData = true;
    } else if (options.select && typeof state.data !== "undefined") {
      if (prevResult && state.data === (prevResultState == null ? void 0 : prevResultState.data) && options.select === this.selectFn) {
        data = this.selectResult;
      } else {
        try {
          this.selectFn = options.select;
          data = options.select(state.data);
          if (options.structuralSharing !== false) {
            data = replaceEqualDeep(prevResult == null ? void 0 : prevResult.data, data);
          }
          this.selectResult = data;
          this.selectError = null;
        } catch (selectError) {
          getLogger().error(selectError);
          this.selectError = selectError;
        }
      }
    } else {
      data = state.data;
    }
    if (typeof options.placeholderData !== "undefined" && typeof data === "undefined" && (status === "loading" || status === "idle")) {
      var placeholderData;
      if ((prevResult == null ? void 0 : prevResult.isPlaceholderData) && options.placeholderData === (prevResultOptions == null ? void 0 : prevResultOptions.placeholderData)) {
        placeholderData = prevResult.data;
      } else {
        placeholderData = typeof options.placeholderData === "function" ? options.placeholderData() : options.placeholderData;
        if (options.select && typeof placeholderData !== "undefined") {
          try {
            placeholderData = options.select(placeholderData);
            if (options.structuralSharing !== false) {
              placeholderData = replaceEqualDeep(prevResult == null ? void 0 : prevResult.data, placeholderData);
            }
            this.selectError = null;
          } catch (selectError) {
            getLogger().error(selectError);
            this.selectError = selectError;
          }
        }
      }
      if (typeof placeholderData !== "undefined") {
        status = "success";
        data = placeholderData;
        isPlaceholderData = true;
      }
    }
    if (this.selectError) {
      error2 = this.selectError;
      data = this.selectResult;
      errorUpdatedAt = Date.now();
      status = "error";
    }
    var result = {
      status,
      isLoading: status === "loading",
      isSuccess: status === "success",
      isError: status === "error",
      isIdle: status === "idle",
      data,
      dataUpdatedAt,
      error: error2,
      errorUpdatedAt,
      failureCount: state.fetchFailureCount,
      errorUpdateCount: state.errorUpdateCount,
      isFetched: state.dataUpdateCount > 0 || state.errorUpdateCount > 0,
      isFetchedAfterMount: state.dataUpdateCount > queryInitialState.dataUpdateCount || state.errorUpdateCount > queryInitialState.errorUpdateCount,
      isFetching,
      isRefetching: isFetching && status !== "loading",
      isLoadingError: status === "error" && state.dataUpdatedAt === 0,
      isPlaceholderData,
      isPreviousData,
      isRefetchError: status === "error" && state.dataUpdatedAt !== 0,
      isStale: isStale(query2, options),
      refetch: this.refetch,
      remove: this.remove
    };
    return result;
  };
  _proto.shouldNotifyListeners = function shouldNotifyListeners(result, prevResult) {
    if (!prevResult) {
      return true;
    }
    var _this$options = this.options, notifyOnChangeProps = _this$options.notifyOnChangeProps, notifyOnChangePropsExclusions = _this$options.notifyOnChangePropsExclusions;
    if (!notifyOnChangeProps && !notifyOnChangePropsExclusions) {
      return true;
    }
    if (notifyOnChangeProps === "tracked" && !this.trackedProps.length) {
      return true;
    }
    var includedProps = notifyOnChangeProps === "tracked" ? this.trackedProps : notifyOnChangeProps;
    return Object.keys(result).some(function(key) {
      var typedKey = key;
      var changed = result[typedKey] !== prevResult[typedKey];
      var isIncluded = includedProps == null ? void 0 : includedProps.some(function(x) {
        return x === key;
      });
      var isExcluded = notifyOnChangePropsExclusions == null ? void 0 : notifyOnChangePropsExclusions.some(function(x) {
        return x === key;
      });
      return changed && !isExcluded && (!includedProps || isIncluded);
    });
  };
  _proto.updateResult = function updateResult(notifyOptions) {
    var prevResult = this.currentResult;
    this.currentResult = this.createResult(this.currentQuery, this.options);
    this.currentResultState = this.currentQuery.state;
    this.currentResultOptions = this.options;
    if (shallowEqualObjects(this.currentResult, prevResult)) {
      return;
    }
    var defaultNotifyOptions = {
      cache: true
    };
    if ((notifyOptions == null ? void 0 : notifyOptions.listeners) !== false && this.shouldNotifyListeners(this.currentResult, prevResult)) {
      defaultNotifyOptions.listeners = true;
    }
    this.notify(_extends$8({}, defaultNotifyOptions, notifyOptions));
  };
  _proto.updateQuery = function updateQuery() {
    var query2 = this.client.getQueryCache().build(this.client, this.options);
    if (query2 === this.currentQuery) {
      return;
    }
    var prevQuery = this.currentQuery;
    this.currentQuery = query2;
    this.currentQueryInitialState = query2.state;
    this.previousQueryResult = this.currentResult;
    if (this.hasListeners()) {
      prevQuery == null ? void 0 : prevQuery.removeObserver(this);
      query2.addObserver(this);
    }
  };
  _proto.onQueryUpdate = function onQueryUpdate(action) {
    var notifyOptions = {};
    if (action.type === "success") {
      notifyOptions.onSuccess = true;
    } else if (action.type === "error" && !isCancelledError(action.error)) {
      notifyOptions.onError = true;
    }
    this.updateResult(notifyOptions);
    if (this.hasListeners()) {
      this.updateTimers();
    }
  };
  _proto.notify = function notify(notifyOptions) {
    var _this8 = this;
    notifyManager.batch(function() {
      if (notifyOptions.onSuccess) {
        _this8.options.onSuccess == null ? void 0 : _this8.options.onSuccess(_this8.currentResult.data);
        _this8.options.onSettled == null ? void 0 : _this8.options.onSettled(_this8.currentResult.data, null);
      } else if (notifyOptions.onError) {
        _this8.options.onError == null ? void 0 : _this8.options.onError(_this8.currentResult.error);
        _this8.options.onSettled == null ? void 0 : _this8.options.onSettled(void 0, _this8.currentResult.error);
      }
      if (notifyOptions.listeners) {
        _this8.listeners.forEach(function(listener) {
          listener(_this8.currentResult);
        });
      }
      if (notifyOptions.cache) {
        _this8.client.getQueryCache().notify({
          query: _this8.currentQuery,
          type: "observerResultsUpdated"
        });
      }
    });
  };
  return QueryObserver2;
}(Subscribable);
function shouldLoadOnMount(query2, options) {
  return options.enabled !== false && !query2.state.dataUpdatedAt && !(query2.state.status === "error" && options.retryOnMount === false);
}
function shouldFetchOnMount(query2, options) {
  return shouldLoadOnMount(query2, options) || query2.state.dataUpdatedAt > 0 && shouldFetchOn(query2, options, options.refetchOnMount);
}
function shouldFetchOn(query2, options, field) {
  if (options.enabled !== false) {
    var value = typeof field === "function" ? field(query2) : field;
    return value === "always" || value !== false && isStale(query2, options);
  }
  return false;
}
function shouldFetchOptionally(query2, prevQuery, options, prevOptions) {
  return options.enabled !== false && (query2 !== prevQuery || prevOptions.enabled === false) && (!options.suspense || query2.state.status !== "error") && isStale(query2, options);
}
function isStale(query2, options) {
  return query2.isStaleByTime(options.staleTime);
}
var unstable_batchedUpdates = ReactDOM.unstable_batchedUpdates;
notifyManager.setBatchNotifyFunction(unstable_batchedUpdates);
var logger = console;
setLogger(logger);
var defaultContext$1 = /* @__PURE__ */ React.createContext(void 0);
var QueryClientSharingContext = /* @__PURE__ */ React.createContext(false);
function getQueryClientContext(contextSharing) {
  if (contextSharing && typeof window !== "undefined") {
    if (!window.ReactQueryClientContext) {
      window.ReactQueryClientContext = defaultContext$1;
    }
    return window.ReactQueryClientContext;
  }
  return defaultContext$1;
}
var useQueryClient = function useQueryClient2() {
  var queryClient2 = React.useContext(getQueryClientContext(React.useContext(QueryClientSharingContext)));
  if (!queryClient2) {
    throw new Error("No QueryClient set, use QueryClientProvider to set one");
  }
  return queryClient2;
};
var QueryClientProvider = function QueryClientProvider2(_ref) {
  var client = _ref.client, _ref$contextSharing = _ref.contextSharing, contextSharing = _ref$contextSharing === void 0 ? false : _ref$contextSharing, children = _ref.children;
  React.useEffect(function() {
    client.mount();
    return function() {
      client.unmount();
    };
  }, [client]);
  var Context = getQueryClientContext(contextSharing);
  return /* @__PURE__ */ React.createElement(QueryClientSharingContext.Provider, {
    value: contextSharing
  }, /* @__PURE__ */ React.createElement(Context.Provider, {
    value: client
  }, children));
};
function createValue() {
  var _isReset = false;
  return {
    clearReset: function clearReset() {
      _isReset = false;
    },
    reset: function reset() {
      _isReset = true;
    },
    isReset: function isReset() {
      return _isReset;
    }
  };
}
var QueryErrorResetBoundaryContext = /* @__PURE__ */ React.createContext(createValue());
var useQueryErrorResetBoundary = function useQueryErrorResetBoundary2() {
  return React.useContext(QueryErrorResetBoundaryContext);
};
function shouldThrowError(suspense, _useErrorBoundary, params) {
  if (typeof _useErrorBoundary === "function") {
    return _useErrorBoundary.apply(void 0, params);
  }
  if (typeof _useErrorBoundary === "boolean")
    return _useErrorBoundary;
  return !!suspense;
}
function useBaseQuery(options, Observer) {
  var mountedRef = React.useRef(false);
  var _React$useState = React.useState(0), forceUpdate = _React$useState[1];
  var queryClient2 = useQueryClient();
  var errorResetBoundary = useQueryErrorResetBoundary();
  var defaultedOptions = queryClient2.defaultQueryObserverOptions(options);
  defaultedOptions.optimisticResults = true;
  if (defaultedOptions.onError) {
    defaultedOptions.onError = notifyManager.batchCalls(defaultedOptions.onError);
  }
  if (defaultedOptions.onSuccess) {
    defaultedOptions.onSuccess = notifyManager.batchCalls(defaultedOptions.onSuccess);
  }
  if (defaultedOptions.onSettled) {
    defaultedOptions.onSettled = notifyManager.batchCalls(defaultedOptions.onSettled);
  }
  if (defaultedOptions.suspense) {
    if (typeof defaultedOptions.staleTime !== "number") {
      defaultedOptions.staleTime = 1e3;
    }
    if (defaultedOptions.cacheTime === 0) {
      defaultedOptions.cacheTime = 1;
    }
  }
  if (defaultedOptions.suspense || defaultedOptions.useErrorBoundary) {
    if (!errorResetBoundary.isReset()) {
      defaultedOptions.retryOnMount = false;
    }
  }
  var _React$useState2 = React.useState(function() {
    return new Observer(queryClient2, defaultedOptions);
  }), observer = _React$useState2[0];
  var result = observer.getOptimisticResult(defaultedOptions);
  React.useEffect(function() {
    mountedRef.current = true;
    errorResetBoundary.clearReset();
    var unsubscribe = observer.subscribe(notifyManager.batchCalls(function() {
      if (mountedRef.current) {
        forceUpdate(function(x) {
          return x + 1;
        });
      }
    }));
    observer.updateResult();
    return function() {
      mountedRef.current = false;
      unsubscribe();
    };
  }, [errorResetBoundary, observer]);
  React.useEffect(function() {
    observer.setOptions(defaultedOptions, {
      listeners: false
    });
  }, [defaultedOptions, observer]);
  if (defaultedOptions.suspense && result.isLoading) {
    throw observer.fetchOptimistic(defaultedOptions).then(function(_ref) {
      var data = _ref.data;
      defaultedOptions.onSuccess == null ? void 0 : defaultedOptions.onSuccess(data);
      defaultedOptions.onSettled == null ? void 0 : defaultedOptions.onSettled(data, null);
    }).catch(function(error2) {
      errorResetBoundary.clearReset();
      defaultedOptions.onError == null ? void 0 : defaultedOptions.onError(error2);
      defaultedOptions.onSettled == null ? void 0 : defaultedOptions.onSettled(void 0, error2);
    });
  }
  if (result.isError && !errorResetBoundary.isReset() && !result.isFetching && shouldThrowError(defaultedOptions.suspense, defaultedOptions.useErrorBoundary, [result.error, observer.getCurrentQuery()])) {
    throw result.error;
  }
  if (defaultedOptions.notifyOnChangeProps === "tracked") {
    result = observer.trackResult(result, defaultedOptions);
  }
  return result;
}
function useQuery(arg1, arg2, arg3) {
  var parsedOptions = parseQueryArgs(arg1, arg2, arg3);
  return useBaseQuery(parsedOptions, QueryObserver);
}
const getMutationFetchType = (mutation) => mutation.type === "update" ? mutation.partial ? "update" : "replace" : mutation.type;
const resolveDynamicQuery = (_ref, variables) => {
  let {
    resource,
    id,
    data,
    params
  } = _ref;
  return {
    resource,
    id: typeof id === "function" ? id(variables) : id,
    data: typeof data === "function" ? data(variables) : data,
    params: typeof params === "function" ? params(variables) : params
  };
};
function _defineProperty$5(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, { value, enumerable: true, configurable: true, writable: true });
  } else {
    obj[key] = value;
  }
  return obj;
}
class InvalidQueryError extends Error {
  constructor(errors) {
    super(`Invalid query
${errors.map((e) => " - " + e).join("\n")}`);
    _defineProperty$5(this, "type", "invalid-query");
    _defineProperty$5(this, "details", void 0);
    this.details = errors;
  }
}
const validQueryKeys = ["resource", "id", "params", "data"];
const validTypes = ["read", "create", "update", "replace", "delete", "json-patch"];
const getResourceQueryErrors = (type, query2) => {
  if (!validTypes.includes(type)) {
    return [`Unknown query or mutation type ${type}`];
  }
  if (typeof query2 !== "object") {
    return ["A query or mutation must be a javascript object"];
  }
  const errors = [];
  if (!query2.resource || typeof query2.resource !== "string") {
    errors.push("Property resource must be a string");
  }
  if (type === "create" && query2.id) {
    errors.push("Mutation type 'create' does not support property 'id'");
  }
  if (query2.id && typeof query2.id !== "string") {
    errors.push("Property id must be a string");
  }
  if (query2.params && typeof query2.params !== "object") {
    errors.push("Property params must be an object");
  }
  if (type === "delete" && query2.data) {
    errors.push("Mutation type 'delete' does not support property 'data'");
  }
  if (type === "json-patch" && !Array.isArray(query2.data)) {
    errors.push("Mutation type 'json-patch' requires property 'data' to be of type Array");
  }
  const invalidKeys = Object.keys(query2).filter((k) => !validQueryKeys.includes(k));
  invalidKeys.forEach((k) => {
    errors.push(`Property ${k} is not supported`);
  });
  return errors;
};
const validateResourceQueries = function(queries) {
  let names = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : [];
  if (names.length !== queries.length) {
    for (let i = names.length; i < queries.length; ++i) {
      names.push("query#" + i);
    }
  }
  const errors = queries.reduce((errors2, query2, i) => errors2.concat(getResourceQueryErrors("read", query2).map((e) => `[${names[i]}] ${e}`)), []);
  if (errors.length) {
    throw new InvalidQueryError(errors);
  }
};
const validateResourceQuery = (type, query2) => {
  const errors = getResourceQueryErrors(type, query2);
  if (errors.length) {
    throw new InvalidQueryError(errors);
  }
};
function _defineProperty$4(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, { value, enumerable: true, configurable: true, writable: true });
  } else {
    obj[key] = value;
  }
  return obj;
}
const reduceResponses = (responses, names) => responses.reduce((out, response, idx) => {
  out[names[idx]] = response;
  return out;
}, {});
class DataEngine {
  constructor(link2) {
    _defineProperty$4(this, "link", void 0);
    this.link = link2;
  }
  query(query2) {
    let {
      variables = {},
      signal,
      onComplete,
      onError
    } = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    const names = Object.keys(query2);
    const queries = names.map((name) => query2[name]).map((q) => resolveDynamicQuery(q, variables));
    validateResourceQueries(queries, names);
    return Promise.all(queries.map((q) => {
      return this.link.executeResourceQuery("read", q, {
        signal
      });
    })).then((results) => {
      const data = reduceResponses(results, names);
      onComplete && onComplete(data);
      return data;
    }).catch((error2) => {
      onError && onError(error2);
      throw error2;
    });
  }
  mutate(mutation) {
    let {
      variables = {},
      signal,
      onComplete,
      onError
    } = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    const query2 = resolveDynamicQuery(mutation, variables);
    const type = getMutationFetchType(mutation);
    validateResourceQuery(type, query2);
    const result = this.link.executeResourceQuery(type, query2, {
      signal
    });
    return result.then((data) => {
      onComplete && onComplete(data);
      return data;
    }).catch((error2) => {
      onError && onError(error2);
      throw error2;
    });
  }
}
function _defineProperty$3(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, { value, enumerable: true, configurable: true, writable: true });
  } else {
    obj[key] = value;
  }
  return obj;
}
class FetchError extends Error {
  constructor(_ref) {
    let {
      message,
      type,
      details = {}
    } = _ref;
    super(message);
    _defineProperty$3(this, "type", void 0);
    _defineProperty$3(this, "details", void 0);
    this.type = type;
    this.details = details;
  }
}
function _defineProperty$2(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, { value, enumerable: true, configurable: true, writable: true });
  } else {
    obj[key] = value;
  }
  return obj;
}
class ErrorLink {
  constructor(errorMessage2) {
    _defineProperty$2(this, "errorMessage", void 0);
    this.errorMessage = errorMessage2;
  }
  executeResourceQuery() {
    console.error(this.errorMessage);
    return Promise.reject(this.errorMessage);
  }
}
const parseContentType = (contentType) => contentType ? contentType.split(";")[0].trim().toLowerCase() : "";
const parseStatus = async (response) => {
  const accessError = response.status === 401 || response.status === 403 || response.status === 409;
  if (accessError) {
    let message;
    let details = {};
    try {
      details = await response.json();
      message = details.message;
    } catch (e) {
    }
    if (!message) {
      message = response.status === 401 ? "Unauthorized" : "Forbidden";
    }
    throw new FetchError({
      type: "access",
      message,
      details
    });
  }
  if (response.status < 200 || response.status >= 400) {
    const message = `An unknown error occurred - ${response.statusText} (${response.status})`;
    let details = {};
    try {
      details = await response.json();
    } catch (e) {
    }
    throw new FetchError({
      type: "unknown",
      message,
      details
    });
  }
  return response;
};
function fetchData(url) {
  let options = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
  return fetch(url, {
    ...options,
    credentials: "include",
    headers: {
      "X-Requested-With": "XMLHttpRequest",
      Accept: "application/json",
      ...options.headers
    }
  }).catch((err) => {
    throw new FetchError({
      type: "network",
      message: "An unknown network error occurred",
      details: err
    });
  }).then(parseStatus).then(async (response) => {
    const contentType = parseContentType(response.headers.get("Content-Type"));
    if (contentType === "application/json") {
      return await response.json();
    }
    if (/^text\/[a-z0-9.-]+$/.test(contentType)) {
      return await response.text();
    }
    return await response.blob();
  });
}
const joinPath$1 = function() {
  for (var _len = arguments.length, parts = new Array(_len), _key = 0; _key < _len; _key++) {
    parts[_key] = arguments[_key];
  }
  const realParts = parts.filter((part) => !!part);
  return realParts.map((part) => part.replace(/^\/+|\/+$/g, "")).join("/");
};
const isDataValue = (type, _ref) => {
  let {
    resource
  } = _ref;
  return type === "create" && (resource === "dataValues" || resource === "dataValues/file");
};
const isFileResourceUpload = (type, _ref2) => {
  let {
    resource
  } = _ref2;
  return type === "create" && resource === "fileResources";
};
const isMessageConversationAttachment = (type, _ref3) => {
  let {
    resource
  } = _ref3;
  return type === "create" && resource === "messageConversations/attachments";
};
const isStaticContentUpload = (type, _ref4) => {
  let {
    resource
  } = _ref4;
  const pattern = /^staticContent\/(?:logo_banner|logo_front)$/;
  return type === "create" && pattern.test(resource);
};
const isAppInstall = (type, _ref5) => {
  let {
    resource
  } = _ref5;
  return type === "create" && resource === "apps";
};
const multipartFormDataMatchers = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  isAppInstall,
  isDataValue,
  isFileResourceUpload,
  isMessageConversationAttachment,
  isStaticContentUpload
}, Symbol.toStringTag, { value: "Module" }));
const isReplyToMessageConversation = (type, _ref) => {
  let {
    resource
  } = _ref;
  const pattern = /^messageConversations\/[a-zA-Z0-9]{11}$/;
  return type === "create" && pattern.test(resource);
};
const isCreateFeedbackMessage = (type, _ref2) => {
  let {
    resource
  } = _ref2;
  return type === "create" && resource === "messageConversations/feedback";
};
const isCreateInterpretation = (type, _ref3) => {
  let {
    resource
  } = _ref3;
  const pattern = /^interpretations\/(?:reportTable|chart|visualization|map|eventVisualization|eventReport|eventChart|dataSetReport)\/[a-zA-Z0-9]{11}$/;
  return type === "create" && pattern.test(resource);
};
const isUpdateInterpretation = (type, _ref4) => {
  let {
    resource,
    id
  } = _ref4;
  if (type !== "replace") {
    return false;
  }
  let resourcePattern;
  if (id) {
    resourcePattern = /^interpretations$/;
    const idPattern = /^[a-zA-Z0-9]{11}$/;
    return resourcePattern.test(resource) && idPattern.test(id);
  }
  resourcePattern = /^interpretations\/[a-zA-Z0-9]{11}$/;
  return resourcePattern.test(resource);
};
const isCommentOnInterpretation = (type, _ref5) => {
  let {
    resource
  } = _ref5;
  const pattern = /^interpretations\/[a-zA-Z0-9]{11}\/comments$/;
  return type === "create" && pattern.test(resource);
};
const isInterpretationCommentUpdate = (type, _ref6) => {
  let {
    resource,
    id
  } = _ref6;
  if (type !== "replace") {
    return false;
  }
  if (id) {
    const idPatternLong = /^[a-zA-Z0-9]{11}\/comments\/[a-zA-Z0-9]{11}$/;
    const idPatternShort = /^[a-zA-Z0-9]{11}$/;
    const resourcePattern = /^interpretations\/[a-zA-Z0-9]{11}\/comments$/;
    return resource === "interpretations" && idPatternLong.test(id) || resourcePattern.test(resource) && idPatternShort.test(id);
  }
  const pattern = /^interpretations\/[a-zA-Z0-9]{11}\/comments\/[a-zA-Z0-9]{11}$/;
  return pattern.test(resource);
};
const isAddOrUpdateSystemOrUserSetting = (type, _ref7) => {
  let {
    resource
  } = _ref7;
  const pattern = /^(?:systemSettings|userSettings)\/[a-zA-Z]{4,}$/;
  return type === "create" && pattern.test(resource);
};
const addOrUpdateConfigurationProperty = (type, _ref8) => {
  let {
    resource
  } = _ref8;
  const pattern = /^(configuration)\/([a-zA-Z]{1,50})$/;
  const match = resource.match(pattern);
  return type === "create" && !!match && match[2] !== "corsWhitelist";
};
const isMetadataPackageInstallation = (type, _ref9) => {
  let {
    resource
  } = _ref9;
  return type === "create" && resource === "synchronization/metadataPull";
};
const isExpressionDescriptionValidation = (type, _ref10) => {
  let {
    resource
  } = _ref10;
  return type === "create" && resource === "indicators/expression/description";
};
const textPlainMatchers = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  addOrUpdateConfigurationProperty,
  isAddOrUpdateSystemOrUserSetting,
  isCommentOnInterpretation,
  isCreateFeedbackMessage,
  isCreateInterpretation,
  isExpressionDescriptionValidation,
  isInterpretationCommentUpdate,
  isMetadataPackageInstallation,
  isReplyToMessageConversation,
  isUpdateInterpretation
}, Symbol.toStringTag, { value: "Module" }));
const isSvgConversion = (type, _ref) => {
  let {
    resource
  } = _ref;
  return type === "create" && (resource === "svg.png" || resource === "svg.pdf");
};
const xWwwFormUrlencodedMatchers = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  isSvgConversion
}, Symbol.toStringTag, { value: "Module" }));
const resourceExpectsTextPlain = (type, query2) => Object.values(textPlainMatchers).some((textPlainMatcher) => textPlainMatcher(type, query2));
const resourceExpectsMultipartFormData = (type, query2) => Object.values(multipartFormDataMatchers).some((multipartFormDataMatcher) => multipartFormDataMatcher(type, query2));
const resourceExpectsXWwwFormUrlencoded = (type, query2) => Object.values(xWwwFormUrlencodedMatchers).some((xWwwFormUrlencodedMatcher) => xWwwFormUrlencodedMatcher(type, query2));
const convertData = (data, initialValue) => {
  const dataEntries = Object.entries(data);
  if (dataEntries.length === 0) {
    throw new Error(`Could not convert data to ${initialValue.constructor.name}: object does not have own enumerable string-keyed properties`);
  }
  return dataEntries.reduce((convertedData, _ref) => {
    let [key, value] = _ref;
    convertedData.append(key, value);
    return convertedData;
  }, initialValue);
};
const requestContentType = (type, query2) => {
  if (!query2.data) {
    return null;
  }
  if (type === "json-patch") {
    return "application/json-patch+json";
  }
  if (resourceExpectsTextPlain(type, query2)) {
    return "text/plain";
  }
  if (resourceExpectsMultipartFormData(type, query2)) {
    return "multipart/form-data";
  }
  if (resourceExpectsXWwwFormUrlencoded(type, query2)) {
    return "application/x-www-form-urlencoded";
  }
  return "application/json";
};
const requestHeadersForContentType = (contentType) => {
  if (!contentType || contentType === "multipart/form-data") {
    return void 0;
  }
  return {
    "Content-Type": contentType
  };
};
const requestBodyForContentType = (contentType, _ref2) => {
  let {
    data
  } = _ref2;
  if (typeof data === "undefined") {
    return void 0;
  }
  if (contentType === "application/json" || contentType === "application/json-patch+json") {
    return JSON.stringify(data);
  }
  if (contentType === "multipart/form-data") {
    return convertData(data, new FormData());
  }
  if (contentType === "application/x-www-form-urlencoded") {
    return convertData(data, new URLSearchParams());
  }
  return data;
};
const getMethod = (type) => {
  switch (type) {
    case "create":
      return "POST";
    case "read":
      return "GET";
    case "update":
    case "json-patch":
      return "PATCH";
    case "replace":
      return "PUT";
    case "delete":
      return "DELETE";
    default:
      throw new Error(`Unknown type ${type}`);
  }
};
const queryToRequestOptions = (type, query2, signal) => {
  const contentType = requestContentType(type, query2);
  return {
    method: getMethod(type),
    body: requestBodyForContentType(contentType, query2),
    headers: requestHeadersForContentType(contentType),
    signal
  };
};
const encodeQueryParameter = (param) => {
  if (Array.isArray(param)) {
    return param.map(encodeQueryParameter).join(",");
  }
  if (typeof param === "string") {
    return encodeURIComponent(param);
  }
  if (typeof param === "number" || typeof param === "boolean") {
    return String(param);
  }
  if (typeof param === "object") {
    throw new Error("Object parameter mappings not yet implemented");
  }
  throw new Error("Unknown parameter type");
};
const queryParametersMapToArray = (params) => Object.keys(params).reduce((out, key) => {
  const value = params[key];
  if (key === "filter" && Array.isArray(value)) {
    value.forEach((item) => {
      out.push({
        key: "filter",
        value: item
      });
    });
  } else if (params[key] !== null && params[key] !== void 0) {
    out.push({
      key,
      value: params[key]
    });
  }
  return out;
}, []);
const queryParametersToQueryString = (params) => {
  const expandedParams = queryParametersMapToArray(params);
  return expandedParams.map((_ref) => {
    let {
      key,
      value
    } = _ref;
    return `${encodeURIComponent(key)}=${encodeQueryParameter(value)}`;
  }).join("&");
};
const actionPrefix = "action::";
const isAction = (resource) => resource.startsWith(actionPrefix);
const makeActionPath = (resource) => joinPath$1("dhis-web-commons", `${resource.substr(actionPrefix.length)}.action`);
const skipApiVersion = (resource, config) => {
  if (resource === "tracker" || resource.startsWith("tracker/")) {
    var _config$serverVersion, _config$serverVersion2;
    if (!((_config$serverVersion = config.serverVersion) !== null && _config$serverVersion !== void 0 && _config$serverVersion.minor) || ((_config$serverVersion2 = config.serverVersion) === null || _config$serverVersion2 === void 0 ? void 0 : _config$serverVersion2.minor) < 38) {
      return true;
    }
  }
  if (resource === "ping") {
    return true;
  }
  return false;
};
const queryToResourcePath = (link2, query2, type) => {
  const {
    resource,
    id,
    params = {}
  } = query2;
  const apiBase = skipApiVersion(resource, link2.config) ? link2.unversionedApiPath : link2.versionedApiPath;
  const base = isAction(resource) ? makeActionPath(resource) : joinPath$1(apiBase, resource, id);
  if (Object.keys(params).length) {
    return `${base}?${queryParametersToQueryString(params)}`;
  }
  return base;
};
function _defineProperty$1(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, { value, enumerable: true, configurable: true, writable: true });
  } else {
    obj[key] = value;
  }
  return obj;
}
class RestAPILink {
  constructor(config) {
    _defineProperty$1(this, "config", void 0);
    _defineProperty$1(this, "versionedApiPath", void 0);
    _defineProperty$1(this, "unversionedApiPath", void 0);
    this.config = config;
    this.versionedApiPath = joinPath$1("api", String(config.apiVersion));
    this.unversionedApiPath = joinPath$1("api");
  }
  fetch(path, options) {
    return fetchData(joinPath$1(this.config.baseUrl, path), options);
  }
  executeResourceQuery(type, query2, _ref) {
    let {
      signal
    } = _ref;
    return this.fetch(queryToResourcePath(this, query2), queryToRequestOptions(type, query2, signal));
  }
}
const errorMessage = "DHIS2 data context must be initialized, please ensure that you include a <DataProvider> in your application";
const link = new ErrorLink(errorMessage);
const engine = new DataEngine(link);
const defaultContext = {
  engine
};
const DataContext = /* @__PURE__ */ React.createContext(defaultContext);
const ConfigContext = /* @__PURE__ */ React.createContext({
  baseUrl: "..",
  apiVersion: 32
});
const useConfig = () => reactExports.useContext(ConfigContext);
const makeContext = (config) => config;
const ConfigProvider = (_ref) => {
  let {
    config,
    children
  } = _ref;
  return /* @__PURE__ */ React.createElement(ConfigContext.Provider, {
    value: makeContext(config)
  }, children);
};
const queryClientOptions = {
  defaultOptions: {
    queries: {
      // Disable automatic error retries
      retry: false,
      // Retry on mount if query has errored
      retryOnMount: true,
      // Refetch on mount if data is stale
      refetchOnMount: true,
      // Don't refetch when the window regains focus
      refetchOnWindowFocus: false,
      // Don't refetch after connection issues
      refetchOnReconnect: false
    }
  }
};
const queryClient = new QueryClient(queryClientOptions);
const DataProvider = (props) => {
  const config = {
    ...useConfig(),
    ...props
  };
  const link2 = new RestAPILink(config);
  const engine2 = new DataEngine(link2);
  const context = {
    engine: engine2
  };
  return /* @__PURE__ */ React.createElement(QueryClientProvider, {
    client: queryClient
  }, /* @__PURE__ */ React.createElement(DataContext.Provider, {
    value: context
  }, props.children));
};
const useDataEngine = () => {
  const context = reactExports.useContext(DataContext);
  return context.engine;
};
const useStaticInput = function(staticValue) {
  let {
    warn: warn2 = false,
    name = "input"
  } = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
  const originalValue = reactExports.useRef(staticValue);
  const [value, setValue] = reactExports.useState(() => originalValue.current);
  reactExports.useDebugValue(value, (debugValue) => `${name}: ${JSON.stringify(debugValue)}`);
  reactExports.useEffect(() => {
    if (warn2 && originalValue.current !== staticValue) {
      console.warn(`The ${name} should be static, don't create it within the render loop!`);
    }
  }, [warn2, staticValue, originalValue, name]);
  return [value, setValue];
};
function hasObjectPrototype(o) {
  return Object.prototype.toString.call(o) === "[object Object]";
}
function isPlainObject(o) {
  if (!hasObjectPrototype(o)) {
    return false;
  }
  const ctor = o.constructor;
  if (typeof ctor === "undefined") {
    return true;
  }
  const prot = ctor.prototype;
  if (!hasObjectPrototype(prot)) {
    return false;
  }
  if (!Object.prototype.hasOwnProperty.call(prot, "isPrototypeOf")) {
    return false;
  }
  return true;
}
function stableVariablesHash(value) {
  let hash2;
  try {
    hash2 = JSON.stringify(value, (_22, val) => isPlainObject(val) ? Object.keys(val).sort().reduce((result, key) => {
      result[key] = val[key];
      return result;
    }, {}) : val);
  } catch (e) {
    throw new Error("Could not serialize variables. Make sure that the variables do not contain circular references and can be processed by JSON.stringify.");
  }
  return hash2;
}
const mergeAndCompareVariables = (previousVariables, newVariables, previousHash) => {
  if (!newVariables) {
    return {
      identical: true,
      mergedVariablesHash: previousHash,
      mergedVariables: previousVariables
    };
  }
  const currentHash = previousHash || stableVariablesHash(previousVariables);
  const mergedVariables = {
    ...previousVariables,
    ...newVariables
  };
  const mergedVariablesHash = stableVariablesHash(mergedVariables);
  const identical = currentHash === mergedVariablesHash;
  return {
    identical,
    mergedVariablesHash,
    mergedVariables
  };
};
const noop$1 = () => {
};
setLogger({
  log: noop$1,
  warn: noop$1,
  error: noop$1
});
const useDataQuery = function(query2) {
  let {
    onComplete: userOnSuccess,
    onError: userOnError,
    variables: initialVariables = {},
    lazy: initialLazy = false
  } = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
  const [staticQuery] = useStaticInput(query2, {
    warn: true,
    name: "query"
  });
  const [variablesUpdateCount, setVariablesUpdateCount] = reactExports.useState(0);
  const queryState = reactExports.useRef({
    variables: initialVariables,
    variablesHash: void 0,
    enabled: !initialLazy,
    refetchCallback: void 0
  });
  reactExports.useDebugValue({
    variablesUpdateCount,
    enabled: queryState.current.enabled,
    variables: queryState.current.variables
  }, (debugValue) => JSON.stringify(debugValue));
  const onSuccess = (data2) => {
    var _queryState$current$r, _queryState$current;
    (_queryState$current$r = (_queryState$current = queryState.current).refetchCallback) === null || _queryState$current$r === void 0 ? void 0 : _queryState$current$r.call(_queryState$current, data2);
    queryState.current.refetchCallback = void 0;
    if (userOnSuccess) {
      userOnSuccess(data2);
    }
  };
  const onError = (error3) => {
    queryState.current.refetchCallback = void 0;
    if (userOnError) {
      userOnError(error3);
    }
  };
  const engine2 = useDataEngine();
  const queryKey = [staticQuery, queryState.current.variables];
  const queryFn = () => engine2.query(staticQuery, {
    variables: queryState.current.variables
  });
  const {
    isIdle,
    isFetching,
    isLoading,
    error: error2,
    data,
    refetch: queryRefetch
  } = useQuery(queryKey, queryFn, {
    enabled: queryState.current.enabled,
    onSuccess,
    onError
  });
  const refetch = reactExports.useCallback((newVariables) => {
    const {
      identical,
      mergedVariables,
      mergedVariablesHash
    } = mergeAndCompareVariables(queryState.current.variables, newVariables, queryState.current.variablesHash);
    if (queryState.current.enabled && identical) {
      return queryRefetch({
        cancelRefetch: true,
        throwOnError: false
      }).then((_ref) => {
        let {
          data: data2
        } = _ref;
        return data2;
      });
    }
    queryState.current.variables = mergedVariables;
    queryState.current.variablesHash = mergedVariablesHash;
    queryState.current.enabled = true;
    const refetchPromise = new Promise((resolve) => {
      queryState.current.refetchCallback = (data2) => {
        resolve(data2);
      };
    });
    setVariablesUpdateCount((prevCount) => prevCount + 1);
    return refetchPromise;
  }, [queryRefetch]);
  const ourError = error2 || void 0;
  return {
    engine: engine2,
    // A query is idle if it is lazy and no initial data is available.
    called: !isIdle,
    loading: isLoading,
    fetching: isFetching,
    error: ourError,
    data,
    refetch
  };
};
const AlertsContext = /* @__PURE__ */ React.createContext([]);
const placeholder = () => {
  throw new Error("This function is a placeholder used when creating the AlertsManagerContext, it should be overridden");
};
const defaultAlertsManager = {
  add: placeholder,
  plugin: false,
  parentAlertsAdd: null,
  showAlertsInPlugin: false
};
const AlertsManagerContext = /* @__PURE__ */ React.createContext(defaultAlertsManager);
const toVisibleAlertsArray = (alertsMap) => Array.from(alertsMap.values());
const makeAlertsManager = (setAlerts, plugin) => {
  const alertsMap = /* @__PURE__ */ new Map();
  let id = 0;
  const add = (alert, alertRef) => {
    var _alertRef$current$id, _alertRef$current;
    const alertId = (_alertRef$current$id = (_alertRef$current = alertRef.current) === null || _alertRef$current === void 0 ? void 0 : _alertRef$current.id) !== null && _alertRef$current$id !== void 0 ? _alertRef$current$id : ++id;
    const alertsMapAlert = {
      ...alert,
      id: alertId,
      remove: () => {
        alertsMap.delete(alertId);
        alertRef.current = null;
        setAlerts(toVisibleAlertsArray(alertsMap));
      }
    };
    alertsMap.set(alertId, alertsMapAlert);
    setAlerts(toVisibleAlertsArray(alertsMap));
    return alertsMapAlert;
  };
  return {
    add,
    plugin
  };
};
const AlertsProvider = (_ref) => {
  let {
    plugin,
    parentAlertsAdd,
    showAlertsInPlugin,
    children
  } = _ref;
  const [alerts, setAlerts] = reactExports.useState([]);
  const [alertsManager] = reactExports.useState(() => makeAlertsManager(setAlerts, plugin));
  return /* @__PURE__ */ React.createElement(AlertsManagerContext.Provider, {
    value: {
      ...alertsManager,
      parentAlertsAdd,
      showAlertsInPlugin
    }
  }, /* @__PURE__ */ React.createElement(AlertsContext.Provider, {
    value: alerts
  }, children));
};
const useAlert = function(message) {
  let options = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
  const {
    add,
    plugin,
    parentAlertsAdd,
    showAlertsInPlugin
  } = reactExports.useContext(AlertsManagerContext);
  const alertRef = reactExports.useRef(null);
  const show = reactExports.useCallback((props) => {
    const resolvedMessage = String(typeof message === "function" ? message(props) : message);
    const resolvedOptions = typeof options === "function" ? options(props) : options;
    if (plugin && parentAlertsAdd && !showAlertsInPlugin) {
      alertRef.current = parentAlertsAdd({
        message: resolvedMessage,
        options: resolvedOptions
      }, alertRef);
    } else {
      alertRef.current = add({
        message: resolvedMessage,
        options: resolvedOptions
      }, alertRef);
    }
  }, [add, parentAlertsAdd, message, options, plugin, showAlertsInPlugin]);
  const hide2 = reactExports.useCallback(() => {
    var _alertRef$current, _alertRef$current$rem;
    (_alertRef$current = alertRef.current) === null || _alertRef$current === void 0 ? void 0 : (_alertRef$current$rem = _alertRef$current.remove) === null || _alertRef$current$rem === void 0 ? void 0 : _alertRef$current$rem.call(_alertRef$current);
  }, []);
  return {
    show,
    hide: hide2
  };
};
var propTypes = { exports: {} };
var ReactPropTypesSecret$1 = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED";
var ReactPropTypesSecret_1 = ReactPropTypesSecret$1;
var ReactPropTypesSecret = ReactPropTypesSecret_1;
function emptyFunction() {
}
function emptyFunctionWithReset() {
}
emptyFunctionWithReset.resetWarningCache = emptyFunction;
var factoryWithThrowingShims = function() {
  function shim(props, propName, componentName, location, propFullName, secret) {
    if (secret === ReactPropTypesSecret) {
      return;
    }
    var err = new Error(
      "Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types"
    );
    err.name = "Invariant Violation";
    throw err;
  }
  shim.isRequired = shim;
  function getShim() {
    return shim;
  }
  var ReactPropTypes = {
    array: shim,
    bigint: shim,
    bool: shim,
    func: shim,
    number: shim,
    object: shim,
    string: shim,
    symbol: shim,
    any: shim,
    arrayOf: getShim,
    element: shim,
    elementType: shim,
    instanceOf: getShim,
    node: shim,
    objectOf: getShim,
    oneOf: getShim,
    oneOfType: getShim,
    shape: getShim,
    exact: getShim,
    checkPropTypes: emptyFunctionWithReset,
    resetWarningCache: emptyFunction
  };
  ReactPropTypes.PropTypes = ReactPropTypes;
  return ReactPropTypes;
};
{
  propTypes.exports = factoryWithThrowingShims();
}
var propTypesExports = propTypes.exports;
const PropTypes = /* @__PURE__ */ getDefaultExportFromCjs(propTypesExports);
function listCacheClear$1() {
  this.__data__ = [];
  this.size = 0;
}
var _listCacheClear = listCacheClear$1;
function eq$1(value, other) {
  return value === other || value !== value && other !== other;
}
var eq_1 = eq$1;
var eq = eq_1;
function assocIndexOf$4(array, key) {
  var length = array.length;
  while (length--) {
    if (eq(array[length][0], key)) {
      return length;
    }
  }
  return -1;
}
var _assocIndexOf = assocIndexOf$4;
var assocIndexOf$3 = _assocIndexOf;
var arrayProto = Array.prototype;
var splice = arrayProto.splice;
function listCacheDelete$1(key) {
  var data = this.__data__, index2 = assocIndexOf$3(data, key);
  if (index2 < 0) {
    return false;
  }
  var lastIndex = data.length - 1;
  if (index2 == lastIndex) {
    data.pop();
  } else {
    splice.call(data, index2, 1);
  }
  --this.size;
  return true;
}
var _listCacheDelete = listCacheDelete$1;
var assocIndexOf$2 = _assocIndexOf;
function listCacheGet$1(key) {
  var data = this.__data__, index2 = assocIndexOf$2(data, key);
  return index2 < 0 ? void 0 : data[index2][1];
}
var _listCacheGet = listCacheGet$1;
var assocIndexOf$1 = _assocIndexOf;
function listCacheHas$1(key) {
  return assocIndexOf$1(this.__data__, key) > -1;
}
var _listCacheHas = listCacheHas$1;
var assocIndexOf = _assocIndexOf;
function listCacheSet$1(key, value) {
  var data = this.__data__, index2 = assocIndexOf(data, key);
  if (index2 < 0) {
    ++this.size;
    data.push([key, value]);
  } else {
    data[index2][1] = value;
  }
  return this;
}
var _listCacheSet = listCacheSet$1;
var listCacheClear = _listCacheClear, listCacheDelete = _listCacheDelete, listCacheGet = _listCacheGet, listCacheHas = _listCacheHas, listCacheSet = _listCacheSet;
function ListCache$4(entries) {
  var index2 = -1, length = entries == null ? 0 : entries.length;
  this.clear();
  while (++index2 < length) {
    var entry = entries[index2];
    this.set(entry[0], entry[1]);
  }
}
ListCache$4.prototype.clear = listCacheClear;
ListCache$4.prototype["delete"] = listCacheDelete;
ListCache$4.prototype.get = listCacheGet;
ListCache$4.prototype.has = listCacheHas;
ListCache$4.prototype.set = listCacheSet;
var _ListCache = ListCache$4;
var ListCache$3 = _ListCache;
function stackClear$1() {
  this.__data__ = new ListCache$3();
  this.size = 0;
}
var _stackClear = stackClear$1;
function stackDelete$1(key) {
  var data = this.__data__, result = data["delete"](key);
  this.size = data.size;
  return result;
}
var _stackDelete = stackDelete$1;
function stackGet$1(key) {
  return this.__data__.get(key);
}
var _stackGet = stackGet$1;
function stackHas$1(key) {
  return this.__data__.has(key);
}
var _stackHas = stackHas$1;
var freeGlobal$1 = typeof commonjsGlobal == "object" && commonjsGlobal && commonjsGlobal.Object === Object && commonjsGlobal;
var _freeGlobal = freeGlobal$1;
var freeGlobal = _freeGlobal;
var freeSelf = typeof self == "object" && self && self.Object === Object && self;
var root$8 = freeGlobal || freeSelf || Function("return this")();
var _root = root$8;
var root$7 = _root;
var Symbol$4 = root$7.Symbol;
var _Symbol = Symbol$4;
var Symbol$3 = _Symbol;
var objectProto$5 = Object.prototype;
var hasOwnProperty$4 = objectProto$5.hasOwnProperty;
var nativeObjectToString$1 = objectProto$5.toString;
var symToStringTag$1 = Symbol$3 ? Symbol$3.toStringTag : void 0;
function getRawTag$1(value) {
  var isOwn = hasOwnProperty$4.call(value, symToStringTag$1), tag = value[symToStringTag$1];
  try {
    value[symToStringTag$1] = void 0;
    var unmasked = true;
  } catch (e) {
  }
  var result = nativeObjectToString$1.call(value);
  if (unmasked) {
    if (isOwn) {
      value[symToStringTag$1] = tag;
    } else {
      delete value[symToStringTag$1];
    }
  }
  return result;
}
var _getRawTag = getRawTag$1;
var objectProto$4 = Object.prototype;
var nativeObjectToString = objectProto$4.toString;
function objectToString$1(value) {
  return nativeObjectToString.call(value);
}
var _objectToString = objectToString$1;
var Symbol$2 = _Symbol, getRawTag = _getRawTag, objectToString = _objectToString;
var nullTag = "[object Null]", undefinedTag = "[object Undefined]";
var symToStringTag = Symbol$2 ? Symbol$2.toStringTag : void 0;
function baseGetTag$3(value) {
  if (value == null) {
    return value === void 0 ? undefinedTag : nullTag;
  }
  return symToStringTag && symToStringTag in Object(value) ? getRawTag(value) : objectToString(value);
}
var _baseGetTag = baseGetTag$3;
function isObject$2(value) {
  var type = typeof value;
  return value != null && (type == "object" || type == "function");
}
var isObject_1 = isObject$2;
var baseGetTag$2 = _baseGetTag, isObject$1 = isObject_1;
var asyncTag = "[object AsyncFunction]", funcTag = "[object Function]", genTag = "[object GeneratorFunction]", proxyTag = "[object Proxy]";
function isFunction$1(value) {
  if (!isObject$1(value)) {
    return false;
  }
  var tag = baseGetTag$2(value);
  return tag == funcTag || tag == genTag || tag == asyncTag || tag == proxyTag;
}
var isFunction_1 = isFunction$1;
var root$6 = _root;
var coreJsData$1 = root$6["__core-js_shared__"];
var _coreJsData = coreJsData$1;
var coreJsData = _coreJsData;
var maskSrcKey = function() {
  var uid = /[^.]+$/.exec(coreJsData && coreJsData.keys && coreJsData.keys.IE_PROTO || "");
  return uid ? "Symbol(src)_1." + uid : "";
}();
function isMasked$1(func) {
  return !!maskSrcKey && maskSrcKey in func;
}
var _isMasked = isMasked$1;
var funcProto$1 = Function.prototype;
var funcToString$1 = funcProto$1.toString;
function toSource$2(func) {
  if (func != null) {
    try {
      return funcToString$1.call(func);
    } catch (e) {
    }
    try {
      return func + "";
    } catch (e) {
    }
  }
  return "";
}
var _toSource = toSource$2;
var isFunction = isFunction_1, isMasked = _isMasked, isObject = isObject_1, toSource$1 = _toSource;
var reRegExpChar = /[\\^$.*+?()[\]{}|]/g;
var reIsHostCtor = /^\[object .+?Constructor\]$/;
var funcProto = Function.prototype, objectProto$3 = Object.prototype;
var funcToString = funcProto.toString;
var hasOwnProperty$3 = objectProto$3.hasOwnProperty;
var reIsNative = RegExp(
  "^" + funcToString.call(hasOwnProperty$3).replace(reRegExpChar, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"
);
function baseIsNative$1(value) {
  if (!isObject(value) || isMasked(value)) {
    return false;
  }
  var pattern = isFunction(value) ? reIsNative : reIsHostCtor;
  return pattern.test(toSource$1(value));
}
var _baseIsNative = baseIsNative$1;
function getValue$1(object, key) {
  return object == null ? void 0 : object[key];
}
var _getValue = getValue$1;
var baseIsNative = _baseIsNative, getValue = _getValue;
function getNative$6(object, key) {
  var value = getValue(object, key);
  return baseIsNative(value) ? value : void 0;
}
var _getNative = getNative$6;
var getNative$5 = _getNative, root$5 = _root;
var Map$4 = getNative$5(root$5, "Map");
var _Map = Map$4;
var getNative$4 = _getNative;
var nativeCreate$4 = getNative$4(Object, "create");
var _nativeCreate = nativeCreate$4;
var nativeCreate$3 = _nativeCreate;
function hashClear$1() {
  this.__data__ = nativeCreate$3 ? nativeCreate$3(null) : {};
  this.size = 0;
}
var _hashClear = hashClear$1;
function hashDelete$1(key) {
  var result = this.has(key) && delete this.__data__[key];
  this.size -= result ? 1 : 0;
  return result;
}
var _hashDelete = hashDelete$1;
var nativeCreate$2 = _nativeCreate;
var HASH_UNDEFINED$2 = "__lodash_hash_undefined__";
var objectProto$2 = Object.prototype;
var hasOwnProperty$2 = objectProto$2.hasOwnProperty;
function hashGet$1(key) {
  var data = this.__data__;
  if (nativeCreate$2) {
    var result = data[key];
    return result === HASH_UNDEFINED$2 ? void 0 : result;
  }
  return hasOwnProperty$2.call(data, key) ? data[key] : void 0;
}
var _hashGet = hashGet$1;
var nativeCreate$1 = _nativeCreate;
var objectProto$1 = Object.prototype;
var hasOwnProperty$1 = objectProto$1.hasOwnProperty;
function hashHas$1(key) {
  var data = this.__data__;
  return nativeCreate$1 ? data[key] !== void 0 : hasOwnProperty$1.call(data, key);
}
var _hashHas = hashHas$1;
var nativeCreate = _nativeCreate;
var HASH_UNDEFINED$1 = "__lodash_hash_undefined__";
function hashSet$1(key, value) {
  var data = this.__data__;
  this.size += this.has(key) ? 0 : 1;
  data[key] = nativeCreate && value === void 0 ? HASH_UNDEFINED$1 : value;
  return this;
}
var _hashSet = hashSet$1;
var hashClear = _hashClear, hashDelete = _hashDelete, hashGet = _hashGet, hashHas = _hashHas, hashSet = _hashSet;
function Hash$1(entries) {
  var index2 = -1, length = entries == null ? 0 : entries.length;
  this.clear();
  while (++index2 < length) {
    var entry = entries[index2];
    this.set(entry[0], entry[1]);
  }
}
Hash$1.prototype.clear = hashClear;
Hash$1.prototype["delete"] = hashDelete;
Hash$1.prototype.get = hashGet;
Hash$1.prototype.has = hashHas;
Hash$1.prototype.set = hashSet;
var _Hash = Hash$1;
var Hash = _Hash, ListCache$2 = _ListCache, Map$3 = _Map;
function mapCacheClear$1() {
  this.size = 0;
  this.__data__ = {
    "hash": new Hash(),
    "map": new (Map$3 || ListCache$2)(),
    "string": new Hash()
  };
}
var _mapCacheClear = mapCacheClear$1;
function isKeyable$1(value) {
  var type = typeof value;
  return type == "string" || type == "number" || type == "symbol" || type == "boolean" ? value !== "__proto__" : value === null;
}
var _isKeyable = isKeyable$1;
var isKeyable = _isKeyable;
function getMapData$4(map, key) {
  var data = map.__data__;
  return isKeyable(key) ? data[typeof key == "string" ? "string" : "hash"] : data.map;
}
var _getMapData = getMapData$4;
var getMapData$3 = _getMapData;
function mapCacheDelete$1(key) {
  var result = getMapData$3(this, key)["delete"](key);
  this.size -= result ? 1 : 0;
  return result;
}
var _mapCacheDelete = mapCacheDelete$1;
var getMapData$2 = _getMapData;
function mapCacheGet$1(key) {
  return getMapData$2(this, key).get(key);
}
var _mapCacheGet = mapCacheGet$1;
var getMapData$1 = _getMapData;
function mapCacheHas$1(key) {
  return getMapData$1(this, key).has(key);
}
var _mapCacheHas = mapCacheHas$1;
var getMapData = _getMapData;
function mapCacheSet$1(key, value) {
  var data = getMapData(this, key), size = data.size;
  data.set(key, value);
  this.size += data.size == size ? 0 : 1;
  return this;
}
var _mapCacheSet = mapCacheSet$1;
var mapCacheClear = _mapCacheClear, mapCacheDelete = _mapCacheDelete, mapCacheGet = _mapCacheGet, mapCacheHas = _mapCacheHas, mapCacheSet = _mapCacheSet;
function MapCache$2(entries) {
  var index2 = -1, length = entries == null ? 0 : entries.length;
  this.clear();
  while (++index2 < length) {
    var entry = entries[index2];
    this.set(entry[0], entry[1]);
  }
}
MapCache$2.prototype.clear = mapCacheClear;
MapCache$2.prototype["delete"] = mapCacheDelete;
MapCache$2.prototype.get = mapCacheGet;
MapCache$2.prototype.has = mapCacheHas;
MapCache$2.prototype.set = mapCacheSet;
var _MapCache = MapCache$2;
var ListCache$1 = _ListCache, Map$2 = _Map, MapCache$1 = _MapCache;
var LARGE_ARRAY_SIZE = 200;
function stackSet$1(key, value) {
  var data = this.__data__;
  if (data instanceof ListCache$1) {
    var pairs = data.__data__;
    if (!Map$2 || pairs.length < LARGE_ARRAY_SIZE - 1) {
      pairs.push([key, value]);
      this.size = ++data.size;
      return this;
    }
    data = this.__data__ = new MapCache$1(pairs);
  }
  data.set(key, value);
  this.size = data.size;
  return this;
}
var _stackSet = stackSet$1;
var ListCache = _ListCache, stackClear = _stackClear, stackDelete = _stackDelete, stackGet = _stackGet, stackHas = _stackHas, stackSet = _stackSet;
function Stack(entries) {
  var data = this.__data__ = new ListCache(entries);
  this.size = data.size;
}
Stack.prototype.clear = stackClear;
Stack.prototype["delete"] = stackDelete;
Stack.prototype.get = stackGet;
Stack.prototype.has = stackHas;
Stack.prototype.set = stackSet;
var HASH_UNDEFINED = "__lodash_hash_undefined__";
function setCacheAdd$1(value) {
  this.__data__.set(value, HASH_UNDEFINED);
  return this;
}
var _setCacheAdd = setCacheAdd$1;
function setCacheHas$1(value) {
  return this.__data__.has(value);
}
var _setCacheHas = setCacheHas$1;
var MapCache = _MapCache, setCacheAdd = _setCacheAdd, setCacheHas = _setCacheHas;
function SetCache(values) {
  var index2 = -1, length = values == null ? 0 : values.length;
  this.__data__ = new MapCache();
  while (++index2 < length) {
    this.add(values[index2]);
  }
}
SetCache.prototype.add = SetCache.prototype.push = setCacheAdd;
SetCache.prototype.has = setCacheHas;
var root$4 = _root;
root$4.Uint8Array;
var Symbol$1 = _Symbol;
var symbolProto = Symbol$1 ? Symbol$1.prototype : void 0;
symbolProto ? symbolProto.valueOf : void 0;
function isObjectLike$2(value) {
  return value != null && typeof value == "object";
}
var isObjectLike_1 = isObjectLike$2;
var baseGetTag$1 = _baseGetTag, isObjectLike$1 = isObjectLike_1;
var argsTag = "[object Arguments]";
function baseIsArguments$1(value) {
  return isObjectLike$1(value) && baseGetTag$1(value) == argsTag;
}
var _baseIsArguments = baseIsArguments$1;
var baseIsArguments = _baseIsArguments, isObjectLike = isObjectLike_1;
var objectProto = Object.prototype;
var hasOwnProperty = objectProto.hasOwnProperty;
var propertyIsEnumerable = objectProto.propertyIsEnumerable;
baseIsArguments(/* @__PURE__ */ function() {
  return arguments;
}()) ? baseIsArguments : function(value) {
  return isObjectLike(value) && hasOwnProperty.call(value, "callee") && !propertyIsEnumerable.call(value, "callee");
};
var isBuffer = { exports: {} };
function stubFalse() {
  return false;
}
var stubFalse_1 = stubFalse;
isBuffer.exports;
(function(module, exports) {
  var root2 = _root, stubFalse2 = stubFalse_1;
  var freeExports = exports && !exports.nodeType && exports;
  var freeModule = freeExports && true && module && !module.nodeType && module;
  var moduleExports = freeModule && freeModule.exports === freeExports;
  var Buffer = moduleExports ? root2.Buffer : void 0;
  var nativeIsBuffer = Buffer ? Buffer.isBuffer : void 0;
  var isBuffer2 = nativeIsBuffer || stubFalse2;
  module.exports = isBuffer2;
})(isBuffer, isBuffer.exports);
isBuffer.exports;
var _nodeUtil = { exports: {} };
_nodeUtil.exports;
(function(module, exports) {
  var freeGlobal2 = _freeGlobal;
  var freeExports = exports && !exports.nodeType && exports;
  var freeModule = freeExports && true && module && !module.nodeType && module;
  var moduleExports = freeModule && freeModule.exports === freeExports;
  var freeProcess = moduleExports && freeGlobal2.process;
  var nodeUtil2 = function() {
    try {
      var types = freeModule && freeModule.require && freeModule.require("util").types;
      if (types) {
        return types;
      }
      return freeProcess && freeProcess.binding && freeProcess.binding("util");
    } catch (e) {
    }
  }();
  module.exports = nodeUtil2;
})(_nodeUtil, _nodeUtil.exports);
var _nodeUtilExports = _nodeUtil.exports;
var nodeUtil = _nodeUtilExports;
nodeUtil && nodeUtil.isTypedArray;
var getNative$3 = _getNative, root$3 = _root;
var DataView$1 = getNative$3(root$3, "DataView");
var _DataView = DataView$1;
var getNative$2 = _getNative, root$2 = _root;
var Promise$2 = getNative$2(root$2, "Promise");
var _Promise = Promise$2;
var getNative$1 = _getNative, root$1 = _root;
var Set$2 = getNative$1(root$1, "Set");
var _Set = Set$2;
var getNative = _getNative, root = _root;
var WeakMap$2 = getNative(root, "WeakMap");
var _WeakMap = WeakMap$2;
var DataView = _DataView, Map$1 = _Map, Promise$1 = _Promise, Set$1 = _Set, WeakMap$1 = _WeakMap, baseGetTag = _baseGetTag, toSource = _toSource;
var mapTag = "[object Map]", objectTag = "[object Object]", promiseTag = "[object Promise]", setTag = "[object Set]", weakMapTag = "[object WeakMap]";
var dataViewTag = "[object DataView]";
var dataViewCtorString = toSource(DataView), mapCtorString = toSource(Map$1), promiseCtorString = toSource(Promise$1), setCtorString = toSource(Set$1), weakMapCtorString = toSource(WeakMap$1);
var getTag = baseGetTag;
if (DataView && getTag(new DataView(new ArrayBuffer(1))) != dataViewTag || Map$1 && getTag(new Map$1()) != mapTag || Promise$1 && getTag(Promise$1.resolve()) != promiseTag || Set$1 && getTag(new Set$1()) != setTag || WeakMap$1 && getTag(new WeakMap$1()) != weakMapTag) {
  getTag = function(value) {
    var result = baseGetTag(value), Ctor = result == objectTag ? value.constructor : void 0, ctorString = Ctor ? toSource(Ctor) : "";
    if (ctorString) {
      switch (ctorString) {
        case dataViewCtorString:
          return dataViewTag;
        case mapCtorString:
          return mapTag;
        case promiseCtorString:
          return promiseTag;
        case setCtorString:
          return setTag;
        case weakMapCtorString:
          return weakMapTag;
      }
    }
    return result;
  };
}
const createStore = function() {
  let initialState = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
  const subscriptions = /* @__PURE__ */ new Set();
  let state = initialState;
  return {
    getState: () => state,
    subscribe: (callback) => {
      subscriptions.add(callback);
    },
    unsubscribe: (callback) => {
      subscriptions.delete(callback);
    },
    mutate: (mutation) => {
      state = mutation(state);
      for (const callback of subscriptions) {
        callback(state);
      }
    }
  };
};
const GlobalStateContext = /* @__PURE__ */ React.createContext(createStore());
const GlobalStateProvider = (_ref) => {
  let {
    store,
    children
  } = _ref;
  return /* @__PURE__ */ React.createElement(GlobalStateContext.Provider, {
    value: store
  }, children);
};
GlobalStateProvider.propTypes = {
  children: PropTypes.node,
  store: PropTypes.shape({})
};
const noopOfflineInterface = {
  pwaEnabled: false,
  latestIsConnected: false,
  subscribeToDhis2ConnectionStatus: () => () => void 0,
  startRecording: async () => void 0,
  getCachedSections: async () => [],
  removeSection: async () => false
};
const OfflineInterfaceContext = /* @__PURE__ */ reactExports.createContext(noopOfflineInterface);
function OfflineInterfaceProvider(_ref) {
  let {
    offlineInterface,
    children
  } = _ref;
  return /* @__PURE__ */ React.createElement(OfflineInterfaceContext.Provider, {
    value: offlineInterface
  }, children);
}
OfflineInterfaceProvider.propTypes = {
  children: PropTypes.node,
  offlineInterface: PropTypes.shape({
    init: PropTypes.func
  })
};
function useOfflineInterface() {
  const offlineInterface = reactExports.useContext(OfflineInterfaceContext);
  if (offlineInterface === void 0) {
    throw new Error("Offline interface context not found. If this app is using the app platform, make sure `pwa: { enabled: true }` is in d2.config.js. If this is not a platform app, make sure your app is wrapped with an app-runtime <Provider> or an <OfflineProvider> from app-service-offline.");
  }
  return offlineInterface;
}
function getSectionsById(sectionsArray) {
  return sectionsArray.reduce((result, _ref) => {
    let {
      sectionId,
      lastUpdated
    } = _ref;
    return {
      ...result,
      [sectionId]: {
        lastUpdated
      }
    };
  }, {});
}
function createCacheableSectionStore() {
  const initialState = {
    recordingStates: {},
    cachedSections: {}
  };
  return createStore(initialState);
}
function useConst(factory) {
  const ref = React.useRef(null);
  if (ref.current === null) {
    ref.current = factory();
  }
  return ref.current;
}
function CacheableSectionProvider(_ref2) {
  let {
    children
  } = _ref2;
  const offlineInterface = useOfflineInterface();
  const store = useConst(createCacheableSectionStore);
  React.useEffect(() => {
    if (offlineInterface) {
      offlineInterface.getCachedSections().then((sections) => {
        store.mutate((state) => ({
          ...state,
          cachedSections: getSectionsById(sections)
        }));
      });
    }
  }, [store, offlineInterface]);
  return /* @__PURE__ */ React.createElement(GlobalStateProvider, {
    store
  }, children);
}
CacheableSectionProvider.propTypes = {
  children: PropTypes.node
};
var lodash = { exports: {} };
/**
 * @license
 * Lodash <https://lodash.com/>
 * Copyright OpenJS Foundation and other contributors <https://openjsf.org/>
 * Released under MIT license <https://lodash.com/license>
 * Based on Underscore.js 1.8.3 <http://underscorejs.org/LICENSE>
 * Copyright Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
 */
lodash.exports;
(function(module, exports) {
  (function() {
    var undefined$1;
    var VERSION = "4.17.21";
    var LARGE_ARRAY_SIZE2 = 200;
    var CORE_ERROR_TEXT = "Unsupported core-js use. Try https://npms.io/search?q=ponyfill.", FUNC_ERROR_TEXT = "Expected a function", INVALID_TEMPL_VAR_ERROR_TEXT = "Invalid `variable` option passed into `_.template`";
    var HASH_UNDEFINED2 = "__lodash_hash_undefined__";
    var MAX_MEMOIZE_SIZE = 500;
    var PLACEHOLDER = "__lodash_placeholder__";
    var CLONE_DEEP_FLAG = 1, CLONE_FLAT_FLAG = 2, CLONE_SYMBOLS_FLAG = 4;
    var COMPARE_PARTIAL_FLAG = 1, COMPARE_UNORDERED_FLAG = 2;
    var WRAP_BIND_FLAG = 1, WRAP_BIND_KEY_FLAG = 2, WRAP_CURRY_BOUND_FLAG = 4, WRAP_CURRY_FLAG = 8, WRAP_CURRY_RIGHT_FLAG = 16, WRAP_PARTIAL_FLAG = 32, WRAP_PARTIAL_RIGHT_FLAG = 64, WRAP_ARY_FLAG = 128, WRAP_REARG_FLAG = 256, WRAP_FLIP_FLAG = 512;
    var DEFAULT_TRUNC_LENGTH = 30, DEFAULT_TRUNC_OMISSION = "...";
    var HOT_COUNT = 800, HOT_SPAN = 16;
    var LAZY_FILTER_FLAG = 1, LAZY_MAP_FLAG = 2, LAZY_WHILE_FLAG = 3;
    var INFINITY = 1 / 0, MAX_SAFE_INTEGER = 9007199254740991, MAX_INTEGER = 17976931348623157e292, NAN = 0 / 0;
    var MAX_ARRAY_LENGTH = 4294967295, MAX_ARRAY_INDEX = MAX_ARRAY_LENGTH - 1, HALF_MAX_ARRAY_LENGTH = MAX_ARRAY_LENGTH >>> 1;
    var wrapFlags = [
      ["ary", WRAP_ARY_FLAG],
      ["bind", WRAP_BIND_FLAG],
      ["bindKey", WRAP_BIND_KEY_FLAG],
      ["curry", WRAP_CURRY_FLAG],
      ["curryRight", WRAP_CURRY_RIGHT_FLAG],
      ["flip", WRAP_FLIP_FLAG],
      ["partial", WRAP_PARTIAL_FLAG],
      ["partialRight", WRAP_PARTIAL_RIGHT_FLAG],
      ["rearg", WRAP_REARG_FLAG]
    ];
    var argsTag2 = "[object Arguments]", arrayTag = "[object Array]", asyncTag2 = "[object AsyncFunction]", boolTag = "[object Boolean]", dateTag = "[object Date]", domExcTag = "[object DOMException]", errorTag = "[object Error]", funcTag2 = "[object Function]", genTag2 = "[object GeneratorFunction]", mapTag2 = "[object Map]", numberTag = "[object Number]", nullTag2 = "[object Null]", objectTag2 = "[object Object]", promiseTag2 = "[object Promise]", proxyTag2 = "[object Proxy]", regexpTag = "[object RegExp]", setTag2 = "[object Set]", stringTag = "[object String]", symbolTag = "[object Symbol]", undefinedTag2 = "[object Undefined]", weakMapTag2 = "[object WeakMap]", weakSetTag = "[object WeakSet]";
    var arrayBufferTag = "[object ArrayBuffer]", dataViewTag2 = "[object DataView]", float32Tag = "[object Float32Array]", float64Tag = "[object Float64Array]", int8Tag = "[object Int8Array]", int16Tag = "[object Int16Array]", int32Tag = "[object Int32Array]", uint8Tag = "[object Uint8Array]", uint8ClampedTag = "[object Uint8ClampedArray]", uint16Tag = "[object Uint16Array]", uint32Tag = "[object Uint32Array]";
    var reEmptyStringLeading = /\b__p \+= '';/g, reEmptyStringMiddle = /\b(__p \+=) '' \+/g, reEmptyStringTrailing = /(__e\(.*?\)|\b__t\)) \+\n'';/g;
    var reEscapedHtml = /&(?:amp|lt|gt|quot|#39);/g, reUnescapedHtml = /[&<>"']/g, reHasEscapedHtml = RegExp(reEscapedHtml.source), reHasUnescapedHtml = RegExp(reUnescapedHtml.source);
    var reEscape = /<%-([\s\S]+?)%>/g, reEvaluate = /<%([\s\S]+?)%>/g, reInterpolate = /<%=([\s\S]+?)%>/g;
    var reIsDeepProp = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/, reIsPlainProp = /^\w*$/, rePropName = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g;
    var reRegExpChar2 = /[\\^$.*+?()[\]{}|]/g, reHasRegExpChar = RegExp(reRegExpChar2.source);
    var reTrimStart = /^\s+/;
    var reWhitespace = /\s/;
    var reWrapComment = /\{(?:\n\/\* \[wrapped with .+\] \*\/)?\n?/, reWrapDetails = /\{\n\/\* \[wrapped with (.+)\] \*/, reSplitDetails = /,? & /;
    var reAsciiWord = /[^\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7f]+/g;
    var reForbiddenIdentifierChars = /[()=,{}\[\]\/\s]/;
    var reEscapeChar = /\\(\\)?/g;
    var reEsTemplate = /\$\{([^\\}]*(?:\\.[^\\}]*)*)\}/g;
    var reFlags = /\w*$/;
    var reIsBadHex = /^[-+]0x[0-9a-f]+$/i;
    var reIsBinary = /^0b[01]+$/i;
    var reIsHostCtor2 = /^\[object .+?Constructor\]$/;
    var reIsOctal = /^0o[0-7]+$/i;
    var reIsUint = /^(?:0|[1-9]\d*)$/;
    var reLatin = /[\xc0-\xd6\xd8-\xf6\xf8-\xff\u0100-\u017f]/g;
    var reNoMatch = /($^)/;
    var reUnescapedString = /['\n\r\u2028\u2029\\]/g;
    var rsAstralRange = "\\ud800-\\udfff", rsComboMarksRange = "\\u0300-\\u036f", reComboHalfMarksRange = "\\ufe20-\\ufe2f", rsComboSymbolsRange = "\\u20d0-\\u20ff", rsComboRange = rsComboMarksRange + reComboHalfMarksRange + rsComboSymbolsRange, rsDingbatRange = "\\u2700-\\u27bf", rsLowerRange = "a-z\\xdf-\\xf6\\xf8-\\xff", rsMathOpRange = "\\xac\\xb1\\xd7\\xf7", rsNonCharRange = "\\x00-\\x2f\\x3a-\\x40\\x5b-\\x60\\x7b-\\xbf", rsPunctuationRange = "\\u2000-\\u206f", rsSpaceRange = " \\t\\x0b\\f\\xa0\\ufeff\\n\\r\\u2028\\u2029\\u1680\\u180e\\u2000\\u2001\\u2002\\u2003\\u2004\\u2005\\u2006\\u2007\\u2008\\u2009\\u200a\\u202f\\u205f\\u3000", rsUpperRange = "A-Z\\xc0-\\xd6\\xd8-\\xde", rsVarRange = "\\ufe0e\\ufe0f", rsBreakRange = rsMathOpRange + rsNonCharRange + rsPunctuationRange + rsSpaceRange;
    var rsApos = "['’]", rsAstral = "[" + rsAstralRange + "]", rsBreak = "[" + rsBreakRange + "]", rsCombo = "[" + rsComboRange + "]", rsDigits = "\\d+", rsDingbat = "[" + rsDingbatRange + "]", rsLower = "[" + rsLowerRange + "]", rsMisc = "[^" + rsAstralRange + rsBreakRange + rsDigits + rsDingbatRange + rsLowerRange + rsUpperRange + "]", rsFitz = "\\ud83c[\\udffb-\\udfff]", rsModifier = "(?:" + rsCombo + "|" + rsFitz + ")", rsNonAstral = "[^" + rsAstralRange + "]", rsRegional = "(?:\\ud83c[\\udde6-\\uddff]){2}", rsSurrPair = "[\\ud800-\\udbff][\\udc00-\\udfff]", rsUpper = "[" + rsUpperRange + "]", rsZWJ = "\\u200d";
    var rsMiscLower = "(?:" + rsLower + "|" + rsMisc + ")", rsMiscUpper = "(?:" + rsUpper + "|" + rsMisc + ")", rsOptContrLower = "(?:" + rsApos + "(?:d|ll|m|re|s|t|ve))?", rsOptContrUpper = "(?:" + rsApos + "(?:D|LL|M|RE|S|T|VE))?", reOptMod = rsModifier + "?", rsOptVar = "[" + rsVarRange + "]?", rsOptJoin = "(?:" + rsZWJ + "(?:" + [rsNonAstral, rsRegional, rsSurrPair].join("|") + ")" + rsOptVar + reOptMod + ")*", rsOrdLower = "\\d*(?:1st|2nd|3rd|(?![123])\\dth)(?=\\b|[A-Z_])", rsOrdUpper = "\\d*(?:1ST|2ND|3RD|(?![123])\\dTH)(?=\\b|[a-z_])", rsSeq = rsOptVar + reOptMod + rsOptJoin, rsEmoji = "(?:" + [rsDingbat, rsRegional, rsSurrPair].join("|") + ")" + rsSeq, rsSymbol = "(?:" + [rsNonAstral + rsCombo + "?", rsCombo, rsRegional, rsSurrPair, rsAstral].join("|") + ")";
    var reApos = RegExp(rsApos, "g");
    var reComboMark = RegExp(rsCombo, "g");
    var reUnicode = RegExp(rsFitz + "(?=" + rsFitz + ")|" + rsSymbol + rsSeq, "g");
    var reUnicodeWord = RegExp([
      rsUpper + "?" + rsLower + "+" + rsOptContrLower + "(?=" + [rsBreak, rsUpper, "$"].join("|") + ")",
      rsMiscUpper + "+" + rsOptContrUpper + "(?=" + [rsBreak, rsUpper + rsMiscLower, "$"].join("|") + ")",
      rsUpper + "?" + rsMiscLower + "+" + rsOptContrLower,
      rsUpper + "+" + rsOptContrUpper,
      rsOrdUpper,
      rsOrdLower,
      rsDigits,
      rsEmoji
    ].join("|"), "g");
    var reHasUnicode = RegExp("[" + rsZWJ + rsAstralRange + rsComboRange + rsVarRange + "]");
    var reHasUnicodeWord = /[a-z][A-Z]|[A-Z]{2}[a-z]|[0-9][a-zA-Z]|[a-zA-Z][0-9]|[^a-zA-Z0-9 ]/;
    var contextProps = [
      "Array",
      "Buffer",
      "DataView",
      "Date",
      "Error",
      "Float32Array",
      "Float64Array",
      "Function",
      "Int8Array",
      "Int16Array",
      "Int32Array",
      "Map",
      "Math",
      "Object",
      "Promise",
      "RegExp",
      "Set",
      "String",
      "Symbol",
      "TypeError",
      "Uint8Array",
      "Uint8ClampedArray",
      "Uint16Array",
      "Uint32Array",
      "WeakMap",
      "_",
      "clearTimeout",
      "isFinite",
      "parseInt",
      "setTimeout"
    ];
    var templateCounter = -1;
    var typedArrayTags = {};
    typedArrayTags[float32Tag] = typedArrayTags[float64Tag] = typedArrayTags[int8Tag] = typedArrayTags[int16Tag] = typedArrayTags[int32Tag] = typedArrayTags[uint8Tag] = typedArrayTags[uint8ClampedTag] = typedArrayTags[uint16Tag] = typedArrayTags[uint32Tag] = true;
    typedArrayTags[argsTag2] = typedArrayTags[arrayTag] = typedArrayTags[arrayBufferTag] = typedArrayTags[boolTag] = typedArrayTags[dataViewTag2] = typedArrayTags[dateTag] = typedArrayTags[errorTag] = typedArrayTags[funcTag2] = typedArrayTags[mapTag2] = typedArrayTags[numberTag] = typedArrayTags[objectTag2] = typedArrayTags[regexpTag] = typedArrayTags[setTag2] = typedArrayTags[stringTag] = typedArrayTags[weakMapTag2] = false;
    var cloneableTags = {};
    cloneableTags[argsTag2] = cloneableTags[arrayTag] = cloneableTags[arrayBufferTag] = cloneableTags[dataViewTag2] = cloneableTags[boolTag] = cloneableTags[dateTag] = cloneableTags[float32Tag] = cloneableTags[float64Tag] = cloneableTags[int8Tag] = cloneableTags[int16Tag] = cloneableTags[int32Tag] = cloneableTags[mapTag2] = cloneableTags[numberTag] = cloneableTags[objectTag2] = cloneableTags[regexpTag] = cloneableTags[setTag2] = cloneableTags[stringTag] = cloneableTags[symbolTag] = cloneableTags[uint8Tag] = cloneableTags[uint8ClampedTag] = cloneableTags[uint16Tag] = cloneableTags[uint32Tag] = true;
    cloneableTags[errorTag] = cloneableTags[funcTag2] = cloneableTags[weakMapTag2] = false;
    var deburredLetters = {
      // Latin-1 Supplement block.
      "À": "A",
      "Á": "A",
      "Â": "A",
      "Ã": "A",
      "Ä": "A",
      "Å": "A",
      "à": "a",
      "á": "a",
      "â": "a",
      "ã": "a",
      "ä": "a",
      "å": "a",
      "Ç": "C",
      "ç": "c",
      "Ð": "D",
      "ð": "d",
      "È": "E",
      "É": "E",
      "Ê": "E",
      "Ë": "E",
      "è": "e",
      "é": "e",
      "ê": "e",
      "ë": "e",
      "Ì": "I",
      "Í": "I",
      "Î": "I",
      "Ï": "I",
      "ì": "i",
      "í": "i",
      "î": "i",
      "ï": "i",
      "Ñ": "N",
      "ñ": "n",
      "Ò": "O",
      "Ó": "O",
      "Ô": "O",
      "Õ": "O",
      "Ö": "O",
      "Ø": "O",
      "ò": "o",
      "ó": "o",
      "ô": "o",
      "õ": "o",
      "ö": "o",
      "ø": "o",
      "Ù": "U",
      "Ú": "U",
      "Û": "U",
      "Ü": "U",
      "ù": "u",
      "ú": "u",
      "û": "u",
      "ü": "u",
      "Ý": "Y",
      "ý": "y",
      "ÿ": "y",
      "Æ": "Ae",
      "æ": "ae",
      "Þ": "Th",
      "þ": "th",
      "ß": "ss",
      // Latin Extended-A block.
      "Ā": "A",
      "Ă": "A",
      "Ą": "A",
      "ā": "a",
      "ă": "a",
      "ą": "a",
      "Ć": "C",
      "Ĉ": "C",
      "Ċ": "C",
      "Č": "C",
      "ć": "c",
      "ĉ": "c",
      "ċ": "c",
      "č": "c",
      "Ď": "D",
      "Đ": "D",
      "ď": "d",
      "đ": "d",
      "Ē": "E",
      "Ĕ": "E",
      "Ė": "E",
      "Ę": "E",
      "Ě": "E",
      "ē": "e",
      "ĕ": "e",
      "ė": "e",
      "ę": "e",
      "ě": "e",
      "Ĝ": "G",
      "Ğ": "G",
      "Ġ": "G",
      "Ģ": "G",
      "ĝ": "g",
      "ğ": "g",
      "ġ": "g",
      "ģ": "g",
      "Ĥ": "H",
      "Ħ": "H",
      "ĥ": "h",
      "ħ": "h",
      "Ĩ": "I",
      "Ī": "I",
      "Ĭ": "I",
      "Į": "I",
      "İ": "I",
      "ĩ": "i",
      "ī": "i",
      "ĭ": "i",
      "į": "i",
      "ı": "i",
      "Ĵ": "J",
      "ĵ": "j",
      "Ķ": "K",
      "ķ": "k",
      "ĸ": "k",
      "Ĺ": "L",
      "Ļ": "L",
      "Ľ": "L",
      "Ŀ": "L",
      "Ł": "L",
      "ĺ": "l",
      "ļ": "l",
      "ľ": "l",
      "ŀ": "l",
      "ł": "l",
      "Ń": "N",
      "Ņ": "N",
      "Ň": "N",
      "Ŋ": "N",
      "ń": "n",
      "ņ": "n",
      "ň": "n",
      "ŋ": "n",
      "Ō": "O",
      "Ŏ": "O",
      "Ő": "O",
      "ō": "o",
      "ŏ": "o",
      "ő": "o",
      "Ŕ": "R",
      "Ŗ": "R",
      "Ř": "R",
      "ŕ": "r",
      "ŗ": "r",
      "ř": "r",
      "Ś": "S",
      "Ŝ": "S",
      "Ş": "S",
      "Š": "S",
      "ś": "s",
      "ŝ": "s",
      "ş": "s",
      "š": "s",
      "Ţ": "T",
      "Ť": "T",
      "Ŧ": "T",
      "ţ": "t",
      "ť": "t",
      "ŧ": "t",
      "Ũ": "U",
      "Ū": "U",
      "Ŭ": "U",
      "Ů": "U",
      "Ű": "U",
      "Ų": "U",
      "ũ": "u",
      "ū": "u",
      "ŭ": "u",
      "ů": "u",
      "ű": "u",
      "ų": "u",
      "Ŵ": "W",
      "ŵ": "w",
      "Ŷ": "Y",
      "ŷ": "y",
      "Ÿ": "Y",
      "Ź": "Z",
      "Ż": "Z",
      "Ž": "Z",
      "ź": "z",
      "ż": "z",
      "ž": "z",
      "Ĳ": "IJ",
      "ĳ": "ij",
      "Œ": "Oe",
      "œ": "oe",
      "ŉ": "'n",
      "ſ": "s"
    };
    var htmlEscapes = {
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;"
    };
    var htmlUnescapes = {
      "&amp;": "&",
      "&lt;": "<",
      "&gt;": ">",
      "&quot;": '"',
      "&#39;": "'"
    };
    var stringEscapes = {
      "\\": "\\",
      "'": "'",
      "\n": "n",
      "\r": "r",
      "\u2028": "u2028",
      "\u2029": "u2029"
    };
    var freeParseFloat = parseFloat, freeParseInt = parseInt;
    var freeGlobal2 = typeof commonjsGlobal == "object" && commonjsGlobal && commonjsGlobal.Object === Object && commonjsGlobal;
    var freeSelf2 = typeof self == "object" && self && self.Object === Object && self;
    var root2 = freeGlobal2 || freeSelf2 || Function("return this")();
    var freeExports = exports && !exports.nodeType && exports;
    var freeModule = freeExports && true && module && !module.nodeType && module;
    var moduleExports = freeModule && freeModule.exports === freeExports;
    var freeProcess = moduleExports && freeGlobal2.process;
    var nodeUtil2 = function() {
      try {
        var types = freeModule && freeModule.require && freeModule.require("util").types;
        if (types) {
          return types;
        }
        return freeProcess && freeProcess.binding && freeProcess.binding("util");
      } catch (e) {
      }
    }();
    var nodeIsArrayBuffer = nodeUtil2 && nodeUtil2.isArrayBuffer, nodeIsDate = nodeUtil2 && nodeUtil2.isDate, nodeIsMap = nodeUtil2 && nodeUtil2.isMap, nodeIsRegExp = nodeUtil2 && nodeUtil2.isRegExp, nodeIsSet = nodeUtil2 && nodeUtil2.isSet, nodeIsTypedArray = nodeUtil2 && nodeUtil2.isTypedArray;
    function apply(func, thisArg, args) {
      switch (args.length) {
        case 0:
          return func.call(thisArg);
        case 1:
          return func.call(thisArg, args[0]);
        case 2:
          return func.call(thisArg, args[0], args[1]);
        case 3:
          return func.call(thisArg, args[0], args[1], args[2]);
      }
      return func.apply(thisArg, args);
    }
    function arrayAggregator(array, setter, iteratee, accumulator) {
      var index2 = -1, length = array == null ? 0 : array.length;
      while (++index2 < length) {
        var value = array[index2];
        setter(accumulator, value, iteratee(value), array);
      }
      return accumulator;
    }
    function arrayEach(array, iteratee) {
      var index2 = -1, length = array == null ? 0 : array.length;
      while (++index2 < length) {
        if (iteratee(array[index2], index2, array) === false) {
          break;
        }
      }
      return array;
    }
    function arrayEachRight(array, iteratee) {
      var length = array == null ? 0 : array.length;
      while (length--) {
        if (iteratee(array[length], length, array) === false) {
          break;
        }
      }
      return array;
    }
    function arrayEvery(array, predicate) {
      var index2 = -1, length = array == null ? 0 : array.length;
      while (++index2 < length) {
        if (!predicate(array[index2], index2, array)) {
          return false;
        }
      }
      return true;
    }
    function arrayFilter(array, predicate) {
      var index2 = -1, length = array == null ? 0 : array.length, resIndex = 0, result = [];
      while (++index2 < length) {
        var value = array[index2];
        if (predicate(value, index2, array)) {
          result[resIndex++] = value;
        }
      }
      return result;
    }
    function arrayIncludes(array, value) {
      var length = array == null ? 0 : array.length;
      return !!length && baseIndexOf(array, value, 0) > -1;
    }
    function arrayIncludesWith(array, value, comparator) {
      var index2 = -1, length = array == null ? 0 : array.length;
      while (++index2 < length) {
        if (comparator(value, array[index2])) {
          return true;
        }
      }
      return false;
    }
    function arrayMap(array, iteratee) {
      var index2 = -1, length = array == null ? 0 : array.length, result = Array(length);
      while (++index2 < length) {
        result[index2] = iteratee(array[index2], index2, array);
      }
      return result;
    }
    function arrayPush(array, values) {
      var index2 = -1, length = values.length, offset2 = array.length;
      while (++index2 < length) {
        array[offset2 + index2] = values[index2];
      }
      return array;
    }
    function arrayReduce(array, iteratee, accumulator, initAccum) {
      var index2 = -1, length = array == null ? 0 : array.length;
      if (initAccum && length) {
        accumulator = array[++index2];
      }
      while (++index2 < length) {
        accumulator = iteratee(accumulator, array[index2], index2, array);
      }
      return accumulator;
    }
    function arrayReduceRight(array, iteratee, accumulator, initAccum) {
      var length = array == null ? 0 : array.length;
      if (initAccum && length) {
        accumulator = array[--length];
      }
      while (length--) {
        accumulator = iteratee(accumulator, array[length], length, array);
      }
      return accumulator;
    }
    function arraySome(array, predicate) {
      var index2 = -1, length = array == null ? 0 : array.length;
      while (++index2 < length) {
        if (predicate(array[index2], index2, array)) {
          return true;
        }
      }
      return false;
    }
    var asciiSize = baseProperty("length");
    function asciiToArray(string) {
      return string.split("");
    }
    function asciiWords(string) {
      return string.match(reAsciiWord) || [];
    }
    function baseFindKey(collection, predicate, eachFunc) {
      var result;
      eachFunc(collection, function(value, key, collection2) {
        if (predicate(value, key, collection2)) {
          result = key;
          return false;
        }
      });
      return result;
    }
    function baseFindIndex(array, predicate, fromIndex, fromRight) {
      var length = array.length, index2 = fromIndex + (fromRight ? 1 : -1);
      while (fromRight ? index2-- : ++index2 < length) {
        if (predicate(array[index2], index2, array)) {
          return index2;
        }
      }
      return -1;
    }
    function baseIndexOf(array, value, fromIndex) {
      return value === value ? strictIndexOf(array, value, fromIndex) : baseFindIndex(array, baseIsNaN, fromIndex);
    }
    function baseIndexOfWith(array, value, fromIndex, comparator) {
      var index2 = fromIndex - 1, length = array.length;
      while (++index2 < length) {
        if (comparator(array[index2], value)) {
          return index2;
        }
      }
      return -1;
    }
    function baseIsNaN(value) {
      return value !== value;
    }
    function baseMean(array, iteratee) {
      var length = array == null ? 0 : array.length;
      return length ? baseSum(array, iteratee) / length : NAN;
    }
    function baseProperty(key) {
      return function(object) {
        return object == null ? undefined$1 : object[key];
      };
    }
    function basePropertyOf(object) {
      return function(key) {
        return object == null ? undefined$1 : object[key];
      };
    }
    function baseReduce(collection, iteratee, accumulator, initAccum, eachFunc) {
      eachFunc(collection, function(value, index2, collection2) {
        accumulator = initAccum ? (initAccum = false, value) : iteratee(accumulator, value, index2, collection2);
      });
      return accumulator;
    }
    function baseSortBy(array, comparer) {
      var length = array.length;
      array.sort(comparer);
      while (length--) {
        array[length] = array[length].value;
      }
      return array;
    }
    function baseSum(array, iteratee) {
      var result, index2 = -1, length = array.length;
      while (++index2 < length) {
        var current = iteratee(array[index2]);
        if (current !== undefined$1) {
          result = result === undefined$1 ? current : result + current;
        }
      }
      return result;
    }
    function baseTimes(n, iteratee) {
      var index2 = -1, result = Array(n);
      while (++index2 < n) {
        result[index2] = iteratee(index2);
      }
      return result;
    }
    function baseToPairs(object, props) {
      return arrayMap(props, function(key) {
        return [key, object[key]];
      });
    }
    function baseTrim(string) {
      return string ? string.slice(0, trimmedEndIndex(string) + 1).replace(reTrimStart, "") : string;
    }
    function baseUnary(func) {
      return function(value) {
        return func(value);
      };
    }
    function baseValues(object, props) {
      return arrayMap(props, function(key) {
        return object[key];
      });
    }
    function cacheHas(cache, key) {
      return cache.has(key);
    }
    function charsStartIndex(strSymbols, chrSymbols) {
      var index2 = -1, length = strSymbols.length;
      while (++index2 < length && baseIndexOf(chrSymbols, strSymbols[index2], 0) > -1) {
      }
      return index2;
    }
    function charsEndIndex(strSymbols, chrSymbols) {
      var index2 = strSymbols.length;
      while (index2-- && baseIndexOf(chrSymbols, strSymbols[index2], 0) > -1) {
      }
      return index2;
    }
    function countHolders(array, placeholder2) {
      var length = array.length, result = 0;
      while (length--) {
        if (array[length] === placeholder2) {
          ++result;
        }
      }
      return result;
    }
    var deburrLetter = basePropertyOf(deburredLetters);
    var escapeHtmlChar = basePropertyOf(htmlEscapes);
    function escapeStringChar(chr) {
      return "\\" + stringEscapes[chr];
    }
    function getValue2(object, key) {
      return object == null ? undefined$1 : object[key];
    }
    function hasUnicode(string) {
      return reHasUnicode.test(string);
    }
    function hasUnicodeWord(string) {
      return reHasUnicodeWord.test(string);
    }
    function iteratorToArray(iterator) {
      var data, result = [];
      while (!(data = iterator.next()).done) {
        result.push(data.value);
      }
      return result;
    }
    function mapToArray(map) {
      var index2 = -1, result = Array(map.size);
      map.forEach(function(value, key) {
        result[++index2] = [key, value];
      });
      return result;
    }
    function overArg(func, transform) {
      return function(arg) {
        return func(transform(arg));
      };
    }
    function replaceHolders(array, placeholder2) {
      var index2 = -1, length = array.length, resIndex = 0, result = [];
      while (++index2 < length) {
        var value = array[index2];
        if (value === placeholder2 || value === PLACEHOLDER) {
          array[index2] = PLACEHOLDER;
          result[resIndex++] = index2;
        }
      }
      return result;
    }
    function setToArray(set) {
      var index2 = -1, result = Array(set.size);
      set.forEach(function(value) {
        result[++index2] = value;
      });
      return result;
    }
    function setToPairs(set) {
      var index2 = -1, result = Array(set.size);
      set.forEach(function(value) {
        result[++index2] = [value, value];
      });
      return result;
    }
    function strictIndexOf(array, value, fromIndex) {
      var index2 = fromIndex - 1, length = array.length;
      while (++index2 < length) {
        if (array[index2] === value) {
          return index2;
        }
      }
      return -1;
    }
    function strictLastIndexOf(array, value, fromIndex) {
      var index2 = fromIndex + 1;
      while (index2--) {
        if (array[index2] === value) {
          return index2;
        }
      }
      return index2;
    }
    function stringSize(string) {
      return hasUnicode(string) ? unicodeSize(string) : asciiSize(string);
    }
    function stringToArray(string) {
      return hasUnicode(string) ? unicodeToArray(string) : asciiToArray(string);
    }
    function trimmedEndIndex(string) {
      var index2 = string.length;
      while (index2-- && reWhitespace.test(string.charAt(index2))) {
      }
      return index2;
    }
    var unescapeHtmlChar = basePropertyOf(htmlUnescapes);
    function unicodeSize(string) {
      var result = reUnicode.lastIndex = 0;
      while (reUnicode.test(string)) {
        ++result;
      }
      return result;
    }
    function unicodeToArray(string) {
      return string.match(reUnicode) || [];
    }
    function unicodeWords(string) {
      return string.match(reUnicodeWord) || [];
    }
    var runInContext = function runInContext2(context) {
      context = context == null ? root2 : _22.defaults(root2.Object(), context, _22.pick(root2, contextProps));
      var Array2 = context.Array, Date2 = context.Date, Error2 = context.Error, Function2 = context.Function, Math2 = context.Math, Object2 = context.Object, RegExp2 = context.RegExp, String2 = context.String, TypeError2 = context.TypeError;
      var arrayProto2 = Array2.prototype, funcProto2 = Function2.prototype, objectProto2 = Object2.prototype;
      var coreJsData2 = context["__core-js_shared__"];
      var funcToString2 = funcProto2.toString;
      var hasOwnProperty2 = objectProto2.hasOwnProperty;
      var idCounter = 0;
      var maskSrcKey2 = function() {
        var uid = /[^.]+$/.exec(coreJsData2 && coreJsData2.keys && coreJsData2.keys.IE_PROTO || "");
        return uid ? "Symbol(src)_1." + uid : "";
      }();
      var nativeObjectToString2 = objectProto2.toString;
      var objectCtorString = funcToString2.call(Object2);
      var oldDash = root2._;
      var reIsNative2 = RegExp2(
        "^" + funcToString2.call(hasOwnProperty2).replace(reRegExpChar2, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"
      );
      var Buffer = moduleExports ? context.Buffer : undefined$1, Symbol2 = context.Symbol, Uint8Array = context.Uint8Array, allocUnsafe = Buffer ? Buffer.allocUnsafe : undefined$1, getPrototype = overArg(Object2.getPrototypeOf, Object2), objectCreate = Object2.create, propertyIsEnumerable2 = objectProto2.propertyIsEnumerable, splice2 = arrayProto2.splice, spreadableSymbol = Symbol2 ? Symbol2.isConcatSpreadable : undefined$1, symIterator = Symbol2 ? Symbol2.iterator : undefined$1, symToStringTag2 = Symbol2 ? Symbol2.toStringTag : undefined$1;
      var defineProperty = function() {
        try {
          var func = getNative2(Object2, "defineProperty");
          func({}, "", {});
          return func;
        } catch (e) {
        }
      }();
      var ctxClearTimeout = context.clearTimeout !== root2.clearTimeout && context.clearTimeout, ctxNow = Date2 && Date2.now !== root2.Date.now && Date2.now, ctxSetTimeout = context.setTimeout !== root2.setTimeout && context.setTimeout;
      var nativeCeil = Math2.ceil, nativeFloor = Math2.floor, nativeGetSymbols = Object2.getOwnPropertySymbols, nativeIsBuffer = Buffer ? Buffer.isBuffer : undefined$1, nativeIsFinite = context.isFinite, nativeJoin = arrayProto2.join, nativeKeys = overArg(Object2.keys, Object2), nativeMax = Math2.max, nativeMin = Math2.min, nativeNow = Date2.now, nativeParseInt = context.parseInt, nativeRandom = Math2.random, nativeReverse = arrayProto2.reverse;
      var DataView2 = getNative2(context, "DataView"), Map2 = getNative2(context, "Map"), Promise2 = getNative2(context, "Promise"), Set2 = getNative2(context, "Set"), WeakMap2 = getNative2(context, "WeakMap"), nativeCreate2 = getNative2(Object2, "create");
      var metaMap = WeakMap2 && new WeakMap2();
      var realNames = {};
      var dataViewCtorString2 = toSource2(DataView2), mapCtorString2 = toSource2(Map2), promiseCtorString2 = toSource2(Promise2), setCtorString2 = toSource2(Set2), weakMapCtorString2 = toSource2(WeakMap2);
      var symbolProto2 = Symbol2 ? Symbol2.prototype : undefined$1, symbolValueOf = symbolProto2 ? symbolProto2.valueOf : undefined$1, symbolToString = symbolProto2 ? symbolProto2.toString : undefined$1;
      function lodash2(value) {
        if (isObjectLike2(value) && !isArray(value) && !(value instanceof LazyWrapper)) {
          if (value instanceof LodashWrapper) {
            return value;
          }
          if (hasOwnProperty2.call(value, "__wrapped__")) {
            return wrapperClone(value);
          }
        }
        return new LodashWrapper(value);
      }
      var baseCreate = /* @__PURE__ */ function() {
        function object() {
        }
        return function(proto) {
          if (!isObject2(proto)) {
            return {};
          }
          if (objectCreate) {
            return objectCreate(proto);
          }
          object.prototype = proto;
          var result2 = new object();
          object.prototype = undefined$1;
          return result2;
        };
      }();
      function baseLodash() {
      }
      function LodashWrapper(value, chainAll) {
        this.__wrapped__ = value;
        this.__actions__ = [];
        this.__chain__ = !!chainAll;
        this.__index__ = 0;
        this.__values__ = undefined$1;
      }
      lodash2.templateSettings = {
        /**
         * Used to detect `data` property values to be HTML-escaped.
         *
         * @memberOf _.templateSettings
         * @type {RegExp}
         */
        "escape": reEscape,
        /**
         * Used to detect code to be evaluated.
         *
         * @memberOf _.templateSettings
         * @type {RegExp}
         */
        "evaluate": reEvaluate,
        /**
         * Used to detect `data` property values to inject.
         *
         * @memberOf _.templateSettings
         * @type {RegExp}
         */
        "interpolate": reInterpolate,
        /**
         * Used to reference the data object in the template text.
         *
         * @memberOf _.templateSettings
         * @type {string}
         */
        "variable": "",
        /**
         * Used to import variables into the compiled template.
         *
         * @memberOf _.templateSettings
         * @type {Object}
         */
        "imports": {
          /**
           * A reference to the `lodash` function.
           *
           * @memberOf _.templateSettings.imports
           * @type {Function}
           */
          "_": lodash2
        }
      };
      lodash2.prototype = baseLodash.prototype;
      lodash2.prototype.constructor = lodash2;
      LodashWrapper.prototype = baseCreate(baseLodash.prototype);
      LodashWrapper.prototype.constructor = LodashWrapper;
      function LazyWrapper(value) {
        this.__wrapped__ = value;
        this.__actions__ = [];
        this.__dir__ = 1;
        this.__filtered__ = false;
        this.__iteratees__ = [];
        this.__takeCount__ = MAX_ARRAY_LENGTH;
        this.__views__ = [];
      }
      function lazyClone() {
        var result2 = new LazyWrapper(this.__wrapped__);
        result2.__actions__ = copyArray(this.__actions__);
        result2.__dir__ = this.__dir__;
        result2.__filtered__ = this.__filtered__;
        result2.__iteratees__ = copyArray(this.__iteratees__);
        result2.__takeCount__ = this.__takeCount__;
        result2.__views__ = copyArray(this.__views__);
        return result2;
      }
      function lazyReverse() {
        if (this.__filtered__) {
          var result2 = new LazyWrapper(this);
          result2.__dir__ = -1;
          result2.__filtered__ = true;
        } else {
          result2 = this.clone();
          result2.__dir__ *= -1;
        }
        return result2;
      }
      function lazyValue() {
        var array = this.__wrapped__.value(), dir = this.__dir__, isArr = isArray(array), isRight = dir < 0, arrLength = isArr ? array.length : 0, view = getView(0, arrLength, this.__views__), start2 = view.start, end2 = view.end, length = end2 - start2, index2 = isRight ? end2 : start2 - 1, iteratees = this.__iteratees__, iterLength = iteratees.length, resIndex = 0, takeCount = nativeMin(length, this.__takeCount__);
        if (!isArr || !isRight && arrLength == length && takeCount == length) {
          return baseWrapperValue(array, this.__actions__);
        }
        var result2 = [];
        outer:
          while (length-- && resIndex < takeCount) {
            index2 += dir;
            var iterIndex = -1, value = array[index2];
            while (++iterIndex < iterLength) {
              var data = iteratees[iterIndex], iteratee2 = data.iteratee, type = data.type, computed = iteratee2(value);
              if (type == LAZY_MAP_FLAG) {
                value = computed;
              } else if (!computed) {
                if (type == LAZY_FILTER_FLAG) {
                  continue outer;
                } else {
                  break outer;
                }
              }
            }
            result2[resIndex++] = value;
          }
        return result2;
      }
      LazyWrapper.prototype = baseCreate(baseLodash.prototype);
      LazyWrapper.prototype.constructor = LazyWrapper;
      function Hash2(entries) {
        var index2 = -1, length = entries == null ? 0 : entries.length;
        this.clear();
        while (++index2 < length) {
          var entry = entries[index2];
          this.set(entry[0], entry[1]);
        }
      }
      function hashClear2() {
        this.__data__ = nativeCreate2 ? nativeCreate2(null) : {};
        this.size = 0;
      }
      function hashDelete2(key) {
        var result2 = this.has(key) && delete this.__data__[key];
        this.size -= result2 ? 1 : 0;
        return result2;
      }
      function hashGet2(key) {
        var data = this.__data__;
        if (nativeCreate2) {
          var result2 = data[key];
          return result2 === HASH_UNDEFINED2 ? undefined$1 : result2;
        }
        return hasOwnProperty2.call(data, key) ? data[key] : undefined$1;
      }
      function hashHas2(key) {
        var data = this.__data__;
        return nativeCreate2 ? data[key] !== undefined$1 : hasOwnProperty2.call(data, key);
      }
      function hashSet2(key, value) {
        var data = this.__data__;
        this.size += this.has(key) ? 0 : 1;
        data[key] = nativeCreate2 && value === undefined$1 ? HASH_UNDEFINED2 : value;
        return this;
      }
      Hash2.prototype.clear = hashClear2;
      Hash2.prototype["delete"] = hashDelete2;
      Hash2.prototype.get = hashGet2;
      Hash2.prototype.has = hashHas2;
      Hash2.prototype.set = hashSet2;
      function ListCache2(entries) {
        var index2 = -1, length = entries == null ? 0 : entries.length;
        this.clear();
        while (++index2 < length) {
          var entry = entries[index2];
          this.set(entry[0], entry[1]);
        }
      }
      function listCacheClear2() {
        this.__data__ = [];
        this.size = 0;
      }
      function listCacheDelete2(key) {
        var data = this.__data__, index2 = assocIndexOf2(data, key);
        if (index2 < 0) {
          return false;
        }
        var lastIndex = data.length - 1;
        if (index2 == lastIndex) {
          data.pop();
        } else {
          splice2.call(data, index2, 1);
        }
        --this.size;
        return true;
      }
      function listCacheGet2(key) {
        var data = this.__data__, index2 = assocIndexOf2(data, key);
        return index2 < 0 ? undefined$1 : data[index2][1];
      }
      function listCacheHas2(key) {
        return assocIndexOf2(this.__data__, key) > -1;
      }
      function listCacheSet2(key, value) {
        var data = this.__data__, index2 = assocIndexOf2(data, key);
        if (index2 < 0) {
          ++this.size;
          data.push([key, value]);
        } else {
          data[index2][1] = value;
        }
        return this;
      }
      ListCache2.prototype.clear = listCacheClear2;
      ListCache2.prototype["delete"] = listCacheDelete2;
      ListCache2.prototype.get = listCacheGet2;
      ListCache2.prototype.has = listCacheHas2;
      ListCache2.prototype.set = listCacheSet2;
      function MapCache2(entries) {
        var index2 = -1, length = entries == null ? 0 : entries.length;
        this.clear();
        while (++index2 < length) {
          var entry = entries[index2];
          this.set(entry[0], entry[1]);
        }
      }
      function mapCacheClear2() {
        this.size = 0;
        this.__data__ = {
          "hash": new Hash2(),
          "map": new (Map2 || ListCache2)(),
          "string": new Hash2()
        };
      }
      function mapCacheDelete2(key) {
        var result2 = getMapData2(this, key)["delete"](key);
        this.size -= result2 ? 1 : 0;
        return result2;
      }
      function mapCacheGet2(key) {
        return getMapData2(this, key).get(key);
      }
      function mapCacheHas2(key) {
        return getMapData2(this, key).has(key);
      }
      function mapCacheSet2(key, value) {
        var data = getMapData2(this, key), size2 = data.size;
        data.set(key, value);
        this.size += data.size == size2 ? 0 : 1;
        return this;
      }
      MapCache2.prototype.clear = mapCacheClear2;
      MapCache2.prototype["delete"] = mapCacheDelete2;
      MapCache2.prototype.get = mapCacheGet2;
      MapCache2.prototype.has = mapCacheHas2;
      MapCache2.prototype.set = mapCacheSet2;
      function SetCache2(values2) {
        var index2 = -1, length = values2 == null ? 0 : values2.length;
        this.__data__ = new MapCache2();
        while (++index2 < length) {
          this.add(values2[index2]);
        }
      }
      function setCacheAdd2(value) {
        this.__data__.set(value, HASH_UNDEFINED2);
        return this;
      }
      function setCacheHas2(value) {
        return this.__data__.has(value);
      }
      SetCache2.prototype.add = SetCache2.prototype.push = setCacheAdd2;
      SetCache2.prototype.has = setCacheHas2;
      function Stack2(entries) {
        var data = this.__data__ = new ListCache2(entries);
        this.size = data.size;
      }
      function stackClear2() {
        this.__data__ = new ListCache2();
        this.size = 0;
      }
      function stackDelete2(key) {
        var data = this.__data__, result2 = data["delete"](key);
        this.size = data.size;
        return result2;
      }
      function stackGet2(key) {
        return this.__data__.get(key);
      }
      function stackHas2(key) {
        return this.__data__.has(key);
      }
      function stackSet2(key, value) {
        var data = this.__data__;
        if (data instanceof ListCache2) {
          var pairs = data.__data__;
          if (!Map2 || pairs.length < LARGE_ARRAY_SIZE2 - 1) {
            pairs.push([key, value]);
            this.size = ++data.size;
            return this;
          }
          data = this.__data__ = new MapCache2(pairs);
        }
        data.set(key, value);
        this.size = data.size;
        return this;
      }
      Stack2.prototype.clear = stackClear2;
      Stack2.prototype["delete"] = stackDelete2;
      Stack2.prototype.get = stackGet2;
      Stack2.prototype.has = stackHas2;
      Stack2.prototype.set = stackSet2;
      function arrayLikeKeys(value, inherited) {
        var isArr = isArray(value), isArg = !isArr && isArguments(value), isBuff = !isArr && !isArg && isBuffer2(value), isType = !isArr && !isArg && !isBuff && isTypedArray(value), skipIndexes = isArr || isArg || isBuff || isType, result2 = skipIndexes ? baseTimes(value.length, String2) : [], length = result2.length;
        for (var key in value) {
          if ((inherited || hasOwnProperty2.call(value, key)) && !(skipIndexes && // Safari 9 has enumerable `arguments.length` in strict mode.
          (key == "length" || // Node.js 0.10 has enumerable non-index properties on buffers.
          isBuff && (key == "offset" || key == "parent") || // PhantomJS 2 has enumerable non-index properties on typed arrays.
          isType && (key == "buffer" || key == "byteLength" || key == "byteOffset") || // Skip index properties.
          isIndex(key, length)))) {
            result2.push(key);
          }
        }
        return result2;
      }
      function arraySample(array) {
        var length = array.length;
        return length ? array[baseRandom(0, length - 1)] : undefined$1;
      }
      function arraySampleSize(array, n) {
        return shuffleSelf(copyArray(array), baseClamp(n, 0, array.length));
      }
      function arrayShuffle(array) {
        return shuffleSelf(copyArray(array));
      }
      function assignMergeValue(object, key, value) {
        if (value !== undefined$1 && !eq2(object[key], value) || value === undefined$1 && !(key in object)) {
          baseAssignValue(object, key, value);
        }
      }
      function assignValue(object, key, value) {
        var objValue = object[key];
        if (!(hasOwnProperty2.call(object, key) && eq2(objValue, value)) || value === undefined$1 && !(key in object)) {
          baseAssignValue(object, key, value);
        }
      }
      function assocIndexOf2(array, key) {
        var length = array.length;
        while (length--) {
          if (eq2(array[length][0], key)) {
            return length;
          }
        }
        return -1;
      }
      function baseAggregator(collection, setter, iteratee2, accumulator) {
        baseEach(collection, function(value, key, collection2) {
          setter(accumulator, value, iteratee2(value), collection2);
        });
        return accumulator;
      }
      function baseAssign(object, source) {
        return object && copyObject(source, keys(source), object);
      }
      function baseAssignIn(object, source) {
        return object && copyObject(source, keysIn(source), object);
      }
      function baseAssignValue(object, key, value) {
        if (key == "__proto__" && defineProperty) {
          defineProperty(object, key, {
            "configurable": true,
            "enumerable": true,
            "value": value,
            "writable": true
          });
        } else {
          object[key] = value;
        }
      }
      function baseAt(object, paths) {
        var index2 = -1, length = paths.length, result2 = Array2(length), skip = object == null;
        while (++index2 < length) {
          result2[index2] = skip ? undefined$1 : get2(object, paths[index2]);
        }
        return result2;
      }
      function baseClamp(number, lower, upper) {
        if (number === number) {
          if (upper !== undefined$1) {
            number = number <= upper ? number : upper;
          }
          if (lower !== undefined$1) {
            number = number >= lower ? number : lower;
          }
        }
        return number;
      }
      function baseClone(value, bitmask, customizer, key, object, stack) {
        var result2, isDeep = bitmask & CLONE_DEEP_FLAG, isFlat = bitmask & CLONE_FLAT_FLAG, isFull = bitmask & CLONE_SYMBOLS_FLAG;
        if (customizer) {
          result2 = object ? customizer(value, key, object, stack) : customizer(value);
        }
        if (result2 !== undefined$1) {
          return result2;
        }
        if (!isObject2(value)) {
          return value;
        }
        var isArr = isArray(value);
        if (isArr) {
          result2 = initCloneArray(value);
          if (!isDeep) {
            return copyArray(value, result2);
          }
        } else {
          var tag = getTag2(value), isFunc = tag == funcTag2 || tag == genTag2;
          if (isBuffer2(value)) {
            return cloneBuffer(value, isDeep);
          }
          if (tag == objectTag2 || tag == argsTag2 || isFunc && !object) {
            result2 = isFlat || isFunc ? {} : initCloneObject(value);
            if (!isDeep) {
              return isFlat ? copySymbolsIn(value, baseAssignIn(result2, value)) : copySymbols(value, baseAssign(result2, value));
            }
          } else {
            if (!cloneableTags[tag]) {
              return object ? value : {};
            }
            result2 = initCloneByTag(value, tag, isDeep);
          }
        }
        stack || (stack = new Stack2());
        var stacked = stack.get(value);
        if (stacked) {
          return stacked;
        }
        stack.set(value, result2);
        if (isSet(value)) {
          value.forEach(function(subValue) {
            result2.add(baseClone(subValue, bitmask, customizer, subValue, value, stack));
          });
        } else if (isMap(value)) {
          value.forEach(function(subValue, key2) {
            result2.set(key2, baseClone(subValue, bitmask, customizer, key2, value, stack));
          });
        }
        var keysFunc = isFull ? isFlat ? getAllKeysIn : getAllKeys : isFlat ? keysIn : keys;
        var props = isArr ? undefined$1 : keysFunc(value);
        arrayEach(props || value, function(subValue, key2) {
          if (props) {
            key2 = subValue;
            subValue = value[key2];
          }
          assignValue(result2, key2, baseClone(subValue, bitmask, customizer, key2, value, stack));
        });
        return result2;
      }
      function baseConforms(source) {
        var props = keys(source);
        return function(object) {
          return baseConformsTo(object, source, props);
        };
      }
      function baseConformsTo(object, source, props) {
        var length = props.length;
        if (object == null) {
          return !length;
        }
        object = Object2(object);
        while (length--) {
          var key = props[length], predicate = source[key], value = object[key];
          if (value === undefined$1 && !(key in object) || !predicate(value)) {
            return false;
          }
        }
        return true;
      }
      function baseDelay(func, wait, args) {
        if (typeof func != "function") {
          throw new TypeError2(FUNC_ERROR_TEXT);
        }
        return setTimeout2(function() {
          func.apply(undefined$1, args);
        }, wait);
      }
      function baseDifference(array, values2, iteratee2, comparator) {
        var index2 = -1, includes2 = arrayIncludes, isCommon = true, length = array.length, result2 = [], valuesLength = values2.length;
        if (!length) {
          return result2;
        }
        if (iteratee2) {
          values2 = arrayMap(values2, baseUnary(iteratee2));
        }
        if (comparator) {
          includes2 = arrayIncludesWith;
          isCommon = false;
        } else if (values2.length >= LARGE_ARRAY_SIZE2) {
          includes2 = cacheHas;
          isCommon = false;
          values2 = new SetCache2(values2);
        }
        outer:
          while (++index2 < length) {
            var value = array[index2], computed = iteratee2 == null ? value : iteratee2(value);
            value = comparator || value !== 0 ? value : 0;
            if (isCommon && computed === computed) {
              var valuesIndex = valuesLength;
              while (valuesIndex--) {
                if (values2[valuesIndex] === computed) {
                  continue outer;
                }
              }
              result2.push(value);
            } else if (!includes2(values2, computed, comparator)) {
              result2.push(value);
            }
          }
        return result2;
      }
      var baseEach = createBaseEach(baseForOwn);
      var baseEachRight = createBaseEach(baseForOwnRight, true);
      function baseEvery(collection, predicate) {
        var result2 = true;
        baseEach(collection, function(value, index2, collection2) {
          result2 = !!predicate(value, index2, collection2);
          return result2;
        });
        return result2;
      }
      function baseExtremum(array, iteratee2, comparator) {
        var index2 = -1, length = array.length;
        while (++index2 < length) {
          var value = array[index2], current = iteratee2(value);
          if (current != null && (computed === undefined$1 ? current === current && !isSymbol(current) : comparator(current, computed))) {
            var computed = current, result2 = value;
          }
        }
        return result2;
      }
      function baseFill(array, value, start2, end2) {
        var length = array.length;
        start2 = toInteger(start2);
        if (start2 < 0) {
          start2 = -start2 > length ? 0 : length + start2;
        }
        end2 = end2 === undefined$1 || end2 > length ? length : toInteger(end2);
        if (end2 < 0) {
          end2 += length;
        }
        end2 = start2 > end2 ? 0 : toLength(end2);
        while (start2 < end2) {
          array[start2++] = value;
        }
        return array;
      }
      function baseFilter(collection, predicate) {
        var result2 = [];
        baseEach(collection, function(value, index2, collection2) {
          if (predicate(value, index2, collection2)) {
            result2.push(value);
          }
        });
        return result2;
      }
      function baseFlatten(array, depth, predicate, isStrict, result2) {
        var index2 = -1, length = array.length;
        predicate || (predicate = isFlattenable);
        result2 || (result2 = []);
        while (++index2 < length) {
          var value = array[index2];
          if (depth > 0 && predicate(value)) {
            if (depth > 1) {
              baseFlatten(value, depth - 1, predicate, isStrict, result2);
            } else {
              arrayPush(result2, value);
            }
          } else if (!isStrict) {
            result2[result2.length] = value;
          }
        }
        return result2;
      }
      var baseFor = createBaseFor();
      var baseForRight = createBaseFor(true);
      function baseForOwn(object, iteratee2) {
        return object && baseFor(object, iteratee2, keys);
      }
      function baseForOwnRight(object, iteratee2) {
        return object && baseForRight(object, iteratee2, keys);
      }
      function baseFunctions(object, props) {
        return arrayFilter(props, function(key) {
          return isFunction2(object[key]);
        });
      }
      function baseGet(object, path) {
        path = castPath(path, object);
        var index2 = 0, length = path.length;
        while (object != null && index2 < length) {
          object = object[toKey(path[index2++])];
        }
        return index2 && index2 == length ? object : undefined$1;
      }
      function baseGetAllKeys(object, keysFunc, symbolsFunc) {
        var result2 = keysFunc(object);
        return isArray(object) ? result2 : arrayPush(result2, symbolsFunc(object));
      }
      function baseGetTag2(value) {
        if (value == null) {
          return value === undefined$1 ? undefinedTag2 : nullTag2;
        }
        return symToStringTag2 && symToStringTag2 in Object2(value) ? getRawTag2(value) : objectToString2(value);
      }
      function baseGt(value, other) {
        return value > other;
      }
      function baseHas(object, key) {
        return object != null && hasOwnProperty2.call(object, key);
      }
      function baseHasIn(object, key) {
        return object != null && key in Object2(object);
      }
      function baseInRange(number, start2, end2) {
        return number >= nativeMin(start2, end2) && number < nativeMax(start2, end2);
      }
      function baseIntersection(arrays, iteratee2, comparator) {
        var includes2 = comparator ? arrayIncludesWith : arrayIncludes, length = arrays[0].length, othLength = arrays.length, othIndex = othLength, caches2 = Array2(othLength), maxLength = Infinity, result2 = [];
        while (othIndex--) {
          var array = arrays[othIndex];
          if (othIndex && iteratee2) {
            array = arrayMap(array, baseUnary(iteratee2));
          }
          maxLength = nativeMin(array.length, maxLength);
          caches2[othIndex] = !comparator && (iteratee2 || length >= 120 && array.length >= 120) ? new SetCache2(othIndex && array) : undefined$1;
        }
        array = arrays[0];
        var index2 = -1, seen = caches2[0];
        outer:
          while (++index2 < length && result2.length < maxLength) {
            var value = array[index2], computed = iteratee2 ? iteratee2(value) : value;
            value = comparator || value !== 0 ? value : 0;
            if (!(seen ? cacheHas(seen, computed) : includes2(result2, computed, comparator))) {
              othIndex = othLength;
              while (--othIndex) {
                var cache = caches2[othIndex];
                if (!(cache ? cacheHas(cache, computed) : includes2(arrays[othIndex], computed, comparator))) {
                  continue outer;
                }
              }
              if (seen) {
                seen.push(computed);
              }
              result2.push(value);
            }
          }
        return result2;
      }
      function baseInverter(object, setter, iteratee2, accumulator) {
        baseForOwn(object, function(value, key, object2) {
          setter(accumulator, iteratee2(value), key, object2);
        });
        return accumulator;
      }
      function baseInvoke(object, path, args) {
        path = castPath(path, object);
        object = parent(object, path);
        var func = object == null ? object : object[toKey(last(path))];
        return func == null ? undefined$1 : apply(func, object, args);
      }
      function baseIsArguments2(value) {
        return isObjectLike2(value) && baseGetTag2(value) == argsTag2;
      }
      function baseIsArrayBuffer(value) {
        return isObjectLike2(value) && baseGetTag2(value) == arrayBufferTag;
      }
      function baseIsDate(value) {
        return isObjectLike2(value) && baseGetTag2(value) == dateTag;
      }
      function baseIsEqual(value, other, bitmask, customizer, stack) {
        if (value === other) {
          return true;
        }
        if (value == null || other == null || !isObjectLike2(value) && !isObjectLike2(other)) {
          return value !== value && other !== other;
        }
        return baseIsEqualDeep(value, other, bitmask, customizer, baseIsEqual, stack);
      }
      function baseIsEqualDeep(object, other, bitmask, customizer, equalFunc, stack) {
        var objIsArr = isArray(object), othIsArr = isArray(other), objTag = objIsArr ? arrayTag : getTag2(object), othTag = othIsArr ? arrayTag : getTag2(other);
        objTag = objTag == argsTag2 ? objectTag2 : objTag;
        othTag = othTag == argsTag2 ? objectTag2 : othTag;
        var objIsObj = objTag == objectTag2, othIsObj = othTag == objectTag2, isSameTag = objTag == othTag;
        if (isSameTag && isBuffer2(object)) {
          if (!isBuffer2(other)) {
            return false;
          }
          objIsArr = true;
          objIsObj = false;
        }
        if (isSameTag && !objIsObj) {
          stack || (stack = new Stack2());
          return objIsArr || isTypedArray(object) ? equalArrays(object, other, bitmask, customizer, equalFunc, stack) : equalByTag(object, other, objTag, bitmask, customizer, equalFunc, stack);
        }
        if (!(bitmask & COMPARE_PARTIAL_FLAG)) {
          var objIsWrapped = objIsObj && hasOwnProperty2.call(object, "__wrapped__"), othIsWrapped = othIsObj && hasOwnProperty2.call(other, "__wrapped__");
          if (objIsWrapped || othIsWrapped) {
            var objUnwrapped = objIsWrapped ? object.value() : object, othUnwrapped = othIsWrapped ? other.value() : other;
            stack || (stack = new Stack2());
            return equalFunc(objUnwrapped, othUnwrapped, bitmask, customizer, stack);
          }
        }
        if (!isSameTag) {
          return false;
        }
        stack || (stack = new Stack2());
        return equalObjects(object, other, bitmask, customizer, equalFunc, stack);
      }
      function baseIsMap(value) {
        return isObjectLike2(value) && getTag2(value) == mapTag2;
      }
      function baseIsMatch(object, source, matchData, customizer) {
        var index2 = matchData.length, length = index2, noCustomizer = !customizer;
        if (object == null) {
          return !length;
        }
        object = Object2(object);
        while (index2--) {
          var data = matchData[index2];
          if (noCustomizer && data[2] ? data[1] !== object[data[0]] : !(data[0] in object)) {
            return false;
          }
        }
        while (++index2 < length) {
          data = matchData[index2];
          var key = data[0], objValue = object[key], srcValue = data[1];
          if (noCustomizer && data[2]) {
            if (objValue === undefined$1 && !(key in object)) {
              return false;
            }
          } else {
            var stack = new Stack2();
            if (customizer) {
              var result2 = customizer(objValue, srcValue, key, object, source, stack);
            }
            if (!(result2 === undefined$1 ? baseIsEqual(srcValue, objValue, COMPARE_PARTIAL_FLAG | COMPARE_UNORDERED_FLAG, customizer, stack) : result2)) {
              return false;
            }
          }
        }
        return true;
      }
      function baseIsNative2(value) {
        if (!isObject2(value) || isMasked2(value)) {
          return false;
        }
        var pattern = isFunction2(value) ? reIsNative2 : reIsHostCtor2;
        return pattern.test(toSource2(value));
      }
      function baseIsRegExp(value) {
        return isObjectLike2(value) && baseGetTag2(value) == regexpTag;
      }
      function baseIsSet(value) {
        return isObjectLike2(value) && getTag2(value) == setTag2;
      }
      function baseIsTypedArray(value) {
        return isObjectLike2(value) && isLength(value.length) && !!typedArrayTags[baseGetTag2(value)];
      }
      function baseIteratee(value) {
        if (typeof value == "function") {
          return value;
        }
        if (value == null) {
          return identity;
        }
        if (typeof value == "object") {
          return isArray(value) ? baseMatchesProperty(value[0], value[1]) : baseMatches(value);
        }
        return property(value);
      }
      function baseKeys(object) {
        if (!isPrototype(object)) {
          return nativeKeys(object);
        }
        var result2 = [];
        for (var key in Object2(object)) {
          if (hasOwnProperty2.call(object, key) && key != "constructor") {
            result2.push(key);
          }
        }
        return result2;
      }
      function baseKeysIn(object) {
        if (!isObject2(object)) {
          return nativeKeysIn(object);
        }
        var isProto = isPrototype(object), result2 = [];
        for (var key in object) {
          if (!(key == "constructor" && (isProto || !hasOwnProperty2.call(object, key)))) {
            result2.push(key);
          }
        }
        return result2;
      }
      function baseLt(value, other) {
        return value < other;
      }
      function baseMap(collection, iteratee2) {
        var index2 = -1, result2 = isArrayLike(collection) ? Array2(collection.length) : [];
        baseEach(collection, function(value, key, collection2) {
          result2[++index2] = iteratee2(value, key, collection2);
        });
        return result2;
      }
      function baseMatches(source) {
        var matchData = getMatchData(source);
        if (matchData.length == 1 && matchData[0][2]) {
          return matchesStrictComparable(matchData[0][0], matchData[0][1]);
        }
        return function(object) {
          return object === source || baseIsMatch(object, source, matchData);
        };
      }
      function baseMatchesProperty(path, srcValue) {
        if (isKey(path) && isStrictComparable(srcValue)) {
          return matchesStrictComparable(toKey(path), srcValue);
        }
        return function(object) {
          var objValue = get2(object, path);
          return objValue === undefined$1 && objValue === srcValue ? hasIn(object, path) : baseIsEqual(srcValue, objValue, COMPARE_PARTIAL_FLAG | COMPARE_UNORDERED_FLAG);
        };
      }
      function baseMerge(object, source, srcIndex, customizer, stack) {
        if (object === source) {
          return;
        }
        baseFor(source, function(srcValue, key) {
          stack || (stack = new Stack2());
          if (isObject2(srcValue)) {
            baseMergeDeep(object, source, key, srcIndex, baseMerge, customizer, stack);
          } else {
            var newValue = customizer ? customizer(safeGet(object, key), srcValue, key + "", object, source, stack) : undefined$1;
            if (newValue === undefined$1) {
              newValue = srcValue;
            }
            assignMergeValue(object, key, newValue);
          }
        }, keysIn);
      }
      function baseMergeDeep(object, source, key, srcIndex, mergeFunc, customizer, stack) {
        var objValue = safeGet(object, key), srcValue = safeGet(source, key), stacked = stack.get(srcValue);
        if (stacked) {
          assignMergeValue(object, key, stacked);
          return;
        }
        var newValue = customizer ? customizer(objValue, srcValue, key + "", object, source, stack) : undefined$1;
        var isCommon = newValue === undefined$1;
        if (isCommon) {
          var isArr = isArray(srcValue), isBuff = !isArr && isBuffer2(srcValue), isTyped = !isArr && !isBuff && isTypedArray(srcValue);
          newValue = srcValue;
          if (isArr || isBuff || isTyped) {
            if (isArray(objValue)) {
              newValue = objValue;
            } else if (isArrayLikeObject(objValue)) {
              newValue = copyArray(objValue);
            } else if (isBuff) {
              isCommon = false;
              newValue = cloneBuffer(srcValue, true);
            } else if (isTyped) {
              isCommon = false;
              newValue = cloneTypedArray(srcValue, true);
            } else {
              newValue = [];
            }
          } else if (isPlainObject2(srcValue) || isArguments(srcValue)) {
            newValue = objValue;
            if (isArguments(objValue)) {
              newValue = toPlainObject(objValue);
            } else if (!isObject2(objValue) || isFunction2(objValue)) {
              newValue = initCloneObject(srcValue);
            }
          } else {
            isCommon = false;
          }
        }
        if (isCommon) {
          stack.set(srcValue, newValue);
          mergeFunc(newValue, srcValue, srcIndex, customizer, stack);
          stack["delete"](srcValue);
        }
        assignMergeValue(object, key, newValue);
      }
      function baseNth(array, n) {
        var length = array.length;
        if (!length) {
          return;
        }
        n += n < 0 ? length : 0;
        return isIndex(n, length) ? array[n] : undefined$1;
      }
      function baseOrderBy(collection, iteratees, orders) {
        if (iteratees.length) {
          iteratees = arrayMap(iteratees, function(iteratee2) {
            if (isArray(iteratee2)) {
              return function(value) {
                return baseGet(value, iteratee2.length === 1 ? iteratee2[0] : iteratee2);
              };
            }
            return iteratee2;
          });
        } else {
          iteratees = [identity];
        }
        var index2 = -1;
        iteratees = arrayMap(iteratees, baseUnary(getIteratee()));
        var result2 = baseMap(collection, function(value, key, collection2) {
          var criteria = arrayMap(iteratees, function(iteratee2) {
            return iteratee2(value);
          });
          return { "criteria": criteria, "index": ++index2, "value": value };
        });
        return baseSortBy(result2, function(object, other) {
          return compareMultiple(object, other, orders);
        });
      }
      function basePick(object, paths) {
        return basePickBy(object, paths, function(value, path) {
          return hasIn(object, path);
        });
      }
      function basePickBy(object, paths, predicate) {
        var index2 = -1, length = paths.length, result2 = {};
        while (++index2 < length) {
          var path = paths[index2], value = baseGet(object, path);
          if (predicate(value, path)) {
            baseSet(result2, castPath(path, object), value);
          }
        }
        return result2;
      }
      function basePropertyDeep(path) {
        return function(object) {
          return baseGet(object, path);
        };
      }
      function basePullAll(array, values2, iteratee2, comparator) {
        var indexOf2 = comparator ? baseIndexOfWith : baseIndexOf, index2 = -1, length = values2.length, seen = array;
        if (array === values2) {
          values2 = copyArray(values2);
        }
        if (iteratee2) {
          seen = arrayMap(array, baseUnary(iteratee2));
        }
        while (++index2 < length) {
          var fromIndex = 0, value = values2[index2], computed = iteratee2 ? iteratee2(value) : value;
          while ((fromIndex = indexOf2(seen, computed, fromIndex, comparator)) > -1) {
            if (seen !== array) {
              splice2.call(seen, fromIndex, 1);
            }
            splice2.call(array, fromIndex, 1);
          }
        }
        return array;
      }
      function basePullAt(array, indexes) {
        var length = array ? indexes.length : 0, lastIndex = length - 1;
        while (length--) {
          var index2 = indexes[length];
          if (length == lastIndex || index2 !== previous) {
            var previous = index2;
            if (isIndex(index2)) {
              splice2.call(array, index2, 1);
            } else {
              baseUnset(array, index2);
            }
          }
        }
        return array;
      }
      function baseRandom(lower, upper) {
        return lower + nativeFloor(nativeRandom() * (upper - lower + 1));
      }
      function baseRange(start2, end2, step, fromRight) {
        var index2 = -1, length = nativeMax(nativeCeil((end2 - start2) / (step || 1)), 0), result2 = Array2(length);
        while (length--) {
          result2[fromRight ? length : ++index2] = start2;
          start2 += step;
        }
        return result2;
      }
      function baseRepeat(string, n) {
        var result2 = "";
        if (!string || n < 1 || n > MAX_SAFE_INTEGER) {
          return result2;
        }
        do {
          if (n % 2) {
            result2 += string;
          }
          n = nativeFloor(n / 2);
          if (n) {
            string += string;
          }
        } while (n);
        return result2;
      }
      function baseRest(func, start2) {
        return setToString(overRest(func, start2, identity), func + "");
      }
      function baseSample(collection) {
        return arraySample(values(collection));
      }
      function baseSampleSize(collection, n) {
        var array = values(collection);
        return shuffleSelf(array, baseClamp(n, 0, array.length));
      }
      function baseSet(object, path, value, customizer) {
        if (!isObject2(object)) {
          return object;
        }
        path = castPath(path, object);
        var index2 = -1, length = path.length, lastIndex = length - 1, nested = object;
        while (nested != null && ++index2 < length) {
          var key = toKey(path[index2]), newValue = value;
          if (key === "__proto__" || key === "constructor" || key === "prototype") {
            return object;
          }
          if (index2 != lastIndex) {
            var objValue = nested[key];
            newValue = customizer ? customizer(objValue, key, nested) : undefined$1;
            if (newValue === undefined$1) {
              newValue = isObject2(objValue) ? objValue : isIndex(path[index2 + 1]) ? [] : {};
            }
          }
          assignValue(nested, key, newValue);
          nested = nested[key];
        }
        return object;
      }
      var baseSetData = !metaMap ? identity : function(func, data) {
        metaMap.set(func, data);
        return func;
      };
      var baseSetToString = !defineProperty ? identity : function(func, string) {
        return defineProperty(func, "toString", {
          "configurable": true,
          "enumerable": false,
          "value": constant(string),
          "writable": true
        });
      };
      function baseShuffle(collection) {
        return shuffleSelf(values(collection));
      }
      function baseSlice(array, start2, end2) {
        var index2 = -1, length = array.length;
        if (start2 < 0) {
          start2 = -start2 > length ? 0 : length + start2;
        }
        end2 = end2 > length ? length : end2;
        if (end2 < 0) {
          end2 += length;
        }
        length = start2 > end2 ? 0 : end2 - start2 >>> 0;
        start2 >>>= 0;
        var result2 = Array2(length);
        while (++index2 < length) {
          result2[index2] = array[index2 + start2];
        }
        return result2;
      }
      function baseSome(collection, predicate) {
        var result2;
        baseEach(collection, function(value, index2, collection2) {
          result2 = predicate(value, index2, collection2);
          return !result2;
        });
        return !!result2;
      }
      function baseSortedIndex(array, value, retHighest) {
        var low = 0, high = array == null ? low : array.length;
        if (typeof value == "number" && value === value && high <= HALF_MAX_ARRAY_LENGTH) {
          while (low < high) {
            var mid = low + high >>> 1, computed = array[mid];
            if (computed !== null && !isSymbol(computed) && (retHighest ? computed <= value : computed < value)) {
              low = mid + 1;
            } else {
              high = mid;
            }
          }
          return high;
        }
        return baseSortedIndexBy(array, value, identity, retHighest);
      }
      function baseSortedIndexBy(array, value, iteratee2, retHighest) {
        var low = 0, high = array == null ? 0 : array.length;
        if (high === 0) {
          return 0;
        }
        value = iteratee2(value);
        var valIsNaN = value !== value, valIsNull = value === null, valIsSymbol = isSymbol(value), valIsUndefined = value === undefined$1;
        while (low < high) {
          var mid = nativeFloor((low + high) / 2), computed = iteratee2(array[mid]), othIsDefined = computed !== undefined$1, othIsNull = computed === null, othIsReflexive = computed === computed, othIsSymbol = isSymbol(computed);
          if (valIsNaN) {
            var setLow = retHighest || othIsReflexive;
          } else if (valIsUndefined) {
            setLow = othIsReflexive && (retHighest || othIsDefined);
          } else if (valIsNull) {
            setLow = othIsReflexive && othIsDefined && (retHighest || !othIsNull);
          } else if (valIsSymbol) {
            setLow = othIsReflexive && othIsDefined && !othIsNull && (retHighest || !othIsSymbol);
          } else if (othIsNull || othIsSymbol) {
            setLow = false;
          } else {
            setLow = retHighest ? computed <= value : computed < value;
          }
          if (setLow) {
            low = mid + 1;
          } else {
            high = mid;
          }
        }
        return nativeMin(high, MAX_ARRAY_INDEX);
      }
      function baseSortedUniq(array, iteratee2) {
        var index2 = -1, length = array.length, resIndex = 0, result2 = [];
        while (++index2 < length) {
          var value = array[index2], computed = iteratee2 ? iteratee2(value) : value;
          if (!index2 || !eq2(computed, seen)) {
            var seen = computed;
            result2[resIndex++] = value === 0 ? 0 : value;
          }
        }
        return result2;
      }
      function baseToNumber(value) {
        if (typeof value == "number") {
          return value;
        }
        if (isSymbol(value)) {
          return NAN;
        }
        return +value;
      }
      function baseToString(value) {
        if (typeof value == "string") {
          return value;
        }
        if (isArray(value)) {
          return arrayMap(value, baseToString) + "";
        }
        if (isSymbol(value)) {
          return symbolToString ? symbolToString.call(value) : "";
        }
        var result2 = value + "";
        return result2 == "0" && 1 / value == -INFINITY ? "-0" : result2;
      }
      function baseUniq(array, iteratee2, comparator) {
        var index2 = -1, includes2 = arrayIncludes, length = array.length, isCommon = true, result2 = [], seen = result2;
        if (comparator) {
          isCommon = false;
          includes2 = arrayIncludesWith;
        } else if (length >= LARGE_ARRAY_SIZE2) {
          var set2 = iteratee2 ? null : createSet(array);
          if (set2) {
            return setToArray(set2);
          }
          isCommon = false;
          includes2 = cacheHas;
          seen = new SetCache2();
        } else {
          seen = iteratee2 ? [] : result2;
        }
        outer:
          while (++index2 < length) {
            var value = array[index2], computed = iteratee2 ? iteratee2(value) : value;
            value = comparator || value !== 0 ? value : 0;
            if (isCommon && computed === computed) {
              var seenIndex = seen.length;
              while (seenIndex--) {
                if (seen[seenIndex] === computed) {
                  continue outer;
                }
              }
              if (iteratee2) {
                seen.push(computed);
              }
              result2.push(value);
            } else if (!includes2(seen, computed, comparator)) {
              if (seen !== result2) {
                seen.push(computed);
              }
              result2.push(value);
            }
          }
        return result2;
      }
      function baseUnset(object, path) {
        path = castPath(path, object);
        object = parent(object, path);
        return object == null || delete object[toKey(last(path))];
      }
      function baseUpdate(object, path, updater, customizer) {
        return baseSet(object, path, updater(baseGet(object, path)), customizer);
      }
      function baseWhile(array, predicate, isDrop, fromRight) {
        var length = array.length, index2 = fromRight ? length : -1;
        while ((fromRight ? index2-- : ++index2 < length) && predicate(array[index2], index2, array)) {
        }
        return isDrop ? baseSlice(array, fromRight ? 0 : index2, fromRight ? index2 + 1 : length) : baseSlice(array, fromRight ? index2 + 1 : 0, fromRight ? length : index2);
      }
      function baseWrapperValue(value, actions) {
        var result2 = value;
        if (result2 instanceof LazyWrapper) {
          result2 = result2.value();
        }
        return arrayReduce(actions, function(result3, action) {
          return action.func.apply(action.thisArg, arrayPush([result3], action.args));
        }, result2);
      }
      function baseXor(arrays, iteratee2, comparator) {
        var length = arrays.length;
        if (length < 2) {
          return length ? baseUniq(arrays[0]) : [];
        }
        var index2 = -1, result2 = Array2(length);
        while (++index2 < length) {
          var array = arrays[index2], othIndex = -1;
          while (++othIndex < length) {
            if (othIndex != index2) {
              result2[index2] = baseDifference(result2[index2] || array, arrays[othIndex], iteratee2, comparator);
            }
          }
        }
        return baseUniq(baseFlatten(result2, 1), iteratee2, comparator);
      }
      function baseZipObject(props, values2, assignFunc) {
        var index2 = -1, length = props.length, valsLength = values2.length, result2 = {};
        while (++index2 < length) {
          var value = index2 < valsLength ? values2[index2] : undefined$1;
          assignFunc(result2, props[index2], value);
        }
        return result2;
      }
      function castArrayLikeObject(value) {
        return isArrayLikeObject(value) ? value : [];
      }
      function castFunction(value) {
        return typeof value == "function" ? value : identity;
      }
      function castPath(value, object) {
        if (isArray(value)) {
          return value;
        }
        return isKey(value, object) ? [value] : stringToPath(toString(value));
      }
      var castRest = baseRest;
      function castSlice(array, start2, end2) {
        var length = array.length;
        end2 = end2 === undefined$1 ? length : end2;
        return !start2 && end2 >= length ? array : baseSlice(array, start2, end2);
      }
      var clearTimeout2 = ctxClearTimeout || function(id) {
        return root2.clearTimeout(id);
      };
      function cloneBuffer(buffer, isDeep) {
        if (isDeep) {
          return buffer.slice();
        }
        var length = buffer.length, result2 = allocUnsafe ? allocUnsafe(length) : new buffer.constructor(length);
        buffer.copy(result2);
        return result2;
      }
      function cloneArrayBuffer(arrayBuffer) {
        var result2 = new arrayBuffer.constructor(arrayBuffer.byteLength);
        new Uint8Array(result2).set(new Uint8Array(arrayBuffer));
        return result2;
      }
      function cloneDataView(dataView, isDeep) {
        var buffer = isDeep ? cloneArrayBuffer(dataView.buffer) : dataView.buffer;
        return new dataView.constructor(buffer, dataView.byteOffset, dataView.byteLength);
      }
      function cloneRegExp(regexp) {
        var result2 = new regexp.constructor(regexp.source, reFlags.exec(regexp));
        result2.lastIndex = regexp.lastIndex;
        return result2;
      }
      function cloneSymbol(symbol) {
        return symbolValueOf ? Object2(symbolValueOf.call(symbol)) : {};
      }
      function cloneTypedArray(typedArray, isDeep) {
        var buffer = isDeep ? cloneArrayBuffer(typedArray.buffer) : typedArray.buffer;
        return new typedArray.constructor(buffer, typedArray.byteOffset, typedArray.length);
      }
      function compareAscending(value, other) {
        if (value !== other) {
          var valIsDefined = value !== undefined$1, valIsNull = value === null, valIsReflexive = value === value, valIsSymbol = isSymbol(value);
          var othIsDefined = other !== undefined$1, othIsNull = other === null, othIsReflexive = other === other, othIsSymbol = isSymbol(other);
          if (!othIsNull && !othIsSymbol && !valIsSymbol && value > other || valIsSymbol && othIsDefined && othIsReflexive && !othIsNull && !othIsSymbol || valIsNull && othIsDefined && othIsReflexive || !valIsDefined && othIsReflexive || !valIsReflexive) {
            return 1;
          }
          if (!valIsNull && !valIsSymbol && !othIsSymbol && value < other || othIsSymbol && valIsDefined && valIsReflexive && !valIsNull && !valIsSymbol || othIsNull && valIsDefined && valIsReflexive || !othIsDefined && valIsReflexive || !othIsReflexive) {
            return -1;
          }
        }
        return 0;
      }
      function compareMultiple(object, other, orders) {
        var index2 = -1, objCriteria = object.criteria, othCriteria = other.criteria, length = objCriteria.length, ordersLength = orders.length;
        while (++index2 < length) {
          var result2 = compareAscending(objCriteria[index2], othCriteria[index2]);
          if (result2) {
            if (index2 >= ordersLength) {
              return result2;
            }
            var order2 = orders[index2];
            return result2 * (order2 == "desc" ? -1 : 1);
          }
        }
        return object.index - other.index;
      }
      function composeArgs(args, partials, holders, isCurried) {
        var argsIndex = -1, argsLength = args.length, holdersLength = holders.length, leftIndex = -1, leftLength = partials.length, rangeLength = nativeMax(argsLength - holdersLength, 0), result2 = Array2(leftLength + rangeLength), isUncurried = !isCurried;
        while (++leftIndex < leftLength) {
          result2[leftIndex] = partials[leftIndex];
        }
        while (++argsIndex < holdersLength) {
          if (isUncurried || argsIndex < argsLength) {
            result2[holders[argsIndex]] = args[argsIndex];
          }
        }
        while (rangeLength--) {
          result2[leftIndex++] = args[argsIndex++];
        }
        return result2;
      }
      function composeArgsRight(args, partials, holders, isCurried) {
        var argsIndex = -1, argsLength = args.length, holdersIndex = -1, holdersLength = holders.length, rightIndex = -1, rightLength = partials.length, rangeLength = nativeMax(argsLength - holdersLength, 0), result2 = Array2(rangeLength + rightLength), isUncurried = !isCurried;
        while (++argsIndex < rangeLength) {
          result2[argsIndex] = args[argsIndex];
        }
        var offset2 = argsIndex;
        while (++rightIndex < rightLength) {
          result2[offset2 + rightIndex] = partials[rightIndex];
        }
        while (++holdersIndex < holdersLength) {
          if (isUncurried || argsIndex < argsLength) {
            result2[offset2 + holders[holdersIndex]] = args[argsIndex++];
          }
        }
        return result2;
      }
      function copyArray(source, array) {
        var index2 = -1, length = source.length;
        array || (array = Array2(length));
        while (++index2 < length) {
          array[index2] = source[index2];
        }
        return array;
      }
      function copyObject(source, props, object, customizer) {
        var isNew = !object;
        object || (object = {});
        var index2 = -1, length = props.length;
        while (++index2 < length) {
          var key = props[index2];
          var newValue = customizer ? customizer(object[key], source[key], key, object, source) : undefined$1;
          if (newValue === undefined$1) {
            newValue = source[key];
          }
          if (isNew) {
            baseAssignValue(object, key, newValue);
          } else {
            assignValue(object, key, newValue);
          }
        }
        return object;
      }
      function copySymbols(source, object) {
        return copyObject(source, getSymbols(source), object);
      }
      function copySymbolsIn(source, object) {
        return copyObject(source, getSymbolsIn(source), object);
      }
      function createAggregator(setter, initializer) {
        return function(collection, iteratee2) {
          var func = isArray(collection) ? arrayAggregator : baseAggregator, accumulator = initializer ? initializer() : {};
          return func(collection, setter, getIteratee(iteratee2, 2), accumulator);
        };
      }
      function createAssigner(assigner) {
        return baseRest(function(object, sources) {
          var index2 = -1, length = sources.length, customizer = length > 1 ? sources[length - 1] : undefined$1, guard = length > 2 ? sources[2] : undefined$1;
          customizer = assigner.length > 3 && typeof customizer == "function" ? (length--, customizer) : undefined$1;
          if (guard && isIterateeCall(sources[0], sources[1], guard)) {
            customizer = length < 3 ? undefined$1 : customizer;
            length = 1;
          }
          object = Object2(object);
          while (++index2 < length) {
            var source = sources[index2];
            if (source) {
              assigner(object, source, index2, customizer);
            }
          }
          return object;
        });
      }
      function createBaseEach(eachFunc, fromRight) {
        return function(collection, iteratee2) {
          if (collection == null) {
            return collection;
          }
          if (!isArrayLike(collection)) {
            return eachFunc(collection, iteratee2);
          }
          var length = collection.length, index2 = fromRight ? length : -1, iterable = Object2(collection);
          while (fromRight ? index2-- : ++index2 < length) {
            if (iteratee2(iterable[index2], index2, iterable) === false) {
              break;
            }
          }
          return collection;
        };
      }
      function createBaseFor(fromRight) {
        return function(object, iteratee2, keysFunc) {
          var index2 = -1, iterable = Object2(object), props = keysFunc(object), length = props.length;
          while (length--) {
            var key = props[fromRight ? length : ++index2];
            if (iteratee2(iterable[key], key, iterable) === false) {
              break;
            }
          }
          return object;
        };
      }
      function createBind(func, bitmask, thisArg) {
        var isBind = bitmask & WRAP_BIND_FLAG, Ctor = createCtor(func);
        function wrapper() {
          var fn2 = this && this !== root2 && this instanceof wrapper ? Ctor : func;
          return fn2.apply(isBind ? thisArg : this, arguments);
        }
        return wrapper;
      }
      function createCaseFirst(methodName) {
        return function(string) {
          string = toString(string);
          var strSymbols = hasUnicode(string) ? stringToArray(string) : undefined$1;
          var chr = strSymbols ? strSymbols[0] : string.charAt(0);
          var trailing = strSymbols ? castSlice(strSymbols, 1).join("") : string.slice(1);
          return chr[methodName]() + trailing;
        };
      }
      function createCompounder(callback) {
        return function(string) {
          return arrayReduce(words(deburr(string).replace(reApos, "")), callback, "");
        };
      }
      function createCtor(Ctor) {
        return function() {
          var args = arguments;
          switch (args.length) {
            case 0:
              return new Ctor();
            case 1:
              return new Ctor(args[0]);
            case 2:
              return new Ctor(args[0], args[1]);
            case 3:
              return new Ctor(args[0], args[1], args[2]);
            case 4:
              return new Ctor(args[0], args[1], args[2], args[3]);
            case 5:
              return new Ctor(args[0], args[1], args[2], args[3], args[4]);
            case 6:
              return new Ctor(args[0], args[1], args[2], args[3], args[4], args[5]);
            case 7:
              return new Ctor(args[0], args[1], args[2], args[3], args[4], args[5], args[6]);
          }
          var thisBinding = baseCreate(Ctor.prototype), result2 = Ctor.apply(thisBinding, args);
          return isObject2(result2) ? result2 : thisBinding;
        };
      }
      function createCurry(func, bitmask, arity) {
        var Ctor = createCtor(func);
        function wrapper() {
          var length = arguments.length, args = Array2(length), index2 = length, placeholder2 = getHolder(wrapper);
          while (index2--) {
            args[index2] = arguments[index2];
          }
          var holders = length < 3 && args[0] !== placeholder2 && args[length - 1] !== placeholder2 ? [] : replaceHolders(args, placeholder2);
          length -= holders.length;
          if (length < arity) {
            return createRecurry(
              func,
              bitmask,
              createHybrid,
              wrapper.placeholder,
              undefined$1,
              args,
              holders,
              undefined$1,
              undefined$1,
              arity - length
            );
          }
          var fn2 = this && this !== root2 && this instanceof wrapper ? Ctor : func;
          return apply(fn2, this, args);
        }
        return wrapper;
      }
      function createFind(findIndexFunc) {
        return function(collection, predicate, fromIndex) {
          var iterable = Object2(collection);
          if (!isArrayLike(collection)) {
            var iteratee2 = getIteratee(predicate, 3);
            collection = keys(collection);
            predicate = function(key) {
              return iteratee2(iterable[key], key, iterable);
            };
          }
          var index2 = findIndexFunc(collection, predicate, fromIndex);
          return index2 > -1 ? iterable[iteratee2 ? collection[index2] : index2] : undefined$1;
        };
      }
      function createFlow(fromRight) {
        return flatRest(function(funcs) {
          var length = funcs.length, index2 = length, prereq = LodashWrapper.prototype.thru;
          if (fromRight) {
            funcs.reverse();
          }
          while (index2--) {
            var func = funcs[index2];
            if (typeof func != "function") {
              throw new TypeError2(FUNC_ERROR_TEXT);
            }
            if (prereq && !wrapper && getFuncName(func) == "wrapper") {
              var wrapper = new LodashWrapper([], true);
            }
          }
          index2 = wrapper ? index2 : length;
          while (++index2 < length) {
            func = funcs[index2];
            var funcName = getFuncName(func), data = funcName == "wrapper" ? getData(func) : undefined$1;
            if (data && isLaziable(data[0]) && data[1] == (WRAP_ARY_FLAG | WRAP_CURRY_FLAG | WRAP_PARTIAL_FLAG | WRAP_REARG_FLAG) && !data[4].length && data[9] == 1) {
              wrapper = wrapper[getFuncName(data[0])].apply(wrapper, data[3]);
            } else {
              wrapper = func.length == 1 && isLaziable(func) ? wrapper[funcName]() : wrapper.thru(func);
            }
          }
          return function() {
            var args = arguments, value = args[0];
            if (wrapper && args.length == 1 && isArray(value)) {
              return wrapper.plant(value).value();
            }
            var index3 = 0, result2 = length ? funcs[index3].apply(this, args) : value;
            while (++index3 < length) {
              result2 = funcs[index3].call(this, result2);
            }
            return result2;
          };
        });
      }
      function createHybrid(func, bitmask, thisArg, partials, holders, partialsRight, holdersRight, argPos, ary2, arity) {
        var isAry = bitmask & WRAP_ARY_FLAG, isBind = bitmask & WRAP_BIND_FLAG, isBindKey = bitmask & WRAP_BIND_KEY_FLAG, isCurried = bitmask & (WRAP_CURRY_FLAG | WRAP_CURRY_RIGHT_FLAG), isFlip = bitmask & WRAP_FLIP_FLAG, Ctor = isBindKey ? undefined$1 : createCtor(func);
        function wrapper() {
          var length = arguments.length, args = Array2(length), index2 = length;
          while (index2--) {
            args[index2] = arguments[index2];
          }
          if (isCurried) {
            var placeholder2 = getHolder(wrapper), holdersCount = countHolders(args, placeholder2);
          }
          if (partials) {
            args = composeArgs(args, partials, holders, isCurried);
          }
          if (partialsRight) {
            args = composeArgsRight(args, partialsRight, holdersRight, isCurried);
          }
          length -= holdersCount;
          if (isCurried && length < arity) {
            var newHolders = replaceHolders(args, placeholder2);
            return createRecurry(
              func,
              bitmask,
              createHybrid,
              wrapper.placeholder,
              thisArg,
              args,
              newHolders,
              argPos,
              ary2,
              arity - length
            );
          }
          var thisBinding = isBind ? thisArg : this, fn2 = isBindKey ? thisBinding[func] : func;
          length = args.length;
          if (argPos) {
            args = reorder(args, argPos);
          } else if (isFlip && length > 1) {
            args.reverse();
          }
          if (isAry && ary2 < length) {
            args.length = ary2;
          }
          if (this && this !== root2 && this instanceof wrapper) {
            fn2 = Ctor || createCtor(fn2);
          }
          return fn2.apply(thisBinding, args);
        }
        return wrapper;
      }
      function createInverter(setter, toIteratee) {
        return function(object, iteratee2) {
          return baseInverter(object, setter, toIteratee(iteratee2), {});
        };
      }
      function createMathOperation(operator, defaultValue) {
        return function(value, other) {
          var result2;
          if (value === undefined$1 && other === undefined$1) {
            return defaultValue;
          }
          if (value !== undefined$1) {
            result2 = value;
          }
          if (other !== undefined$1) {
            if (result2 === undefined$1) {
              return other;
            }
            if (typeof value == "string" || typeof other == "string") {
              value = baseToString(value);
              other = baseToString(other);
            } else {
              value = baseToNumber(value);
              other = baseToNumber(other);
            }
            result2 = operator(value, other);
          }
          return result2;
        };
      }
      function createOver(arrayFunc) {
        return flatRest(function(iteratees) {
          iteratees = arrayMap(iteratees, baseUnary(getIteratee()));
          return baseRest(function(args) {
            var thisArg = this;
            return arrayFunc(iteratees, function(iteratee2) {
              return apply(iteratee2, thisArg, args);
            });
          });
        });
      }
      function createPadding(length, chars) {
        chars = chars === undefined$1 ? " " : baseToString(chars);
        var charsLength = chars.length;
        if (charsLength < 2) {
          return charsLength ? baseRepeat(chars, length) : chars;
        }
        var result2 = baseRepeat(chars, nativeCeil(length / stringSize(chars)));
        return hasUnicode(chars) ? castSlice(stringToArray(result2), 0, length).join("") : result2.slice(0, length);
      }
      function createPartial(func, bitmask, thisArg, partials) {
        var isBind = bitmask & WRAP_BIND_FLAG, Ctor = createCtor(func);
        function wrapper() {
          var argsIndex = -1, argsLength = arguments.length, leftIndex = -1, leftLength = partials.length, args = Array2(leftLength + argsLength), fn2 = this && this !== root2 && this instanceof wrapper ? Ctor : func;
          while (++leftIndex < leftLength) {
            args[leftIndex] = partials[leftIndex];
          }
          while (argsLength--) {
            args[leftIndex++] = arguments[++argsIndex];
          }
          return apply(fn2, isBind ? thisArg : this, args);
        }
        return wrapper;
      }
      function createRange(fromRight) {
        return function(start2, end2, step) {
          if (step && typeof step != "number" && isIterateeCall(start2, end2, step)) {
            end2 = step = undefined$1;
          }
          start2 = toFinite(start2);
          if (end2 === undefined$1) {
            end2 = start2;
            start2 = 0;
          } else {
            end2 = toFinite(end2);
          }
          step = step === undefined$1 ? start2 < end2 ? 1 : -1 : toFinite(step);
          return baseRange(start2, end2, step, fromRight);
        };
      }
      function createRelationalOperation(operator) {
        return function(value, other) {
          if (!(typeof value == "string" && typeof other == "string")) {
            value = toNumber(value);
            other = toNumber(other);
          }
          return operator(value, other);
        };
      }
      function createRecurry(func, bitmask, wrapFunc, placeholder2, thisArg, partials, holders, argPos, ary2, arity) {
        var isCurry = bitmask & WRAP_CURRY_FLAG, newHolders = isCurry ? holders : undefined$1, newHoldersRight = isCurry ? undefined$1 : holders, newPartials = isCurry ? partials : undefined$1, newPartialsRight = isCurry ? undefined$1 : partials;
        bitmask |= isCurry ? WRAP_PARTIAL_FLAG : WRAP_PARTIAL_RIGHT_FLAG;
        bitmask &= ~(isCurry ? WRAP_PARTIAL_RIGHT_FLAG : WRAP_PARTIAL_FLAG);
        if (!(bitmask & WRAP_CURRY_BOUND_FLAG)) {
          bitmask &= ~(WRAP_BIND_FLAG | WRAP_BIND_KEY_FLAG);
        }
        var newData = [
          func,
          bitmask,
          thisArg,
          newPartials,
          newHolders,
          newPartialsRight,
          newHoldersRight,
          argPos,
          ary2,
          arity
        ];
        var result2 = wrapFunc.apply(undefined$1, newData);
        if (isLaziable(func)) {
          setData(result2, newData);
        }
        result2.placeholder = placeholder2;
        return setWrapToString(result2, func, bitmask);
      }
      function createRound(methodName) {
        var func = Math2[methodName];
        return function(number, precision) {
          number = toNumber(number);
          precision = precision == null ? 0 : nativeMin(toInteger(precision), 292);
          if (precision && nativeIsFinite(number)) {
            var pair = (toString(number) + "e").split("e"), value = func(pair[0] + "e" + (+pair[1] + precision));
            pair = (toString(value) + "e").split("e");
            return +(pair[0] + "e" + (+pair[1] - precision));
          }
          return func(number);
        };
      }
      var createSet = !(Set2 && 1 / setToArray(new Set2([, -0]))[1] == INFINITY) ? noop2 : function(values2) {
        return new Set2(values2);
      };
      function createToPairs(keysFunc) {
        return function(object) {
          var tag = getTag2(object);
          if (tag == mapTag2) {
            return mapToArray(object);
          }
          if (tag == setTag2) {
            return setToPairs(object);
          }
          return baseToPairs(object, keysFunc(object));
        };
      }
      function createWrap(func, bitmask, thisArg, partials, holders, argPos, ary2, arity) {
        var isBindKey = bitmask & WRAP_BIND_KEY_FLAG;
        if (!isBindKey && typeof func != "function") {
          throw new TypeError2(FUNC_ERROR_TEXT);
        }
        var length = partials ? partials.length : 0;
        if (!length) {
          bitmask &= ~(WRAP_PARTIAL_FLAG | WRAP_PARTIAL_RIGHT_FLAG);
          partials = holders = undefined$1;
        }
        ary2 = ary2 === undefined$1 ? ary2 : nativeMax(toInteger(ary2), 0);
        arity = arity === undefined$1 ? arity : toInteger(arity);
        length -= holders ? holders.length : 0;
        if (bitmask & WRAP_PARTIAL_RIGHT_FLAG) {
          var partialsRight = partials, holdersRight = holders;
          partials = holders = undefined$1;
        }
        var data = isBindKey ? undefined$1 : getData(func);
        var newData = [
          func,
          bitmask,
          thisArg,
          partials,
          holders,
          partialsRight,
          holdersRight,
          argPos,
          ary2,
          arity
        ];
        if (data) {
          mergeData(newData, data);
        }
        func = newData[0];
        bitmask = newData[1];
        thisArg = newData[2];
        partials = newData[3];
        holders = newData[4];
        arity = newData[9] = newData[9] === undefined$1 ? isBindKey ? 0 : func.length : nativeMax(newData[9] - length, 0);
        if (!arity && bitmask & (WRAP_CURRY_FLAG | WRAP_CURRY_RIGHT_FLAG)) {
          bitmask &= ~(WRAP_CURRY_FLAG | WRAP_CURRY_RIGHT_FLAG);
        }
        if (!bitmask || bitmask == WRAP_BIND_FLAG) {
          var result2 = createBind(func, bitmask, thisArg);
        } else if (bitmask == WRAP_CURRY_FLAG || bitmask == WRAP_CURRY_RIGHT_FLAG) {
          result2 = createCurry(func, bitmask, arity);
        } else if ((bitmask == WRAP_PARTIAL_FLAG || bitmask == (WRAP_BIND_FLAG | WRAP_PARTIAL_FLAG)) && !holders.length) {
          result2 = createPartial(func, bitmask, thisArg, partials);
        } else {
          result2 = createHybrid.apply(undefined$1, newData);
        }
        var setter = data ? baseSetData : setData;
        return setWrapToString(setter(result2, newData), func, bitmask);
      }
      function customDefaultsAssignIn(objValue, srcValue, key, object) {
        if (objValue === undefined$1 || eq2(objValue, objectProto2[key]) && !hasOwnProperty2.call(object, key)) {
          return srcValue;
        }
        return objValue;
      }
      function customDefaultsMerge(objValue, srcValue, key, object, source, stack) {
        if (isObject2(objValue) && isObject2(srcValue)) {
          stack.set(srcValue, objValue);
          baseMerge(objValue, srcValue, undefined$1, customDefaultsMerge, stack);
          stack["delete"](srcValue);
        }
        return objValue;
      }
      function customOmitClone(value) {
        return isPlainObject2(value) ? undefined$1 : value;
      }
      function equalArrays(array, other, bitmask, customizer, equalFunc, stack) {
        var isPartial = bitmask & COMPARE_PARTIAL_FLAG, arrLength = array.length, othLength = other.length;
        if (arrLength != othLength && !(isPartial && othLength > arrLength)) {
          return false;
        }
        var arrStacked = stack.get(array);
        var othStacked = stack.get(other);
        if (arrStacked && othStacked) {
          return arrStacked == other && othStacked == array;
        }
        var index2 = -1, result2 = true, seen = bitmask & COMPARE_UNORDERED_FLAG ? new SetCache2() : undefined$1;
        stack.set(array, other);
        stack.set(other, array);
        while (++index2 < arrLength) {
          var arrValue = array[index2], othValue = other[index2];
          if (customizer) {
            var compared = isPartial ? customizer(othValue, arrValue, index2, other, array, stack) : customizer(arrValue, othValue, index2, array, other, stack);
          }
          if (compared !== undefined$1) {
            if (compared) {
              continue;
            }
            result2 = false;
            break;
          }
          if (seen) {
            if (!arraySome(other, function(othValue2, othIndex) {
              if (!cacheHas(seen, othIndex) && (arrValue === othValue2 || equalFunc(arrValue, othValue2, bitmask, customizer, stack))) {
                return seen.push(othIndex);
              }
            })) {
              result2 = false;
              break;
            }
          } else if (!(arrValue === othValue || equalFunc(arrValue, othValue, bitmask, customizer, stack))) {
            result2 = false;
            break;
          }
        }
        stack["delete"](array);
        stack["delete"](other);
        return result2;
      }
      function equalByTag(object, other, tag, bitmask, customizer, equalFunc, stack) {
        switch (tag) {
          case dataViewTag2:
            if (object.byteLength != other.byteLength || object.byteOffset != other.byteOffset) {
              return false;
            }
            object = object.buffer;
            other = other.buffer;
          case arrayBufferTag:
            if (object.byteLength != other.byteLength || !equalFunc(new Uint8Array(object), new Uint8Array(other))) {
              return false;
            }
            return true;
          case boolTag:
          case dateTag:
          case numberTag:
            return eq2(+object, +other);
          case errorTag:
            return object.name == other.name && object.message == other.message;
          case regexpTag:
          case stringTag:
            return object == other + "";
          case mapTag2:
            var convert = mapToArray;
          case setTag2:
            var isPartial = bitmask & COMPARE_PARTIAL_FLAG;
            convert || (convert = setToArray);
            if (object.size != other.size && !isPartial) {
              return false;
            }
            var stacked = stack.get(object);
            if (stacked) {
              return stacked == other;
            }
            bitmask |= COMPARE_UNORDERED_FLAG;
            stack.set(object, other);
            var result2 = equalArrays(convert(object), convert(other), bitmask, customizer, equalFunc, stack);
            stack["delete"](object);
            return result2;
          case symbolTag:
            if (symbolValueOf) {
              return symbolValueOf.call(object) == symbolValueOf.call(other);
            }
        }
        return false;
      }
      function equalObjects(object, other, bitmask, customizer, equalFunc, stack) {
        var isPartial = bitmask & COMPARE_PARTIAL_FLAG, objProps = getAllKeys(object), objLength = objProps.length, othProps = getAllKeys(other), othLength = othProps.length;
        if (objLength != othLength && !isPartial) {
          return false;
        }
        var index2 = objLength;
        while (index2--) {
          var key = objProps[index2];
          if (!(isPartial ? key in other : hasOwnProperty2.call(other, key))) {
            return false;
          }
        }
        var objStacked = stack.get(object);
        var othStacked = stack.get(other);
        if (objStacked && othStacked) {
          return objStacked == other && othStacked == object;
        }
        var result2 = true;
        stack.set(object, other);
        stack.set(other, object);
        var skipCtor = isPartial;
        while (++index2 < objLength) {
          key = objProps[index2];
          var objValue = object[key], othValue = other[key];
          if (customizer) {
            var compared = isPartial ? customizer(othValue, objValue, key, other, object, stack) : customizer(objValue, othValue, key, object, other, stack);
          }
          if (!(compared === undefined$1 ? objValue === othValue || equalFunc(objValue, othValue, bitmask, customizer, stack) : compared)) {
            result2 = false;
            break;
          }
          skipCtor || (skipCtor = key == "constructor");
        }
        if (result2 && !skipCtor) {
          var objCtor = object.constructor, othCtor = other.constructor;
          if (objCtor != othCtor && ("constructor" in object && "constructor" in other) && !(typeof objCtor == "function" && objCtor instanceof objCtor && typeof othCtor == "function" && othCtor instanceof othCtor)) {
            result2 = false;
          }
        }
        stack["delete"](object);
        stack["delete"](other);
        return result2;
      }
      function flatRest(func) {
        return setToString(overRest(func, undefined$1, flatten), func + "");
      }
      function getAllKeys(object) {
        return baseGetAllKeys(object, keys, getSymbols);
      }
      function getAllKeysIn(object) {
        return baseGetAllKeys(object, keysIn, getSymbolsIn);
      }
      var getData = !metaMap ? noop2 : function(func) {
        return metaMap.get(func);
      };
      function getFuncName(func) {
        var result2 = func.name + "", array = realNames[result2], length = hasOwnProperty2.call(realNames, result2) ? array.length : 0;
        while (length--) {
          var data = array[length], otherFunc = data.func;
          if (otherFunc == null || otherFunc == func) {
            return data.name;
          }
        }
        return result2;
      }
      function getHolder(func) {
        var object = hasOwnProperty2.call(lodash2, "placeholder") ? lodash2 : func;
        return object.placeholder;
      }
      function getIteratee() {
        var result2 = lodash2.iteratee || iteratee;
        result2 = result2 === iteratee ? baseIteratee : result2;
        return arguments.length ? result2(arguments[0], arguments[1]) : result2;
      }
      function getMapData2(map2, key) {
        var data = map2.__data__;
        return isKeyable2(key) ? data[typeof key == "string" ? "string" : "hash"] : data.map;
      }
      function getMatchData(object) {
        var result2 = keys(object), length = result2.length;
        while (length--) {
          var key = result2[length], value = object[key];
          result2[length] = [key, value, isStrictComparable(value)];
        }
        return result2;
      }
      function getNative2(object, key) {
        var value = getValue2(object, key);
        return baseIsNative2(value) ? value : undefined$1;
      }
      function getRawTag2(value) {
        var isOwn = hasOwnProperty2.call(value, symToStringTag2), tag = value[symToStringTag2];
        try {
          value[symToStringTag2] = undefined$1;
          var unmasked = true;
        } catch (e) {
        }
        var result2 = nativeObjectToString2.call(value);
        if (unmasked) {
          if (isOwn) {
            value[symToStringTag2] = tag;
          } else {
            delete value[symToStringTag2];
          }
        }
        return result2;
      }
      var getSymbols = !nativeGetSymbols ? stubArray : function(object) {
        if (object == null) {
          return [];
        }
        object = Object2(object);
        return arrayFilter(nativeGetSymbols(object), function(symbol) {
          return propertyIsEnumerable2.call(object, symbol);
        });
      };
      var getSymbolsIn = !nativeGetSymbols ? stubArray : function(object) {
        var result2 = [];
        while (object) {
          arrayPush(result2, getSymbols(object));
          object = getPrototype(object);
        }
        return result2;
      };
      var getTag2 = baseGetTag2;
      if (DataView2 && getTag2(new DataView2(new ArrayBuffer(1))) != dataViewTag2 || Map2 && getTag2(new Map2()) != mapTag2 || Promise2 && getTag2(Promise2.resolve()) != promiseTag2 || Set2 && getTag2(new Set2()) != setTag2 || WeakMap2 && getTag2(new WeakMap2()) != weakMapTag2) {
        getTag2 = function(value) {
          var result2 = baseGetTag2(value), Ctor = result2 == objectTag2 ? value.constructor : undefined$1, ctorString = Ctor ? toSource2(Ctor) : "";
          if (ctorString) {
            switch (ctorString) {
              case dataViewCtorString2:
                return dataViewTag2;
              case mapCtorString2:
                return mapTag2;
              case promiseCtorString2:
                return promiseTag2;
              case setCtorString2:
                return setTag2;
              case weakMapCtorString2:
                return weakMapTag2;
            }
          }
          return result2;
        };
      }
      function getView(start2, end2, transforms) {
        var index2 = -1, length = transforms.length;
        while (++index2 < length) {
          var data = transforms[index2], size2 = data.size;
          switch (data.type) {
            case "drop":
              start2 += size2;
              break;
            case "dropRight":
              end2 -= size2;
              break;
            case "take":
              end2 = nativeMin(end2, start2 + size2);
              break;
            case "takeRight":
              start2 = nativeMax(start2, end2 - size2);
              break;
          }
        }
        return { "start": start2, "end": end2 };
      }
      function getWrapDetails(source) {
        var match = source.match(reWrapDetails);
        return match ? match[1].split(reSplitDetails) : [];
      }
      function hasPath(object, path, hasFunc) {
        path = castPath(path, object);
        var index2 = -1, length = path.length, result2 = false;
        while (++index2 < length) {
          var key = toKey(path[index2]);
          if (!(result2 = object != null && hasFunc(object, key))) {
            break;
          }
          object = object[key];
        }
        if (result2 || ++index2 != length) {
          return result2;
        }
        length = object == null ? 0 : object.length;
        return !!length && isLength(length) && isIndex(key, length) && (isArray(object) || isArguments(object));
      }
      function initCloneArray(array) {
        var length = array.length, result2 = new array.constructor(length);
        if (length && typeof array[0] == "string" && hasOwnProperty2.call(array, "index")) {
          result2.index = array.index;
          result2.input = array.input;
        }
        return result2;
      }
      function initCloneObject(object) {
        return typeof object.constructor == "function" && !isPrototype(object) ? baseCreate(getPrototype(object)) : {};
      }
      function initCloneByTag(object, tag, isDeep) {
        var Ctor = object.constructor;
        switch (tag) {
          case arrayBufferTag:
            return cloneArrayBuffer(object);
          case boolTag:
          case dateTag:
            return new Ctor(+object);
          case dataViewTag2:
            return cloneDataView(object, isDeep);
          case float32Tag:
          case float64Tag:
          case int8Tag:
          case int16Tag:
          case int32Tag:
          case uint8Tag:
          case uint8ClampedTag:
          case uint16Tag:
          case uint32Tag:
            return cloneTypedArray(object, isDeep);
          case mapTag2:
            return new Ctor();
          case numberTag:
          case stringTag:
            return new Ctor(object);
          case regexpTag:
            return cloneRegExp(object);
          case setTag2:
            return new Ctor();
          case symbolTag:
            return cloneSymbol(object);
        }
      }
      function insertWrapDetails(source, details) {
        var length = details.length;
        if (!length) {
          return source;
        }
        var lastIndex = length - 1;
        details[lastIndex] = (length > 1 ? "& " : "") + details[lastIndex];
        details = details.join(length > 2 ? ", " : " ");
        return source.replace(reWrapComment, "{\n/* [wrapped with " + details + "] */\n");
      }
      function isFlattenable(value) {
        return isArray(value) || isArguments(value) || !!(spreadableSymbol && value && value[spreadableSymbol]);
      }
      function isIndex(value, length) {
        var type = typeof value;
        length = length == null ? MAX_SAFE_INTEGER : length;
        return !!length && (type == "number" || type != "symbol" && reIsUint.test(value)) && (value > -1 && value % 1 == 0 && value < length);
      }
      function isIterateeCall(value, index2, object) {
        if (!isObject2(object)) {
          return false;
        }
        var type = typeof index2;
        if (type == "number" ? isArrayLike(object) && isIndex(index2, object.length) : type == "string" && index2 in object) {
          return eq2(object[index2], value);
        }
        return false;
      }
      function isKey(value, object) {
        if (isArray(value)) {
          return false;
        }
        var type = typeof value;
        if (type == "number" || type == "symbol" || type == "boolean" || value == null || isSymbol(value)) {
          return true;
        }
        return reIsPlainProp.test(value) || !reIsDeepProp.test(value) || object != null && value in Object2(object);
      }
      function isKeyable2(value) {
        var type = typeof value;
        return type == "string" || type == "number" || type == "symbol" || type == "boolean" ? value !== "__proto__" : value === null;
      }
      function isLaziable(func) {
        var funcName = getFuncName(func), other = lodash2[funcName];
        if (typeof other != "function" || !(funcName in LazyWrapper.prototype)) {
          return false;
        }
        if (func === other) {
          return true;
        }
        var data = getData(other);
        return !!data && func === data[0];
      }
      function isMasked2(func) {
        return !!maskSrcKey2 && maskSrcKey2 in func;
      }
      var isMaskable = coreJsData2 ? isFunction2 : stubFalse2;
      function isPrototype(value) {
        var Ctor = value && value.constructor, proto = typeof Ctor == "function" && Ctor.prototype || objectProto2;
        return value === proto;
      }
      function isStrictComparable(value) {
        return value === value && !isObject2(value);
      }
      function matchesStrictComparable(key, srcValue) {
        return function(object) {
          if (object == null) {
            return false;
          }
          return object[key] === srcValue && (srcValue !== undefined$1 || key in Object2(object));
        };
      }
      function memoizeCapped(func) {
        var result2 = memoize(func, function(key) {
          if (cache.size === MAX_MEMOIZE_SIZE) {
            cache.clear();
          }
          return key;
        });
        var cache = result2.cache;
        return result2;
      }
      function mergeData(data, source) {
        var bitmask = data[1], srcBitmask = source[1], newBitmask = bitmask | srcBitmask, isCommon = newBitmask < (WRAP_BIND_FLAG | WRAP_BIND_KEY_FLAG | WRAP_ARY_FLAG);
        var isCombo = srcBitmask == WRAP_ARY_FLAG && bitmask == WRAP_CURRY_FLAG || srcBitmask == WRAP_ARY_FLAG && bitmask == WRAP_REARG_FLAG && data[7].length <= source[8] || srcBitmask == (WRAP_ARY_FLAG | WRAP_REARG_FLAG) && source[7].length <= source[8] && bitmask == WRAP_CURRY_FLAG;
        if (!(isCommon || isCombo)) {
          return data;
        }
        if (srcBitmask & WRAP_BIND_FLAG) {
          data[2] = source[2];
          newBitmask |= bitmask & WRAP_BIND_FLAG ? 0 : WRAP_CURRY_BOUND_FLAG;
        }
        var value = source[3];
        if (value) {
          var partials = data[3];
          data[3] = partials ? composeArgs(partials, value, source[4]) : value;
          data[4] = partials ? replaceHolders(data[3], PLACEHOLDER) : source[4];
        }
        value = source[5];
        if (value) {
          partials = data[5];
          data[5] = partials ? composeArgsRight(partials, value, source[6]) : value;
          data[6] = partials ? replaceHolders(data[5], PLACEHOLDER) : source[6];
        }
        value = source[7];
        if (value) {
          data[7] = value;
        }
        if (srcBitmask & WRAP_ARY_FLAG) {
          data[8] = data[8] == null ? source[8] : nativeMin(data[8], source[8]);
        }
        if (data[9] == null) {
          data[9] = source[9];
        }
        data[0] = source[0];
        data[1] = newBitmask;
        return data;
      }
      function nativeKeysIn(object) {
        var result2 = [];
        if (object != null) {
          for (var key in Object2(object)) {
            result2.push(key);
          }
        }
        return result2;
      }
      function objectToString2(value) {
        return nativeObjectToString2.call(value);
      }
      function overRest(func, start2, transform2) {
        start2 = nativeMax(start2 === undefined$1 ? func.length - 1 : start2, 0);
        return function() {
          var args = arguments, index2 = -1, length = nativeMax(args.length - start2, 0), array = Array2(length);
          while (++index2 < length) {
            array[index2] = args[start2 + index2];
          }
          index2 = -1;
          var otherArgs = Array2(start2 + 1);
          while (++index2 < start2) {
            otherArgs[index2] = args[index2];
          }
          otherArgs[start2] = transform2(array);
          return apply(func, this, otherArgs);
        };
      }
      function parent(object, path) {
        return path.length < 2 ? object : baseGet(object, baseSlice(path, 0, -1));
      }
      function reorder(array, indexes) {
        var arrLength = array.length, length = nativeMin(indexes.length, arrLength), oldArray = copyArray(array);
        while (length--) {
          var index2 = indexes[length];
          array[length] = isIndex(index2, arrLength) ? oldArray[index2] : undefined$1;
        }
        return array;
      }
      function safeGet(object, key) {
        if (key === "constructor" && typeof object[key] === "function") {
          return;
        }
        if (key == "__proto__") {
          return;
        }
        return object[key];
      }
      var setData = shortOut(baseSetData);
      var setTimeout2 = ctxSetTimeout || function(func, wait) {
        return root2.setTimeout(func, wait);
      };
      var setToString = shortOut(baseSetToString);
      function setWrapToString(wrapper, reference2, bitmask) {
        var source = reference2 + "";
        return setToString(wrapper, insertWrapDetails(source, updateWrapDetails(getWrapDetails(source), bitmask)));
      }
      function shortOut(func) {
        var count = 0, lastCalled = 0;
        return function() {
          var stamp = nativeNow(), remaining = HOT_SPAN - (stamp - lastCalled);
          lastCalled = stamp;
          if (remaining > 0) {
            if (++count >= HOT_COUNT) {
              return arguments[0];
            }
          } else {
            count = 0;
          }
          return func.apply(undefined$1, arguments);
        };
      }
      function shuffleSelf(array, size2) {
        var index2 = -1, length = array.length, lastIndex = length - 1;
        size2 = size2 === undefined$1 ? length : size2;
        while (++index2 < size2) {
          var rand = baseRandom(index2, lastIndex), value = array[rand];
          array[rand] = array[index2];
          array[index2] = value;
        }
        array.length = size2;
        return array;
      }
      var stringToPath = memoizeCapped(function(string) {
        var result2 = [];
        if (string.charCodeAt(0) === 46) {
          result2.push("");
        }
        string.replace(rePropName, function(match, number, quote, subString) {
          result2.push(quote ? subString.replace(reEscapeChar, "$1") : number || match);
        });
        return result2;
      });
      function toKey(value) {
        if (typeof value == "string" || isSymbol(value)) {
          return value;
        }
        var result2 = value + "";
        return result2 == "0" && 1 / value == -INFINITY ? "-0" : result2;
      }
      function toSource2(func) {
        if (func != null) {
          try {
            return funcToString2.call(func);
          } catch (e) {
          }
          try {
            return func + "";
          } catch (e) {
          }
        }
        return "";
      }
      function updateWrapDetails(details, bitmask) {
        arrayEach(wrapFlags, function(pair) {
          var value = "_." + pair[0];
          if (bitmask & pair[1] && !arrayIncludes(details, value)) {
            details.push(value);
          }
        });
        return details.sort();
      }
      function wrapperClone(wrapper) {
        if (wrapper instanceof LazyWrapper) {
          return wrapper.clone();
        }
        var result2 = new LodashWrapper(wrapper.__wrapped__, wrapper.__chain__);
        result2.__actions__ = copyArray(wrapper.__actions__);
        result2.__index__ = wrapper.__index__;
        result2.__values__ = wrapper.__values__;
        return result2;
      }
      function chunk(array, size2, guard) {
        if (guard ? isIterateeCall(array, size2, guard) : size2 === undefined$1) {
          size2 = 1;
        } else {
          size2 = nativeMax(toInteger(size2), 0);
        }
        var length = array == null ? 0 : array.length;
        if (!length || size2 < 1) {
          return [];
        }
        var index2 = 0, resIndex = 0, result2 = Array2(nativeCeil(length / size2));
        while (index2 < length) {
          result2[resIndex++] = baseSlice(array, index2, index2 += size2);
        }
        return result2;
      }
      function compact(array) {
        var index2 = -1, length = array == null ? 0 : array.length, resIndex = 0, result2 = [];
        while (++index2 < length) {
          var value = array[index2];
          if (value) {
            result2[resIndex++] = value;
          }
        }
        return result2;
      }
      function concat() {
        var length = arguments.length;
        if (!length) {
          return [];
        }
        var args = Array2(length - 1), array = arguments[0], index2 = length;
        while (index2--) {
          args[index2 - 1] = arguments[index2];
        }
        return arrayPush(isArray(array) ? copyArray(array) : [array], baseFlatten(args, 1));
      }
      var difference = baseRest(function(array, values2) {
        return isArrayLikeObject(array) ? baseDifference(array, baseFlatten(values2, 1, isArrayLikeObject, true)) : [];
      });
      var differenceBy = baseRest(function(array, values2) {
        var iteratee2 = last(values2);
        if (isArrayLikeObject(iteratee2)) {
          iteratee2 = undefined$1;
        }
        return isArrayLikeObject(array) ? baseDifference(array, baseFlatten(values2, 1, isArrayLikeObject, true), getIteratee(iteratee2, 2)) : [];
      });
      var differenceWith = baseRest(function(array, values2) {
        var comparator = last(values2);
        if (isArrayLikeObject(comparator)) {
          comparator = undefined$1;
        }
        return isArrayLikeObject(array) ? baseDifference(array, baseFlatten(values2, 1, isArrayLikeObject, true), undefined$1, comparator) : [];
      });
      function drop(array, n, guard) {
        var length = array == null ? 0 : array.length;
        if (!length) {
          return [];
        }
        n = guard || n === undefined$1 ? 1 : toInteger(n);
        return baseSlice(array, n < 0 ? 0 : n, length);
      }
      function dropRight(array, n, guard) {
        var length = array == null ? 0 : array.length;
        if (!length) {
          return [];
        }
        n = guard || n === undefined$1 ? 1 : toInteger(n);
        n = length - n;
        return baseSlice(array, 0, n < 0 ? 0 : n);
      }
      function dropRightWhile(array, predicate) {
        return array && array.length ? baseWhile(array, getIteratee(predicate, 3), true, true) : [];
      }
      function dropWhile(array, predicate) {
        return array && array.length ? baseWhile(array, getIteratee(predicate, 3), true) : [];
      }
      function fill(array, value, start2, end2) {
        var length = array == null ? 0 : array.length;
        if (!length) {
          return [];
        }
        if (start2 && typeof start2 != "number" && isIterateeCall(array, value, start2)) {
          start2 = 0;
          end2 = length;
        }
        return baseFill(array, value, start2, end2);
      }
      function findIndex(array, predicate, fromIndex) {
        var length = array == null ? 0 : array.length;
        if (!length) {
          return -1;
        }
        var index2 = fromIndex == null ? 0 : toInteger(fromIndex);
        if (index2 < 0) {
          index2 = nativeMax(length + index2, 0);
        }
        return baseFindIndex(array, getIteratee(predicate, 3), index2);
      }
      function findLastIndex(array, predicate, fromIndex) {
        var length = array == null ? 0 : array.length;
        if (!length) {
          return -1;
        }
        var index2 = length - 1;
        if (fromIndex !== undefined$1) {
          index2 = toInteger(fromIndex);
          index2 = fromIndex < 0 ? nativeMax(length + index2, 0) : nativeMin(index2, length - 1);
        }
        return baseFindIndex(array, getIteratee(predicate, 3), index2, true);
      }
      function flatten(array) {
        var length = array == null ? 0 : array.length;
        return length ? baseFlatten(array, 1) : [];
      }
      function flattenDeep(array) {
        var length = array == null ? 0 : array.length;
        return length ? baseFlatten(array, INFINITY) : [];
      }
      function flattenDepth(array, depth) {
        var length = array == null ? 0 : array.length;
        if (!length) {
          return [];
        }
        depth = depth === undefined$1 ? 1 : toInteger(depth);
        return baseFlatten(array, depth);
      }
      function fromPairs(pairs) {
        var index2 = -1, length = pairs == null ? 0 : pairs.length, result2 = {};
        while (++index2 < length) {
          var pair = pairs[index2];
          result2[pair[0]] = pair[1];
        }
        return result2;
      }
      function head(array) {
        return array && array.length ? array[0] : undefined$1;
      }
      function indexOf(array, value, fromIndex) {
        var length = array == null ? 0 : array.length;
        if (!length) {
          return -1;
        }
        var index2 = fromIndex == null ? 0 : toInteger(fromIndex);
        if (index2 < 0) {
          index2 = nativeMax(length + index2, 0);
        }
        return baseIndexOf(array, value, index2);
      }
      function initial(array) {
        var length = array == null ? 0 : array.length;
        return length ? baseSlice(array, 0, -1) : [];
      }
      var intersection = baseRest(function(arrays) {
        var mapped = arrayMap(arrays, castArrayLikeObject);
        return mapped.length && mapped[0] === arrays[0] ? baseIntersection(mapped) : [];
      });
      var intersectionBy = baseRest(function(arrays) {
        var iteratee2 = last(arrays), mapped = arrayMap(arrays, castArrayLikeObject);
        if (iteratee2 === last(mapped)) {
          iteratee2 = undefined$1;
        } else {
          mapped.pop();
        }
        return mapped.length && mapped[0] === arrays[0] ? baseIntersection(mapped, getIteratee(iteratee2, 2)) : [];
      });
      var intersectionWith = baseRest(function(arrays) {
        var comparator = last(arrays), mapped = arrayMap(arrays, castArrayLikeObject);
        comparator = typeof comparator == "function" ? comparator : undefined$1;
        if (comparator) {
          mapped.pop();
        }
        return mapped.length && mapped[0] === arrays[0] ? baseIntersection(mapped, undefined$1, comparator) : [];
      });
      function join(array, separator) {
        return array == null ? "" : nativeJoin.call(array, separator);
      }
      function last(array) {
        var length = array == null ? 0 : array.length;
        return length ? array[length - 1] : undefined$1;
      }
      function lastIndexOf(array, value, fromIndex) {
        var length = array == null ? 0 : array.length;
        if (!length) {
          return -1;
        }
        var index2 = length;
        if (fromIndex !== undefined$1) {
          index2 = toInteger(fromIndex);
          index2 = index2 < 0 ? nativeMax(length + index2, 0) : nativeMin(index2, length - 1);
        }
        return value === value ? strictLastIndexOf(array, value, index2) : baseFindIndex(array, baseIsNaN, index2, true);
      }
      function nth(array, n) {
        return array && array.length ? baseNth(array, toInteger(n)) : undefined$1;
      }
      var pull = baseRest(pullAll);
      function pullAll(array, values2) {
        return array && array.length && values2 && values2.length ? basePullAll(array, values2) : array;
      }
      function pullAllBy(array, values2, iteratee2) {
        return array && array.length && values2 && values2.length ? basePullAll(array, values2, getIteratee(iteratee2, 2)) : array;
      }
      function pullAllWith(array, values2, comparator) {
        return array && array.length && values2 && values2.length ? basePullAll(array, values2, undefined$1, comparator) : array;
      }
      var pullAt = flatRest(function(array, indexes) {
        var length = array == null ? 0 : array.length, result2 = baseAt(array, indexes);
        basePullAt(array, arrayMap(indexes, function(index2) {
          return isIndex(index2, length) ? +index2 : index2;
        }).sort(compareAscending));
        return result2;
      });
      function remove2(array, predicate) {
        var result2 = [];
        if (!(array && array.length)) {
          return result2;
        }
        var index2 = -1, indexes = [], length = array.length;
        predicate = getIteratee(predicate, 3);
        while (++index2 < length) {
          var value = array[index2];
          if (predicate(value, index2, array)) {
            result2.push(value);
            indexes.push(index2);
          }
        }
        basePullAt(array, indexes);
        return result2;
      }
      function reverse(array) {
        return array == null ? array : nativeReverse.call(array);
      }
      function slice(array, start2, end2) {
        var length = array == null ? 0 : array.length;
        if (!length) {
          return [];
        }
        if (end2 && typeof end2 != "number" && isIterateeCall(array, start2, end2)) {
          start2 = 0;
          end2 = length;
        } else {
          start2 = start2 == null ? 0 : toInteger(start2);
          end2 = end2 === undefined$1 ? length : toInteger(end2);
        }
        return baseSlice(array, start2, end2);
      }
      function sortedIndex(array, value) {
        return baseSortedIndex(array, value);
      }
      function sortedIndexBy(array, value, iteratee2) {
        return baseSortedIndexBy(array, value, getIteratee(iteratee2, 2));
      }
      function sortedIndexOf(array, value) {
        var length = array == null ? 0 : array.length;
        if (length) {
          var index2 = baseSortedIndex(array, value);
          if (index2 < length && eq2(array[index2], value)) {
            return index2;
          }
        }
        return -1;
      }
      function sortedLastIndex(array, value) {
        return baseSortedIndex(array, value, true);
      }
      function sortedLastIndexBy(array, value, iteratee2) {
        return baseSortedIndexBy(array, value, getIteratee(iteratee2, 2), true);
      }
      function sortedLastIndexOf(array, value) {
        var length = array == null ? 0 : array.length;
        if (length) {
          var index2 = baseSortedIndex(array, value, true) - 1;
          if (eq2(array[index2], value)) {
            return index2;
          }
        }
        return -1;
      }
      function sortedUniq(array) {
        return array && array.length ? baseSortedUniq(array) : [];
      }
      function sortedUniqBy(array, iteratee2) {
        return array && array.length ? baseSortedUniq(array, getIteratee(iteratee2, 2)) : [];
      }
      function tail(array) {
        var length = array == null ? 0 : array.length;
        return length ? baseSlice(array, 1, length) : [];
      }
      function take(array, n, guard) {
        if (!(array && array.length)) {
          return [];
        }
        n = guard || n === undefined$1 ? 1 : toInteger(n);
        return baseSlice(array, 0, n < 0 ? 0 : n);
      }
      function takeRight(array, n, guard) {
        var length = array == null ? 0 : array.length;
        if (!length) {
          return [];
        }
        n = guard || n === undefined$1 ? 1 : toInteger(n);
        n = length - n;
        return baseSlice(array, n < 0 ? 0 : n, length);
      }
      function takeRightWhile(array, predicate) {
        return array && array.length ? baseWhile(array, getIteratee(predicate, 3), false, true) : [];
      }
      function takeWhile(array, predicate) {
        return array && array.length ? baseWhile(array, getIteratee(predicate, 3)) : [];
      }
      var union = baseRest(function(arrays) {
        return baseUniq(baseFlatten(arrays, 1, isArrayLikeObject, true));
      });
      var unionBy = baseRest(function(arrays) {
        var iteratee2 = last(arrays);
        if (isArrayLikeObject(iteratee2)) {
          iteratee2 = undefined$1;
        }
        return baseUniq(baseFlatten(arrays, 1, isArrayLikeObject, true), getIteratee(iteratee2, 2));
      });
      var unionWith = baseRest(function(arrays) {
        var comparator = last(arrays);
        comparator = typeof comparator == "function" ? comparator : undefined$1;
        return baseUniq(baseFlatten(arrays, 1, isArrayLikeObject, true), undefined$1, comparator);
      });
      function uniq(array) {
        return array && array.length ? baseUniq(array) : [];
      }
      function uniqBy(array, iteratee2) {
        return array && array.length ? baseUniq(array, getIteratee(iteratee2, 2)) : [];
      }
      function uniqWith(array, comparator) {
        comparator = typeof comparator == "function" ? comparator : undefined$1;
        return array && array.length ? baseUniq(array, undefined$1, comparator) : [];
      }
      function unzip(array) {
        if (!(array && array.length)) {
          return [];
        }
        var length = 0;
        array = arrayFilter(array, function(group) {
          if (isArrayLikeObject(group)) {
            length = nativeMax(group.length, length);
            return true;
          }
        });
        return baseTimes(length, function(index2) {
          return arrayMap(array, baseProperty(index2));
        });
      }
      function unzipWith(array, iteratee2) {
        if (!(array && array.length)) {
          return [];
        }
        var result2 = unzip(array);
        if (iteratee2 == null) {
          return result2;
        }
        return arrayMap(result2, function(group) {
          return apply(iteratee2, undefined$1, group);
        });
      }
      var without = baseRest(function(array, values2) {
        return isArrayLikeObject(array) ? baseDifference(array, values2) : [];
      });
      var xor = baseRest(function(arrays) {
        return baseXor(arrayFilter(arrays, isArrayLikeObject));
      });
      var xorBy = baseRest(function(arrays) {
        var iteratee2 = last(arrays);
        if (isArrayLikeObject(iteratee2)) {
          iteratee2 = undefined$1;
        }
        return baseXor(arrayFilter(arrays, isArrayLikeObject), getIteratee(iteratee2, 2));
      });
      var xorWith = baseRest(function(arrays) {
        var comparator = last(arrays);
        comparator = typeof comparator == "function" ? comparator : undefined$1;
        return baseXor(arrayFilter(arrays, isArrayLikeObject), undefined$1, comparator);
      });
      var zip = baseRest(unzip);
      function zipObject(props, values2) {
        return baseZipObject(props || [], values2 || [], assignValue);
      }
      function zipObjectDeep(props, values2) {
        return baseZipObject(props || [], values2 || [], baseSet);
      }
      var zipWith = baseRest(function(arrays) {
        var length = arrays.length, iteratee2 = length > 1 ? arrays[length - 1] : undefined$1;
        iteratee2 = typeof iteratee2 == "function" ? (arrays.pop(), iteratee2) : undefined$1;
        return unzipWith(arrays, iteratee2);
      });
      function chain(value) {
        var result2 = lodash2(value);
        result2.__chain__ = true;
        return result2;
      }
      function tap(value, interceptor) {
        interceptor(value);
        return value;
      }
      function thru(value, interceptor) {
        return interceptor(value);
      }
      var wrapperAt = flatRest(function(paths) {
        var length = paths.length, start2 = length ? paths[0] : 0, value = this.__wrapped__, interceptor = function(object) {
          return baseAt(object, paths);
        };
        if (length > 1 || this.__actions__.length || !(value instanceof LazyWrapper) || !isIndex(start2)) {
          return this.thru(interceptor);
        }
        value = value.slice(start2, +start2 + (length ? 1 : 0));
        value.__actions__.push({
          "func": thru,
          "args": [interceptor],
          "thisArg": undefined$1
        });
        return new LodashWrapper(value, this.__chain__).thru(function(array) {
          if (length && !array.length) {
            array.push(undefined$1);
          }
          return array;
        });
      });
      function wrapperChain() {
        return chain(this);
      }
      function wrapperCommit() {
        return new LodashWrapper(this.value(), this.__chain__);
      }
      function wrapperNext() {
        if (this.__values__ === undefined$1) {
          this.__values__ = toArray(this.value());
        }
        var done = this.__index__ >= this.__values__.length, value = done ? undefined$1 : this.__values__[this.__index__++];
        return { "done": done, "value": value };
      }
      function wrapperToIterator() {
        return this;
      }
      function wrapperPlant(value) {
        var result2, parent2 = this;
        while (parent2 instanceof baseLodash) {
          var clone2 = wrapperClone(parent2);
          clone2.__index__ = 0;
          clone2.__values__ = undefined$1;
          if (result2) {
            previous.__wrapped__ = clone2;
          } else {
            result2 = clone2;
          }
          var previous = clone2;
          parent2 = parent2.__wrapped__;
        }
        previous.__wrapped__ = value;
        return result2;
      }
      function wrapperReverse() {
        var value = this.__wrapped__;
        if (value instanceof LazyWrapper) {
          var wrapped = value;
          if (this.__actions__.length) {
            wrapped = new LazyWrapper(this);
          }
          wrapped = wrapped.reverse();
          wrapped.__actions__.push({
            "func": thru,
            "args": [reverse],
            "thisArg": undefined$1
          });
          return new LodashWrapper(wrapped, this.__chain__);
        }
        return this.thru(reverse);
      }
      function wrapperValue() {
        return baseWrapperValue(this.__wrapped__, this.__actions__);
      }
      var countBy = createAggregator(function(result2, value, key) {
        if (hasOwnProperty2.call(result2, key)) {
          ++result2[key];
        } else {
          baseAssignValue(result2, key, 1);
        }
      });
      function every(collection, predicate, guard) {
        var func = isArray(collection) ? arrayEvery : baseEvery;
        if (guard && isIterateeCall(collection, predicate, guard)) {
          predicate = undefined$1;
        }
        return func(collection, getIteratee(predicate, 3));
      }
      function filter(collection, predicate) {
        var func = isArray(collection) ? arrayFilter : baseFilter;
        return func(collection, getIteratee(predicate, 3));
      }
      var find = createFind(findIndex);
      var findLast = createFind(findLastIndex);
      function flatMap(collection, iteratee2) {
        return baseFlatten(map(collection, iteratee2), 1);
      }
      function flatMapDeep(collection, iteratee2) {
        return baseFlatten(map(collection, iteratee2), INFINITY);
      }
      function flatMapDepth(collection, iteratee2, depth) {
        depth = depth === undefined$1 ? 1 : toInteger(depth);
        return baseFlatten(map(collection, iteratee2), depth);
      }
      function forEach(collection, iteratee2) {
        var func = isArray(collection) ? arrayEach : baseEach;
        return func(collection, getIteratee(iteratee2, 3));
      }
      function forEachRight(collection, iteratee2) {
        var func = isArray(collection) ? arrayEachRight : baseEachRight;
        return func(collection, getIteratee(iteratee2, 3));
      }
      var groupBy = createAggregator(function(result2, value, key) {
        if (hasOwnProperty2.call(result2, key)) {
          result2[key].push(value);
        } else {
          baseAssignValue(result2, key, [value]);
        }
      });
      function includes(collection, value, fromIndex, guard) {
        collection = isArrayLike(collection) ? collection : values(collection);
        fromIndex = fromIndex && !guard ? toInteger(fromIndex) : 0;
        var length = collection.length;
        if (fromIndex < 0) {
          fromIndex = nativeMax(length + fromIndex, 0);
        }
        return isString(collection) ? fromIndex <= length && collection.indexOf(value, fromIndex) > -1 : !!length && baseIndexOf(collection, value, fromIndex) > -1;
      }
      var invokeMap = baseRest(function(collection, path, args) {
        var index2 = -1, isFunc = typeof path == "function", result2 = isArrayLike(collection) ? Array2(collection.length) : [];
        baseEach(collection, function(value) {
          result2[++index2] = isFunc ? apply(path, value, args) : baseInvoke(value, path, args);
        });
        return result2;
      });
      var keyBy = createAggregator(function(result2, value, key) {
        baseAssignValue(result2, key, value);
      });
      function map(collection, iteratee2) {
        var func = isArray(collection) ? arrayMap : baseMap;
        return func(collection, getIteratee(iteratee2, 3));
      }
      function orderBy(collection, iteratees, orders, guard) {
        if (collection == null) {
          return [];
        }
        if (!isArray(iteratees)) {
          iteratees = iteratees == null ? [] : [iteratees];
        }
        orders = guard ? undefined$1 : orders;
        if (!isArray(orders)) {
          orders = orders == null ? [] : [orders];
        }
        return baseOrderBy(collection, iteratees, orders);
      }
      var partition = createAggregator(function(result2, value, key) {
        result2[key ? 0 : 1].push(value);
      }, function() {
        return [[], []];
      });
      function reduce(collection, iteratee2, accumulator) {
        var func = isArray(collection) ? arrayReduce : baseReduce, initAccum = arguments.length < 3;
        return func(collection, getIteratee(iteratee2, 4), accumulator, initAccum, baseEach);
      }
      function reduceRight(collection, iteratee2, accumulator) {
        var func = isArray(collection) ? arrayReduceRight : baseReduce, initAccum = arguments.length < 3;
        return func(collection, getIteratee(iteratee2, 4), accumulator, initAccum, baseEachRight);
      }
      function reject(collection, predicate) {
        var func = isArray(collection) ? arrayFilter : baseFilter;
        return func(collection, negate(getIteratee(predicate, 3)));
      }
      function sample(collection) {
        var func = isArray(collection) ? arraySample : baseSample;
        return func(collection);
      }
      function sampleSize(collection, n, guard) {
        if (guard ? isIterateeCall(collection, n, guard) : n === undefined$1) {
          n = 1;
        } else {
          n = toInteger(n);
        }
        var func = isArray(collection) ? arraySampleSize : baseSampleSize;
        return func(collection, n);
      }
      function shuffle(collection) {
        var func = isArray(collection) ? arrayShuffle : baseShuffle;
        return func(collection);
      }
      function size(collection) {
        if (collection == null) {
          return 0;
        }
        if (isArrayLike(collection)) {
          return isString(collection) ? stringSize(collection) : collection.length;
        }
        var tag = getTag2(collection);
        if (tag == mapTag2 || tag == setTag2) {
          return collection.size;
        }
        return baseKeys(collection).length;
      }
      function some(collection, predicate, guard) {
        var func = isArray(collection) ? arraySome : baseSome;
        if (guard && isIterateeCall(collection, predicate, guard)) {
          predicate = undefined$1;
        }
        return func(collection, getIteratee(predicate, 3));
      }
      var sortBy = baseRest(function(collection, iteratees) {
        if (collection == null) {
          return [];
        }
        var length = iteratees.length;
        if (length > 1 && isIterateeCall(collection, iteratees[0], iteratees[1])) {
          iteratees = [];
        } else if (length > 2 && isIterateeCall(iteratees[0], iteratees[1], iteratees[2])) {
          iteratees = [iteratees[0]];
        }
        return baseOrderBy(collection, baseFlatten(iteratees, 1), []);
      });
      var now = ctxNow || function() {
        return root2.Date.now();
      };
      function after(n, func) {
        if (typeof func != "function") {
          throw new TypeError2(FUNC_ERROR_TEXT);
        }
        n = toInteger(n);
        return function() {
          if (--n < 1) {
            return func.apply(this, arguments);
          }
        };
      }
      function ary(func, n, guard) {
        n = guard ? undefined$1 : n;
        n = func && n == null ? func.length : n;
        return createWrap(func, WRAP_ARY_FLAG, undefined$1, undefined$1, undefined$1, undefined$1, n);
      }
      function before(n, func) {
        var result2;
        if (typeof func != "function") {
          throw new TypeError2(FUNC_ERROR_TEXT);
        }
        n = toInteger(n);
        return function() {
          if (--n > 0) {
            result2 = func.apply(this, arguments);
          }
          if (n <= 1) {
            func = undefined$1;
          }
          return result2;
        };
      }
      var bind = baseRest(function(func, thisArg, partials) {
        var bitmask = WRAP_BIND_FLAG;
        if (partials.length) {
          var holders = replaceHolders(partials, getHolder(bind));
          bitmask |= WRAP_PARTIAL_FLAG;
        }
        return createWrap(func, bitmask, thisArg, partials, holders);
      });
      var bindKey = baseRest(function(object, key, partials) {
        var bitmask = WRAP_BIND_FLAG | WRAP_BIND_KEY_FLAG;
        if (partials.length) {
          var holders = replaceHolders(partials, getHolder(bindKey));
          bitmask |= WRAP_PARTIAL_FLAG;
        }
        return createWrap(key, bitmask, object, partials, holders);
      });
      function curry(func, arity, guard) {
        arity = guard ? undefined$1 : arity;
        var result2 = createWrap(func, WRAP_CURRY_FLAG, undefined$1, undefined$1, undefined$1, undefined$1, undefined$1, arity);
        result2.placeholder = curry.placeholder;
        return result2;
      }
      function curryRight(func, arity, guard) {
        arity = guard ? undefined$1 : arity;
        var result2 = createWrap(func, WRAP_CURRY_RIGHT_FLAG, undefined$1, undefined$1, undefined$1, undefined$1, undefined$1, arity);
        result2.placeholder = curryRight.placeholder;
        return result2;
      }
      function debounce2(func, wait, options) {
        var lastArgs, lastThis, maxWait, result2, timerId, lastCallTime, lastInvokeTime = 0, leading = false, maxing = false, trailing = true;
        if (typeof func != "function") {
          throw new TypeError2(FUNC_ERROR_TEXT);
        }
        wait = toNumber(wait) || 0;
        if (isObject2(options)) {
          leading = !!options.leading;
          maxing = "maxWait" in options;
          maxWait = maxing ? nativeMax(toNumber(options.maxWait) || 0, wait) : maxWait;
          trailing = "trailing" in options ? !!options.trailing : trailing;
        }
        function invokeFunc(time) {
          var args = lastArgs, thisArg = lastThis;
          lastArgs = lastThis = undefined$1;
          lastInvokeTime = time;
          result2 = func.apply(thisArg, args);
          return result2;
        }
        function leadingEdge(time) {
          lastInvokeTime = time;
          timerId = setTimeout2(timerExpired, wait);
          return leading ? invokeFunc(time) : result2;
        }
        function remainingWait(time) {
          var timeSinceLastCall = time - lastCallTime, timeSinceLastInvoke = time - lastInvokeTime, timeWaiting = wait - timeSinceLastCall;
          return maxing ? nativeMin(timeWaiting, maxWait - timeSinceLastInvoke) : timeWaiting;
        }
        function shouldInvoke(time) {
          var timeSinceLastCall = time - lastCallTime, timeSinceLastInvoke = time - lastInvokeTime;
          return lastCallTime === undefined$1 || timeSinceLastCall >= wait || timeSinceLastCall < 0 || maxing && timeSinceLastInvoke >= maxWait;
        }
        function timerExpired() {
          var time = now();
          if (shouldInvoke(time)) {
            return trailingEdge(time);
          }
          timerId = setTimeout2(timerExpired, remainingWait(time));
        }
        function trailingEdge(time) {
          timerId = undefined$1;
          if (trailing && lastArgs) {
            return invokeFunc(time);
          }
          lastArgs = lastThis = undefined$1;
          return result2;
        }
        function cancel() {
          if (timerId !== undefined$1) {
            clearTimeout2(timerId);
          }
          lastInvokeTime = 0;
          lastArgs = lastCallTime = lastThis = timerId = undefined$1;
        }
        function flush() {
          return timerId === undefined$1 ? result2 : trailingEdge(now());
        }
        function debounced() {
          var time = now(), isInvoking = shouldInvoke(time);
          lastArgs = arguments;
          lastThis = this;
          lastCallTime = time;
          if (isInvoking) {
            if (timerId === undefined$1) {
              return leadingEdge(lastCallTime);
            }
            if (maxing) {
              clearTimeout2(timerId);
              timerId = setTimeout2(timerExpired, wait);
              return invokeFunc(lastCallTime);
            }
          }
          if (timerId === undefined$1) {
            timerId = setTimeout2(timerExpired, wait);
          }
          return result2;
        }
        debounced.cancel = cancel;
        debounced.flush = flush;
        return debounced;
      }
      var defer = baseRest(function(func, args) {
        return baseDelay(func, 1, args);
      });
      var delay = baseRest(function(func, wait, args) {
        return baseDelay(func, toNumber(wait) || 0, args);
      });
      function flip2(func) {
        return createWrap(func, WRAP_FLIP_FLAG);
      }
      function memoize(func, resolver) {
        if (typeof func != "function" || resolver != null && typeof resolver != "function") {
          throw new TypeError2(FUNC_ERROR_TEXT);
        }
        var memoized = function() {
          var args = arguments, key = resolver ? resolver.apply(this, args) : args[0], cache = memoized.cache;
          if (cache.has(key)) {
            return cache.get(key);
          }
          var result2 = func.apply(this, args);
          memoized.cache = cache.set(key, result2) || cache;
          return result2;
        };
        memoized.cache = new (memoize.Cache || MapCache2)();
        return memoized;
      }
      memoize.Cache = MapCache2;
      function negate(predicate) {
        if (typeof predicate != "function") {
          throw new TypeError2(FUNC_ERROR_TEXT);
        }
        return function() {
          var args = arguments;
          switch (args.length) {
            case 0:
              return !predicate.call(this);
            case 1:
              return !predicate.call(this, args[0]);
            case 2:
              return !predicate.call(this, args[0], args[1]);
            case 3:
              return !predicate.call(this, args[0], args[1], args[2]);
          }
          return !predicate.apply(this, args);
        };
      }
      function once(func) {
        return before(2, func);
      }
      var overArgs = castRest(function(func, transforms) {
        transforms = transforms.length == 1 && isArray(transforms[0]) ? arrayMap(transforms[0], baseUnary(getIteratee())) : arrayMap(baseFlatten(transforms, 1), baseUnary(getIteratee()));
        var funcsLength = transforms.length;
        return baseRest(function(args) {
          var index2 = -1, length = nativeMin(args.length, funcsLength);
          while (++index2 < length) {
            args[index2] = transforms[index2].call(this, args[index2]);
          }
          return apply(func, this, args);
        });
      });
      var partial = baseRest(function(func, partials) {
        var holders = replaceHolders(partials, getHolder(partial));
        return createWrap(func, WRAP_PARTIAL_FLAG, undefined$1, partials, holders);
      });
      var partialRight = baseRest(function(func, partials) {
        var holders = replaceHolders(partials, getHolder(partialRight));
        return createWrap(func, WRAP_PARTIAL_RIGHT_FLAG, undefined$1, partials, holders);
      });
      var rearg = flatRest(function(func, indexes) {
        return createWrap(func, WRAP_REARG_FLAG, undefined$1, undefined$1, undefined$1, indexes);
      });
      function rest(func, start2) {
        if (typeof func != "function") {
          throw new TypeError2(FUNC_ERROR_TEXT);
        }
        start2 = start2 === undefined$1 ? start2 : toInteger(start2);
        return baseRest(func, start2);
      }
      function spread(func, start2) {
        if (typeof func != "function") {
          throw new TypeError2(FUNC_ERROR_TEXT);
        }
        start2 = start2 == null ? 0 : nativeMax(toInteger(start2), 0);
        return baseRest(function(args) {
          var array = args[start2], otherArgs = castSlice(args, 0, start2);
          if (array) {
            arrayPush(otherArgs, array);
          }
          return apply(func, this, otherArgs);
        });
      }
      function throttle2(func, wait, options) {
        var leading = true, trailing = true;
        if (typeof func != "function") {
          throw new TypeError2(FUNC_ERROR_TEXT);
        }
        if (isObject2(options)) {
          leading = "leading" in options ? !!options.leading : leading;
          trailing = "trailing" in options ? !!options.trailing : trailing;
        }
        return debounce2(func, wait, {
          "leading": leading,
          "maxWait": wait,
          "trailing": trailing
        });
      }
      function unary(func) {
        return ary(func, 1);
      }
      function wrap(value, wrapper) {
        return partial(castFunction(wrapper), value);
      }
      function castArray() {
        if (!arguments.length) {
          return [];
        }
        var value = arguments[0];
        return isArray(value) ? value : [value];
      }
      function clone(value) {
        return baseClone(value, CLONE_SYMBOLS_FLAG);
      }
      function cloneWith(value, customizer) {
        customizer = typeof customizer == "function" ? customizer : undefined$1;
        return baseClone(value, CLONE_SYMBOLS_FLAG, customizer);
      }
      function cloneDeep(value) {
        return baseClone(value, CLONE_DEEP_FLAG | CLONE_SYMBOLS_FLAG);
      }
      function cloneDeepWith(value, customizer) {
        customizer = typeof customizer == "function" ? customizer : undefined$1;
        return baseClone(value, CLONE_DEEP_FLAG | CLONE_SYMBOLS_FLAG, customizer);
      }
      function conformsTo(object, source) {
        return source == null || baseConformsTo(object, source, keys(source));
      }
      function eq2(value, other) {
        return value === other || value !== value && other !== other;
      }
      var gt = createRelationalOperation(baseGt);
      var gte = createRelationalOperation(function(value, other) {
        return value >= other;
      });
      var isArguments = baseIsArguments2(/* @__PURE__ */ function() {
        return arguments;
      }()) ? baseIsArguments2 : function(value) {
        return isObjectLike2(value) && hasOwnProperty2.call(value, "callee") && !propertyIsEnumerable2.call(value, "callee");
      };
      var isArray = Array2.isArray;
      var isArrayBuffer = nodeIsArrayBuffer ? baseUnary(nodeIsArrayBuffer) : baseIsArrayBuffer;
      function isArrayLike(value) {
        return value != null && isLength(value.length) && !isFunction2(value);
      }
      function isArrayLikeObject(value) {
        return isObjectLike2(value) && isArrayLike(value);
      }
      function isBoolean(value) {
        return value === true || value === false || isObjectLike2(value) && baseGetTag2(value) == boolTag;
      }
      var isBuffer2 = nativeIsBuffer || stubFalse2;
      var isDate = nodeIsDate ? baseUnary(nodeIsDate) : baseIsDate;
      function isElement2(value) {
        return isObjectLike2(value) && value.nodeType === 1 && !isPlainObject2(value);
      }
      function isEmpty(value) {
        if (value == null) {
          return true;
        }
        if (isArrayLike(value) && (isArray(value) || typeof value == "string" || typeof value.splice == "function" || isBuffer2(value) || isTypedArray(value) || isArguments(value))) {
          return !value.length;
        }
        var tag = getTag2(value);
        if (tag == mapTag2 || tag == setTag2) {
          return !value.size;
        }
        if (isPrototype(value)) {
          return !baseKeys(value).length;
        }
        for (var key in value) {
          if (hasOwnProperty2.call(value, key)) {
            return false;
          }
        }
        return true;
      }
      function isEqual3(value, other) {
        return baseIsEqual(value, other);
      }
      function isEqualWith(value, other, customizer) {
        customizer = typeof customizer == "function" ? customizer : undefined$1;
        var result2 = customizer ? customizer(value, other) : undefined$1;
        return result2 === undefined$1 ? baseIsEqual(value, other, undefined$1, customizer) : !!result2;
      }
      function isError(value) {
        if (!isObjectLike2(value)) {
          return false;
        }
        var tag = baseGetTag2(value);
        return tag == errorTag || tag == domExcTag || typeof value.message == "string" && typeof value.name == "string" && !isPlainObject2(value);
      }
      function isFinite(value) {
        return typeof value == "number" && nativeIsFinite(value);
      }
      function isFunction2(value) {
        if (!isObject2(value)) {
          return false;
        }
        var tag = baseGetTag2(value);
        return tag == funcTag2 || tag == genTag2 || tag == asyncTag2 || tag == proxyTag2;
      }
      function isInteger(value) {
        return typeof value == "number" && value == toInteger(value);
      }
      function isLength(value) {
        return typeof value == "number" && value > -1 && value % 1 == 0 && value <= MAX_SAFE_INTEGER;
      }
      function isObject2(value) {
        var type = typeof value;
        return value != null && (type == "object" || type == "function");
      }
      function isObjectLike2(value) {
        return value != null && typeof value == "object";
      }
      var isMap = nodeIsMap ? baseUnary(nodeIsMap) : baseIsMap;
      function isMatch(object, source) {
        return object === source || baseIsMatch(object, source, getMatchData(source));
      }
      function isMatchWith(object, source, customizer) {
        customizer = typeof customizer == "function" ? customizer : undefined$1;
        return baseIsMatch(object, source, getMatchData(source), customizer);
      }
      function isNaN(value) {
        return isNumber(value) && value != +value;
      }
      function isNative(value) {
        if (isMaskable(value)) {
          throw new Error2(CORE_ERROR_TEXT);
        }
        return baseIsNative2(value);
      }
      function isNull(value) {
        return value === null;
      }
      function isNil(value) {
        return value == null;
      }
      function isNumber(value) {
        return typeof value == "number" || isObjectLike2(value) && baseGetTag2(value) == numberTag;
      }
      function isPlainObject2(value) {
        if (!isObjectLike2(value) || baseGetTag2(value) != objectTag2) {
          return false;
        }
        var proto = getPrototype(value);
        if (proto === null) {
          return true;
        }
        var Ctor = hasOwnProperty2.call(proto, "constructor") && proto.constructor;
        return typeof Ctor == "function" && Ctor instanceof Ctor && funcToString2.call(Ctor) == objectCtorString;
      }
      var isRegExp = nodeIsRegExp ? baseUnary(nodeIsRegExp) : baseIsRegExp;
      function isSafeInteger(value) {
        return isInteger(value) && value >= -MAX_SAFE_INTEGER && value <= MAX_SAFE_INTEGER;
      }
      var isSet = nodeIsSet ? baseUnary(nodeIsSet) : baseIsSet;
      function isString(value) {
        return typeof value == "string" || !isArray(value) && isObjectLike2(value) && baseGetTag2(value) == stringTag;
      }
      function isSymbol(value) {
        return typeof value == "symbol" || isObjectLike2(value) && baseGetTag2(value) == symbolTag;
      }
      var isTypedArray = nodeIsTypedArray ? baseUnary(nodeIsTypedArray) : baseIsTypedArray;
      function isUndefined(value) {
        return value === undefined$1;
      }
      function isWeakMap(value) {
        return isObjectLike2(value) && getTag2(value) == weakMapTag2;
      }
      function isWeakSet(value) {
        return isObjectLike2(value) && baseGetTag2(value) == weakSetTag;
      }
      var lt = createRelationalOperation(baseLt);
      var lte = createRelationalOperation(function(value, other) {
        return value <= other;
      });
      function toArray(value) {
        if (!value) {
          return [];
        }
        if (isArrayLike(value)) {
          return isString(value) ? stringToArray(value) : copyArray(value);
        }
        if (symIterator && value[symIterator]) {
          return iteratorToArray(value[symIterator]());
        }
        var tag = getTag2(value), func = tag == mapTag2 ? mapToArray : tag == setTag2 ? setToArray : values;
        return func(value);
      }
      function toFinite(value) {
        if (!value) {
          return value === 0 ? value : 0;
        }
        value = toNumber(value);
        if (value === INFINITY || value === -INFINITY) {
          var sign = value < 0 ? -1 : 1;
          return sign * MAX_INTEGER;
        }
        return value === value ? value : 0;
      }
      function toInteger(value) {
        var result2 = toFinite(value), remainder = result2 % 1;
        return result2 === result2 ? remainder ? result2 - remainder : result2 : 0;
      }
      function toLength(value) {
        return value ? baseClamp(toInteger(value), 0, MAX_ARRAY_LENGTH) : 0;
      }
      function toNumber(value) {
        if (typeof value == "number") {
          return value;
        }
        if (isSymbol(value)) {
          return NAN;
        }
        if (isObject2(value)) {
          var other = typeof value.valueOf == "function" ? value.valueOf() : value;
          value = isObject2(other) ? other + "" : other;
        }
        if (typeof value != "string") {
          return value === 0 ? value : +value;
        }
        value = baseTrim(value);
        var isBinary = reIsBinary.test(value);
        return isBinary || reIsOctal.test(value) ? freeParseInt(value.slice(2), isBinary ? 2 : 8) : reIsBadHex.test(value) ? NAN : +value;
      }
      function toPlainObject(value) {
        return copyObject(value, keysIn(value));
      }
      function toSafeInteger(value) {
        return value ? baseClamp(toInteger(value), -MAX_SAFE_INTEGER, MAX_SAFE_INTEGER) : value === 0 ? value : 0;
      }
      function toString(value) {
        return value == null ? "" : baseToString(value);
      }
      var assign = createAssigner(function(object, source) {
        if (isPrototype(source) || isArrayLike(source)) {
          copyObject(source, keys(source), object);
          return;
        }
        for (var key in source) {
          if (hasOwnProperty2.call(source, key)) {
            assignValue(object, key, source[key]);
          }
        }
      });
      var assignIn = createAssigner(function(object, source) {
        copyObject(source, keysIn(source), object);
      });
      var assignInWith = createAssigner(function(object, source, srcIndex, customizer) {
        copyObject(source, keysIn(source), object, customizer);
      });
      var assignWith = createAssigner(function(object, source, srcIndex, customizer) {
        copyObject(source, keys(source), object, customizer);
      });
      var at = flatRest(baseAt);
      function create(prototype, properties) {
        var result2 = baseCreate(prototype);
        return properties == null ? result2 : baseAssign(result2, properties);
      }
      var defaults = baseRest(function(object, sources) {
        object = Object2(object);
        var index2 = -1;
        var length = sources.length;
        var guard = length > 2 ? sources[2] : undefined$1;
        if (guard && isIterateeCall(sources[0], sources[1], guard)) {
          length = 1;
        }
        while (++index2 < length) {
          var source = sources[index2];
          var props = keysIn(source);
          var propsIndex = -1;
          var propsLength = props.length;
          while (++propsIndex < propsLength) {
            var key = props[propsIndex];
            var value = object[key];
            if (value === undefined$1 || eq2(value, objectProto2[key]) && !hasOwnProperty2.call(object, key)) {
              object[key] = source[key];
            }
          }
        }
        return object;
      });
      var defaultsDeep = baseRest(function(args) {
        args.push(undefined$1, customDefaultsMerge);
        return apply(mergeWith, undefined$1, args);
      });
      function findKey(object, predicate) {
        return baseFindKey(object, getIteratee(predicate, 3), baseForOwn);
      }
      function findLastKey(object, predicate) {
        return baseFindKey(object, getIteratee(predicate, 3), baseForOwnRight);
      }
      function forIn(object, iteratee2) {
        return object == null ? object : baseFor(object, getIteratee(iteratee2, 3), keysIn);
      }
      function forInRight(object, iteratee2) {
        return object == null ? object : baseForRight(object, getIteratee(iteratee2, 3), keysIn);
      }
      function forOwn(object, iteratee2) {
        return object && baseForOwn(object, getIteratee(iteratee2, 3));
      }
      function forOwnRight(object, iteratee2) {
        return object && baseForOwnRight(object, getIteratee(iteratee2, 3));
      }
      function functions(object) {
        return object == null ? [] : baseFunctions(object, keys(object));
      }
      function functionsIn(object) {
        return object == null ? [] : baseFunctions(object, keysIn(object));
      }
      function get2(object, path, defaultValue) {
        var result2 = object == null ? undefined$1 : baseGet(object, path);
        return result2 === undefined$1 ? defaultValue : result2;
      }
      function has(object, path) {
        return object != null && hasPath(object, path, baseHas);
      }
      function hasIn(object, path) {
        return object != null && hasPath(object, path, baseHasIn);
      }
      var invert = createInverter(function(result2, value, key) {
        if (value != null && typeof value.toString != "function") {
          value = nativeObjectToString2.call(value);
        }
        result2[value] = key;
      }, constant(identity));
      var invertBy = createInverter(function(result2, value, key) {
        if (value != null && typeof value.toString != "function") {
          value = nativeObjectToString2.call(value);
        }
        if (hasOwnProperty2.call(result2, value)) {
          result2[value].push(key);
        } else {
          result2[value] = [key];
        }
      }, getIteratee);
      var invoke = baseRest(baseInvoke);
      function keys(object) {
        return isArrayLike(object) ? arrayLikeKeys(object) : baseKeys(object);
      }
      function keysIn(object) {
        return isArrayLike(object) ? arrayLikeKeys(object, true) : baseKeysIn(object);
      }
      function mapKeys(object, iteratee2) {
        var result2 = {};
        iteratee2 = getIteratee(iteratee2, 3);
        baseForOwn(object, function(value, key, object2) {
          baseAssignValue(result2, iteratee2(value, key, object2), value);
        });
        return result2;
      }
      function mapValues(object, iteratee2) {
        var result2 = {};
        iteratee2 = getIteratee(iteratee2, 3);
        baseForOwn(object, function(value, key, object2) {
          baseAssignValue(result2, key, iteratee2(value, key, object2));
        });
        return result2;
      }
      var merge = createAssigner(function(object, source, srcIndex) {
        baseMerge(object, source, srcIndex);
      });
      var mergeWith = createAssigner(function(object, source, srcIndex, customizer) {
        baseMerge(object, source, srcIndex, customizer);
      });
      var omit = flatRest(function(object, paths) {
        var result2 = {};
        if (object == null) {
          return result2;
        }
        var isDeep = false;
        paths = arrayMap(paths, function(path) {
          path = castPath(path, object);
          isDeep || (isDeep = path.length > 1);
          return path;
        });
        copyObject(object, getAllKeysIn(object), result2);
        if (isDeep) {
          result2 = baseClone(result2, CLONE_DEEP_FLAG | CLONE_FLAT_FLAG | CLONE_SYMBOLS_FLAG, customOmitClone);
        }
        var length = paths.length;
        while (length--) {
          baseUnset(result2, paths[length]);
        }
        return result2;
      });
      function omitBy(object, predicate) {
        return pickBy(object, negate(getIteratee(predicate)));
      }
      var pick = flatRest(function(object, paths) {
        return object == null ? {} : basePick(object, paths);
      });
      function pickBy(object, predicate) {
        if (object == null) {
          return {};
        }
        var props = arrayMap(getAllKeysIn(object), function(prop) {
          return [prop];
        });
        predicate = getIteratee(predicate);
        return basePickBy(object, props, function(value, path) {
          return predicate(value, path[0]);
        });
      }
      function result(object, path, defaultValue) {
        path = castPath(path, object);
        var index2 = -1, length = path.length;
        if (!length) {
          length = 1;
          object = undefined$1;
        }
        while (++index2 < length) {
          var value = object == null ? undefined$1 : object[toKey(path[index2])];
          if (value === undefined$1) {
            index2 = length;
            value = defaultValue;
          }
          object = isFunction2(value) ? value.call(object) : value;
        }
        return object;
      }
      function set(object, path, value) {
        return object == null ? object : baseSet(object, path, value);
      }
      function setWith(object, path, value, customizer) {
        customizer = typeof customizer == "function" ? customizer : undefined$1;
        return object == null ? object : baseSet(object, path, value, customizer);
      }
      var toPairs = createToPairs(keys);
      var toPairsIn = createToPairs(keysIn);
      function transform(object, iteratee2, accumulator) {
        var isArr = isArray(object), isArrLike = isArr || isBuffer2(object) || isTypedArray(object);
        iteratee2 = getIteratee(iteratee2, 4);
        if (accumulator == null) {
          var Ctor = object && object.constructor;
          if (isArrLike) {
            accumulator = isArr ? new Ctor() : [];
          } else if (isObject2(object)) {
            accumulator = isFunction2(Ctor) ? baseCreate(getPrototype(object)) : {};
          } else {
            accumulator = {};
          }
        }
        (isArrLike ? arrayEach : baseForOwn)(object, function(value, index2, object2) {
          return iteratee2(accumulator, value, index2, object2);
        });
        return accumulator;
      }
      function unset(object, path) {
        return object == null ? true : baseUnset(object, path);
      }
      function update(object, path, updater) {
        return object == null ? object : baseUpdate(object, path, castFunction(updater));
      }
      function updateWith(object, path, updater, customizer) {
        customizer = typeof customizer == "function" ? customizer : undefined$1;
        return object == null ? object : baseUpdate(object, path, castFunction(updater), customizer);
      }
      function values(object) {
        return object == null ? [] : baseValues(object, keys(object));
      }
      function valuesIn(object) {
        return object == null ? [] : baseValues(object, keysIn(object));
      }
      function clamp(number, lower, upper) {
        if (upper === undefined$1) {
          upper = lower;
          lower = undefined$1;
        }
        if (upper !== undefined$1) {
          upper = toNumber(upper);
          upper = upper === upper ? upper : 0;
        }
        if (lower !== undefined$1) {
          lower = toNumber(lower);
          lower = lower === lower ? lower : 0;
        }
        return baseClamp(toNumber(number), lower, upper);
      }
      function inRange(number, start2, end2) {
        start2 = toFinite(start2);
        if (end2 === undefined$1) {
          end2 = start2;
          start2 = 0;
        } else {
          end2 = toFinite(end2);
        }
        number = toNumber(number);
        return baseInRange(number, start2, end2);
      }
      function random(lower, upper, floating) {
        if (floating && typeof floating != "boolean" && isIterateeCall(lower, upper, floating)) {
          upper = floating = undefined$1;
        }
        if (floating === undefined$1) {
          if (typeof upper == "boolean") {
            floating = upper;
            upper = undefined$1;
          } else if (typeof lower == "boolean") {
            floating = lower;
            lower = undefined$1;
          }
        }
        if (lower === undefined$1 && upper === undefined$1) {
          lower = 0;
          upper = 1;
        } else {
          lower = toFinite(lower);
          if (upper === undefined$1) {
            upper = lower;
            lower = 0;
          } else {
            upper = toFinite(upper);
          }
        }
        if (lower > upper) {
          var temp = lower;
          lower = upper;
          upper = temp;
        }
        if (floating || lower % 1 || upper % 1) {
          var rand = nativeRandom();
          return nativeMin(lower + rand * (upper - lower + freeParseFloat("1e-" + ((rand + "").length - 1))), upper);
        }
        return baseRandom(lower, upper);
      }
      var camelCase = createCompounder(function(result2, word, index2) {
        word = word.toLowerCase();
        return result2 + (index2 ? capitalize2(word) : word);
      });
      function capitalize2(string) {
        return upperFirst(toString(string).toLowerCase());
      }
      function deburr(string) {
        string = toString(string);
        return string && string.replace(reLatin, deburrLetter).replace(reComboMark, "");
      }
      function endsWith(string, target, position) {
        string = toString(string);
        target = baseToString(target);
        var length = string.length;
        position = position === undefined$1 ? length : baseClamp(toInteger(position), 0, length);
        var end2 = position;
        position -= target.length;
        return position >= 0 && string.slice(position, end2) == target;
      }
      function escape2(string) {
        string = toString(string);
        return string && reHasUnescapedHtml.test(string) ? string.replace(reUnescapedHtml, escapeHtmlChar) : string;
      }
      function escapeRegExp(string) {
        string = toString(string);
        return string && reHasRegExpChar.test(string) ? string.replace(reRegExpChar2, "\\$&") : string;
      }
      var kebabCase = createCompounder(function(result2, word, index2) {
        return result2 + (index2 ? "-" : "") + word.toLowerCase();
      });
      var lowerCase = createCompounder(function(result2, word, index2) {
        return result2 + (index2 ? " " : "") + word.toLowerCase();
      });
      var lowerFirst = createCaseFirst("toLowerCase");
      function pad(string, length, chars) {
        string = toString(string);
        length = toInteger(length);
        var strLength = length ? stringSize(string) : 0;
        if (!length || strLength >= length) {
          return string;
        }
        var mid = (length - strLength) / 2;
        return createPadding(nativeFloor(mid), chars) + string + createPadding(nativeCeil(mid), chars);
      }
      function padEnd(string, length, chars) {
        string = toString(string);
        length = toInteger(length);
        var strLength = length ? stringSize(string) : 0;
        return length && strLength < length ? string + createPadding(length - strLength, chars) : string;
      }
      function padStart(string, length, chars) {
        string = toString(string);
        length = toInteger(length);
        var strLength = length ? stringSize(string) : 0;
        return length && strLength < length ? createPadding(length - strLength, chars) + string : string;
      }
      function parseInt2(string, radix, guard) {
        if (guard || radix == null) {
          radix = 0;
        } else if (radix) {
          radix = +radix;
        }
        return nativeParseInt(toString(string).replace(reTrimStart, ""), radix || 0);
      }
      function repeat(string, n, guard) {
        if (guard ? isIterateeCall(string, n, guard) : n === undefined$1) {
          n = 1;
        } else {
          n = toInteger(n);
        }
        return baseRepeat(toString(string), n);
      }
      function replace() {
        var args = arguments, string = toString(args[0]);
        return args.length < 3 ? string : string.replace(args[1], args[2]);
      }
      var snakeCase = createCompounder(function(result2, word, index2) {
        return result2 + (index2 ? "_" : "") + word.toLowerCase();
      });
      function split(string, separator, limit) {
        if (limit && typeof limit != "number" && isIterateeCall(string, separator, limit)) {
          separator = limit = undefined$1;
        }
        limit = limit === undefined$1 ? MAX_ARRAY_LENGTH : limit >>> 0;
        if (!limit) {
          return [];
        }
        string = toString(string);
        if (string && (typeof separator == "string" || separator != null && !isRegExp(separator))) {
          separator = baseToString(separator);
          if (!separator && hasUnicode(string)) {
            return castSlice(stringToArray(string), 0, limit);
          }
        }
        return string.split(separator, limit);
      }
      var startCase = createCompounder(function(result2, word, index2) {
        return result2 + (index2 ? " " : "") + upperFirst(word);
      });
      function startsWith(string, target, position) {
        string = toString(string);
        position = position == null ? 0 : baseClamp(toInteger(position), 0, string.length);
        target = baseToString(target);
        return string.slice(position, position + target.length) == target;
      }
      function template(string, options, guard) {
        var settings = lodash2.templateSettings;
        if (guard && isIterateeCall(string, options, guard)) {
          options = undefined$1;
        }
        string = toString(string);
        options = assignInWith({}, options, settings, customDefaultsAssignIn);
        var imports = assignInWith({}, options.imports, settings.imports, customDefaultsAssignIn), importsKeys = keys(imports), importsValues = baseValues(imports, importsKeys);
        var isEscaping, isEvaluating, index2 = 0, interpolate = options.interpolate || reNoMatch, source = "__p += '";
        var reDelimiters = RegExp2(
          (options.escape || reNoMatch).source + "|" + interpolate.source + "|" + (interpolate === reInterpolate ? reEsTemplate : reNoMatch).source + "|" + (options.evaluate || reNoMatch).source + "|$",
          "g"
        );
        var sourceURL = "//# sourceURL=" + (hasOwnProperty2.call(options, "sourceURL") ? (options.sourceURL + "").replace(/\s/g, " ") : "lodash.templateSources[" + ++templateCounter + "]") + "\n";
        string.replace(reDelimiters, function(match, escapeValue, interpolateValue, esTemplateValue, evaluateValue, offset2) {
          interpolateValue || (interpolateValue = esTemplateValue);
          source += string.slice(index2, offset2).replace(reUnescapedString, escapeStringChar);
          if (escapeValue) {
            isEscaping = true;
            source += "' +\n__e(" + escapeValue + ") +\n'";
          }
          if (evaluateValue) {
            isEvaluating = true;
            source += "';\n" + evaluateValue + ";\n__p += '";
          }
          if (interpolateValue) {
            source += "' +\n((__t = (" + interpolateValue + ")) == null ? '' : __t) +\n'";
          }
          index2 = offset2 + match.length;
          return match;
        });
        source += "';\n";
        var variable = hasOwnProperty2.call(options, "variable") && options.variable;
        if (!variable) {
          source = "with (obj) {\n" + source + "\n}\n";
        } else if (reForbiddenIdentifierChars.test(variable)) {
          throw new Error2(INVALID_TEMPL_VAR_ERROR_TEXT);
        }
        source = (isEvaluating ? source.replace(reEmptyStringLeading, "") : source).replace(reEmptyStringMiddle, "$1").replace(reEmptyStringTrailing, "$1;");
        source = "function(" + (variable || "obj") + ") {\n" + (variable ? "" : "obj || (obj = {});\n") + "var __t, __p = ''" + (isEscaping ? ", __e = _.escape" : "") + (isEvaluating ? ", __j = Array.prototype.join;\nfunction print() { __p += __j.call(arguments, '') }\n" : ";\n") + source + "return __p\n}";
        var result2 = attempt(function() {
          return Function2(importsKeys, sourceURL + "return " + source).apply(undefined$1, importsValues);
        });
        result2.source = source;
        if (isError(result2)) {
          throw result2;
        }
        return result2;
      }
      function toLower(value) {
        return toString(value).toLowerCase();
      }
      function toUpper(value) {
        return toString(value).toUpperCase();
      }
      function trim(string, chars, guard) {
        string = toString(string);
        if (string && (guard || chars === undefined$1)) {
          return baseTrim(string);
        }
        if (!string || !(chars = baseToString(chars))) {
          return string;
        }
        var strSymbols = stringToArray(string), chrSymbols = stringToArray(chars), start2 = charsStartIndex(strSymbols, chrSymbols), end2 = charsEndIndex(strSymbols, chrSymbols) + 1;
        return castSlice(strSymbols, start2, end2).join("");
      }
      function trimEnd(string, chars, guard) {
        string = toString(string);
        if (string && (guard || chars === undefined$1)) {
          return string.slice(0, trimmedEndIndex(string) + 1);
        }
        if (!string || !(chars = baseToString(chars))) {
          return string;
        }
        var strSymbols = stringToArray(string), end2 = charsEndIndex(strSymbols, stringToArray(chars)) + 1;
        return castSlice(strSymbols, 0, end2).join("");
      }
      function trimStart(string, chars, guard) {
        string = toString(string);
        if (string && (guard || chars === undefined$1)) {
          return string.replace(reTrimStart, "");
        }
        if (!string || !(chars = baseToString(chars))) {
          return string;
        }
        var strSymbols = stringToArray(string), start2 = charsStartIndex(strSymbols, stringToArray(chars));
        return castSlice(strSymbols, start2).join("");
      }
      function truncate(string, options) {
        var length = DEFAULT_TRUNC_LENGTH, omission = DEFAULT_TRUNC_OMISSION;
        if (isObject2(options)) {
          var separator = "separator" in options ? options.separator : separator;
          length = "length" in options ? toInteger(options.length) : length;
          omission = "omission" in options ? baseToString(options.omission) : omission;
        }
        string = toString(string);
        var strLength = string.length;
        if (hasUnicode(string)) {
          var strSymbols = stringToArray(string);
          strLength = strSymbols.length;
        }
        if (length >= strLength) {
          return string;
        }
        var end2 = length - stringSize(omission);
        if (end2 < 1) {
          return omission;
        }
        var result2 = strSymbols ? castSlice(strSymbols, 0, end2).join("") : string.slice(0, end2);
        if (separator === undefined$1) {
          return result2 + omission;
        }
        if (strSymbols) {
          end2 += result2.length - end2;
        }
        if (isRegExp(separator)) {
          if (string.slice(end2).search(separator)) {
            var match, substring = result2;
            if (!separator.global) {
              separator = RegExp2(separator.source, toString(reFlags.exec(separator)) + "g");
            }
            separator.lastIndex = 0;
            while (match = separator.exec(substring)) {
              var newEnd = match.index;
            }
            result2 = result2.slice(0, newEnd === undefined$1 ? end2 : newEnd);
          }
        } else if (string.indexOf(baseToString(separator), end2) != end2) {
          var index2 = result2.lastIndexOf(separator);
          if (index2 > -1) {
            result2 = result2.slice(0, index2);
          }
        }
        return result2 + omission;
      }
      function unescape(string) {
        string = toString(string);
        return string && reHasEscapedHtml.test(string) ? string.replace(reEscapedHtml, unescapeHtmlChar) : string;
      }
      var upperCase = createCompounder(function(result2, word, index2) {
        return result2 + (index2 ? " " : "") + word.toUpperCase();
      });
      var upperFirst = createCaseFirst("toUpperCase");
      function words(string, pattern, guard) {
        string = toString(string);
        pattern = guard ? undefined$1 : pattern;
        if (pattern === undefined$1) {
          return hasUnicodeWord(string) ? unicodeWords(string) : asciiWords(string);
        }
        return string.match(pattern) || [];
      }
      var attempt = baseRest(function(func, args) {
        try {
          return apply(func, undefined$1, args);
        } catch (e) {
          return isError(e) ? e : new Error2(e);
        }
      });
      var bindAll = flatRest(function(object, methodNames) {
        arrayEach(methodNames, function(key) {
          key = toKey(key);
          baseAssignValue(object, key, bind(object[key], object));
        });
        return object;
      });
      function cond(pairs) {
        var length = pairs == null ? 0 : pairs.length, toIteratee = getIteratee();
        pairs = !length ? [] : arrayMap(pairs, function(pair) {
          if (typeof pair[1] != "function") {
            throw new TypeError2(FUNC_ERROR_TEXT);
          }
          return [toIteratee(pair[0]), pair[1]];
        });
        return baseRest(function(args) {
          var index2 = -1;
          while (++index2 < length) {
            var pair = pairs[index2];
            if (apply(pair[0], this, args)) {
              return apply(pair[1], this, args);
            }
          }
        });
      }
      function conforms(source) {
        return baseConforms(baseClone(source, CLONE_DEEP_FLAG));
      }
      function constant(value) {
        return function() {
          return value;
        };
      }
      function defaultTo(value, defaultValue) {
        return value == null || value !== value ? defaultValue : value;
      }
      var flow = createFlow();
      var flowRight = createFlow(true);
      function identity(value) {
        return value;
      }
      function iteratee(func) {
        return baseIteratee(typeof func == "function" ? func : baseClone(func, CLONE_DEEP_FLAG));
      }
      function matches(source) {
        return baseMatches(baseClone(source, CLONE_DEEP_FLAG));
      }
      function matchesProperty(path, srcValue) {
        return baseMatchesProperty(path, baseClone(srcValue, CLONE_DEEP_FLAG));
      }
      var method = baseRest(function(path, args) {
        return function(object) {
          return baseInvoke(object, path, args);
        };
      });
      var methodOf = baseRest(function(object, args) {
        return function(path) {
          return baseInvoke(object, path, args);
        };
      });
      function mixin(object, source, options) {
        var props = keys(source), methodNames = baseFunctions(source, props);
        if (options == null && !(isObject2(source) && (methodNames.length || !props.length))) {
          options = source;
          source = object;
          object = this;
          methodNames = baseFunctions(source, keys(source));
        }
        var chain2 = !(isObject2(options) && "chain" in options) || !!options.chain, isFunc = isFunction2(object);
        arrayEach(methodNames, function(methodName) {
          var func = source[methodName];
          object[methodName] = func;
          if (isFunc) {
            object.prototype[methodName] = function() {
              var chainAll = this.__chain__;
              if (chain2 || chainAll) {
                var result2 = object(this.__wrapped__), actions = result2.__actions__ = copyArray(this.__actions__);
                actions.push({ "func": func, "args": arguments, "thisArg": object });
                result2.__chain__ = chainAll;
                return result2;
              }
              return func.apply(object, arrayPush([this.value()], arguments));
            };
          }
        });
        return object;
      }
      function noConflict() {
        if (root2._ === this) {
          root2._ = oldDash;
        }
        return this;
      }
      function noop2() {
      }
      function nthArg(n) {
        n = toInteger(n);
        return baseRest(function(args) {
          return baseNth(args, n);
        });
      }
      var over = createOver(arrayMap);
      var overEvery = createOver(arrayEvery);
      var overSome = createOver(arraySome);
      function property(path) {
        return isKey(path) ? baseProperty(toKey(path)) : basePropertyDeep(path);
      }
      function propertyOf(object) {
        return function(path) {
          return object == null ? undefined$1 : baseGet(object, path);
        };
      }
      var range = createRange();
      var rangeRight = createRange(true);
      function stubArray() {
        return [];
      }
      function stubFalse2() {
        return false;
      }
      function stubObject() {
        return {};
      }
      function stubString() {
        return "";
      }
      function stubTrue() {
        return true;
      }
      function times(n, iteratee2) {
        n = toInteger(n);
        if (n < 1 || n > MAX_SAFE_INTEGER) {
          return [];
        }
        var index2 = MAX_ARRAY_LENGTH, length = nativeMin(n, MAX_ARRAY_LENGTH);
        iteratee2 = getIteratee(iteratee2);
        n -= MAX_ARRAY_LENGTH;
        var result2 = baseTimes(length, iteratee2);
        while (++index2 < n) {
          iteratee2(index2);
        }
        return result2;
      }
      function toPath(value) {
        if (isArray(value)) {
          return arrayMap(value, toKey);
        }
        return isSymbol(value) ? [value] : copyArray(stringToPath(toString(value)));
      }
      function uniqueId(prefix) {
        var id = ++idCounter;
        return toString(prefix) + id;
      }
      var add = createMathOperation(function(augend, addend) {
        return augend + addend;
      }, 0);
      var ceil = createRound("ceil");
      var divide = createMathOperation(function(dividend, divisor) {
        return dividend / divisor;
      }, 1);
      var floor = createRound("floor");
      function max2(array) {
        return array && array.length ? baseExtremum(array, identity, baseGt) : undefined$1;
      }
      function maxBy(array, iteratee2) {
        return array && array.length ? baseExtremum(array, getIteratee(iteratee2, 2), baseGt) : undefined$1;
      }
      function mean(array) {
        return baseMean(array, identity);
      }
      function meanBy(array, iteratee2) {
        return baseMean(array, getIteratee(iteratee2, 2));
      }
      function min2(array) {
        return array && array.length ? baseExtremum(array, identity, baseLt) : undefined$1;
      }
      function minBy(array, iteratee2) {
        return array && array.length ? baseExtremum(array, getIteratee(iteratee2, 2), baseLt) : undefined$1;
      }
      var multiply = createMathOperation(function(multiplier, multiplicand) {
        return multiplier * multiplicand;
      }, 1);
      var round2 = createRound("round");
      var subtract = createMathOperation(function(minuend, subtrahend) {
        return minuend - subtrahend;
      }, 0);
      function sum(array) {
        return array && array.length ? baseSum(array, identity) : 0;
      }
      function sumBy(array, iteratee2) {
        return array && array.length ? baseSum(array, getIteratee(iteratee2, 2)) : 0;
      }
      lodash2.after = after;
      lodash2.ary = ary;
      lodash2.assign = assign;
      lodash2.assignIn = assignIn;
      lodash2.assignInWith = assignInWith;
      lodash2.assignWith = assignWith;
      lodash2.at = at;
      lodash2.before = before;
      lodash2.bind = bind;
      lodash2.bindAll = bindAll;
      lodash2.bindKey = bindKey;
      lodash2.castArray = castArray;
      lodash2.chain = chain;
      lodash2.chunk = chunk;
      lodash2.compact = compact;
      lodash2.concat = concat;
      lodash2.cond = cond;
      lodash2.conforms = conforms;
      lodash2.constant = constant;
      lodash2.countBy = countBy;
      lodash2.create = create;
      lodash2.curry = curry;
      lodash2.curryRight = curryRight;
      lodash2.debounce = debounce2;
      lodash2.defaults = defaults;
      lodash2.defaultsDeep = defaultsDeep;
      lodash2.defer = defer;
      lodash2.delay = delay;
      lodash2.difference = difference;
      lodash2.differenceBy = differenceBy;
      lodash2.differenceWith = differenceWith;
      lodash2.drop = drop;
      lodash2.dropRight = dropRight;
      lodash2.dropRightWhile = dropRightWhile;
      lodash2.dropWhile = dropWhile;
      lodash2.fill = fill;
      lodash2.filter = filter;
      lodash2.flatMap = flatMap;
      lodash2.flatMapDeep = flatMapDeep;
      lodash2.flatMapDepth = flatMapDepth;
      lodash2.flatten = flatten;
      lodash2.flattenDeep = flattenDeep;
      lodash2.flattenDepth = flattenDepth;
      lodash2.flip = flip2;
      lodash2.flow = flow;
      lodash2.flowRight = flowRight;
      lodash2.fromPairs = fromPairs;
      lodash2.functions = functions;
      lodash2.functionsIn = functionsIn;
      lodash2.groupBy = groupBy;
      lodash2.initial = initial;
      lodash2.intersection = intersection;
      lodash2.intersectionBy = intersectionBy;
      lodash2.intersectionWith = intersectionWith;
      lodash2.invert = invert;
      lodash2.invertBy = invertBy;
      lodash2.invokeMap = invokeMap;
      lodash2.iteratee = iteratee;
      lodash2.keyBy = keyBy;
      lodash2.keys = keys;
      lodash2.keysIn = keysIn;
      lodash2.map = map;
      lodash2.mapKeys = mapKeys;
      lodash2.mapValues = mapValues;
      lodash2.matches = matches;
      lodash2.matchesProperty = matchesProperty;
      lodash2.memoize = memoize;
      lodash2.merge = merge;
      lodash2.mergeWith = mergeWith;
      lodash2.method = method;
      lodash2.methodOf = methodOf;
      lodash2.mixin = mixin;
      lodash2.negate = negate;
      lodash2.nthArg = nthArg;
      lodash2.omit = omit;
      lodash2.omitBy = omitBy;
      lodash2.once = once;
      lodash2.orderBy = orderBy;
      lodash2.over = over;
      lodash2.overArgs = overArgs;
      lodash2.overEvery = overEvery;
      lodash2.overSome = overSome;
      lodash2.partial = partial;
      lodash2.partialRight = partialRight;
      lodash2.partition = partition;
      lodash2.pick = pick;
      lodash2.pickBy = pickBy;
      lodash2.property = property;
      lodash2.propertyOf = propertyOf;
      lodash2.pull = pull;
      lodash2.pullAll = pullAll;
      lodash2.pullAllBy = pullAllBy;
      lodash2.pullAllWith = pullAllWith;
      lodash2.pullAt = pullAt;
      lodash2.range = range;
      lodash2.rangeRight = rangeRight;
      lodash2.rearg = rearg;
      lodash2.reject = reject;
      lodash2.remove = remove2;
      lodash2.rest = rest;
      lodash2.reverse = reverse;
      lodash2.sampleSize = sampleSize;
      lodash2.set = set;
      lodash2.setWith = setWith;
      lodash2.shuffle = shuffle;
      lodash2.slice = slice;
      lodash2.sortBy = sortBy;
      lodash2.sortedUniq = sortedUniq;
      lodash2.sortedUniqBy = sortedUniqBy;
      lodash2.split = split;
      lodash2.spread = spread;
      lodash2.tail = tail;
      lodash2.take = take;
      lodash2.takeRight = takeRight;
      lodash2.takeRightWhile = takeRightWhile;
      lodash2.takeWhile = takeWhile;
      lodash2.tap = tap;
      lodash2.throttle = throttle2;
      lodash2.thru = thru;
      lodash2.toArray = toArray;
      lodash2.toPairs = toPairs;
      lodash2.toPairsIn = toPairsIn;
      lodash2.toPath = toPath;
      lodash2.toPlainObject = toPlainObject;
      lodash2.transform = transform;
      lodash2.unary = unary;
      lodash2.union = union;
      lodash2.unionBy = unionBy;
      lodash2.unionWith = unionWith;
      lodash2.uniq = uniq;
      lodash2.uniqBy = uniqBy;
      lodash2.uniqWith = uniqWith;
      lodash2.unset = unset;
      lodash2.unzip = unzip;
      lodash2.unzipWith = unzipWith;
      lodash2.update = update;
      lodash2.updateWith = updateWith;
      lodash2.values = values;
      lodash2.valuesIn = valuesIn;
      lodash2.without = without;
      lodash2.words = words;
      lodash2.wrap = wrap;
      lodash2.xor = xor;
      lodash2.xorBy = xorBy;
      lodash2.xorWith = xorWith;
      lodash2.zip = zip;
      lodash2.zipObject = zipObject;
      lodash2.zipObjectDeep = zipObjectDeep;
      lodash2.zipWith = zipWith;
      lodash2.entries = toPairs;
      lodash2.entriesIn = toPairsIn;
      lodash2.extend = assignIn;
      lodash2.extendWith = assignInWith;
      mixin(lodash2, lodash2);
      lodash2.add = add;
      lodash2.attempt = attempt;
      lodash2.camelCase = camelCase;
      lodash2.capitalize = capitalize2;
      lodash2.ceil = ceil;
      lodash2.clamp = clamp;
      lodash2.clone = clone;
      lodash2.cloneDeep = cloneDeep;
      lodash2.cloneDeepWith = cloneDeepWith;
      lodash2.cloneWith = cloneWith;
      lodash2.conformsTo = conformsTo;
      lodash2.deburr = deburr;
      lodash2.defaultTo = defaultTo;
      lodash2.divide = divide;
      lodash2.endsWith = endsWith;
      lodash2.eq = eq2;
      lodash2.escape = escape2;
      lodash2.escapeRegExp = escapeRegExp;
      lodash2.every = every;
      lodash2.find = find;
      lodash2.findIndex = findIndex;
      lodash2.findKey = findKey;
      lodash2.findLast = findLast;
      lodash2.findLastIndex = findLastIndex;
      lodash2.findLastKey = findLastKey;
      lodash2.floor = floor;
      lodash2.forEach = forEach;
      lodash2.forEachRight = forEachRight;
      lodash2.forIn = forIn;
      lodash2.forInRight = forInRight;
      lodash2.forOwn = forOwn;
      lodash2.forOwnRight = forOwnRight;
      lodash2.get = get2;
      lodash2.gt = gt;
      lodash2.gte = gte;
      lodash2.has = has;
      lodash2.hasIn = hasIn;
      lodash2.head = head;
      lodash2.identity = identity;
      lodash2.includes = includes;
      lodash2.indexOf = indexOf;
      lodash2.inRange = inRange;
      lodash2.invoke = invoke;
      lodash2.isArguments = isArguments;
      lodash2.isArray = isArray;
      lodash2.isArrayBuffer = isArrayBuffer;
      lodash2.isArrayLike = isArrayLike;
      lodash2.isArrayLikeObject = isArrayLikeObject;
      lodash2.isBoolean = isBoolean;
      lodash2.isBuffer = isBuffer2;
      lodash2.isDate = isDate;
      lodash2.isElement = isElement2;
      lodash2.isEmpty = isEmpty;
      lodash2.isEqual = isEqual3;
      lodash2.isEqualWith = isEqualWith;
      lodash2.isError = isError;
      lodash2.isFinite = isFinite;
      lodash2.isFunction = isFunction2;
      lodash2.isInteger = isInteger;
      lodash2.isLength = isLength;
      lodash2.isMap = isMap;
      lodash2.isMatch = isMatch;
      lodash2.isMatchWith = isMatchWith;
      lodash2.isNaN = isNaN;
      lodash2.isNative = isNative;
      lodash2.isNil = isNil;
      lodash2.isNull = isNull;
      lodash2.isNumber = isNumber;
      lodash2.isObject = isObject2;
      lodash2.isObjectLike = isObjectLike2;
      lodash2.isPlainObject = isPlainObject2;
      lodash2.isRegExp = isRegExp;
      lodash2.isSafeInteger = isSafeInteger;
      lodash2.isSet = isSet;
      lodash2.isString = isString;
      lodash2.isSymbol = isSymbol;
      lodash2.isTypedArray = isTypedArray;
      lodash2.isUndefined = isUndefined;
      lodash2.isWeakMap = isWeakMap;
      lodash2.isWeakSet = isWeakSet;
      lodash2.join = join;
      lodash2.kebabCase = kebabCase;
      lodash2.last = last;
      lodash2.lastIndexOf = lastIndexOf;
      lodash2.lowerCase = lowerCase;
      lodash2.lowerFirst = lowerFirst;
      lodash2.lt = lt;
      lodash2.lte = lte;
      lodash2.max = max2;
      lodash2.maxBy = maxBy;
      lodash2.mean = mean;
      lodash2.meanBy = meanBy;
      lodash2.min = min2;
      lodash2.minBy = minBy;
      lodash2.stubArray = stubArray;
      lodash2.stubFalse = stubFalse2;
      lodash2.stubObject = stubObject;
      lodash2.stubString = stubString;
      lodash2.stubTrue = stubTrue;
      lodash2.multiply = multiply;
      lodash2.nth = nth;
      lodash2.noConflict = noConflict;
      lodash2.noop = noop2;
      lodash2.now = now;
      lodash2.pad = pad;
      lodash2.padEnd = padEnd;
      lodash2.padStart = padStart;
      lodash2.parseInt = parseInt2;
      lodash2.random = random;
      lodash2.reduce = reduce;
      lodash2.reduceRight = reduceRight;
      lodash2.repeat = repeat;
      lodash2.replace = replace;
      lodash2.result = result;
      lodash2.round = round2;
      lodash2.runInContext = runInContext2;
      lodash2.sample = sample;
      lodash2.size = size;
      lodash2.snakeCase = snakeCase;
      lodash2.some = some;
      lodash2.sortedIndex = sortedIndex;
      lodash2.sortedIndexBy = sortedIndexBy;
      lodash2.sortedIndexOf = sortedIndexOf;
      lodash2.sortedLastIndex = sortedLastIndex;
      lodash2.sortedLastIndexBy = sortedLastIndexBy;
      lodash2.sortedLastIndexOf = sortedLastIndexOf;
      lodash2.startCase = startCase;
      lodash2.startsWith = startsWith;
      lodash2.subtract = subtract;
      lodash2.sum = sum;
      lodash2.sumBy = sumBy;
      lodash2.template = template;
      lodash2.times = times;
      lodash2.toFinite = toFinite;
      lodash2.toInteger = toInteger;
      lodash2.toLength = toLength;
      lodash2.toLower = toLower;
      lodash2.toNumber = toNumber;
      lodash2.toSafeInteger = toSafeInteger;
      lodash2.toString = toString;
      lodash2.toUpper = toUpper;
      lodash2.trim = trim;
      lodash2.trimEnd = trimEnd;
      lodash2.trimStart = trimStart;
      lodash2.truncate = truncate;
      lodash2.unescape = unescape;
      lodash2.uniqueId = uniqueId;
      lodash2.upperCase = upperCase;
      lodash2.upperFirst = upperFirst;
      lodash2.each = forEach;
      lodash2.eachRight = forEachRight;
      lodash2.first = head;
      mixin(lodash2, function() {
        var source = {};
        baseForOwn(lodash2, function(func, methodName) {
          if (!hasOwnProperty2.call(lodash2.prototype, methodName)) {
            source[methodName] = func;
          }
        });
        return source;
      }(), { "chain": false });
      lodash2.VERSION = VERSION;
      arrayEach(["bind", "bindKey", "curry", "curryRight", "partial", "partialRight"], function(methodName) {
        lodash2[methodName].placeholder = lodash2;
      });
      arrayEach(["drop", "take"], function(methodName, index2) {
        LazyWrapper.prototype[methodName] = function(n) {
          n = n === undefined$1 ? 1 : nativeMax(toInteger(n), 0);
          var result2 = this.__filtered__ && !index2 ? new LazyWrapper(this) : this.clone();
          if (result2.__filtered__) {
            result2.__takeCount__ = nativeMin(n, result2.__takeCount__);
          } else {
            result2.__views__.push({
              "size": nativeMin(n, MAX_ARRAY_LENGTH),
              "type": methodName + (result2.__dir__ < 0 ? "Right" : "")
            });
          }
          return result2;
        };
        LazyWrapper.prototype[methodName + "Right"] = function(n) {
          return this.reverse()[methodName](n).reverse();
        };
      });
      arrayEach(["filter", "map", "takeWhile"], function(methodName, index2) {
        var type = index2 + 1, isFilter = type == LAZY_FILTER_FLAG || type == LAZY_WHILE_FLAG;
        LazyWrapper.prototype[methodName] = function(iteratee2) {
          var result2 = this.clone();
          result2.__iteratees__.push({
            "iteratee": getIteratee(iteratee2, 3),
            "type": type
          });
          result2.__filtered__ = result2.__filtered__ || isFilter;
          return result2;
        };
      });
      arrayEach(["head", "last"], function(methodName, index2) {
        var takeName = "take" + (index2 ? "Right" : "");
        LazyWrapper.prototype[methodName] = function() {
          return this[takeName](1).value()[0];
        };
      });
      arrayEach(["initial", "tail"], function(methodName, index2) {
        var dropName = "drop" + (index2 ? "" : "Right");
        LazyWrapper.prototype[methodName] = function() {
          return this.__filtered__ ? new LazyWrapper(this) : this[dropName](1);
        };
      });
      LazyWrapper.prototype.compact = function() {
        return this.filter(identity);
      };
      LazyWrapper.prototype.find = function(predicate) {
        return this.filter(predicate).head();
      };
      LazyWrapper.prototype.findLast = function(predicate) {
        return this.reverse().find(predicate);
      };
      LazyWrapper.prototype.invokeMap = baseRest(function(path, args) {
        if (typeof path == "function") {
          return new LazyWrapper(this);
        }
        return this.map(function(value) {
          return baseInvoke(value, path, args);
        });
      });
      LazyWrapper.prototype.reject = function(predicate) {
        return this.filter(negate(getIteratee(predicate)));
      };
      LazyWrapper.prototype.slice = function(start2, end2) {
        start2 = toInteger(start2);
        var result2 = this;
        if (result2.__filtered__ && (start2 > 0 || end2 < 0)) {
          return new LazyWrapper(result2);
        }
        if (start2 < 0) {
          result2 = result2.takeRight(-start2);
        } else if (start2) {
          result2 = result2.drop(start2);
        }
        if (end2 !== undefined$1) {
          end2 = toInteger(end2);
          result2 = end2 < 0 ? result2.dropRight(-end2) : result2.take(end2 - start2);
        }
        return result2;
      };
      LazyWrapper.prototype.takeRightWhile = function(predicate) {
        return this.reverse().takeWhile(predicate).reverse();
      };
      LazyWrapper.prototype.toArray = function() {
        return this.take(MAX_ARRAY_LENGTH);
      };
      baseForOwn(LazyWrapper.prototype, function(func, methodName) {
        var checkIteratee = /^(?:filter|find|map|reject)|While$/.test(methodName), isTaker = /^(?:head|last)$/.test(methodName), lodashFunc = lodash2[isTaker ? "take" + (methodName == "last" ? "Right" : "") : methodName], retUnwrapped = isTaker || /^find/.test(methodName);
        if (!lodashFunc) {
          return;
        }
        lodash2.prototype[methodName] = function() {
          var value = this.__wrapped__, args = isTaker ? [1] : arguments, isLazy = value instanceof LazyWrapper, iteratee2 = args[0], useLazy = isLazy || isArray(value);
          var interceptor = function(value2) {
            var result3 = lodashFunc.apply(lodash2, arrayPush([value2], args));
            return isTaker && chainAll ? result3[0] : result3;
          };
          if (useLazy && checkIteratee && typeof iteratee2 == "function" && iteratee2.length != 1) {
            isLazy = useLazy = false;
          }
          var chainAll = this.__chain__, isHybrid = !!this.__actions__.length, isUnwrapped = retUnwrapped && !chainAll, onlyLazy = isLazy && !isHybrid;
          if (!retUnwrapped && useLazy) {
            value = onlyLazy ? value : new LazyWrapper(this);
            var result2 = func.apply(value, args);
            result2.__actions__.push({ "func": thru, "args": [interceptor], "thisArg": undefined$1 });
            return new LodashWrapper(result2, chainAll);
          }
          if (isUnwrapped && onlyLazy) {
            return func.apply(this, args);
          }
          result2 = this.thru(interceptor);
          return isUnwrapped ? isTaker ? result2.value()[0] : result2.value() : result2;
        };
      });
      arrayEach(["pop", "push", "shift", "sort", "splice", "unshift"], function(methodName) {
        var func = arrayProto2[methodName], chainName = /^(?:push|sort|unshift)$/.test(methodName) ? "tap" : "thru", retUnwrapped = /^(?:pop|shift)$/.test(methodName);
        lodash2.prototype[methodName] = function() {
          var args = arguments;
          if (retUnwrapped && !this.__chain__) {
            var value = this.value();
            return func.apply(isArray(value) ? value : [], args);
          }
          return this[chainName](function(value2) {
            return func.apply(isArray(value2) ? value2 : [], args);
          });
        };
      });
      baseForOwn(LazyWrapper.prototype, function(func, methodName) {
        var lodashFunc = lodash2[methodName];
        if (lodashFunc) {
          var key = lodashFunc.name + "";
          if (!hasOwnProperty2.call(realNames, key)) {
            realNames[key] = [];
          }
          realNames[key].push({ "name": methodName, "func": lodashFunc });
        }
      });
      realNames[createHybrid(undefined$1, WRAP_BIND_KEY_FLAG).name] = [{
        "name": "wrapper",
        "func": undefined$1
      }];
      LazyWrapper.prototype.clone = lazyClone;
      LazyWrapper.prototype.reverse = lazyReverse;
      LazyWrapper.prototype.value = lazyValue;
      lodash2.prototype.at = wrapperAt;
      lodash2.prototype.chain = wrapperChain;
      lodash2.prototype.commit = wrapperCommit;
      lodash2.prototype.next = wrapperNext;
      lodash2.prototype.plant = wrapperPlant;
      lodash2.prototype.reverse = wrapperReverse;
      lodash2.prototype.toJSON = lodash2.prototype.valueOf = lodash2.prototype.value = wrapperValue;
      lodash2.prototype.first = lodash2.prototype.head;
      if (symIterator) {
        lodash2.prototype[symIterator] = wrapperToIterator;
      }
      return lodash2;
    };
    var _22 = runInContext();
    if (freeModule) {
      (freeModule.exports = _22)._ = _22;
      freeExports._ = _22;
    } else {
      root2._ = _22;
    }
  }).call(commonjsGlobal);
})(lodash, lodash.exports);
var lodashExports = lodash.exports;
const shouldLog = localStorage.getItem("dhis2.debugConnectionStatus");
if (shouldLog) {
  console.log("Logging for dhis2ConnectionStatus is enabled. Remove the `dhis2.debugConnectionStatus` item in localStorage to disable logging.");
}
function devDebugLog() {
  if (shouldLog) {
    console.log(...arguments);
  }
}
function isPingAvailable(serverVersion) {
  if (!serverVersion) {
    return false;
  }
  const {
    minor,
    patch
  } = serverVersion;
  switch (minor) {
    case 39:
      return patch === void 0 || patch >= 2;
    case 38:
      return patch === void 0 || patch >= 4;
    case 37:
      return patch === void 0 || patch >= 10;
    default:
      return minor >= 40;
  }
}
const DEFAULT_INITIAL_DELAY_MS = 1e3 * 30;
const DEFAULT_MAX_DELAY_MS = 1e3 * 60 * 5;
const DEFAULT_INCREMENT_FACTOR = 1.5;
const throwErrorIfNoCallbackIsProvided = () => {
  throw new Error("Provide a callback");
};
function createSmartInterval() {
  let {
    initialDelay = DEFAULT_INITIAL_DELAY_MS,
    maxDelay = DEFAULT_MAX_DELAY_MS,
    delayIncrementFactor = DEFAULT_INCREMENT_FACTOR,
    initialPauseValue = false,
    callback = throwErrorIfNoCallbackIsProvided
  } = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
  const state = {
    paused: initialPauseValue,
    delay: initialDelay,
    // Timeout types are weird; this dummy timeout helps fix them:
    // (named to help debugging in tests)
    timeout: setTimeout(function dummyTimeout() {
      return;
    }, 0),
    standbyCallback: null
  };
  function incrementDelay() {
    const newDelay = Math.min(state.delay * delayIncrementFactor, maxDelay);
    devDebugLog("[SI] incrementing delay", {
      prev: state.delay,
      new: newDelay
    });
    state.delay = newDelay;
  }
  function invokeCallbackAndHandleDelay() {
    incrementDelay();
    callback();
  }
  function clearTimeoutAndStart() {
    devDebugLog("[SI] clearing and starting timeout", {
      delay: state.delay
    });
    clearTimeout(state.timeout);
    state.timeout = setTimeout(function callbackAndRestart() {
      if (state.paused) {
        devDebugLog("[SI] entering regular standby");
        state.standbyCallback = () => {
          invokeCallbackAndHandleDelay();
          clearTimeoutAndStart();
        };
        return;
      }
      invokeCallbackAndHandleDelay();
      clearTimeoutAndStart();
    }, state.delay);
  }
  function clear() {
    clearTimeout(state.timeout);
  }
  function invokeCallbackImmediately() {
    if (state.paused) {
      if (state.standbyCallback === null) {
        devDebugLog("[SI] entering standby without timer increment");
        state.standbyCallback = () => {
          callback();
          clearTimeoutAndStart();
        };
      }
      return;
    }
    callback();
    clearTimeoutAndStart();
  }
  function pause() {
    devDebugLog("[SI] pausing");
    state.paused = true;
  }
  function resume() {
    devDebugLog("[SI] resuming", {
      standbyCb: state.standbyCallback
    });
    state.paused = false;
    if (state.standbyCallback !== null) {
      state.standbyCallback();
      state.standbyCallback = null;
    }
  }
  function snooze() {
    devDebugLog("[SI] snoozing timeout");
    clearTimeoutAndStart();
  }
  function reset() {
    devDebugLog("[SI] resetting interval from beginning");
    state.delay = initialDelay;
    clearTimeoutAndStart();
  }
  clearTimeoutAndStart();
  return {
    clear,
    pause,
    resume,
    invokeCallbackImmediately,
    snooze,
    reset
  };
}
function usePingQuery() {
  const {
    baseUrl
  } = useConfig();
  const ping = reactExports.useCallback(() => fetch(baseUrl + "/api/ping"), [baseUrl]);
  return ping;
}
const lastConnectedKey = "dhis2.lastConnected";
const getLastConnectedKey = (appName) => appName ? `${lastConnectedKey}.${appName}` : lastConnectedKey;
const updateLastConnected = (appName) => {
  const now = new Date(Date.now());
  localStorage.setItem(getLastConnectedKey(appName), now.toUTCString());
  return now;
};
const getLastConnected = (appName) => {
  const lastConnected = localStorage.getItem(getLastConnectedKey(appName));
  return lastConnected ? new Date(lastConnected) : null;
};
const clearLastConnected = (appName) => {
  localStorage.removeItem(getLastConnectedKey(appName));
};
const Dhis2ConnectionStatusContext = /* @__PURE__ */ React.createContext({
  isConnected: true,
  isDisconnected: false,
  lastConnected: null
});
const Dhis2ConnectionStatusProvider = (_ref) => {
  let {
    children
  } = _ref;
  const offlineInterface = useOfflineInterface();
  const {
    appName,
    serverVersion
  } = useConfig();
  const [isConnected, setIsConnected] = reactExports.useState(offlineInterface.latestIsConnected);
  const ping = usePingQuery();
  const smartIntervalRef = reactExports.useRef(null);
  const updateConnectedState = reactExports.useCallback((newIsConnected) => {
    setIsConnected((prevIsConnected) => {
      devDebugLog("[D2CS] updating state:", {
        prevIsConnected,
        newIsConnected
      });
      if (newIsConnected !== prevIsConnected) {
        var _smartIntervalRef$cur;
        (_smartIntervalRef$cur = smartIntervalRef.current) === null || _smartIntervalRef$cur === void 0 ? void 0 : _smartIntervalRef$cur.reset();
        if (newIsConnected) {
          clearLastConnected(appName);
        } else {
          updateLastConnected(appName);
        }
      }
      return newIsConnected;
    });
  }, [appName]);
  const pingAndHandleStatus = reactExports.useCallback(() => {
    return ping().then(() => {
      updateConnectedState(true);
    }).catch((err) => {
      console.error("Ping failed:", err.message);
      updateConnectedState(false);
    });
  }, [ping, updateConnectedState]);
  const onUpdate = reactExports.useCallback((_ref2) => {
    var _smartIntervalRef$cur2;
    let {
      isConnected: newIsConnected
    } = _ref2;
    devDebugLog("[D2CS] handling update from sw");
    (_smartIntervalRef$cur2 = smartIntervalRef.current) === null || _smartIntervalRef$cur2 === void 0 ? void 0 : _smartIntervalRef$cur2.snooze();
    updateConnectedState(newIsConnected);
  }, [updateConnectedState]);
  reactExports.useEffect(() => {
    if (!serverVersion || !isPingAvailable(serverVersion)) {
      return;
    }
    const smartInterval = createSmartInterval({
      // don't ping if window isn't focused or visible
      initialPauseValue: !document.hasFocus() || document.visibilityState !== "visible",
      callback: pingAndHandleStatus
    });
    smartIntervalRef.current = smartInterval;
    const handleBlur = () => smartInterval.pause();
    const handleFocus = () => smartInterval.resume();
    const handleOffline = () => smartInterval.invokeCallbackImmediately();
    const handleOnline = lodashExports.throttle(() => smartInterval.invokeCallbackImmediately(), 15e3);
    window.addEventListener("blur", handleBlur);
    window.addEventListener("focus", handleFocus);
    window.addEventListener("offline", handleOffline);
    window.addEventListener("online", handleOnline);
    return () => {
      window.removeEventListener("blur", handleBlur);
      window.removeEventListener("focus", handleFocus);
      window.removeEventListener("offline", handleOffline);
      window.removeEventListener("online", handleOnline);
      smartInterval.clear();
      handleOnline.cancel();
    };
  }, [pingAndHandleStatus, serverVersion]);
  reactExports.useEffect(() => {
    if (!offlineInterface.subscribeToDhis2ConnectionStatus) {
      var _smartIntervalRef$cur3;
      (_smartIntervalRef$cur3 = smartIntervalRef.current) === null || _smartIntervalRef$cur3 === void 0 ? void 0 : _smartIntervalRef$cur3.invokeCallbackImmediately();
      console.warn("Please upgrade to @dhis2/cli-app-scripts@>10.3.8 for full connection status features");
      return;
    }
    const unsubscribe = offlineInterface.subscribeToDhis2ConnectionStatus({
      onUpdate
    });
    return () => {
      unsubscribe();
    };
  }, [offlineInterface, onUpdate]);
  const contextValue = reactExports.useMemo(() => {
    const validatedIsConnected = isConnected !== null && isConnected !== void 0 ? isConnected : true;
    return {
      isConnected: validatedIsConnected,
      isDisconnected: !validatedIsConnected,
      lastConnected: validatedIsConnected ? null : (
        // Only evaluate if disconnected, since local storage
        // is synchronous and disk-based.
        // If lastConnected is not set in localStorage though, set it.
        // (relevant on startup)
        getLastConnected(appName) || updateLastConnected(appName)
      )
    };
  }, [isConnected, appName]);
  return /* @__PURE__ */ React.createElement(Dhis2ConnectionStatusContext.Provider, {
    value: contextValue
  }, children);
};
Dhis2ConnectionStatusProvider.propTypes = {
  children: PropTypes.node
};
const useDhis2ConnectionStatus = () => {
  const context = reactExports.useContext(Dhis2ConnectionStatusContext);
  if (!context) {
    throw new Error("useDhis2ConnectionStatus must be used within a Dhis2ConnectionStatus provider");
  }
  return context;
};
const OnlineStatusMessageValueContext = /* @__PURE__ */ React.createContext(void 0);
const SetOnlineStatusMessageContext = /* @__PURE__ */ React.createContext(() => void 0);
const OnlineStatusMessageProvider = (_ref) => {
  let {
    children
  } = _ref;
  const [onlineStatusMessage, setOnlineStatusMessage] = reactExports.useState();
  return /* @__PURE__ */ React.createElement(OnlineStatusMessageValueContext.Provider, {
    value: onlineStatusMessage
  }, /* @__PURE__ */ React.createElement(SetOnlineStatusMessageContext.Provider, {
    value: setOnlineStatusMessage
  }, children));
};
const useOnlineStatusMessageValue = () => {
  return reactExports.useContext(OnlineStatusMessageValueContext);
};
const useSetOnlineStatusMessage = () => {
  return reactExports.useContext(SetOnlineStatusMessageContext);
};
const useOnlineStatusMessage = () => {
  const onlineStatusMessage = useOnlineStatusMessageValue();
  const setOnlineStatusMessage = useSetOnlineStatusMessage();
  return {
    onlineStatusMessage,
    setOnlineStatusMessage
  };
};
function OfflineProvider(_ref) {
  let {
    offlineInterface,
    children
  } = _ref;
  if (!offlineInterface || !offlineInterface.pwaEnabled) {
    return /* @__PURE__ */ React.createElement(React.Fragment, null, children);
  }
  return /* @__PURE__ */ React.createElement(OfflineInterfaceProvider, {
    offlineInterface
  }, /* @__PURE__ */ React.createElement(Dhis2ConnectionStatusProvider, null, /* @__PURE__ */ React.createElement(CacheableSectionProvider, null, /* @__PURE__ */ React.createElement(OnlineStatusMessageProvider, null, children))));
}
OfflineProvider.propTypes = {
  children: PropTypes.node,
  offlineInterface: PropTypes.shape({
    pwaEnabled: PropTypes.bool
  })
};
({
  id: PropTypes.string.isRequired,
  children: PropTypes.node,
  loadingMask: PropTypes.node
});
const SECTIONS_DB = "sections-db";
const SECTIONS_STORE = "sections-store";
const KEEPABLE_CACHES = [
  /^workbox-precache/
  // precached static assets
];
const clearDB = async (dbName) => {
  if (!("databases" in indexedDB)) {
    return;
  }
  const dbs = await window.indexedDB.databases();
  if (!dbs.some((_ref) => {
    let {
      name
    } = _ref;
    return name === dbName;
  })) {
    return;
  }
  return new Promise((resolve, reject) => {
    const openDBRequest = indexedDB.open(dbName);
    openDBRequest.onsuccess = (e) => {
      const db = e.target.result;
      const tx = db.transaction(SECTIONS_STORE, "readwrite");
      tx.oncomplete = () => resolve();
      tx.onerror = (e2) => reject(e2.target.error);
      const os = tx.objectStore(SECTIONS_STORE);
      const clearReq = os.clear();
      clearReq.onerror = (e2) => reject(e2.target.error);
    };
    openDBRequest.onerror = (e) => {
      reject(e.target.error);
    };
  });
};
async function clearSensitiveCaches() {
  let dbName = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : SECTIONS_DB;
  console.debug("Clearing sensitive caches");
  let cacheKeys;
  try {
    cacheKeys = await caches.keys();
  } catch (e) {
    return false;
  }
  return Promise.all([
    // (Resolves to 'false' because this can't detect if anything was deleted):
    clearDB(dbName).then(() => false),
    // Remove caches if not in keepable list
    ...cacheKeys.map((key) => {
      if (!KEEPABLE_CACHES.some((pattern) => pattern.test(key))) {
        return caches.delete(key);
      }
      return false;
    })
  ]).then((responses) => {
    return responses.some((response) => response);
  });
}
const Provider = (_ref) => {
  let {
    config,
    children,
    offlineInterface,
    plugin,
    parentAlertsAdd,
    showAlertsInPlugin
  } = _ref;
  return /* @__PURE__ */ React.createElement(ConfigProvider, {
    config
  }, /* @__PURE__ */ React.createElement(AlertsProvider, {
    plugin,
    parentAlertsAdd,
    showAlertsInPlugin
  }, /* @__PURE__ */ React.createElement(DataProvider, null, /* @__PURE__ */ React.createElement(OfflineProvider, {
    offlineInterface
  }, children))));
};
Provider.displayName = "DHIS2RuntimeProvider";
const colors = {
  /*blue*/
  blue900: "#093371",
  blue800: "#0d47a1",
  blue700: "#1565c0",
  blue600: "#147cd7",
  blue500: "#2196f3",
  blue400: "#42a5f5",
  blue300: "#90caf9",
  blue200: "#c5e3fc",
  blue100: "#e3f2fd",
  blue050: "#f5fbff",
  /*teal*/
  teal900: "#00332b",
  teal800: "#004d40",
  teal700: "#00695c",
  teal600: "#00796b",
  teal500: "#00897b",
  teal400: "#009688",
  teal300: "#4db6ac",
  teal200: "#b2dfdb",
  teal100: "#e0f2f1",
  teal050: "#f1f9f9",
  /*red*/
  red900: "#330202",
  red800: "#891515",
  red700: "#b71c1c",
  red600: "#c62828",
  red500: "#d32f2f",
  red400: "#f44336",
  red300: "#e57373",
  red200: "#ffcdd2",
  red100: "#ffe5e8",
  red050: "#fff5f6",
  /*yellow*/
  yellow900: "#6f3205",
  yellow800: "#bb460d",
  yellow700: "#e56408",
  yellow600: "#ff8302",
  yellow500: "#ff9302",
  yellow400: "#ffa902",
  yellow300: "#ffc324",
  yellow200: "#ffe082",
  yellow100: "#ffecb3",
  yellow050: "#fff8e1",
  /*green*/
  green900: "#103713",
  green800: "#1b5e20",
  green700: "#2e7d32",
  green600: "#388e3c",
  green500: "#43a047",
  green400: "#4caf50",
  green300: "#a5d6a7",
  green200: "#c8e6c9",
  green100: "#e8f5e9",
  green050: "#f4fbf4",
  /*grey*/
  grey900: "#212934",
  grey800: "#404b5a",
  grey700: "#4a5768",
  grey600: "#6C7787",
  grey500: "#a0adba",
  grey400: "#d5dde5",
  grey300: "#e8edf2",
  grey200: "#f3f5f7",
  grey100: "#f8f9fa",
  grey050: "#fbfcfd",
  white: "#ffffff"
};
const theme = {
  /* theme */
  fonts: "Roboto, sans-serif",
  /*primary*/
  primary900: colors.blue900,
  primary800: colors.blue800,
  primary700: colors.blue700,
  primary600: colors.blue600,
  primary500: colors.blue500,
  primary400: colors.blue400,
  primary300: colors.blue300,
  primary200: colors.blue200,
  primary100: colors.blue100,
  primary050: colors.blue050,
  /*secondary*/
  secondary900: colors.teal900,
  secondary800: colors.teal800,
  secondary700: colors.teal700,
  secondary600: colors.teal600,
  secondary500: colors.teal500,
  secondary400: colors.teal400,
  secondary300: colors.teal300,
  secondary200: colors.teal200,
  secondary100: colors.teal100,
  secondary050: colors.teal050,
  /*status*/
  default: colors.grey700,
  error: colors.red500,
  valid: colors.blue600,
  warning: colors.yellow500,
  disabled: colors.grey600,
  focus: colors.blue600
};
const spacersNum = {
  dp4: 4,
  dp8: 8,
  dp12: 12,
  dp16: 16,
  dp24: 24,
  dp32: 32,
  dp48: 48,
  dp64: 64,
  dp96: 96,
  dp128: 128,
  dp192: 192,
  dp256: 256,
  dp384: 384,
  dp512: 512,
  dp640: 640
};
const spacers = {
  dp4: "".concat(spacersNum.dp4, "px"),
  dp8: "".concat(spacersNum.dp8, "px"),
  dp12: "".concat(spacersNum.dp12, "px"),
  dp16: "".concat(spacersNum.dp16, "px"),
  dp24: "".concat(spacersNum.dp24, "px"),
  dp32: "".concat(spacersNum.dp32, "px"),
  dp48: "".concat(spacersNum.dp48, "px"),
  dp64: "".concat(spacersNum.dp64, "px"),
  dp96: "".concat(spacersNum.dp96, "px"),
  dp128: "".concat(spacersNum.dp128, "px"),
  dp192: "".concat(spacersNum.dp192, "px"),
  dp256: "".concat(spacersNum.dp256, "px"),
  dp384: "".concat(spacersNum.dp384, "px"),
  dp512: "".concat(spacersNum.dp512, "px"),
  dp640: "".concat(spacersNum.dp640, "px")
};
const elevations = {
  e100: "0px 1px 2px rgba(33,41,52,0.06), 0px 1px 3px rgba(33,41,52,0.1)",
  e200: "0px 0px 1px rgba(33,41,52,0.1), 0px 4px 6px -1px rgba(33,41,52,0.1), 0px 2px 4px -1px rgba(33,41,52,0.06)",
  e300: "0px 10px 15px -3px rgba(33,41,52,0.1), 0px 4px 6px -2px rgba(33,41,52,0.05)",
  e400: "0px 25px 50px -12px rgba(33, 41, 52, 0.25)"
};
const deprecated = (propType, explanation) => {
  const emmittedWarnings = /* @__PURE__ */ new Set();
  return (props, propName, componentName) => {
    const message = `"${propName}" property of "${componentName}" has been deprecated. ${explanation}`;
    if (typeof props[propName] !== "undefined" && !emmittedWarnings.has(message)) {
      console.warn(message);
      emmittedWarnings.add(message);
    }
    PropTypes.checkPropTypes({
      [propName]: propType
    }, props, "prop", componentName);
    return null;
  };
};
const mutuallyExclusiveFactory = (exlusivePropNames, propType, isRequired) => (props, propName, componentName) => {
  const baseMsg = `Invalid prop \`${propName}\` supplied to \`${componentName}\`,`;
  const isDefined = typeof props[propName] !== "undefined";
  if (exlusivePropNames.length === 0) {
    return new Error(`mutuallyExclusive was called without any arguments for property \`${propName}\` on component \`${componentName}\`. Please add the required arguments.`);
  }
  if (isRequired && !isDefined) {
    return new Error(`${baseMsg} this prop is required but no value was found.`);
  }
  PropTypes.checkPropTypes({
    [propName]: propType
  }, props, "prop", componentName);
  if (props[propName]) {
    const thruthySiblingPropName = exlusivePropNames.find((name) => props[name] && name !== propName);
    if (thruthySiblingPropName) {
      return new Error(`${baseMsg} Property '${propName}' is mutually exclusive with '${thruthySiblingPropName}', but both have a thruthy value.`);
    }
  }
  return null;
};
function mutuallyExclusive(exlusivePropNames, propType) {
  const fn2 = mutuallyExclusiveFactory(exlusivePropNames, propType, false);
  fn2.isRequired = mutuallyExclusiveFactory(exlusivePropNames, propType, true);
  return fn2;
}
const statusPropType = mutuallyExclusive(["valid", "warning", "error"], PropTypes.bool);
mutuallyExclusive(["primary", "secondary", "destructive"], PropTypes.bool);
const sizePropType = mutuallyExclusive(["small", "large", "extrasmall", "fluid"], PropTypes.bool);
const insideAlignmentPropType = PropTypes.oneOf(["top", "middle", "bottom"]);
const popperPlacementPropType = PropTypes.oneOf(["auto", "auto-start", "auto-end", "top", "top-start", "top-end", "bottom", "bottom-start", "bottom-end", "right", "right-start", "right-end", "left", "left-start", "left-end"]);
const popperReferencePropType = PropTypes.oneOfType([
  // DOM node
  PropTypes.instanceOf(Element),
  // React ref - React.useRef() or React.createRef()
  PropTypes.shape({
    current: PropTypes.instanceOf(Element)
  }),
  // Virtual element
  PropTypes.shape({
    getBoundingClientRect: PropTypes.func
  })
]);
function SvgApps24(_ref) {
  let {
    color,
    dataTest
  } = _ref;
  return /* @__PURE__ */ reactExports.createElement("svg", {
    height: 24,
    viewBox: "0 0 24 24",
    width: 24,
    xmlns: "http://www.w3.org/2000/svg",
    color,
    "data-test": dataTest
  }, /* @__PURE__ */ reactExports.createElement("path", {
    d: "M7 16a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1v-2a1 1 0 011-1zm6 0a1 1 0 011 1v2a1 1 0 01-1 1h-2a1 1 0 01-1-1v-2a1 1 0 011-1zm6 0a1 1 0 011 1v2a1 1 0 01-1 1h-2a1 1 0 01-1-1v-2a1 1 0 011-1zM7 10a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1v-2a1 1 0 011-1zm6 0a1 1 0 011 1v2a1 1 0 01-1 1h-2a1 1 0 01-1-1v-2a1 1 0 011-1zm6 0a1 1 0 011 1v2a1 1 0 01-1 1h-2a1 1 0 01-1-1v-2a1 1 0 011-1zM7 4a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1V5a1 1 0 011-1zm6 0a1 1 0 011 1v2a1 1 0 01-1 1h-2a1 1 0 01-1-1V5a1 1 0 011-1zm6 0a1 1 0 011 1v2a1 1 0 01-1 1h-2a1 1 0 01-1-1V5a1 1 0 011-1z",
    fill: "currentColor",
    fillRule: "evenodd"
  }));
}
SvgApps24.propTypes = {
  color: PropTypes.string,
  dataTest: PropTypes.string
};
function SvgCheckmark24(_ref) {
  let {
    color,
    dataTest
  } = _ref;
  return /* @__PURE__ */ reactExports.createElement("svg", {
    height: 24,
    viewBox: "0 0 24 24",
    width: 24,
    xmlns: "http://www.w3.org/2000/svg",
    color,
    "data-test": dataTest
  }, /* @__PURE__ */ reactExports.createElement("path", {
    d: "M19.293 6.293a1 1 0 011.497 1.32l-.083.094-10 10a1 1 0 01-1.32.083l-.094-.083-5-5a1 1 0 011.32-1.497l.094.083L10 15.585z",
    fill: "currentColor"
  }));
}
SvgCheckmark24.propTypes = {
  color: PropTypes.string,
  dataTest: PropTypes.string
};
function SvgChevronRight24(_ref) {
  let {
    color,
    dataTest
  } = _ref;
  return /* @__PURE__ */ reactExports.createElement("svg", {
    height: 24,
    viewBox: "0 0 24 24",
    width: 24,
    xmlns: "http://www.w3.org/2000/svg",
    color,
    "data-test": dataTest
  }, /* @__PURE__ */ reactExports.createElement("path", {
    d: "M9.293 6.293a1 1 0 011.32-.083l.094.083 5 5a1 1 0 01.083 1.32l-.083.094-5 5a1 1 0 01-1.497-1.32l.083-.094L13.585 12 9.293 7.707a1 1 0 01-.083-1.32z",
    fill: "currentColor"
  }));
}
SvgChevronRight24.propTypes = {
  color: PropTypes.string,
  dataTest: PropTypes.string
};
function SvgCross16(_ref) {
  let {
    color,
    dataTest
  } = _ref;
  return /* @__PURE__ */ reactExports.createElement("svg", {
    height: 16,
    viewBox: "0 0 16 16",
    width: 16,
    xmlns: "http://www.w3.org/2000/svg",
    color,
    "data-test": dataTest
  }, /* @__PURE__ */ reactExports.createElement("path", {
    d: "M4.284 3.589l.07.057L8 7.293l3.646-3.647a.5.5 0 01.765.638l-.057.07L8.707 8l3.647 3.646a.5.5 0 01-.638.765l-.07-.057L8 8.707l-3.646 3.647a.5.5 0 01-.765-.638l.057-.07L7.293 8 3.646 4.354a.5.5 0 01.638-.765z",
    fill: "currentColor"
  }));
}
SvgCross16.propTypes = {
  color: PropTypes.string,
  dataTest: PropTypes.string
};
function SvgErrorFilled24(_ref) {
  let {
    color,
    dataTest
  } = _ref;
  return /* @__PURE__ */ reactExports.createElement("svg", {
    height: 24,
    viewBox: "0 0 24 24",
    width: 24,
    xmlns: "http://www.w3.org/2000/svg",
    color,
    "data-test": dataTest
  }, /* @__PURE__ */ reactExports.createElement("path", {
    d: "M12 2c5.523 0 10 4.477 10 10s-4.477 10-10 10S2 17.523 2 12 6.477 2 12 2zm0 14a1 1 0 100 2 1 1 0 000-2zm1-10h-2v7h2z",
    fill: "currentColor",
    fillRule: "evenodd"
  }));
}
SvgErrorFilled24.propTypes = {
  color: PropTypes.string,
  dataTest: PropTypes.string
};
function SvgInfo24(_ref) {
  let {
    color,
    dataTest
  } = _ref;
  return /* @__PURE__ */ reactExports.createElement("svg", {
    height: 24,
    viewBox: "0 0 24 24",
    width: 24,
    xmlns: "http://www.w3.org/2000/svg",
    color,
    "data-test": dataTest
  }, /* @__PURE__ */ reactExports.createElement("path", {
    d: "M12 2c5.523 0 10 4.477 10 10s-4.477 10-10 10S2 17.523 2 12 6.477 2 12 2zm0 2a8 8 0 100 16 8 8 0 000-16zm1 7v6h-2v-6zm-1-4a1 1 0 110 2 1 1 0 010-2z",
    fill: "currentColor"
  }));
}
SvgInfo24.propTypes = {
  color: PropTypes.string,
  dataTest: PropTypes.string
};
function SvgLogOut24(_ref) {
  let {
    color,
    dataTest
  } = _ref;
  return /* @__PURE__ */ reactExports.createElement("svg", {
    height: 24,
    viewBox: "0 0 24 24",
    width: 24,
    xmlns: "http://www.w3.org/2000/svg",
    color,
    "data-test": dataTest
  }, /* @__PURE__ */ reactExports.createElement("path", {
    d: "M10 12c1.777 0 3.374.773 4.472 2H8a4 4 0 00-3.995 3.8L4 18v2h12v2H2v-4a6 6 0 016-6zm8.613 1.21l.094.083 3 3a1 1 0 01.083 1.32l-.083.094-3 3a1 1 0 01-1.497-1.32l.083-.094L18.585 18H12a1 1 0 01-.117-1.993L12 16h6.585l-1.292-1.293a1 1 0 01-.083-1.32l.083-.094a1 1 0 011.32-.083zM9 3a4 4 0 110 8 4 4 0 010-8zm0 2a2 2 0 100 4 2 2 0 000-4z",
    fill: "currentColor"
  }));
}
SvgLogOut24.propTypes = {
  color: PropTypes.string,
  dataTest: PropTypes.string
};
function SvgMail24(_ref) {
  let {
    color,
    dataTest
  } = _ref;
  return /* @__PURE__ */ reactExports.createElement("svg", {
    height: 24,
    viewBox: "0 0 24 24",
    width: 24,
    xmlns: "http://www.w3.org/2000/svg",
    color,
    "data-test": dataTest
  }, /* @__PURE__ */ reactExports.createElement("path", {
    d: "M19 5a2 2 0 012 2v10a2 2 0 01-2 2H5a2 2 0 01-2-2V7a2 2 0 012-2zm0 3.414L13.414 14a2 2 0 01-2.701.117L10.586 14 5 8.415V17h14zM17.584 7H6.415L12 12.586z",
    fill: "currentColor"
  }));
}
SvgMail24.propTypes = {
  color: PropTypes.string,
  dataTest: PropTypes.string
};
function SvgMessages24(_ref) {
  let {
    color,
    dataTest
  } = _ref;
  return /* @__PURE__ */ reactExports.createElement("svg", {
    height: 24,
    viewBox: "0 0 24 24",
    width: 24,
    xmlns: "http://www.w3.org/2000/svg",
    color,
    "data-test": dataTest
  }, /* @__PURE__ */ reactExports.createElement("path", {
    d: "M20 5a2 2 0 012 2v8a2 2 0 01-2 2h-1v3.826a1 1 0 01-1.65.759L12 17H7a2 2 0 01-2-2V7a2 2 0 012-2zm0 2H7v8h5.74L17 18.652V15h3zm-6-5v2H5a1 1 0 00-.993.883L4 5v7H2V5a3 3 0 012.824-2.995L5 2z",
    fill: "currentColor"
  }));
}
SvgMessages24.propTypes = {
  color: PropTypes.string,
  dataTest: PropTypes.string
};
function SvgQuestion24(_ref) {
  let {
    color,
    dataTest
  } = _ref;
  return /* @__PURE__ */ reactExports.createElement("svg", {
    height: 24,
    viewBox: "0 0 24 24",
    width: 24,
    xmlns: "http://www.w3.org/2000/svg",
    color,
    "data-test": dataTest
  }, /* @__PURE__ */ reactExports.createElement("path", {
    d: "M12 2c5.523 0 10 4.477 10 10s-4.477 10-10 10S2 17.523 2 12 6.477 2 12 2zm0 2a8 8 0 100 16 8 8 0 000-16zm0 12a1 1 0 110 2 1 1 0 010-2zm0-10a4 4 0 011.155 7.83l-.155.043V15h-2v-3h1a2 2 0 10-1.995-2.15L10 10H8a4 4 0 014-4z",
    fill: "currentColor"
  }));
}
SvgQuestion24.propTypes = {
  color: PropTypes.string,
  dataTest: PropTypes.string
};
function SvgSettings24(_ref) {
  let {
    color,
    dataTest
  } = _ref;
  return /* @__PURE__ */ reactExports.createElement("svg", {
    height: 24,
    viewBox: "0 0 24 24",
    width: 24,
    xmlns: "http://www.w3.org/2000/svg",
    color,
    "data-test": dataTest
  }, /* @__PURE__ */ reactExports.createElement("path", {
    d: "M13 2a2 2 0 012 2v1.674l.295.149c.103.055.204.112.304.172l.287.182 1.346-.775a2 2 0 012.649.6l.083.132 1 1.732a2 2 0 01-.732 2.732l-1.265.731.024.318L19 12c0 .223-.01.444-.031.664l-.027.225 1.29.745a2 2 0 01.805 2.594l-.073.138-1 1.732a2 2 0 01-2.732.732l-1.535-.886-.222.134c-.09.052-.182.102-.275.15l-.2.096V20a2 2 0 01-1.85 1.995L13 22h-2a2 2 0 01-2-2l-.001-1.676-.199-.097a6.986 6.986 0 01-.275-.15l-.223-.133-1.534.886a2 2 0 01-2.649-.6l-.083-.132-1-1.732a2 2 0 01.732-2.732l1.289-.745-.026-.225a7.05 7.05 0 01-.023-.331L5 12a7.1 7.1 0 01.009-.354l.023-.318-1.264-.73a2 2 0 01-.805-2.594l.073-.138 1-1.732a2 2 0 012.732-.732l1.344.776.288-.183c.1-.06.202-.117.305-.172l.294-.149L9 4a2 2 0 011.85-1.995L11 2zm0 2h-2v3.049l-.667.235a4.991 4.991 0 00-1.515.86l-.536.442-2.514-1.452-1 1.732 2.475 1.429L7.1 11a5.028 5.028 0 00.038 2.172l.174.726-2.544 1.468 1 1.732 2.66-1.536.53.407c.417.32.88.572 1.375.747l.667.235V20h2v-3.049l.667-.235a4.987 4.987 0 001.374-.747l.53-.407 2.661 1.536 1-1.732-2.544-1.468.174-.726A5.016 5.016 0 0016.9 11l-.142-.705 2.474-1.43-1-1.732-2.515 1.45-.535-.441a4.991 4.991 0 00-1.515-.859L13 7.05zm-1 5a3 3 0 110 6 3 3 0 010-6zm0 2a1 1 0 100 2 1 1 0 000-2z",
    fill: "currentColor"
  }));
}
SvgSettings24.propTypes = {
  color: PropTypes.string,
  dataTest: PropTypes.string
};
function SvgUser24(_ref) {
  let {
    color,
    dataTest
  } = _ref;
  return /* @__PURE__ */ reactExports.createElement("svg", {
    height: 24,
    viewBox: "0 0 24 24",
    width: 24,
    xmlns: "http://www.w3.org/2000/svg",
    color,
    "data-test": dataTest
  }, /* @__PURE__ */ reactExports.createElement("path", {
    d: "M14 12a6 6 0 016 6v3H4v-3a6 6 0 016-6zm0 2h-4a4 4 0 00-3.995 3.8L6 18v1h12v-1a4 4 0 00-3.8-3.995zM12 3a4 4 0 110 8 4 4 0 010-8zm0 2a2 2 0 100 4 2 2 0 000-4z",
    fill: "currentColor"
  }));
}
SvgUser24.propTypes = {
  color: PropTypes.string,
  dataTest: PropTypes.string
};
function SvgWarningFilled24(_ref) {
  let {
    color,
    dataTest
  } = _ref;
  return /* @__PURE__ */ reactExports.createElement("svg", {
    height: 24,
    viewBox: "0 0 24 24",
    width: 24,
    xmlns: "http://www.w3.org/2000/svg",
    color,
    "data-test": dataTest
  }, /* @__PURE__ */ reactExports.createElement("path", {
    d: "M12.847 2.794l.056.102 8.416 17.674a1 1 0 01-.786 1.423l-.117.007H3.584a1 1 0 01-.947-1.322l.044-.108 8.416-17.674a1 1 0 011.75-.102zM12 18a1 1 0 100 2 1 1 0 000-2zm1-9h-2v7h2z",
    fill: "currentColor"
  }));
}
SvgWarningFilled24.propTypes = {
  color: PropTypes.string,
  dataTest: PropTypes.string
};
var style$1 = {};
var stylesheetRegistry = {};
function hash$2(str) {
  var hash2 = 5381, i = str.length;
  while (i) {
    hash2 = hash2 * 33 ^ str.charCodeAt(--i);
  }
  return hash2 >>> 0;
}
var stringHash = hash$2;
var stylesheet = {};
(function(exports) {
  var define_process_env_default = {};
  exports.__esModule = true;
  exports["default"] = void 0;
  function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor)
        descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }
  function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps)
      _defineProperties(Constructor.prototype, protoProps);
    if (staticProps)
      _defineProperties(Constructor, staticProps);
    return Constructor;
  }
  var isProd = typeof process !== "undefined" && define_process_env_default && true;
  var isString = function isString2(o) {
    return Object.prototype.toString.call(o) === "[object String]";
  };
  var StyleSheet = /* @__PURE__ */ function() {
    function StyleSheet2(_temp) {
      var _ref = _temp === void 0 ? {} : _temp, _ref$name = _ref.name, name = _ref$name === void 0 ? "stylesheet" : _ref$name, _ref$optimizeForSpeed = _ref.optimizeForSpeed, optimizeForSpeed = _ref$optimizeForSpeed === void 0 ? isProd : _ref$optimizeForSpeed, _ref$isBrowser = _ref.isBrowser, isBrowser2 = _ref$isBrowser === void 0 ? typeof window !== "undefined" : _ref$isBrowser;
      invariant(isString(name), "`name` must be a string");
      this._name = name;
      this._deletedRulePlaceholder = "#" + name + "-deleted-rule____{}";
      invariant(typeof optimizeForSpeed === "boolean", "`optimizeForSpeed` must be a boolean");
      this._optimizeForSpeed = optimizeForSpeed;
      this._isBrowser = isBrowser2;
      this._serverSheet = void 0;
      this._tags = [];
      this._injected = false;
      this._rulesCount = 0;
      var node = this._isBrowser && document.querySelector('meta[property="csp-nonce"]');
      this._nonce = node ? node.getAttribute("content") : null;
    }
    var _proto = StyleSheet2.prototype;
    _proto.setOptimizeForSpeed = function setOptimizeForSpeed(bool) {
      invariant(typeof bool === "boolean", "`setOptimizeForSpeed` accepts a boolean");
      invariant(this._rulesCount === 0, "optimizeForSpeed cannot be when rules have already been inserted");
      this.flush();
      this._optimizeForSpeed = bool;
      this.inject();
    };
    _proto.isOptimizeForSpeed = function isOptimizeForSpeed() {
      return this._optimizeForSpeed;
    };
    _proto.inject = function inject() {
      var _this = this;
      invariant(!this._injected, "sheet already injected");
      this._injected = true;
      if (this._isBrowser && this._optimizeForSpeed) {
        this._tags[0] = this.makeStyleTag(this._name);
        this._optimizeForSpeed = "insertRule" in this.getSheet();
        if (!this._optimizeForSpeed) {
          if (!isProd) {
            console.warn("StyleSheet: optimizeForSpeed mode not supported falling back to standard mode.");
          }
          this.flush();
          this._injected = true;
        }
        return;
      }
      this._serverSheet = {
        cssRules: [],
        insertRule: function insertRule(rule, index2) {
          if (typeof index2 === "number") {
            _this._serverSheet.cssRules[index2] = {
              cssText: rule
            };
          } else {
            _this._serverSheet.cssRules.push({
              cssText: rule
            });
          }
          return index2;
        },
        deleteRule: function deleteRule(index2) {
          _this._serverSheet.cssRules[index2] = null;
        }
      };
    };
    _proto.getSheetForTag = function getSheetForTag(tag) {
      if (tag.sheet) {
        return tag.sheet;
      }
      for (var i = 0; i < document.styleSheets.length; i++) {
        if (document.styleSheets[i].ownerNode === tag) {
          return document.styleSheets[i];
        }
      }
    };
    _proto.getSheet = function getSheet() {
      return this.getSheetForTag(this._tags[this._tags.length - 1]);
    };
    _proto.insertRule = function insertRule(rule, index2) {
      invariant(isString(rule), "`insertRule` accepts only strings");
      if (!this._isBrowser) {
        if (typeof index2 !== "number") {
          index2 = this._serverSheet.cssRules.length;
        }
        this._serverSheet.insertRule(rule, index2);
        return this._rulesCount++;
      }
      if (this._optimizeForSpeed) {
        var sheet = this.getSheet();
        if (typeof index2 !== "number") {
          index2 = sheet.cssRules.length;
        }
        try {
          sheet.insertRule(rule, index2);
        } catch (error2) {
          if (!isProd) {
            console.warn("StyleSheet: illegal rule: \n\n" + rule + "\n\nSee https://stackoverflow.com/q/20007992 for more info");
          }
          return -1;
        }
      } else {
        var insertionPoint = this._tags[index2];
        this._tags.push(this.makeStyleTag(this._name, rule, insertionPoint));
      }
      return this._rulesCount++;
    };
    _proto.replaceRule = function replaceRule(index2, rule) {
      if (this._optimizeForSpeed || !this._isBrowser) {
        var sheet = this._isBrowser ? this.getSheet() : this._serverSheet;
        if (!rule.trim()) {
          rule = this._deletedRulePlaceholder;
        }
        if (!sheet.cssRules[index2]) {
          return index2;
        }
        sheet.deleteRule(index2);
        try {
          sheet.insertRule(rule, index2);
        } catch (error2) {
          if (!isProd) {
            console.warn("StyleSheet: illegal rule: \n\n" + rule + "\n\nSee https://stackoverflow.com/q/20007992 for more info");
          }
          sheet.insertRule(this._deletedRulePlaceholder, index2);
        }
      } else {
        var tag = this._tags[index2];
        invariant(tag, "old rule at index `" + index2 + "` not found");
        tag.textContent = rule;
      }
      return index2;
    };
    _proto.deleteRule = function deleteRule(index2) {
      if (!this._isBrowser) {
        this._serverSheet.deleteRule(index2);
        return;
      }
      if (this._optimizeForSpeed) {
        this.replaceRule(index2, "");
      } else {
        var tag = this._tags[index2];
        invariant(tag, "rule at index `" + index2 + "` not found");
        tag.parentNode.removeChild(tag);
        this._tags[index2] = null;
      }
    };
    _proto.flush = function flush() {
      this._injected = false;
      this._rulesCount = 0;
      if (this._isBrowser) {
        this._tags.forEach(function(tag) {
          return tag && tag.parentNode.removeChild(tag);
        });
        this._tags = [];
      } else {
        this._serverSheet.cssRules = [];
      }
    };
    _proto.cssRules = function cssRules() {
      var _this2 = this;
      if (!this._isBrowser) {
        return this._serverSheet.cssRules;
      }
      return this._tags.reduce(function(rules, tag) {
        if (tag) {
          rules = rules.concat(Array.prototype.map.call(_this2.getSheetForTag(tag).cssRules, function(rule) {
            return rule.cssText === _this2._deletedRulePlaceholder ? null : rule;
          }));
        } else {
          rules.push(null);
        }
        return rules;
      }, []);
    };
    _proto.makeStyleTag = function makeStyleTag(name, cssString, relativeToTag) {
      if (cssString) {
        invariant(isString(cssString), "makeStyleTag acceps only strings as second parameter");
      }
      var tag = document.createElement("style");
      if (this._nonce)
        tag.setAttribute("nonce", this._nonce);
      tag.type = "text/css";
      tag.setAttribute("data-" + name, "");
      if (cssString) {
        tag.appendChild(document.createTextNode(cssString));
      }
      var head = document.head || document.getElementsByTagName("head")[0];
      if (relativeToTag) {
        head.insertBefore(tag, relativeToTag);
      } else {
        head.appendChild(tag);
      }
      return tag;
    };
    _createClass(StyleSheet2, [{
      key: "length",
      get: function get2() {
        return this._rulesCount;
      }
    }]);
    return StyleSheet2;
  }();
  exports["default"] = StyleSheet;
  function invariant(condition, message) {
    if (!condition) {
      throw new Error("StyleSheet: " + message + ".");
    }
  }
})(stylesheet);
(function(exports) {
  exports.__esModule = true;
  exports["default"] = void 0;
  var _stringHash = _interopRequireDefault(stringHash);
  var _stylesheet = _interopRequireDefault(stylesheet);
  function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : { "default": obj };
  }
  var sanitize = function sanitize2(rule) {
    return rule.replace(/\/style/gi, "\\/style");
  };
  var StyleSheetRegistry = /* @__PURE__ */ function() {
    function StyleSheetRegistry2(_temp) {
      var _ref = _temp === void 0 ? {} : _temp, _ref$styleSheet = _ref.styleSheet, styleSheet = _ref$styleSheet === void 0 ? null : _ref$styleSheet, _ref$optimizeForSpeed = _ref.optimizeForSpeed, optimizeForSpeed = _ref$optimizeForSpeed === void 0 ? false : _ref$optimizeForSpeed, _ref$isBrowser = _ref.isBrowser, isBrowser2 = _ref$isBrowser === void 0 ? typeof window !== "undefined" : _ref$isBrowser;
      this._sheet = styleSheet || new _stylesheet["default"]({
        name: "styled-jsx",
        optimizeForSpeed
      });
      this._sheet.inject();
      if (styleSheet && typeof optimizeForSpeed === "boolean") {
        this._sheet.setOptimizeForSpeed(optimizeForSpeed);
        this._optimizeForSpeed = this._sheet.isOptimizeForSpeed();
      }
      this._isBrowser = isBrowser2;
      this._fromServer = void 0;
      this._indices = {};
      this._instancesCounts = {};
      this.computeId = this.createComputeId();
      this.computeSelector = this.createComputeSelector();
    }
    var _proto = StyleSheetRegistry2.prototype;
    _proto.add = function add(props) {
      var _this = this;
      if (void 0 === this._optimizeForSpeed) {
        this._optimizeForSpeed = Array.isArray(props.children);
        this._sheet.setOptimizeForSpeed(this._optimizeForSpeed);
        this._optimizeForSpeed = this._sheet.isOptimizeForSpeed();
      }
      if (this._isBrowser && !this._fromServer) {
        this._fromServer = this.selectFromServer();
        this._instancesCounts = Object.keys(this._fromServer).reduce(function(acc, tagName) {
          acc[tagName] = 0;
          return acc;
        }, {});
      }
      var _this$getIdAndRules = this.getIdAndRules(props), styleId = _this$getIdAndRules.styleId, rules = _this$getIdAndRules.rules;
      if (styleId in this._instancesCounts) {
        this._instancesCounts[styleId] += 1;
        return;
      }
      var indices = rules.map(function(rule) {
        return _this._sheet.insertRule(rule);
      }).filter(function(index2) {
        return index2 !== -1;
      });
      this._indices[styleId] = indices;
      this._instancesCounts[styleId] = 1;
    };
    _proto.remove = function remove2(props) {
      var _this2 = this;
      var _this$getIdAndRules2 = this.getIdAndRules(props), styleId = _this$getIdAndRules2.styleId;
      invariant(styleId in this._instancesCounts, "styleId: `" + styleId + "` not found");
      this._instancesCounts[styleId] -= 1;
      if (this._instancesCounts[styleId] < 1) {
        var tagFromServer = this._fromServer && this._fromServer[styleId];
        if (tagFromServer) {
          tagFromServer.parentNode.removeChild(tagFromServer);
          delete this._fromServer[styleId];
        } else {
          this._indices[styleId].forEach(function(index2) {
            return _this2._sheet.deleteRule(index2);
          });
          delete this._indices[styleId];
        }
        delete this._instancesCounts[styleId];
      }
    };
    _proto.update = function update(props, nextProps) {
      this.add(nextProps);
      this.remove(props);
    };
    _proto.flush = function flush() {
      this._sheet.flush();
      this._sheet.inject();
      this._fromServer = void 0;
      this._indices = {};
      this._instancesCounts = {};
      this.computeId = this.createComputeId();
      this.computeSelector = this.createComputeSelector();
    };
    _proto.cssRules = function cssRules() {
      var _this3 = this;
      var fromServer = this._fromServer ? Object.keys(this._fromServer).map(function(styleId) {
        return [styleId, _this3._fromServer[styleId]];
      }) : [];
      var cssRules2 = this._sheet.cssRules();
      return fromServer.concat(Object.keys(this._indices).map(function(styleId) {
        return [styleId, _this3._indices[styleId].map(function(index2) {
          return cssRules2[index2].cssText;
        }).join(_this3._optimizeForSpeed ? "" : "\n")];
      }).filter(function(rule) {
        return Boolean(rule[1]);
      }));
    };
    _proto.createComputeId = function createComputeId() {
      var cache = {};
      return function(baseId, props) {
        if (!props) {
          return "jsx-" + baseId;
        }
        var propsToString = String(props);
        var key = baseId + propsToString;
        if (!cache[key]) {
          cache[key] = "jsx-" + (0, _stringHash["default"])(baseId + "-" + propsToString);
        }
        return cache[key];
      };
    };
    _proto.createComputeSelector = function createComputeSelector(selectoPlaceholderRegexp) {
      if (selectoPlaceholderRegexp === void 0) {
        selectoPlaceholderRegexp = /__jsx-style-dynamic-selector/g;
      }
      var cache = {};
      return function(id, css) {
        if (!this._isBrowser) {
          css = sanitize(css);
        }
        var idcss = id + css;
        if (!cache[idcss]) {
          cache[idcss] = css.replace(selectoPlaceholderRegexp, id);
        }
        return cache[idcss];
      };
    };
    _proto.getIdAndRules = function getIdAndRules(props) {
      var _this4 = this;
      var css = props.children, dynamic = props.dynamic, id = props.id;
      if (dynamic) {
        var styleId = this.computeId(id, dynamic);
        return {
          styleId,
          rules: Array.isArray(css) ? css.map(function(rule) {
            return _this4.computeSelector(styleId, rule);
          }) : [this.computeSelector(styleId, css)]
        };
      }
      return {
        styleId: this.computeId(id),
        rules: Array.isArray(css) ? css : [css]
      };
    };
    _proto.selectFromServer = function selectFromServer() {
      var elements = Array.prototype.slice.call(document.querySelectorAll('[id^="__jsx-"]'));
      return elements.reduce(function(acc, element) {
        var id = element.id.slice(2);
        acc[id] = element;
        return acc;
      }, {});
    };
    return StyleSheetRegistry2;
  }();
  exports["default"] = StyleSheetRegistry;
  function invariant(condition, message) {
    if (!condition) {
      throw new Error("StyleSheetRegistry: " + message + ".");
    }
  }
})(stylesheetRegistry);
(function(exports) {
  exports.__esModule = true;
  exports["default"] = JSXStyle;
  exports.flush = flush;
  var _react = reactExports;
  var _stylesheetRegistry = _interopRequireDefault(stylesheetRegistry);
  function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : { "default": obj };
  }
  var styleSheetRegistry = new _stylesheetRegistry["default"]();
  function JSXStyle(props) {
    if (typeof window === "undefined") {
      styleSheetRegistry.add(props);
      return null;
    }
    (0, _react.useLayoutEffect)(function() {
      styleSheetRegistry.add(props);
      return function() {
        styleSheetRegistry.remove(props);
      };
    }, [props.id, String(props.dynamic)]);
    return null;
  }
  JSXStyle.dynamic = function(info) {
    return info.map(function(tagInfo) {
      var baseId = tagInfo[0];
      var props = tagInfo[1];
      return styleSheetRegistry.computeId(baseId, props);
    }).join(" ");
  };
  function flush() {
    var cssRules = styleSheetRegistry.cssRules();
    styleSheetRegistry.flush();
    return cssRules;
  }
})(style$1);
var style = style$1;
const _JSXStyle = /* @__PURE__ */ getDefaultExportFromCjs(style);
var classnames = { exports: {} };
/*!
	Copyright (c) 2018 Jed Watson.
	Licensed under the MIT License (MIT), see
	http://jedwatson.github.io/classnames
*/
(function(module) {
  (function() {
    var hasOwn = {}.hasOwnProperty;
    function classNames() {
      var classes = "";
      for (var i = 0; i < arguments.length; i++) {
        var arg = arguments[i];
        if (arg) {
          classes = appendClass(classes, parseValue(arg));
        }
      }
      return classes;
    }
    function parseValue(arg) {
      if (typeof arg === "string" || typeof arg === "number") {
        return arg;
      }
      if (typeof arg !== "object") {
        return "";
      }
      if (Array.isArray(arg)) {
        return classNames.apply(null, arg);
      }
      if (arg.toString !== Object.prototype.toString && !arg.toString.toString().includes("[native code]")) {
        return arg.toString();
      }
      var classes = "";
      for (var key in arg) {
        if (hasOwn.call(arg, key) && arg[key]) {
          classes = appendClass(classes, key);
        }
      }
      return classes;
    }
    function appendClass(value, newClass) {
      if (!newClass) {
        return value;
      }
      if (value) {
        return value + " " + newClass;
      }
      return value + newClass;
    }
    if (module.exports) {
      classNames.default = classNames;
      module.exports = classNames;
    } else {
      window.classNames = classNames;
    }
  })();
})(classnames);
var classnamesExports = classnames.exports;
const cx = /* @__PURE__ */ getDefaultExportFromCjs(classnamesExports);
const Box = (_ref) => {
  let {
    overflow,
    height,
    minHeight,
    maxHeight,
    width,
    minWidth,
    maxWidth,
    marginTop,
    children,
    dataTest,
    className
  } = _ref;
  return /* @__PURE__ */ React.createElement("div", {
    "data-test": dataTest,
    className: _JSXStyle.dynamic([["3369228338", [marginTop ? "margin-top: ".concat(marginTop, ";") : "", height ? "height: ".concat(height, ";") : "", minHeight ? "min-height: ".concat(minHeight, ";") : "", maxHeight ? "max-height: ".concat(maxHeight, ";") : "", width ? "width: ".concat(width, ";") : "", minWidth ? "min-width: ".concat(minWidth, ";") : "", maxWidth ? "max-width: ".concat(maxWidth, ";") : "", overflow ? "overflow: ".concat(overflow, ";") : ""]]]) + " " + (className || "")
  }, children, /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "3369228338",
    dynamic: [marginTop ? "margin-top: ".concat(marginTop, ";") : "", height ? "height: ".concat(height, ";") : "", minHeight ? "min-height: ".concat(minHeight, ";") : "", maxHeight ? "max-height: ".concat(maxHeight, ";") : "", width ? "width: ".concat(width, ";") : "", minWidth ? "min-width: ".concat(minWidth, ";") : "", maxWidth ? "max-width: ".concat(maxWidth, ";") : "", overflow ? "overflow: ".concat(overflow, ";") : ""]
  }, ["div.__jsx-style-dynamic-selector{".concat(marginTop ? "margin-top: ".concat(marginTop, ";") : "", " ").concat(height ? "height: ".concat(height, ";") : "", " ").concat(minHeight ? "min-height: ".concat(minHeight, ";") : "", " ").concat(maxHeight ? "max-height: ".concat(maxHeight, ";") : "", " ").concat(width ? "width: ".concat(width, ";") : "", " ").concat(minWidth ? "min-width: ".concat(minWidth, ";") : "", " ").concat(maxWidth ? "max-width: ".concat(maxWidth, ";") : "", " ").concat(overflow ? "overflow: ".concat(overflow, ";") : "", ";}")]));
};
Box.defaultProps = {
  dataTest: "dhis2-uicore-box"
};
Box.propTypes = {
  children: PropTypes.node,
  className: PropTypes.string,
  dataTest: PropTypes.string,
  height: PropTypes.string,
  marginTop: PropTypes.string,
  maxHeight: PropTypes.string,
  maxWidth: PropTypes.string,
  minHeight: PropTypes.string,
  minWidth: PropTypes.string,
  overflow: PropTypes.string,
  width: PropTypes.string
};
const Help$z = (_ref) => {
  let {
    children,
    valid,
    error: error2,
    warning,
    className,
    dataTest
  } = _ref;
  return /* @__PURE__ */ React.createElement("p", {
    "data-test": dataTest,
    className: _JSXStyle.dynamic([["1832050605", [spacers.dp4, theme.default, colors.blue700, theme.error, colors.yellow800]]]) + " " + (cx(className, {
      valid,
      error: error2,
      warning
    }) || "")
  }, children, /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "1832050605",
    dynamic: [spacers.dp4, theme.default, colors.blue700, theme.error, colors.yellow800]
  }, ["p.__jsx-style-dynamic-selector{margin-top:".concat(spacers.dp4, ";margin-right:0;margin-bottom:0;margin-left:0;font-size:12px;line-height:14px;color:").concat(theme.default, ";}"), ".valid.__jsx-style-dynamic-selector{color:".concat(colors.blue700, ";}"), ".error.__jsx-style-dynamic-selector{color:".concat(theme.error, ";}"), ".warning.__jsx-style-dynamic-selector{color:".concat(colors.yellow800, ";}")]));
};
Help$z.defaultProps = {
  dataTest: "dhis2-uicore-help"
};
Help$z.propTypes = {
  children: PropTypes.string,
  className: PropTypes.string,
  dataTest: PropTypes.string,
  error: statusPropType,
  valid: statusPropType,
  warning: statusPropType
};
const Required = (_ref) => {
  let {
    dataTest
  } = _ref;
  return /* @__PURE__ */ React.createElement("span", {
    "data-test": dataTest,
    className: _JSXStyle.dynamic([["149033372", [spacers.dp4]]])
  }, "*", /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "149033372",
    dynamic: [spacers.dp4]
  }, ["span.__jsx-style-dynamic-selector{padding-left:".concat(spacers.dp4, ";}")]));
};
Required.propTypes = {
  dataTest: PropTypes.string.isRequired
};
const styles$4 = ["label.jsx-2904627559{display:block;box-sizing:border-box;font-size:14px;line-height:19px;color:".concat(colors.grey900, ";padding:0;}"), ".disabled.jsx-2904627559{cursor:not-allowed;}"];
styles$4.__hash = "2904627559";
const constructClassName = (_ref) => {
  let {
    disabled,
    className
  } = _ref;
  return cx(className, {
    disabled
  });
};
const Label = (_ref2) => {
  let {
    htmlFor,
    children,
    required,
    disabled,
    className,
    dataTest
  } = _ref2;
  return /* @__PURE__ */ React.createElement("label", {
    htmlFor,
    "data-test": dataTest,
    className: "jsx-".concat(styles$4.__hash) + " " + (constructClassName({
      className,
      disabled
    }) || "")
  }, /* @__PURE__ */ React.createElement("span", {
    className: "jsx-".concat(styles$4.__hash)
  }, children), required && /* @__PURE__ */ React.createElement(Required, {
    dataTest: "".concat(dataTest, "-required")
  }), /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: styles$4.__hash
  }, styles$4));
};
Label.defaultProps = {
  dataTest: "dhis2-uicore-label"
};
Label.propTypes = {
  children: PropTypes.string,
  className: PropTypes.string,
  dataTest: PropTypes.string,
  disabled: PropTypes.bool,
  htmlFor: PropTypes.string,
  required: PropTypes.bool
};
const Field = (_ref) => {
  let {
    children,
    disabled,
    className,
    helpText,
    label,
    name,
    validationText,
    required,
    dataTest,
    valid,
    error: error2,
    warning
  } = _ref;
  return /* @__PURE__ */ React.createElement(Box, {
    className,
    dataTest
  }, label && /* @__PURE__ */ React.createElement(Label, {
    dataTest: "".concat(dataTest, "-label"),
    required,
    disabled,
    htmlFor: name
  }, label), /* @__PURE__ */ React.createElement(Box, {
    dataTest: "".concat(dataTest, "-content"),
    marginTop: label ? "2px" : "0"
  }, children), helpText && /* @__PURE__ */ React.createElement(Help$z, {
    dataTest: "".concat(dataTest, "-help")
  }, helpText), validationText && /* @__PURE__ */ React.createElement(Help$z, {
    error: error2,
    warning,
    valid,
    dataTest: "".concat(dataTest, "-validation")
  }, validationText));
};
Field.defaultProps = {
  dataTest: "dhis2-uicore-field"
};
Field.propTypes = {
  children: PropTypes.node,
  className: PropTypes.string,
  dataTest: PropTypes.string,
  /** Disabled status, shown when mouse is over label */
  disabled: PropTypes.bool,
  /** Field status. Mutually exclusive with `valid` and `warning` props */
  error: statusPropType,
  /** Useful text within the field */
  helpText: PropTypes.string,
  /** Label at the top of the field */
  label: PropTypes.string,
  /** `name` will become the target of the `for`/`htmlFor` attribute on the `<label>` element */
  name: PropTypes.string,
  /** Inidcates this field is required */
  required: PropTypes.bool,
  /** Field status. Mutually exclusive with `error` and `warning` props */
  valid: statusPropType,
  /** Feedback given related to validation status of field */
  validationText: PropTypes.string,
  /** Field status. Mutually exclusive with `valid` and `error` props */
  warning: statusPropType
};
const CircularLoader = (_ref) => {
  let {
    small,
    large,
    extrasmall,
    invert,
    className,
    dataTest
  } = _ref;
  return /* @__PURE__ */ React.createElement("div", {
    role: "progressbar",
    "data-test": dataTest,
    className: _JSXStyle.dynamic([["3803726117", [colors.blue600, colors.white]]]) + " " + (cx(className, {
      small,
      large,
      extrasmall,
      invert
    }) || "")
  }, /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "3803726117",
    dynamic: [colors.blue600, colors.white]
  }, ["div.__jsx-style-dynamic-selector{width:48px;height:48px;border:6px solid rgba(110,122,138,0.15);border-bottom-color:".concat(colors.blue600, ";border-radius:50%;-webkit-animation:rotation-__jsx-style-dynamic-selector 1s linear infinite;animation:rotation-__jsx-style-dynamic-selector 1s linear infinite;}"), "@-webkit-keyframes rotation-__jsx-style-dynamic-selector{0%{-webkit-transform:rotate(0);-ms-transform:rotate(0);transform:rotate(0);}100%{-webkit-transform:rotate(360deg);-ms-transform:rotate(360deg);transform:rotate(360deg);}}", "@keyframes rotation-__jsx-style-dynamic-selector{0%{-webkit-transform:rotate(0);-ms-transform:rotate(0);transform:rotate(0);}100%{-webkit-transform:rotate(360deg);-ms-transform:rotate(360deg);transform:rotate(360deg);}}", ".small.__jsx-style-dynamic-selector{width:24px;height:24px;border-width:4px;}", ".large.__jsx-style-dynamic-selector{width:72px;height:72px;border-width:8px;}", ".extrasmall.__jsx-style-dynamic-selector{width:16px;height:16px;border-width:2px;}", ".invert.__jsx-style-dynamic-selector{border-color:rgba(33,41,52,0.5);border-bottom-color:".concat(colors.white, ";}")]));
};
CircularLoader.defaultProps = {
  dataTest: "dhis2-uicore-circularloader"
};
CircularLoader.propTypes = {
  className: PropTypes.string,
  dataTest: PropTypes.string,
  extrasmall: sizePropType,
  invert: PropTypes.bool,
  large: sizePropType,
  small: sizePropType
};
const _defaultExport$2 = ["button.jsx-2860941869{display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;position:relative;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;border-radius:4px;font-weight:400;-webkit-letter-spacing:0.5px;-moz-letter-spacing:0.5px;-ms-letter-spacing:0.5px;letter-spacing:0.5px;-webkit-text-decoration:none;text-decoration:none;cursor:pointer;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;color:".concat(colors.grey900, ";height:36px;padding:0 ").concat(spacers.dp12, ";font-size:14px;line-height:16px;border:1px solid ").concat(colors.grey500, ";background-color:#f9fafb;}"), "button.jsx-2860941869:disabled{cursor:not-allowed;}", "button.jsx-2860941869:focus{outline:3px solid ".concat(theme.focus, ";outline-offset:-3px;-webkit-text-decoration:underline;text-decoration:underline;}"), "button.jsx-2860941869:focus.jsx-2860941869:not(:focus-visible){outline:none;-webkit-text-decoration:none;text-decoration:none;}", "button.jsx-2860941869:active.jsx-2860941869:focus,button.jsx-2860941869:disabled.jsx-2860941869:focus{outline:none;-webkit-text-decoration:none;text-decoration:none;}", "button.jsx-2860941869:hover{border-color:".concat(colors.grey500, ";background-color:").concat(colors.grey200, ";}"), "button.jsx-2860941869:active,button.jsx-2860941869:active.jsx-2860941869:focus{border-color:".concat(colors.grey500, ";background-color:").concat(colors.grey200, ";box-shadow:0 0 0 1px rgb(0,0,0,0.1) inset;}"), "button.jsx-2860941869:focus{background-color:#f9fafb;}", "button.jsx-2860941869:disabled{border-color:".concat(colors.grey400, ";background-color:#f9fafb;box-shadow:none;color:").concat(theme.disabled, ";fill:").concat(theme.disabled, ";}"), ".small.jsx-2860941869{height:28px;padding:0 6px;font-size:14px;line-height:16px;}", ".large.jsx-2860941869{height:43px;padding:0 ".concat(spacers.dp24, ";font-size:16px;-webkit-letter-spacing:0.57px;-moz-letter-spacing:0.57px;-ms-letter-spacing:0.57px;letter-spacing:0.57px;line-height:19px;}"), ".primary.jsx-2860941869{border-color:".concat(theme.primary800, ";background:linear-gradient(180deg,#1565c0 0%,#0650a3 100%);background-color:#2b61b3;color:").concat(colors.white, ";fill:").concat(colors.white, ";font-weight:500;}"), ".primary.jsx-2860941869:hover{border-color:".concat(theme.primary800, ";background:linear-gradient(180deg,#054fa3 0%,#034793 100%);background-color:#21539f;}"), ".primary.jsx-2860941869:active,.primary.jsx-2860941869:active.jsx-2860941869:focus{background:linear-gradient(180deg,#054fa3 0%,#034793 100%);background-color:#1c4a90;box-shadow:0 0 0 1px rgba(0,0,0,0.18) inset;}", ".primary.jsx-2860941869:focus{background:".concat(colors.blue800, ";border-color:").concat(colors.blue900, ";outline-offset:-5px;}"), ".primary.jsx-2860941869:disabled{border-color:#93a6bd;background:#b3c6de;box-shadow:none;color:".concat(colors.white, ";fill:").concat(colors.white, ";}"), ".secondary.jsx-2860941869{border-color:rgba(74,87,104,0.25);background-color:transparent;}", ".secondary.jsx-2860941869:hover{border-color:rgba(74,87,104,0.5);background-color:rgba(160,173,186,0.05);}", ".secondary.jsx-2860941869:active,.secondary.jsx-2860941869:active.jsx-2860941869:focus{background-color:rgba(160,173,186,0.2);box-shadow:none;}", ".secondary.jsx-2860941869:focus{background-color:transparent;}", ".secondary.jsx-2860941869:disabled{border-color:rgba(74,87,104,0.25);background-color:transparent;box-shadow:none;color:".concat(theme.disabled, ";fill:").concat(theme.disabled, ";}"), ".destructive.jsx-2860941869{border-color:#a10b0b;background:linear-gradient(180deg,#d32f2f 0%,#b71c1c 100%);background-color:#b9242b;color:".concat(colors.white, ";fill:").concat(colors.white, ";font-weight:500;}"), ".destructive.jsx-2860941869:hover{border-color:#a10b0b;background:linear-gradient(180deg,#b81c1c 0%,#b80c0b 100%);background-color:#ac0f1a;}", ".destructive.jsx-2860941869:active,.destructive.jsx-2860941869:active.jsx-2860941869:focus{background:linear-gradient(180deg,#b81c1c 0%,#b80c0b 100%);background-color:#ac101b;box-shadow:0 0 0 1px rgba(0,0,0,0.18) inset;}", ".destructive.jsx-2860941869:focus{background:linear-gradient(180deg,#d32f2f 0%,#b71c1c 100%);background-color:#b72229;}", ".destructive.jsx-2860941869:disabled{border-color:#c59898;background:#d6a8a8;box-shadow:none;color:".concat(colors.white, ";fill:").concat(colors.white, ";}"), ".destructive.secondary.jsx-2860941869{border-color:rgba(74,87,104,0.25);background:transparent;color:".concat(colors.red700, ";fill:").concat(colors.red700, ";font-weight:400;}"), ".destructive.secondary.jsx-2860941869:hover{border-color:".concat(colors.red600, ";background:").concat(colors.red050, ";color:").concat(colors.red800, ";fill:").concat(colors.red800, ";}"), ".destructive.secondary.jsx-2860941869:active,.destructive.secondary.jsx-2860941869:active.jsx-2860941869:focus{background:".concat(colors.red100, ";border-color:").concat(colors.red700, ";box-shadow:none;}"), ".destructive.secondary.jsx-2860941869:disabled{background:transparent;border-color:rgba(74,87,104,0.25);color:rgba(183,28,28,0.6);fill:rgba(183,28,28,0.6);}", ".icon-only.jsx-2860941869{padding:0 0 0 5px;}", ".button-icon.jsx-2860941869{margin-right:6px;color:inherit;fill:inherit;font-size:26px;vertical-align:middle;pointer-events:none;}", ".icon-only.jsx-2860941869 .button-icon.jsx-2860941869{margin-right:5px;}", ".small.icon-only.jsx-2860941869{padding:0 4px 0 5px;}", ".small.jsx-2860941869 .button-icon.jsx-2860941869{margin-right:2px;}", ".small.icon-only.jsx-2860941869 .button-icon.jsx-2860941869{margin-right:1px;}", ".toggled.jsx-2860941869{background:".concat(colors.grey700, ";border:1px solid ").concat(colors.grey900, ";color:").concat(colors.grey050, ";fill:").concat(colors.grey050, ";}"), ".toggled.jsx-2860941869:focus{background:".concat(colors.grey800, ";}"), ".toggled.jsx-2860941869:hover{background:".concat(colors.grey800, ";border-color:").concat(colors.grey900, ";}"), ".toggled.jsx-2860941869:active,.toggled.jsx-2860941869:active.jsx-2860941869:focus{background:".concat(colors.grey900, ";border-color:").concat(colors.grey900, ";}"), ".toggled.jsx-2860941869:disabled{background:".concat(colors.grey500, ";border-color:").concat(colors.grey600, ";color:").concat(colors.grey050, ";fill:").concat(colors.grey050, ";}"), ".loader.jsx-2860941869{width:16px;height:16px;margin-right:8px;}", ".loader.jsx-2860941869+.button-icon.jsx-2860941869{display:none;}", ".icon-only.jsx-2860941869 .loader.jsx-2860941869{margin:0 8px 0 4px;}", ".small.icon-only.jsx-2860941869 .loader.jsx-2860941869{margin:0 4px;}"];
_defaultExport$2.__hash = "2860941869";
const styles$3 = _defaultExport$2;
const Button = (_ref) => {
  let {
    children,
    className,
    dataTest,
    destructive,
    disabled,
    icon: icon2,
    initialFocus,
    large,
    name,
    primary,
    secondary,
    small,
    tabIndex,
    toggled,
    type,
    value,
    onBlur,
    onClick,
    onFocus,
    onKeyDown,
    loading
  } = _ref;
  const ref = reactExports.useRef();
  reactExports.useEffect(() => {
    if (initialFocus && ref.current) {
      ref.current.focus();
    }
  }, [initialFocus, ref.current]);
  const handleClick = (event) => onClick && onClick({
    value,
    name
  }, event);
  const handleBlur = (event) => onBlur && onBlur({
    value,
    name
  }, event);
  const handleFocus = (event) => onFocus && onFocus({
    value,
    name
  }, event);
  const handleKeyDown = (event) => onKeyDown && onKeyDown({
    value,
    name
  }, event);
  const iconOnly = icon2 && !children;
  const buttonClassName = cx(className, {
    primary,
    secondary,
    destructive,
    small,
    large,
    "icon-only": iconOnly,
    toggled,
    loading
  });
  return /* @__PURE__ */ React.createElement("button", {
    ref,
    name,
    "data-test": dataTest,
    disabled: disabled || loading,
    tabIndex,
    type,
    onBlur: handleBlur,
    onClick: handleClick,
    onFocus: handleFocus,
    onKeyDown: handleKeyDown,
    className: "jsx-".concat(styles$3.__hash) + " " + (buttonClassName || "")
  }, loading && /* @__PURE__ */ React.createElement("span", {
    className: "jsx-".concat(styles$3.__hash) + " loader"
  }, destructive || primary ? /* @__PURE__ */ React.createElement(CircularLoader, {
    extrasmall: true,
    invert: true
  }) : /* @__PURE__ */ React.createElement(CircularLoader, {
    extrasmall: true
  })), icon2 && /* @__PURE__ */ React.createElement("span", {
    className: "jsx-".concat(styles$3.__hash) + " button-icon"
  }, icon2), children, /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: styles$3.__hash
  }, styles$3));
};
Button.defaultProps = {
  type: "button",
  dataTest: "dhis2-uicore-button"
};
Button.propTypes = {
  /** Component to render inside the button */
  children: PropTypes.node,
  /** A className that will be passed to the `<button>` element */
  className: PropTypes.string,
  /**
   * A string that will be applied as a `data-test` attribute on the button element
   * for identification during testing
   */
  dataTest: PropTypes.string,
  /**
   * Applies 'destructive' button appearance, implying a dangerous action.
   */
  destructive: PropTypes.bool,
  /** Applies a greyed-out appearance and makes the button non-interactive  */
  disabled: PropTypes.bool,
  /** An icon element to display inside the button */
  icon: PropTypes.element,
  /** Use this variant to capture the initial focus on the page. */
  initialFocus: PropTypes.bool,
  /** Makes the button large. Mutually exclusive with `small` */
  large: sizePropType,
  /** Sets the button into a loading state */
  loading: PropTypes.bool,
  /**
   * Sets `name` attribute on button element.
   * Gets passed as part of the first argument to callbacks (see `onClick`).
   */
  name: PropTypes.string,
  /**
   * Applies 'primary' button appearance, implying the most important action.
   */
  primary: PropTypes.bool,
  /**
   * Applies 'secondary' button appearance.
   */
  secondary: PropTypes.bool,
  /** Makes the button small. Mutually exclusive with `large` prop */
  small: sizePropType,
  /** Tab index for focusing the button with a keyboard */
  tabIndex: PropTypes.string,
  /** Changes appearance of button to an on/off state */
  toggled: PropTypes.bool,
  /** Sets `type` attribute on `<button>` element */
  type: PropTypes.oneOf(["submit", "reset", "button"]),
  /**
   * Value associated with the button.
   * Gets passed as part of the first argument to callbacks (see `onClick`).
   */
  value: PropTypes.string,
  /**
   * Callback to trigger on de-focus (blur).
   * Called with same args as `onClick`
   * */
  onBlur: PropTypes.func,
  /**
   * Callback to trigger on click.
   * Called with args `({ value, name }, event)`
   * */
  onClick: PropTypes.func,
  /** Callback to trigger on focus. Called with same args as `onClick` */
  onFocus: PropTypes.func,
  /** Callback to trigger on key-down. Called with same args as `onClick` */
  onKeyDown: PropTypes.func
};
const ButtonStrip = (_ref) => {
  let {
    className,
    children,
    middle,
    end: end2,
    dataTest
  } = _ref;
  return /* @__PURE__ */ React.createElement("div", {
    "data-test": dataTest,
    className: _JSXStyle.dynamic([["1268901109", [spacers.dp8]]]) + " " + (cx(className, {
      start: !middle && !end2,
      middle,
      end: end2
    }) || "")
  }, reactExports.Children.map(children, (child) => /* @__PURE__ */ React.createElement("div", {
    className: _JSXStyle.dynamic([["1268901109", [spacers.dp8]]]) + " box"
  }, child)), /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "1268901109",
    dynamic: [spacers.dp8]
  }, ["div.__jsx-style-dynamic-selector{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;}", "div.middle.__jsx-style-dynamic-selector{-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;}", "div.end.__jsx-style-dynamic-selector{-webkit-box-pack:end;-webkit-justify-content:flex-end;-ms-flex-pack:end;justify-content:flex-end;}", ".box.__jsx-style-dynamic-selector{margin-left:".concat(spacers.dp8, ";}"), ".box.__jsx-style-dynamic-selector:first-child{margin-left:0;}"]));
};
const alignmentPropType = mutuallyExclusive(["middle", "end"], PropTypes.bool);
ButtonStrip.defaultProps = {
  dataTest: "dhis2-uicore-buttonstrip"
};
ButtonStrip.propTypes = {
  children: PropTypes.node,
  className: PropTypes.string,
  dataTest: PropTypes.string,
  /** Horizontal alignment for buttons. Mutually exclusive with `middle` prop */
  end: alignmentPropType,
  /** Horizontal alignment. Mutually exclusive with `end` prop */
  middle: alignmentPropType
};
const getDefaultNode = () => document.getElementById("dhis2-portal-root") || document.body;
const Portal = (_ref) => {
  let {
    children,
    node,
    disable
  } = _ref;
  const [mountNode, setMountNode] = reactExports.useState(null);
  reactExports.useEffect(() => {
    setMountNode(node || getDefaultNode());
  }, [node]);
  if (disable) {
    return children;
  }
  return mountNode ? /* @__PURE__ */ reactDomExports.createPortal(children, mountNode) : mountNode;
};
Portal.propTypes = {
  children: PropTypes.node,
  disable: PropTypes.bool,
  node: PropTypes.node
};
const Layer = (_ref) => {
  let {
    children,
    className,
    dataTest,
    disablePortal,
    level,
    onBackdropClick,
    onClick,
    position,
    translucent
  } = _ref;
  const resolvedOnClick = onBackdropClick || onClick;
  return /* @__PURE__ */ React.createElement(Portal, {
    disable: disablePortal
  }, /* @__PURE__ */ React.createElement("div", {
    "data-test": dataTest,
    className: "jsx-4284133831 " + _JSXStyle.dynamic([["1893150038", [level]]]) + " " + (cx("layer", className, position, {
      translucent
    }) || "")
  }, resolvedOnClick && /* @__PURE__ */ React.createElement("div", {
    onClick: (event) => resolvedOnClick({}, event),
    className: "jsx-4284133831 " + _JSXStyle.dynamic([["1893150038", [level]]]) + " backdrop"
  }), children, /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "1893150038",
    dynamic: [level]
  }, ["div.__jsx-style-dynamic-selector{z-index:".concat(level, ";}")]), /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "4284133831"
  }, ["div.jsx-4284133831{-webkit-inset-block-start:0;-ms-intb-rlock-start:0;inset-block-start:0;inset-inline-start:0;min-height:100vh;min-width:100vw;}", "div.fixed.jsx-4284133831{position:fixed;height:100vh;width:100vw;}", "div.absolute.jsx-4284133831{position:absolute;height:100%;width:100%;}", "div.translucent.jsx-4284133831{background-color:rgba(33,43,54,0.4);}", "div.backdrop.jsx-4284133831{position:absolute;inset:0;z-index:-1;}"])));
};
Layer.defaultProps = {
  position: "fixed",
  dataTest: "dhis2-uicore-layer",
  level: "auto"
};
Layer.propTypes = {
  children: PropTypes.node,
  className: PropTypes.string,
  dataTest: PropTypes.string,
  /** Disable the Portal, useful for nesting layers */
  disablePortal: PropTypes.bool,
  /** Z-index level */
  level: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  position: PropTypes.oneOf(["absolute", "fixed"]),
  /** Adds a semi-transparent background */
  translucent: PropTypes.bool,
  /** Backdrop click handler */
  onBackdropClick: PropTypes.func,
  /** Click handler - DEPRECATED */
  onClick: deprecated(PropTypes.func, 'Please use "onBackdropClick" instead')
};
var fromEntries = function fromEntries2(entries) {
  return entries.reduce(function(acc, _ref) {
    var key = _ref[0], value = _ref[1];
    acc[key] = value;
    return acc;
  }, {});
};
var useIsomorphicLayoutEffect = typeof window !== "undefined" && window.document && window.document.createElement ? reactExports.useLayoutEffect : reactExports.useEffect;
var top = "top";
var bottom = "bottom";
var right = "right";
var left = "left";
var auto = "auto";
var basePlacements = [top, bottom, right, left];
var start = "start";
var end = "end";
var clippingParents = "clippingParents";
var viewport = "viewport";
var popper = "popper";
var reference = "reference";
var variationPlacements = /* @__PURE__ */ basePlacements.reduce(function(acc, placement) {
  return acc.concat([placement + "-" + start, placement + "-" + end]);
}, []);
var placements = /* @__PURE__ */ [].concat(basePlacements, [auto]).reduce(function(acc, placement) {
  return acc.concat([placement, placement + "-" + start, placement + "-" + end]);
}, []);
var beforeRead = "beforeRead";
var read = "read";
var afterRead = "afterRead";
var beforeMain = "beforeMain";
var main = "main";
var afterMain = "afterMain";
var beforeWrite = "beforeWrite";
var write = "write";
var afterWrite = "afterWrite";
var modifierPhases = [beforeRead, read, afterRead, beforeMain, main, afterMain, beforeWrite, write, afterWrite];
function getNodeName(element) {
  return element ? (element.nodeName || "").toLowerCase() : null;
}
function getWindow(node) {
  if (node == null) {
    return window;
  }
  if (node.toString() !== "[object Window]") {
    var ownerDocument = node.ownerDocument;
    return ownerDocument ? ownerDocument.defaultView || window : window;
  }
  return node;
}
function isElement(node) {
  var OwnElement = getWindow(node).Element;
  return node instanceof OwnElement || node instanceof Element;
}
function isHTMLElement(node) {
  var OwnElement = getWindow(node).HTMLElement;
  return node instanceof OwnElement || node instanceof HTMLElement;
}
function isShadowRoot(node) {
  if (typeof ShadowRoot === "undefined") {
    return false;
  }
  var OwnElement = getWindow(node).ShadowRoot;
  return node instanceof OwnElement || node instanceof ShadowRoot;
}
function applyStyles(_ref) {
  var state = _ref.state;
  Object.keys(state.elements).forEach(function(name) {
    var style2 = state.styles[name] || {};
    var attributes = state.attributes[name] || {};
    var element = state.elements[name];
    if (!isHTMLElement(element) || !getNodeName(element)) {
      return;
    }
    Object.assign(element.style, style2);
    Object.keys(attributes).forEach(function(name2) {
      var value = attributes[name2];
      if (value === false) {
        element.removeAttribute(name2);
      } else {
        element.setAttribute(name2, value === true ? "" : value);
      }
    });
  });
}
function effect$2(_ref2) {
  var state = _ref2.state;
  var initialStyles = {
    popper: {
      position: state.options.strategy,
      left: "0",
      top: "0",
      margin: "0"
    },
    arrow: {
      position: "absolute"
    },
    reference: {}
  };
  Object.assign(state.elements.popper.style, initialStyles.popper);
  state.styles = initialStyles;
  if (state.elements.arrow) {
    Object.assign(state.elements.arrow.style, initialStyles.arrow);
  }
  return function() {
    Object.keys(state.elements).forEach(function(name) {
      var element = state.elements[name];
      var attributes = state.attributes[name] || {};
      var styleProperties = Object.keys(state.styles.hasOwnProperty(name) ? state.styles[name] : initialStyles[name]);
      var style2 = styleProperties.reduce(function(style3, property) {
        style3[property] = "";
        return style3;
      }, {});
      if (!isHTMLElement(element) || !getNodeName(element)) {
        return;
      }
      Object.assign(element.style, style2);
      Object.keys(attributes).forEach(function(attribute) {
        element.removeAttribute(attribute);
      });
    });
  };
}
const applyStyles$1 = {
  name: "applyStyles",
  enabled: true,
  phase: "write",
  fn: applyStyles,
  effect: effect$2,
  requires: ["computeStyles"]
};
function getBasePlacement(placement) {
  return placement.split("-")[0];
}
var max = Math.max;
var min = Math.min;
var round = Math.round;
function getUAString() {
  var uaData = navigator.userAgentData;
  if (uaData != null && uaData.brands && Array.isArray(uaData.brands)) {
    return uaData.brands.map(function(item) {
      return item.brand + "/" + item.version;
    }).join(" ");
  }
  return navigator.userAgent;
}
function isLayoutViewport() {
  return !/^((?!chrome|android).)*safari/i.test(getUAString());
}
function getBoundingClientRect(element, includeScale, isFixedStrategy) {
  if (includeScale === void 0) {
    includeScale = false;
  }
  if (isFixedStrategy === void 0) {
    isFixedStrategy = false;
  }
  var clientRect = element.getBoundingClientRect();
  var scaleX = 1;
  var scaleY = 1;
  if (includeScale && isHTMLElement(element)) {
    scaleX = element.offsetWidth > 0 ? round(clientRect.width) / element.offsetWidth || 1 : 1;
    scaleY = element.offsetHeight > 0 ? round(clientRect.height) / element.offsetHeight || 1 : 1;
  }
  var _ref = isElement(element) ? getWindow(element) : window, visualViewport = _ref.visualViewport;
  var addVisualOffsets = !isLayoutViewport() && isFixedStrategy;
  var x = (clientRect.left + (addVisualOffsets && visualViewport ? visualViewport.offsetLeft : 0)) / scaleX;
  var y = (clientRect.top + (addVisualOffsets && visualViewport ? visualViewport.offsetTop : 0)) / scaleY;
  var width = clientRect.width / scaleX;
  var height = clientRect.height / scaleY;
  return {
    width,
    height,
    top: y,
    right: x + width,
    bottom: y + height,
    left: x,
    x,
    y
  };
}
function getLayoutRect(element) {
  var clientRect = getBoundingClientRect(element);
  var width = element.offsetWidth;
  var height = element.offsetHeight;
  if (Math.abs(clientRect.width - width) <= 1) {
    width = clientRect.width;
  }
  if (Math.abs(clientRect.height - height) <= 1) {
    height = clientRect.height;
  }
  return {
    x: element.offsetLeft,
    y: element.offsetTop,
    width,
    height
  };
}
function contains(parent, child) {
  var rootNode = child.getRootNode && child.getRootNode();
  if (parent.contains(child)) {
    return true;
  } else if (rootNode && isShadowRoot(rootNode)) {
    var next = child;
    do {
      if (next && parent.isSameNode(next)) {
        return true;
      }
      next = next.parentNode || next.host;
    } while (next);
  }
  return false;
}
function getComputedStyle(element) {
  return getWindow(element).getComputedStyle(element);
}
function isTableElement(element) {
  return ["table", "td", "th"].indexOf(getNodeName(element)) >= 0;
}
function getDocumentElement(element) {
  return ((isElement(element) ? element.ownerDocument : (
    // $FlowFixMe[prop-missing]
    element.document
  )) || window.document).documentElement;
}
function getParentNode(element) {
  if (getNodeName(element) === "html") {
    return element;
  }
  return (
    // this is a quicker (but less type safe) way to save quite some bytes from the bundle
    // $FlowFixMe[incompatible-return]
    // $FlowFixMe[prop-missing]
    element.assignedSlot || // step into the shadow DOM of the parent of a slotted node
    element.parentNode || // DOM Element detected
    (isShadowRoot(element) ? element.host : null) || // ShadowRoot detected
    // $FlowFixMe[incompatible-call]: HTMLElement is a Node
    getDocumentElement(element)
  );
}
function getTrueOffsetParent(element) {
  if (!isHTMLElement(element) || // https://github.com/popperjs/popper-core/issues/837
  getComputedStyle(element).position === "fixed") {
    return null;
  }
  return element.offsetParent;
}
function getContainingBlock(element) {
  var isFirefox = /firefox/i.test(getUAString());
  var isIE = /Trident/i.test(getUAString());
  if (isIE && isHTMLElement(element)) {
    var elementCss = getComputedStyle(element);
    if (elementCss.position === "fixed") {
      return null;
    }
  }
  var currentNode = getParentNode(element);
  if (isShadowRoot(currentNode)) {
    currentNode = currentNode.host;
  }
  while (isHTMLElement(currentNode) && ["html", "body"].indexOf(getNodeName(currentNode)) < 0) {
    var css = getComputedStyle(currentNode);
    if (css.transform !== "none" || css.perspective !== "none" || css.contain === "paint" || ["transform", "perspective"].indexOf(css.willChange) !== -1 || isFirefox && css.willChange === "filter" || isFirefox && css.filter && css.filter !== "none") {
      return currentNode;
    } else {
      currentNode = currentNode.parentNode;
    }
  }
  return null;
}
function getOffsetParent(element) {
  var window2 = getWindow(element);
  var offsetParent = getTrueOffsetParent(element);
  while (offsetParent && isTableElement(offsetParent) && getComputedStyle(offsetParent).position === "static") {
    offsetParent = getTrueOffsetParent(offsetParent);
  }
  if (offsetParent && (getNodeName(offsetParent) === "html" || getNodeName(offsetParent) === "body" && getComputedStyle(offsetParent).position === "static")) {
    return window2;
  }
  return offsetParent || getContainingBlock(element) || window2;
}
function getMainAxisFromPlacement(placement) {
  return ["top", "bottom"].indexOf(placement) >= 0 ? "x" : "y";
}
function within(min$1, value, max$1) {
  return max(min$1, min(value, max$1));
}
function withinMaxClamp(min2, value, max2) {
  var v = within(min2, value, max2);
  return v > max2 ? max2 : v;
}
function getFreshSideObject() {
  return {
    top: 0,
    right: 0,
    bottom: 0,
    left: 0
  };
}
function mergePaddingObject(paddingObject) {
  return Object.assign({}, getFreshSideObject(), paddingObject);
}
function expandToHashMap(value, keys) {
  return keys.reduce(function(hashMap, key) {
    hashMap[key] = value;
    return hashMap;
  }, {});
}
var toPaddingObject = function toPaddingObject2(padding, state) {
  padding = typeof padding === "function" ? padding(Object.assign({}, state.rects, {
    placement: state.placement
  })) : padding;
  return mergePaddingObject(typeof padding !== "number" ? padding : expandToHashMap(padding, basePlacements));
};
function arrow(_ref) {
  var _state$modifiersData$;
  var state = _ref.state, name = _ref.name, options = _ref.options;
  var arrowElement = state.elements.arrow;
  var popperOffsets2 = state.modifiersData.popperOffsets;
  var basePlacement = getBasePlacement(state.placement);
  var axis = getMainAxisFromPlacement(basePlacement);
  var isVertical = [left, right].indexOf(basePlacement) >= 0;
  var len = isVertical ? "height" : "width";
  if (!arrowElement || !popperOffsets2) {
    return;
  }
  var paddingObject = toPaddingObject(options.padding, state);
  var arrowRect = getLayoutRect(arrowElement);
  var minProp = axis === "y" ? top : left;
  var maxProp = axis === "y" ? bottom : right;
  var endDiff = state.rects.reference[len] + state.rects.reference[axis] - popperOffsets2[axis] - state.rects.popper[len];
  var startDiff = popperOffsets2[axis] - state.rects.reference[axis];
  var arrowOffsetParent = getOffsetParent(arrowElement);
  var clientSize = arrowOffsetParent ? axis === "y" ? arrowOffsetParent.clientHeight || 0 : arrowOffsetParent.clientWidth || 0 : 0;
  var centerToReference = endDiff / 2 - startDiff / 2;
  var min2 = paddingObject[minProp];
  var max2 = clientSize - arrowRect[len] - paddingObject[maxProp];
  var center = clientSize / 2 - arrowRect[len] / 2 + centerToReference;
  var offset2 = within(min2, center, max2);
  var axisProp = axis;
  state.modifiersData[name] = (_state$modifiersData$ = {}, _state$modifiersData$[axisProp] = offset2, _state$modifiersData$.centerOffset = offset2 - center, _state$modifiersData$);
}
function effect$1(_ref2) {
  var state = _ref2.state, options = _ref2.options;
  var _options$element = options.element, arrowElement = _options$element === void 0 ? "[data-popper-arrow]" : _options$element;
  if (arrowElement == null) {
    return;
  }
  if (typeof arrowElement === "string") {
    arrowElement = state.elements.popper.querySelector(arrowElement);
    if (!arrowElement) {
      return;
    }
  }
  if (!contains(state.elements.popper, arrowElement)) {
    return;
  }
  state.elements.arrow = arrowElement;
}
const arrow$1 = {
  name: "arrow",
  enabled: true,
  phase: "main",
  fn: arrow,
  effect: effect$1,
  requires: ["popperOffsets"],
  requiresIfExists: ["preventOverflow"]
};
function getVariation(placement) {
  return placement.split("-")[1];
}
var unsetSides = {
  top: "auto",
  right: "auto",
  bottom: "auto",
  left: "auto"
};
function roundOffsetsByDPR(_ref, win) {
  var x = _ref.x, y = _ref.y;
  var dpr = win.devicePixelRatio || 1;
  return {
    x: round(x * dpr) / dpr || 0,
    y: round(y * dpr) / dpr || 0
  };
}
function mapToStyles(_ref2) {
  var _Object$assign2;
  var popper2 = _ref2.popper, popperRect = _ref2.popperRect, placement = _ref2.placement, variation = _ref2.variation, offsets = _ref2.offsets, position = _ref2.position, gpuAcceleration = _ref2.gpuAcceleration, adaptive = _ref2.adaptive, roundOffsets = _ref2.roundOffsets, isFixed = _ref2.isFixed;
  var _offsets$x = offsets.x, x = _offsets$x === void 0 ? 0 : _offsets$x, _offsets$y = offsets.y, y = _offsets$y === void 0 ? 0 : _offsets$y;
  var _ref3 = typeof roundOffsets === "function" ? roundOffsets({
    x,
    y
  }) : {
    x,
    y
  };
  x = _ref3.x;
  y = _ref3.y;
  var hasX = offsets.hasOwnProperty("x");
  var hasY = offsets.hasOwnProperty("y");
  var sideX = left;
  var sideY = top;
  var win = window;
  if (adaptive) {
    var offsetParent = getOffsetParent(popper2);
    var heightProp = "clientHeight";
    var widthProp = "clientWidth";
    if (offsetParent === getWindow(popper2)) {
      offsetParent = getDocumentElement(popper2);
      if (getComputedStyle(offsetParent).position !== "static" && position === "absolute") {
        heightProp = "scrollHeight";
        widthProp = "scrollWidth";
      }
    }
    offsetParent = offsetParent;
    if (placement === top || (placement === left || placement === right) && variation === end) {
      sideY = bottom;
      var offsetY = isFixed && offsetParent === win && win.visualViewport ? win.visualViewport.height : (
        // $FlowFixMe[prop-missing]
        offsetParent[heightProp]
      );
      y -= offsetY - popperRect.height;
      y *= gpuAcceleration ? 1 : -1;
    }
    if (placement === left || (placement === top || placement === bottom) && variation === end) {
      sideX = right;
      var offsetX = isFixed && offsetParent === win && win.visualViewport ? win.visualViewport.width : (
        // $FlowFixMe[prop-missing]
        offsetParent[widthProp]
      );
      x -= offsetX - popperRect.width;
      x *= gpuAcceleration ? 1 : -1;
    }
  }
  var commonStyles = Object.assign({
    position
  }, adaptive && unsetSides);
  var _ref4 = roundOffsets === true ? roundOffsetsByDPR({
    x,
    y
  }, getWindow(popper2)) : {
    x,
    y
  };
  x = _ref4.x;
  y = _ref4.y;
  if (gpuAcceleration) {
    var _Object$assign;
    return Object.assign({}, commonStyles, (_Object$assign = {}, _Object$assign[sideY] = hasY ? "0" : "", _Object$assign[sideX] = hasX ? "0" : "", _Object$assign.transform = (win.devicePixelRatio || 1) <= 1 ? "translate(" + x + "px, " + y + "px)" : "translate3d(" + x + "px, " + y + "px, 0)", _Object$assign));
  }
  return Object.assign({}, commonStyles, (_Object$assign2 = {}, _Object$assign2[sideY] = hasY ? y + "px" : "", _Object$assign2[sideX] = hasX ? x + "px" : "", _Object$assign2.transform = "", _Object$assign2));
}
function computeStyles(_ref5) {
  var state = _ref5.state, options = _ref5.options;
  var _options$gpuAccelerat = options.gpuAcceleration, gpuAcceleration = _options$gpuAccelerat === void 0 ? true : _options$gpuAccelerat, _options$adaptive = options.adaptive, adaptive = _options$adaptive === void 0 ? true : _options$adaptive, _options$roundOffsets = options.roundOffsets, roundOffsets = _options$roundOffsets === void 0 ? true : _options$roundOffsets;
  var commonStyles = {
    placement: getBasePlacement(state.placement),
    variation: getVariation(state.placement),
    popper: state.elements.popper,
    popperRect: state.rects.popper,
    gpuAcceleration,
    isFixed: state.options.strategy === "fixed"
  };
  if (state.modifiersData.popperOffsets != null) {
    state.styles.popper = Object.assign({}, state.styles.popper, mapToStyles(Object.assign({}, commonStyles, {
      offsets: state.modifiersData.popperOffsets,
      position: state.options.strategy,
      adaptive,
      roundOffsets
    })));
  }
  if (state.modifiersData.arrow != null) {
    state.styles.arrow = Object.assign({}, state.styles.arrow, mapToStyles(Object.assign({}, commonStyles, {
      offsets: state.modifiersData.arrow,
      position: "absolute",
      adaptive: false,
      roundOffsets
    })));
  }
  state.attributes.popper = Object.assign({}, state.attributes.popper, {
    "data-popper-placement": state.placement
  });
}
const computeStyles$1 = {
  name: "computeStyles",
  enabled: true,
  phase: "beforeWrite",
  fn: computeStyles,
  data: {}
};
var passive = {
  passive: true
};
function effect(_ref) {
  var state = _ref.state, instance = _ref.instance, options = _ref.options;
  var _options$scroll = options.scroll, scroll = _options$scroll === void 0 ? true : _options$scroll, _options$resize = options.resize, resize = _options$resize === void 0 ? true : _options$resize;
  var window2 = getWindow(state.elements.popper);
  var scrollParents = [].concat(state.scrollParents.reference, state.scrollParents.popper);
  if (scroll) {
    scrollParents.forEach(function(scrollParent) {
      scrollParent.addEventListener("scroll", instance.update, passive);
    });
  }
  if (resize) {
    window2.addEventListener("resize", instance.update, passive);
  }
  return function() {
    if (scroll) {
      scrollParents.forEach(function(scrollParent) {
        scrollParent.removeEventListener("scroll", instance.update, passive);
      });
    }
    if (resize) {
      window2.removeEventListener("resize", instance.update, passive);
    }
  };
}
const eventListeners = {
  name: "eventListeners",
  enabled: true,
  phase: "write",
  fn: function fn() {
  },
  effect,
  data: {}
};
var hash$1 = {
  left: "right",
  right: "left",
  bottom: "top",
  top: "bottom"
};
function getOppositePlacement(placement) {
  return placement.replace(/left|right|bottom|top/g, function(matched) {
    return hash$1[matched];
  });
}
var hash = {
  start: "end",
  end: "start"
};
function getOppositeVariationPlacement(placement) {
  return placement.replace(/start|end/g, function(matched) {
    return hash[matched];
  });
}
function getWindowScroll(node) {
  var win = getWindow(node);
  var scrollLeft = win.pageXOffset;
  var scrollTop = win.pageYOffset;
  return {
    scrollLeft,
    scrollTop
  };
}
function getWindowScrollBarX(element) {
  return getBoundingClientRect(getDocumentElement(element)).left + getWindowScroll(element).scrollLeft;
}
function getViewportRect(element, strategy) {
  var win = getWindow(element);
  var html = getDocumentElement(element);
  var visualViewport = win.visualViewport;
  var width = html.clientWidth;
  var height = html.clientHeight;
  var x = 0;
  var y = 0;
  if (visualViewport) {
    width = visualViewport.width;
    height = visualViewport.height;
    var layoutViewport = isLayoutViewport();
    if (layoutViewport || !layoutViewport && strategy === "fixed") {
      x = visualViewport.offsetLeft;
      y = visualViewport.offsetTop;
    }
  }
  return {
    width,
    height,
    x: x + getWindowScrollBarX(element),
    y
  };
}
function getDocumentRect(element) {
  var _element$ownerDocumen;
  var html = getDocumentElement(element);
  var winScroll = getWindowScroll(element);
  var body = (_element$ownerDocumen = element.ownerDocument) == null ? void 0 : _element$ownerDocumen.body;
  var width = max(html.scrollWidth, html.clientWidth, body ? body.scrollWidth : 0, body ? body.clientWidth : 0);
  var height = max(html.scrollHeight, html.clientHeight, body ? body.scrollHeight : 0, body ? body.clientHeight : 0);
  var x = -winScroll.scrollLeft + getWindowScrollBarX(element);
  var y = -winScroll.scrollTop;
  if (getComputedStyle(body || html).direction === "rtl") {
    x += max(html.clientWidth, body ? body.clientWidth : 0) - width;
  }
  return {
    width,
    height,
    x,
    y
  };
}
function isScrollParent(element) {
  var _getComputedStyle = getComputedStyle(element), overflow = _getComputedStyle.overflow, overflowX = _getComputedStyle.overflowX, overflowY = _getComputedStyle.overflowY;
  return /auto|scroll|overlay|hidden/.test(overflow + overflowY + overflowX);
}
function getScrollParent(node) {
  if (["html", "body", "#document"].indexOf(getNodeName(node)) >= 0) {
    return node.ownerDocument.body;
  }
  if (isHTMLElement(node) && isScrollParent(node)) {
    return node;
  }
  return getScrollParent(getParentNode(node));
}
function listScrollParents(element, list) {
  var _element$ownerDocumen;
  if (list === void 0) {
    list = [];
  }
  var scrollParent = getScrollParent(element);
  var isBody = scrollParent === ((_element$ownerDocumen = element.ownerDocument) == null ? void 0 : _element$ownerDocumen.body);
  var win = getWindow(scrollParent);
  var target = isBody ? [win].concat(win.visualViewport || [], isScrollParent(scrollParent) ? scrollParent : []) : scrollParent;
  var updatedList = list.concat(target);
  return isBody ? updatedList : (
    // $FlowFixMe[incompatible-call]: isBody tells us target will be an HTMLElement here
    updatedList.concat(listScrollParents(getParentNode(target)))
  );
}
function rectToClientRect(rect) {
  return Object.assign({}, rect, {
    left: rect.x,
    top: rect.y,
    right: rect.x + rect.width,
    bottom: rect.y + rect.height
  });
}
function getInnerBoundingClientRect(element, strategy) {
  var rect = getBoundingClientRect(element, false, strategy === "fixed");
  rect.top = rect.top + element.clientTop;
  rect.left = rect.left + element.clientLeft;
  rect.bottom = rect.top + element.clientHeight;
  rect.right = rect.left + element.clientWidth;
  rect.width = element.clientWidth;
  rect.height = element.clientHeight;
  rect.x = rect.left;
  rect.y = rect.top;
  return rect;
}
function getClientRectFromMixedType(element, clippingParent, strategy) {
  return clippingParent === viewport ? rectToClientRect(getViewportRect(element, strategy)) : isElement(clippingParent) ? getInnerBoundingClientRect(clippingParent, strategy) : rectToClientRect(getDocumentRect(getDocumentElement(element)));
}
function getClippingParents(element) {
  var clippingParents2 = listScrollParents(getParentNode(element));
  var canEscapeClipping = ["absolute", "fixed"].indexOf(getComputedStyle(element).position) >= 0;
  var clipperElement = canEscapeClipping && isHTMLElement(element) ? getOffsetParent(element) : element;
  if (!isElement(clipperElement)) {
    return [];
  }
  return clippingParents2.filter(function(clippingParent) {
    return isElement(clippingParent) && contains(clippingParent, clipperElement) && getNodeName(clippingParent) !== "body";
  });
}
function getClippingRect(element, boundary, rootBoundary, strategy) {
  var mainClippingParents = boundary === "clippingParents" ? getClippingParents(element) : [].concat(boundary);
  var clippingParents2 = [].concat(mainClippingParents, [rootBoundary]);
  var firstClippingParent = clippingParents2[0];
  var clippingRect = clippingParents2.reduce(function(accRect, clippingParent) {
    var rect = getClientRectFromMixedType(element, clippingParent, strategy);
    accRect.top = max(rect.top, accRect.top);
    accRect.right = min(rect.right, accRect.right);
    accRect.bottom = min(rect.bottom, accRect.bottom);
    accRect.left = max(rect.left, accRect.left);
    return accRect;
  }, getClientRectFromMixedType(element, firstClippingParent, strategy));
  clippingRect.width = clippingRect.right - clippingRect.left;
  clippingRect.height = clippingRect.bottom - clippingRect.top;
  clippingRect.x = clippingRect.left;
  clippingRect.y = clippingRect.top;
  return clippingRect;
}
function computeOffsets(_ref) {
  var reference2 = _ref.reference, element = _ref.element, placement = _ref.placement;
  var basePlacement = placement ? getBasePlacement(placement) : null;
  var variation = placement ? getVariation(placement) : null;
  var commonX = reference2.x + reference2.width / 2 - element.width / 2;
  var commonY = reference2.y + reference2.height / 2 - element.height / 2;
  var offsets;
  switch (basePlacement) {
    case top:
      offsets = {
        x: commonX,
        y: reference2.y - element.height
      };
      break;
    case bottom:
      offsets = {
        x: commonX,
        y: reference2.y + reference2.height
      };
      break;
    case right:
      offsets = {
        x: reference2.x + reference2.width,
        y: commonY
      };
      break;
    case left:
      offsets = {
        x: reference2.x - element.width,
        y: commonY
      };
      break;
    default:
      offsets = {
        x: reference2.x,
        y: reference2.y
      };
  }
  var mainAxis = basePlacement ? getMainAxisFromPlacement(basePlacement) : null;
  if (mainAxis != null) {
    var len = mainAxis === "y" ? "height" : "width";
    switch (variation) {
      case start:
        offsets[mainAxis] = offsets[mainAxis] - (reference2[len] / 2 - element[len] / 2);
        break;
      case end:
        offsets[mainAxis] = offsets[mainAxis] + (reference2[len] / 2 - element[len] / 2);
        break;
    }
  }
  return offsets;
}
function detectOverflow(state, options) {
  if (options === void 0) {
    options = {};
  }
  var _options = options, _options$placement = _options.placement, placement = _options$placement === void 0 ? state.placement : _options$placement, _options$strategy = _options.strategy, strategy = _options$strategy === void 0 ? state.strategy : _options$strategy, _options$boundary = _options.boundary, boundary = _options$boundary === void 0 ? clippingParents : _options$boundary, _options$rootBoundary = _options.rootBoundary, rootBoundary = _options$rootBoundary === void 0 ? viewport : _options$rootBoundary, _options$elementConte = _options.elementContext, elementContext = _options$elementConte === void 0 ? popper : _options$elementConte, _options$altBoundary = _options.altBoundary, altBoundary = _options$altBoundary === void 0 ? false : _options$altBoundary, _options$padding = _options.padding, padding = _options$padding === void 0 ? 0 : _options$padding;
  var paddingObject = mergePaddingObject(typeof padding !== "number" ? padding : expandToHashMap(padding, basePlacements));
  var altContext = elementContext === popper ? reference : popper;
  var popperRect = state.rects.popper;
  var element = state.elements[altBoundary ? altContext : elementContext];
  var clippingClientRect = getClippingRect(isElement(element) ? element : element.contextElement || getDocumentElement(state.elements.popper), boundary, rootBoundary, strategy);
  var referenceClientRect = getBoundingClientRect(state.elements.reference);
  var popperOffsets2 = computeOffsets({
    reference: referenceClientRect,
    element: popperRect,
    strategy: "absolute",
    placement
  });
  var popperClientRect = rectToClientRect(Object.assign({}, popperRect, popperOffsets2));
  var elementClientRect = elementContext === popper ? popperClientRect : referenceClientRect;
  var overflowOffsets = {
    top: clippingClientRect.top - elementClientRect.top + paddingObject.top,
    bottom: elementClientRect.bottom - clippingClientRect.bottom + paddingObject.bottom,
    left: clippingClientRect.left - elementClientRect.left + paddingObject.left,
    right: elementClientRect.right - clippingClientRect.right + paddingObject.right
  };
  var offsetData = state.modifiersData.offset;
  if (elementContext === popper && offsetData) {
    var offset2 = offsetData[placement];
    Object.keys(overflowOffsets).forEach(function(key) {
      var multiply = [right, bottom].indexOf(key) >= 0 ? 1 : -1;
      var axis = [top, bottom].indexOf(key) >= 0 ? "y" : "x";
      overflowOffsets[key] += offset2[axis] * multiply;
    });
  }
  return overflowOffsets;
}
function computeAutoPlacement(state, options) {
  if (options === void 0) {
    options = {};
  }
  var _options = options, placement = _options.placement, boundary = _options.boundary, rootBoundary = _options.rootBoundary, padding = _options.padding, flipVariations = _options.flipVariations, _options$allowedAutoP = _options.allowedAutoPlacements, allowedAutoPlacements = _options$allowedAutoP === void 0 ? placements : _options$allowedAutoP;
  var variation = getVariation(placement);
  var placements$1 = variation ? flipVariations ? variationPlacements : variationPlacements.filter(function(placement2) {
    return getVariation(placement2) === variation;
  }) : basePlacements;
  var allowedPlacements = placements$1.filter(function(placement2) {
    return allowedAutoPlacements.indexOf(placement2) >= 0;
  });
  if (allowedPlacements.length === 0) {
    allowedPlacements = placements$1;
  }
  var overflows = allowedPlacements.reduce(function(acc, placement2) {
    acc[placement2] = detectOverflow(state, {
      placement: placement2,
      boundary,
      rootBoundary,
      padding
    })[getBasePlacement(placement2)];
    return acc;
  }, {});
  return Object.keys(overflows).sort(function(a, b) {
    return overflows[a] - overflows[b];
  });
}
function getExpandedFallbackPlacements(placement) {
  if (getBasePlacement(placement) === auto) {
    return [];
  }
  var oppositePlacement = getOppositePlacement(placement);
  return [getOppositeVariationPlacement(placement), oppositePlacement, getOppositeVariationPlacement(oppositePlacement)];
}
function flip(_ref) {
  var state = _ref.state, options = _ref.options, name = _ref.name;
  if (state.modifiersData[name]._skip) {
    return;
  }
  var _options$mainAxis = options.mainAxis, checkMainAxis = _options$mainAxis === void 0 ? true : _options$mainAxis, _options$altAxis = options.altAxis, checkAltAxis = _options$altAxis === void 0 ? true : _options$altAxis, specifiedFallbackPlacements = options.fallbackPlacements, padding = options.padding, boundary = options.boundary, rootBoundary = options.rootBoundary, altBoundary = options.altBoundary, _options$flipVariatio = options.flipVariations, flipVariations = _options$flipVariatio === void 0 ? true : _options$flipVariatio, allowedAutoPlacements = options.allowedAutoPlacements;
  var preferredPlacement = state.options.placement;
  var basePlacement = getBasePlacement(preferredPlacement);
  var isBasePlacement = basePlacement === preferredPlacement;
  var fallbackPlacements = specifiedFallbackPlacements || (isBasePlacement || !flipVariations ? [getOppositePlacement(preferredPlacement)] : getExpandedFallbackPlacements(preferredPlacement));
  var placements2 = [preferredPlacement].concat(fallbackPlacements).reduce(function(acc, placement2) {
    return acc.concat(getBasePlacement(placement2) === auto ? computeAutoPlacement(state, {
      placement: placement2,
      boundary,
      rootBoundary,
      padding,
      flipVariations,
      allowedAutoPlacements
    }) : placement2);
  }, []);
  var referenceRect = state.rects.reference;
  var popperRect = state.rects.popper;
  var checksMap = /* @__PURE__ */ new Map();
  var makeFallbackChecks = true;
  var firstFittingPlacement = placements2[0];
  for (var i = 0; i < placements2.length; i++) {
    var placement = placements2[i];
    var _basePlacement = getBasePlacement(placement);
    var isStartVariation = getVariation(placement) === start;
    var isVertical = [top, bottom].indexOf(_basePlacement) >= 0;
    var len = isVertical ? "width" : "height";
    var overflow = detectOverflow(state, {
      placement,
      boundary,
      rootBoundary,
      altBoundary,
      padding
    });
    var mainVariationSide = isVertical ? isStartVariation ? right : left : isStartVariation ? bottom : top;
    if (referenceRect[len] > popperRect[len]) {
      mainVariationSide = getOppositePlacement(mainVariationSide);
    }
    var altVariationSide = getOppositePlacement(mainVariationSide);
    var checks = [];
    if (checkMainAxis) {
      checks.push(overflow[_basePlacement] <= 0);
    }
    if (checkAltAxis) {
      checks.push(overflow[mainVariationSide] <= 0, overflow[altVariationSide] <= 0);
    }
    if (checks.every(function(check) {
      return check;
    })) {
      firstFittingPlacement = placement;
      makeFallbackChecks = false;
      break;
    }
    checksMap.set(placement, checks);
  }
  if (makeFallbackChecks) {
    var numberOfChecks = flipVariations ? 3 : 1;
    var _loop = function _loop2(_i2) {
      var fittingPlacement = placements2.find(function(placement2) {
        var checks2 = checksMap.get(placement2);
        if (checks2) {
          return checks2.slice(0, _i2).every(function(check) {
            return check;
          });
        }
      });
      if (fittingPlacement) {
        firstFittingPlacement = fittingPlacement;
        return "break";
      }
    };
    for (var _i = numberOfChecks; _i > 0; _i--) {
      var _ret = _loop(_i);
      if (_ret === "break")
        break;
    }
  }
  if (state.placement !== firstFittingPlacement) {
    state.modifiersData[name]._skip = true;
    state.placement = firstFittingPlacement;
    state.reset = true;
  }
}
const flip$1 = {
  name: "flip",
  enabled: true,
  phase: "main",
  fn: flip,
  requiresIfExists: ["offset"],
  data: {
    _skip: false
  }
};
function getSideOffsets(overflow, rect, preventedOffsets) {
  if (preventedOffsets === void 0) {
    preventedOffsets = {
      x: 0,
      y: 0
    };
  }
  return {
    top: overflow.top - rect.height - preventedOffsets.y,
    right: overflow.right - rect.width + preventedOffsets.x,
    bottom: overflow.bottom - rect.height + preventedOffsets.y,
    left: overflow.left - rect.width - preventedOffsets.x
  };
}
function isAnySideFullyClipped(overflow) {
  return [top, right, bottom, left].some(function(side) {
    return overflow[side] >= 0;
  });
}
function hide(_ref) {
  var state = _ref.state, name = _ref.name;
  var referenceRect = state.rects.reference;
  var popperRect = state.rects.popper;
  var preventedOffsets = state.modifiersData.preventOverflow;
  var referenceOverflow = detectOverflow(state, {
    elementContext: "reference"
  });
  var popperAltOverflow = detectOverflow(state, {
    altBoundary: true
  });
  var referenceClippingOffsets = getSideOffsets(referenceOverflow, referenceRect);
  var popperEscapeOffsets = getSideOffsets(popperAltOverflow, popperRect, preventedOffsets);
  var isReferenceHidden = isAnySideFullyClipped(referenceClippingOffsets);
  var hasPopperEscaped = isAnySideFullyClipped(popperEscapeOffsets);
  state.modifiersData[name] = {
    referenceClippingOffsets,
    popperEscapeOffsets,
    isReferenceHidden,
    hasPopperEscaped
  };
  state.attributes.popper = Object.assign({}, state.attributes.popper, {
    "data-popper-reference-hidden": isReferenceHidden,
    "data-popper-escaped": hasPopperEscaped
  });
}
const hide$1 = {
  name: "hide",
  enabled: true,
  phase: "main",
  requiresIfExists: ["preventOverflow"],
  fn: hide
};
function distanceAndSkiddingToXY(placement, rects, offset2) {
  var basePlacement = getBasePlacement(placement);
  var invertDistance = [left, top].indexOf(basePlacement) >= 0 ? -1 : 1;
  var _ref = typeof offset2 === "function" ? offset2(Object.assign({}, rects, {
    placement
  })) : offset2, skidding = _ref[0], distance = _ref[1];
  skidding = skidding || 0;
  distance = (distance || 0) * invertDistance;
  return [left, right].indexOf(basePlacement) >= 0 ? {
    x: distance,
    y: skidding
  } : {
    x: skidding,
    y: distance
  };
}
function offset(_ref2) {
  var state = _ref2.state, options = _ref2.options, name = _ref2.name;
  var _options$offset = options.offset, offset2 = _options$offset === void 0 ? [0, 0] : _options$offset;
  var data = placements.reduce(function(acc, placement) {
    acc[placement] = distanceAndSkiddingToXY(placement, state.rects, offset2);
    return acc;
  }, {});
  var _data$state$placement = data[state.placement], x = _data$state$placement.x, y = _data$state$placement.y;
  if (state.modifiersData.popperOffsets != null) {
    state.modifiersData.popperOffsets.x += x;
    state.modifiersData.popperOffsets.y += y;
  }
  state.modifiersData[name] = data;
}
const offset$1 = {
  name: "offset",
  enabled: true,
  phase: "main",
  requires: ["popperOffsets"],
  fn: offset
};
function popperOffsets(_ref) {
  var state = _ref.state, name = _ref.name;
  state.modifiersData[name] = computeOffsets({
    reference: state.rects.reference,
    element: state.rects.popper,
    strategy: "absolute",
    placement: state.placement
  });
}
const popperOffsets$1 = {
  name: "popperOffsets",
  enabled: true,
  phase: "read",
  fn: popperOffsets,
  data: {}
};
function getAltAxis(axis) {
  return axis === "x" ? "y" : "x";
}
function preventOverflow(_ref) {
  var state = _ref.state, options = _ref.options, name = _ref.name;
  var _options$mainAxis = options.mainAxis, checkMainAxis = _options$mainAxis === void 0 ? true : _options$mainAxis, _options$altAxis = options.altAxis, checkAltAxis = _options$altAxis === void 0 ? false : _options$altAxis, boundary = options.boundary, rootBoundary = options.rootBoundary, altBoundary = options.altBoundary, padding = options.padding, _options$tether = options.tether, tether = _options$tether === void 0 ? true : _options$tether, _options$tetherOffset = options.tetherOffset, tetherOffset = _options$tetherOffset === void 0 ? 0 : _options$tetherOffset;
  var overflow = detectOverflow(state, {
    boundary,
    rootBoundary,
    padding,
    altBoundary
  });
  var basePlacement = getBasePlacement(state.placement);
  var variation = getVariation(state.placement);
  var isBasePlacement = !variation;
  var mainAxis = getMainAxisFromPlacement(basePlacement);
  var altAxis = getAltAxis(mainAxis);
  var popperOffsets2 = state.modifiersData.popperOffsets;
  var referenceRect = state.rects.reference;
  var popperRect = state.rects.popper;
  var tetherOffsetValue = typeof tetherOffset === "function" ? tetherOffset(Object.assign({}, state.rects, {
    placement: state.placement
  })) : tetherOffset;
  var normalizedTetherOffsetValue = typeof tetherOffsetValue === "number" ? {
    mainAxis: tetherOffsetValue,
    altAxis: tetherOffsetValue
  } : Object.assign({
    mainAxis: 0,
    altAxis: 0
  }, tetherOffsetValue);
  var offsetModifierState = state.modifiersData.offset ? state.modifiersData.offset[state.placement] : null;
  var data = {
    x: 0,
    y: 0
  };
  if (!popperOffsets2) {
    return;
  }
  if (checkMainAxis) {
    var _offsetModifierState$;
    var mainSide = mainAxis === "y" ? top : left;
    var altSide = mainAxis === "y" ? bottom : right;
    var len = mainAxis === "y" ? "height" : "width";
    var offset2 = popperOffsets2[mainAxis];
    var min$1 = offset2 + overflow[mainSide];
    var max$1 = offset2 - overflow[altSide];
    var additive = tether ? -popperRect[len] / 2 : 0;
    var minLen = variation === start ? referenceRect[len] : popperRect[len];
    var maxLen = variation === start ? -popperRect[len] : -referenceRect[len];
    var arrowElement = state.elements.arrow;
    var arrowRect = tether && arrowElement ? getLayoutRect(arrowElement) : {
      width: 0,
      height: 0
    };
    var arrowPaddingObject = state.modifiersData["arrow#persistent"] ? state.modifiersData["arrow#persistent"].padding : getFreshSideObject();
    var arrowPaddingMin = arrowPaddingObject[mainSide];
    var arrowPaddingMax = arrowPaddingObject[altSide];
    var arrowLen = within(0, referenceRect[len], arrowRect[len]);
    var minOffset = isBasePlacement ? referenceRect[len] / 2 - additive - arrowLen - arrowPaddingMin - normalizedTetherOffsetValue.mainAxis : minLen - arrowLen - arrowPaddingMin - normalizedTetherOffsetValue.mainAxis;
    var maxOffset = isBasePlacement ? -referenceRect[len] / 2 + additive + arrowLen + arrowPaddingMax + normalizedTetherOffsetValue.mainAxis : maxLen + arrowLen + arrowPaddingMax + normalizedTetherOffsetValue.mainAxis;
    var arrowOffsetParent = state.elements.arrow && getOffsetParent(state.elements.arrow);
    var clientOffset = arrowOffsetParent ? mainAxis === "y" ? arrowOffsetParent.clientTop || 0 : arrowOffsetParent.clientLeft || 0 : 0;
    var offsetModifierValue = (_offsetModifierState$ = offsetModifierState == null ? void 0 : offsetModifierState[mainAxis]) != null ? _offsetModifierState$ : 0;
    var tetherMin = offset2 + minOffset - offsetModifierValue - clientOffset;
    var tetherMax = offset2 + maxOffset - offsetModifierValue;
    var preventedOffset = within(tether ? min(min$1, tetherMin) : min$1, offset2, tether ? max(max$1, tetherMax) : max$1);
    popperOffsets2[mainAxis] = preventedOffset;
    data[mainAxis] = preventedOffset - offset2;
  }
  if (checkAltAxis) {
    var _offsetModifierState$2;
    var _mainSide = mainAxis === "x" ? top : left;
    var _altSide = mainAxis === "x" ? bottom : right;
    var _offset = popperOffsets2[altAxis];
    var _len = altAxis === "y" ? "height" : "width";
    var _min = _offset + overflow[_mainSide];
    var _max = _offset - overflow[_altSide];
    var isOriginSide = [top, left].indexOf(basePlacement) !== -1;
    var _offsetModifierValue = (_offsetModifierState$2 = offsetModifierState == null ? void 0 : offsetModifierState[altAxis]) != null ? _offsetModifierState$2 : 0;
    var _tetherMin = isOriginSide ? _min : _offset - referenceRect[_len] - popperRect[_len] - _offsetModifierValue + normalizedTetherOffsetValue.altAxis;
    var _tetherMax = isOriginSide ? _offset + referenceRect[_len] + popperRect[_len] - _offsetModifierValue - normalizedTetherOffsetValue.altAxis : _max;
    var _preventedOffset = tether && isOriginSide ? withinMaxClamp(_tetherMin, _offset, _tetherMax) : within(tether ? _tetherMin : _min, _offset, tether ? _tetherMax : _max);
    popperOffsets2[altAxis] = _preventedOffset;
    data[altAxis] = _preventedOffset - _offset;
  }
  state.modifiersData[name] = data;
}
const preventOverflow$1 = {
  name: "preventOverflow",
  enabled: true,
  phase: "main",
  fn: preventOverflow,
  requiresIfExists: ["offset"]
};
function getHTMLElementScroll(element) {
  return {
    scrollLeft: element.scrollLeft,
    scrollTop: element.scrollTop
  };
}
function getNodeScroll(node) {
  if (node === getWindow(node) || !isHTMLElement(node)) {
    return getWindowScroll(node);
  } else {
    return getHTMLElementScroll(node);
  }
}
function isElementScaled(element) {
  var rect = element.getBoundingClientRect();
  var scaleX = round(rect.width) / element.offsetWidth || 1;
  var scaleY = round(rect.height) / element.offsetHeight || 1;
  return scaleX !== 1 || scaleY !== 1;
}
function getCompositeRect(elementOrVirtualElement, offsetParent, isFixed) {
  if (isFixed === void 0) {
    isFixed = false;
  }
  var isOffsetParentAnElement = isHTMLElement(offsetParent);
  var offsetParentIsScaled = isHTMLElement(offsetParent) && isElementScaled(offsetParent);
  var documentElement = getDocumentElement(offsetParent);
  var rect = getBoundingClientRect(elementOrVirtualElement, offsetParentIsScaled, isFixed);
  var scroll = {
    scrollLeft: 0,
    scrollTop: 0
  };
  var offsets = {
    x: 0,
    y: 0
  };
  if (isOffsetParentAnElement || !isOffsetParentAnElement && !isFixed) {
    if (getNodeName(offsetParent) !== "body" || // https://github.com/popperjs/popper-core/issues/1078
    isScrollParent(documentElement)) {
      scroll = getNodeScroll(offsetParent);
    }
    if (isHTMLElement(offsetParent)) {
      offsets = getBoundingClientRect(offsetParent, true);
      offsets.x += offsetParent.clientLeft;
      offsets.y += offsetParent.clientTop;
    } else if (documentElement) {
      offsets.x = getWindowScrollBarX(documentElement);
    }
  }
  return {
    x: rect.left + scroll.scrollLeft - offsets.x,
    y: rect.top + scroll.scrollTop - offsets.y,
    width: rect.width,
    height: rect.height
  };
}
function order(modifiers) {
  var map = /* @__PURE__ */ new Map();
  var visited = /* @__PURE__ */ new Set();
  var result = [];
  modifiers.forEach(function(modifier) {
    map.set(modifier.name, modifier);
  });
  function sort(modifier) {
    visited.add(modifier.name);
    var requires = [].concat(modifier.requires || [], modifier.requiresIfExists || []);
    requires.forEach(function(dep) {
      if (!visited.has(dep)) {
        var depModifier = map.get(dep);
        if (depModifier) {
          sort(depModifier);
        }
      }
    });
    result.push(modifier);
  }
  modifiers.forEach(function(modifier) {
    if (!visited.has(modifier.name)) {
      sort(modifier);
    }
  });
  return result;
}
function orderModifiers(modifiers) {
  var orderedModifiers = order(modifiers);
  return modifierPhases.reduce(function(acc, phase) {
    return acc.concat(orderedModifiers.filter(function(modifier) {
      return modifier.phase === phase;
    }));
  }, []);
}
function debounce(fn2) {
  var pending;
  return function() {
    if (!pending) {
      pending = new Promise(function(resolve) {
        Promise.resolve().then(function() {
          pending = void 0;
          resolve(fn2());
        });
      });
    }
    return pending;
  };
}
function mergeByName(modifiers) {
  var merged = modifiers.reduce(function(merged2, current) {
    var existing = merged2[current.name];
    merged2[current.name] = existing ? Object.assign({}, existing, current, {
      options: Object.assign({}, existing.options, current.options),
      data: Object.assign({}, existing.data, current.data)
    }) : current;
    return merged2;
  }, {});
  return Object.keys(merged).map(function(key) {
    return merged[key];
  });
}
var DEFAULT_OPTIONS = {
  placement: "bottom",
  modifiers: [],
  strategy: "absolute"
};
function areValidElements() {
  for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
    args[_key] = arguments[_key];
  }
  return !args.some(function(element) {
    return !(element && typeof element.getBoundingClientRect === "function");
  });
}
function popperGenerator(generatorOptions) {
  if (generatorOptions === void 0) {
    generatorOptions = {};
  }
  var _generatorOptions = generatorOptions, _generatorOptions$def = _generatorOptions.defaultModifiers, defaultModifiers2 = _generatorOptions$def === void 0 ? [] : _generatorOptions$def, _generatorOptions$def2 = _generatorOptions.defaultOptions, defaultOptions = _generatorOptions$def2 === void 0 ? DEFAULT_OPTIONS : _generatorOptions$def2;
  return function createPopper2(reference2, popper2, options) {
    if (options === void 0) {
      options = defaultOptions;
    }
    var state = {
      placement: "bottom",
      orderedModifiers: [],
      options: Object.assign({}, DEFAULT_OPTIONS, defaultOptions),
      modifiersData: {},
      elements: {
        reference: reference2,
        popper: popper2
      },
      attributes: {},
      styles: {}
    };
    var effectCleanupFns = [];
    var isDestroyed = false;
    var instance = {
      state,
      setOptions: function setOptions(setOptionsAction) {
        var options2 = typeof setOptionsAction === "function" ? setOptionsAction(state.options) : setOptionsAction;
        cleanupModifierEffects();
        state.options = Object.assign({}, defaultOptions, state.options, options2);
        state.scrollParents = {
          reference: isElement(reference2) ? listScrollParents(reference2) : reference2.contextElement ? listScrollParents(reference2.contextElement) : [],
          popper: listScrollParents(popper2)
        };
        var orderedModifiers = orderModifiers(mergeByName([].concat(defaultModifiers2, state.options.modifiers)));
        state.orderedModifiers = orderedModifiers.filter(function(m) {
          return m.enabled;
        });
        runModifierEffects();
        return instance.update();
      },
      // Sync update – it will always be executed, even if not necessary. This
      // is useful for low frequency updates where sync behavior simplifies the
      // logic.
      // For high frequency updates (e.g. `resize` and `scroll` events), always
      // prefer the async Popper#update method
      forceUpdate: function forceUpdate() {
        if (isDestroyed) {
          return;
        }
        var _state$elements = state.elements, reference3 = _state$elements.reference, popper3 = _state$elements.popper;
        if (!areValidElements(reference3, popper3)) {
          return;
        }
        state.rects = {
          reference: getCompositeRect(reference3, getOffsetParent(popper3), state.options.strategy === "fixed"),
          popper: getLayoutRect(popper3)
        };
        state.reset = false;
        state.placement = state.options.placement;
        state.orderedModifiers.forEach(function(modifier) {
          return state.modifiersData[modifier.name] = Object.assign({}, modifier.data);
        });
        for (var index2 = 0; index2 < state.orderedModifiers.length; index2++) {
          if (state.reset === true) {
            state.reset = false;
            index2 = -1;
            continue;
          }
          var _state$orderedModifie = state.orderedModifiers[index2], fn2 = _state$orderedModifie.fn, _state$orderedModifie2 = _state$orderedModifie.options, _options = _state$orderedModifie2 === void 0 ? {} : _state$orderedModifie2, name = _state$orderedModifie.name;
          if (typeof fn2 === "function") {
            state = fn2({
              state,
              options: _options,
              name,
              instance
            }) || state;
          }
        }
      },
      // Async and optimistically optimized update – it will not be executed if
      // not necessary (debounced to run at most once-per-tick)
      update: debounce(function() {
        return new Promise(function(resolve) {
          instance.forceUpdate();
          resolve(state);
        });
      }),
      destroy: function destroy() {
        cleanupModifierEffects();
        isDestroyed = true;
      }
    };
    if (!areValidElements(reference2, popper2)) {
      return instance;
    }
    instance.setOptions(options).then(function(state2) {
      if (!isDestroyed && options.onFirstUpdate) {
        options.onFirstUpdate(state2);
      }
    });
    function runModifierEffects() {
      state.orderedModifiers.forEach(function(_ref) {
        var name = _ref.name, _ref$options = _ref.options, options2 = _ref$options === void 0 ? {} : _ref$options, effect2 = _ref.effect;
        if (typeof effect2 === "function") {
          var cleanupFn = effect2({
            state,
            name,
            instance,
            options: options2
          });
          var noopFn = function noopFn2() {
          };
          effectCleanupFns.push(cleanupFn || noopFn);
        }
      });
    }
    function cleanupModifierEffects() {
      effectCleanupFns.forEach(function(fn2) {
        return fn2();
      });
      effectCleanupFns = [];
    }
    return instance;
  };
}
var defaultModifiers = [eventListeners, popperOffsets$1, computeStyles$1, applyStyles$1, offset$1, flip$1, preventOverflow$1, arrow$1, hide$1];
var createPopper = /* @__PURE__ */ popperGenerator({
  defaultModifiers
});
var hasElementType = typeof Element !== "undefined";
var hasMap = typeof Map === "function";
var hasSet = typeof Set === "function";
var hasArrayBuffer = typeof ArrayBuffer === "function" && !!ArrayBuffer.isView;
function equal(a, b) {
  if (a === b)
    return true;
  if (a && b && typeof a == "object" && typeof b == "object") {
    if (a.constructor !== b.constructor)
      return false;
    var length, i, keys;
    if (Array.isArray(a)) {
      length = a.length;
      if (length != b.length)
        return false;
      for (i = length; i-- !== 0; )
        if (!equal(a[i], b[i]))
          return false;
      return true;
    }
    var it;
    if (hasMap && a instanceof Map && b instanceof Map) {
      if (a.size !== b.size)
        return false;
      it = a.entries();
      while (!(i = it.next()).done)
        if (!b.has(i.value[0]))
          return false;
      it = a.entries();
      while (!(i = it.next()).done)
        if (!equal(i.value[1], b.get(i.value[0])))
          return false;
      return true;
    }
    if (hasSet && a instanceof Set && b instanceof Set) {
      if (a.size !== b.size)
        return false;
      it = a.entries();
      while (!(i = it.next()).done)
        if (!b.has(i.value[0]))
          return false;
      return true;
    }
    if (hasArrayBuffer && ArrayBuffer.isView(a) && ArrayBuffer.isView(b)) {
      length = a.length;
      if (length != b.length)
        return false;
      for (i = length; i-- !== 0; )
        if (a[i] !== b[i])
          return false;
      return true;
    }
    if (a.constructor === RegExp)
      return a.source === b.source && a.flags === b.flags;
    if (a.valueOf !== Object.prototype.valueOf && typeof a.valueOf === "function" && typeof b.valueOf === "function")
      return a.valueOf() === b.valueOf();
    if (a.toString !== Object.prototype.toString && typeof a.toString === "function" && typeof b.toString === "function")
      return a.toString() === b.toString();
    keys = Object.keys(a);
    length = keys.length;
    if (length !== Object.keys(b).length)
      return false;
    for (i = length; i-- !== 0; )
      if (!Object.prototype.hasOwnProperty.call(b, keys[i]))
        return false;
    if (hasElementType && a instanceof Element)
      return false;
    for (i = length; i-- !== 0; ) {
      if ((keys[i] === "_owner" || keys[i] === "__v" || keys[i] === "__o") && a.$$typeof) {
        continue;
      }
      if (!equal(a[keys[i]], b[keys[i]]))
        return false;
    }
    return true;
  }
  return a !== a && b !== b;
}
var reactFastCompare = function isEqual(a, b) {
  try {
    return equal(a, b);
  } catch (error2) {
    if ((error2.message || "").match(/stack|recursion/i)) {
      console.warn("react-fast-compare cannot handle circular refs");
      return false;
    }
    throw error2;
  }
};
const isEqual2 = /* @__PURE__ */ getDefaultExportFromCjs(reactFastCompare);
var EMPTY_MODIFIERS = [];
var usePopper = function usePopper2(referenceElement, popperElement, options) {
  if (options === void 0) {
    options = {};
  }
  var prevOptions = reactExports.useRef(null);
  var optionsWithDefaults = {
    onFirstUpdate: options.onFirstUpdate,
    placement: options.placement || "bottom",
    strategy: options.strategy || "absolute",
    modifiers: options.modifiers || EMPTY_MODIFIERS
  };
  var _React$useState = reactExports.useState({
    styles: {
      popper: {
        position: optionsWithDefaults.strategy,
        left: "0",
        top: "0"
      },
      arrow: {
        position: "absolute"
      }
    },
    attributes: {}
  }), state = _React$useState[0], setState = _React$useState[1];
  var updateStateModifier = reactExports.useMemo(function() {
    return {
      name: "updateState",
      enabled: true,
      phase: "write",
      fn: function fn2(_ref) {
        var state2 = _ref.state;
        var elements = Object.keys(state2.elements);
        reactDomExports.flushSync(function() {
          setState({
            styles: fromEntries(elements.map(function(element) {
              return [element, state2.styles[element] || {}];
            })),
            attributes: fromEntries(elements.map(function(element) {
              return [element, state2.attributes[element]];
            }))
          });
        });
      },
      requires: ["computeStyles"]
    };
  }, []);
  var popperOptions = reactExports.useMemo(function() {
    var newOptions = {
      onFirstUpdate: optionsWithDefaults.onFirstUpdate,
      placement: optionsWithDefaults.placement,
      strategy: optionsWithDefaults.strategy,
      modifiers: [].concat(optionsWithDefaults.modifiers, [updateStateModifier, {
        name: "applyStyles",
        enabled: false
      }])
    };
    if (isEqual2(prevOptions.current, newOptions)) {
      return prevOptions.current || newOptions;
    } else {
      prevOptions.current = newOptions;
      return newOptions;
    }
  }, [optionsWithDefaults.onFirstUpdate, optionsWithDefaults.placement, optionsWithDefaults.strategy, optionsWithDefaults.modifiers, updateStateModifier]);
  var popperInstanceRef = reactExports.useRef();
  useIsomorphicLayoutEffect(function() {
    if (popperInstanceRef.current) {
      popperInstanceRef.current.setOptions(popperOptions);
    }
  }, [popperOptions]);
  useIsomorphicLayoutEffect(function() {
    if (referenceElement == null || popperElement == null) {
      return;
    }
    var createPopper$1 = options.createPopper || createPopper;
    var popperInstance = createPopper$1(referenceElement, popperElement, popperOptions);
    popperInstanceRef.current = popperInstance;
    return function() {
      popperInstance.destroy();
      popperInstanceRef.current = null;
    };
  }, [referenceElement, popperElement, options.createPopper]);
  return {
    state: popperInstanceRef.current ? popperInstanceRef.current.state : null,
    styles: state.styles,
    attributes: state.attributes,
    update: popperInstanceRef.current ? popperInstanceRef.current.update : null,
    forceUpdate: popperInstanceRef.current ? popperInstanceRef.current.forceUpdate : null
  };
};
const getReferenceElement = (reference2) => {
  if (reference2 instanceof Element || reference2 && "getBoundingClientRect" in reference2) {
    return reference2;
  }
  if (reference2 && "current" in reference2) {
    return reference2.current;
  }
  return null;
};
var MapShim = function() {
  if (typeof Map !== "undefined") {
    return Map;
  }
  function getIndex(arr, key) {
    var result = -1;
    arr.some(function(entry, index2) {
      if (entry[0] === key) {
        result = index2;
        return true;
      }
      return false;
    });
    return result;
  }
  return (
    /** @class */
    function() {
      function class_1() {
        this.__entries__ = [];
      }
      Object.defineProperty(class_1.prototype, "size", {
        /**
         * @returns {boolean}
         */
        get: function() {
          return this.__entries__.length;
        },
        enumerable: true,
        configurable: true
      });
      class_1.prototype.get = function(key) {
        var index2 = getIndex(this.__entries__, key);
        var entry = this.__entries__[index2];
        return entry && entry[1];
      };
      class_1.prototype.set = function(key, value) {
        var index2 = getIndex(this.__entries__, key);
        if (~index2) {
          this.__entries__[index2][1] = value;
        } else {
          this.__entries__.push([key, value]);
        }
      };
      class_1.prototype.delete = function(key) {
        var entries = this.__entries__;
        var index2 = getIndex(entries, key);
        if (~index2) {
          entries.splice(index2, 1);
        }
      };
      class_1.prototype.has = function(key) {
        return !!~getIndex(this.__entries__, key);
      };
      class_1.prototype.clear = function() {
        this.__entries__.splice(0);
      };
      class_1.prototype.forEach = function(callback, ctx) {
        if (ctx === void 0) {
          ctx = null;
        }
        for (var _i = 0, _a = this.__entries__; _i < _a.length; _i++) {
          var entry = _a[_i];
          callback.call(ctx, entry[1], entry[0]);
        }
      };
      return class_1;
    }()
  );
}();
var isBrowser = typeof window !== "undefined" && typeof document !== "undefined" && window.document === document;
var global$1 = function() {
  if (typeof global !== "undefined" && global.Math === Math) {
    return global;
  }
  if (typeof self !== "undefined" && self.Math === Math) {
    return self;
  }
  if (typeof window !== "undefined" && window.Math === Math) {
    return window;
  }
  return Function("return this")();
}();
var requestAnimationFrame$1 = function() {
  if (typeof requestAnimationFrame === "function") {
    return requestAnimationFrame.bind(global$1);
  }
  return function(callback) {
    return setTimeout(function() {
      return callback(Date.now());
    }, 1e3 / 60);
  };
}();
var trailingTimeout = 2;
function throttle(callback, delay) {
  var leadingCall = false, trailingCall = false, lastCallTime = 0;
  function resolvePending() {
    if (leadingCall) {
      leadingCall = false;
      callback();
    }
    if (trailingCall) {
      proxy();
    }
  }
  function timeoutCallback() {
    requestAnimationFrame$1(resolvePending);
  }
  function proxy() {
    var timeStamp = Date.now();
    if (leadingCall) {
      if (timeStamp - lastCallTime < trailingTimeout) {
        return;
      }
      trailingCall = true;
    } else {
      leadingCall = true;
      trailingCall = false;
      setTimeout(timeoutCallback, delay);
    }
    lastCallTime = timeStamp;
  }
  return proxy;
}
var REFRESH_DELAY = 20;
var transitionKeys = ["top", "right", "bottom", "left", "width", "height", "size", "weight"];
var mutationObserverSupported = typeof MutationObserver !== "undefined";
var ResizeObserverController = (
  /** @class */
  function() {
    function ResizeObserverController2() {
      this.connected_ = false;
      this.mutationEventsAdded_ = false;
      this.mutationsObserver_ = null;
      this.observers_ = [];
      this.onTransitionEnd_ = this.onTransitionEnd_.bind(this);
      this.refresh = throttle(this.refresh.bind(this), REFRESH_DELAY);
    }
    ResizeObserverController2.prototype.addObserver = function(observer) {
      if (!~this.observers_.indexOf(observer)) {
        this.observers_.push(observer);
      }
      if (!this.connected_) {
        this.connect_();
      }
    };
    ResizeObserverController2.prototype.removeObserver = function(observer) {
      var observers2 = this.observers_;
      var index2 = observers2.indexOf(observer);
      if (~index2) {
        observers2.splice(index2, 1);
      }
      if (!observers2.length && this.connected_) {
        this.disconnect_();
      }
    };
    ResizeObserverController2.prototype.refresh = function() {
      var changesDetected = this.updateObservers_();
      if (changesDetected) {
        this.refresh();
      }
    };
    ResizeObserverController2.prototype.updateObservers_ = function() {
      var activeObservers = this.observers_.filter(function(observer) {
        return observer.gatherActive(), observer.hasActive();
      });
      activeObservers.forEach(function(observer) {
        return observer.broadcastActive();
      });
      return activeObservers.length > 0;
    };
    ResizeObserverController2.prototype.connect_ = function() {
      if (!isBrowser || this.connected_) {
        return;
      }
      document.addEventListener("transitionend", this.onTransitionEnd_);
      window.addEventListener("resize", this.refresh);
      if (mutationObserverSupported) {
        this.mutationsObserver_ = new MutationObserver(this.refresh);
        this.mutationsObserver_.observe(document, {
          attributes: true,
          childList: true,
          characterData: true,
          subtree: true
        });
      } else {
        document.addEventListener("DOMSubtreeModified", this.refresh);
        this.mutationEventsAdded_ = true;
      }
      this.connected_ = true;
    };
    ResizeObserverController2.prototype.disconnect_ = function() {
      if (!isBrowser || !this.connected_) {
        return;
      }
      document.removeEventListener("transitionend", this.onTransitionEnd_);
      window.removeEventListener("resize", this.refresh);
      if (this.mutationsObserver_) {
        this.mutationsObserver_.disconnect();
      }
      if (this.mutationEventsAdded_) {
        document.removeEventListener("DOMSubtreeModified", this.refresh);
      }
      this.mutationsObserver_ = null;
      this.mutationEventsAdded_ = false;
      this.connected_ = false;
    };
    ResizeObserverController2.prototype.onTransitionEnd_ = function(_a) {
      var _b = _a.propertyName, propertyName = _b === void 0 ? "" : _b;
      var isReflowProperty = transitionKeys.some(function(key) {
        return !!~propertyName.indexOf(key);
      });
      if (isReflowProperty) {
        this.refresh();
      }
    };
    ResizeObserverController2.getInstance = function() {
      if (!this.instance_) {
        this.instance_ = new ResizeObserverController2();
      }
      return this.instance_;
    };
    ResizeObserverController2.instance_ = null;
    return ResizeObserverController2;
  }()
);
var defineConfigurable = function(target, props) {
  for (var _i = 0, _a = Object.keys(props); _i < _a.length; _i++) {
    var key = _a[_i];
    Object.defineProperty(target, key, {
      value: props[key],
      enumerable: false,
      writable: false,
      configurable: true
    });
  }
  return target;
};
var getWindowOf = function(target) {
  var ownerGlobal = target && target.ownerDocument && target.ownerDocument.defaultView;
  return ownerGlobal || global$1;
};
var emptyRect = createRectInit(0, 0, 0, 0);
function toFloat(value) {
  return parseFloat(value) || 0;
}
function getBordersSize(styles2) {
  var positions = [];
  for (var _i = 1; _i < arguments.length; _i++) {
    positions[_i - 1] = arguments[_i];
  }
  return positions.reduce(function(size, position) {
    var value = styles2["border-" + position + "-width"];
    return size + toFloat(value);
  }, 0);
}
function getPaddings(styles2) {
  var positions = ["top", "right", "bottom", "left"];
  var paddings = {};
  for (var _i = 0, positions_1 = positions; _i < positions_1.length; _i++) {
    var position = positions_1[_i];
    var value = styles2["padding-" + position];
    paddings[position] = toFloat(value);
  }
  return paddings;
}
function getSVGContentRect(target) {
  var bbox = target.getBBox();
  return createRectInit(0, 0, bbox.width, bbox.height);
}
function getHTMLElementContentRect(target) {
  var clientWidth = target.clientWidth, clientHeight = target.clientHeight;
  if (!clientWidth && !clientHeight) {
    return emptyRect;
  }
  var styles2 = getWindowOf(target).getComputedStyle(target);
  var paddings = getPaddings(styles2);
  var horizPad = paddings.left + paddings.right;
  var vertPad = paddings.top + paddings.bottom;
  var width = toFloat(styles2.width), height = toFloat(styles2.height);
  if (styles2.boxSizing === "border-box") {
    if (Math.round(width + horizPad) !== clientWidth) {
      width -= getBordersSize(styles2, "left", "right") + horizPad;
    }
    if (Math.round(height + vertPad) !== clientHeight) {
      height -= getBordersSize(styles2, "top", "bottom") + vertPad;
    }
  }
  if (!isDocumentElement(target)) {
    var vertScrollbar = Math.round(width + horizPad) - clientWidth;
    var horizScrollbar = Math.round(height + vertPad) - clientHeight;
    if (Math.abs(vertScrollbar) !== 1) {
      width -= vertScrollbar;
    }
    if (Math.abs(horizScrollbar) !== 1) {
      height -= horizScrollbar;
    }
  }
  return createRectInit(paddings.left, paddings.top, width, height);
}
var isSVGGraphicsElement = function() {
  if (typeof SVGGraphicsElement !== "undefined") {
    return function(target) {
      return target instanceof getWindowOf(target).SVGGraphicsElement;
    };
  }
  return function(target) {
    return target instanceof getWindowOf(target).SVGElement && typeof target.getBBox === "function";
  };
}();
function isDocumentElement(target) {
  return target === getWindowOf(target).document.documentElement;
}
function getContentRect(target) {
  if (!isBrowser) {
    return emptyRect;
  }
  if (isSVGGraphicsElement(target)) {
    return getSVGContentRect(target);
  }
  return getHTMLElementContentRect(target);
}
function createReadOnlyRect(_a) {
  var x = _a.x, y = _a.y, width = _a.width, height = _a.height;
  var Constr = typeof DOMRectReadOnly !== "undefined" ? DOMRectReadOnly : Object;
  var rect = Object.create(Constr.prototype);
  defineConfigurable(rect, {
    x,
    y,
    width,
    height,
    top: y,
    right: x + width,
    bottom: height + y,
    left: x
  });
  return rect;
}
function createRectInit(x, y, width, height) {
  return { x, y, width, height };
}
var ResizeObservation = (
  /** @class */
  function() {
    function ResizeObservation2(target) {
      this.broadcastWidth = 0;
      this.broadcastHeight = 0;
      this.contentRect_ = createRectInit(0, 0, 0, 0);
      this.target = target;
    }
    ResizeObservation2.prototype.isActive = function() {
      var rect = getContentRect(this.target);
      this.contentRect_ = rect;
      return rect.width !== this.broadcastWidth || rect.height !== this.broadcastHeight;
    };
    ResizeObservation2.prototype.broadcastRect = function() {
      var rect = this.contentRect_;
      this.broadcastWidth = rect.width;
      this.broadcastHeight = rect.height;
      return rect;
    };
    return ResizeObservation2;
  }()
);
var ResizeObserverEntry = (
  /** @class */
  /* @__PURE__ */ function() {
    function ResizeObserverEntry2(target, rectInit) {
      var contentRect = createReadOnlyRect(rectInit);
      defineConfigurable(this, { target, contentRect });
    }
    return ResizeObserverEntry2;
  }()
);
var ResizeObserverSPI = (
  /** @class */
  function() {
    function ResizeObserverSPI2(callback, controller, callbackCtx) {
      this.activeObservations_ = [];
      this.observations_ = new MapShim();
      if (typeof callback !== "function") {
        throw new TypeError("The callback provided as parameter 1 is not a function.");
      }
      this.callback_ = callback;
      this.controller_ = controller;
      this.callbackCtx_ = callbackCtx;
    }
    ResizeObserverSPI2.prototype.observe = function(target) {
      if (!arguments.length) {
        throw new TypeError("1 argument required, but only 0 present.");
      }
      if (typeof Element === "undefined" || !(Element instanceof Object)) {
        return;
      }
      if (!(target instanceof getWindowOf(target).Element)) {
        throw new TypeError('parameter 1 is not of type "Element".');
      }
      var observations = this.observations_;
      if (observations.has(target)) {
        return;
      }
      observations.set(target, new ResizeObservation(target));
      this.controller_.addObserver(this);
      this.controller_.refresh();
    };
    ResizeObserverSPI2.prototype.unobserve = function(target) {
      if (!arguments.length) {
        throw new TypeError("1 argument required, but only 0 present.");
      }
      if (typeof Element === "undefined" || !(Element instanceof Object)) {
        return;
      }
      if (!(target instanceof getWindowOf(target).Element)) {
        throw new TypeError('parameter 1 is not of type "Element".');
      }
      var observations = this.observations_;
      if (!observations.has(target)) {
        return;
      }
      observations.delete(target);
      if (!observations.size) {
        this.controller_.removeObserver(this);
      }
    };
    ResizeObserverSPI2.prototype.disconnect = function() {
      this.clearActive();
      this.observations_.clear();
      this.controller_.removeObserver(this);
    };
    ResizeObserverSPI2.prototype.gatherActive = function() {
      var _this = this;
      this.clearActive();
      this.observations_.forEach(function(observation) {
        if (observation.isActive()) {
          _this.activeObservations_.push(observation);
        }
      });
    };
    ResizeObserverSPI2.prototype.broadcastActive = function() {
      if (!this.hasActive()) {
        return;
      }
      var ctx = this.callbackCtx_;
      var entries = this.activeObservations_.map(function(observation) {
        return new ResizeObserverEntry(observation.target, observation.broadcastRect());
      });
      this.callback_.call(ctx, entries, ctx);
      this.clearActive();
    };
    ResizeObserverSPI2.prototype.clearActive = function() {
      this.activeObservations_.splice(0);
    };
    ResizeObserverSPI2.prototype.hasActive = function() {
      return this.activeObservations_.length > 0;
    };
    return ResizeObserverSPI2;
  }()
);
var observers = typeof WeakMap !== "undefined" ? /* @__PURE__ */ new WeakMap() : new MapShim();
var ResizeObserver = (
  /** @class */
  /* @__PURE__ */ function() {
    function ResizeObserver2(callback) {
      if (!(this instanceof ResizeObserver2)) {
        throw new TypeError("Cannot call a class as a function.");
      }
      if (!arguments.length) {
        throw new TypeError("1 argument required, but only 0 present.");
      }
      var controller = ResizeObserverController.getInstance();
      var observer = new ResizeObserverSPI(callback, controller, this);
      observers.set(this, observer);
    }
    return ResizeObserver2;
  }()
);
[
  "observe",
  "unobserve",
  "disconnect"
].forEach(function(method) {
  ResizeObserver.prototype[method] = function() {
    var _a;
    return (_a = observers.get(this))[method].apply(_a, arguments);
  };
});
var index = function() {
  if (typeof global$1.ResizeObserver !== "undefined") {
    return global$1.ResizeObserver;
  }
  return ResizeObserver;
}();
const attachResizeObservers = (_ref) => {
  let {
    state: {
      elements
    },
    options,
    instance: {
      update
    }
  } = _ref;
  const observers2 = Object.keys(options).reduce((acc, elementKey) => {
    if (options[elementKey]) {
      const observer = new index(update);
      observer.observe(elements[elementKey]);
      acc.push(observer);
    }
    return acc;
  }, []);
  return () => {
    observers2.forEach((observer) => {
      observer.disconnect();
    });
  };
};
const getBaseModifiers = (_ref2) => {
  let {
    observePopperResize,
    observeReferenceResize
  } = _ref2;
  return [{
    name: "preventOverflow",
    options: {
      altAxis: true,
      rootBoundary: "document",
      boundary: document.body
    }
  }, {
    name: "flip",
    options: {
      rootBoundary: "document",
      boundary: document.body
    }
  }, {
    name: "resizeObserver",
    enabled: true,
    phase: "write",
    fn: () => {
    },
    effect: attachResizeObservers,
    options: {
      popper: observePopperResize,
      reference: observeReferenceResize
    }
  }];
};
const deduplicateModifiers = (modifiers, resizeObservers) => {
  return getBaseModifiers(resizeObservers).filter((_ref3) => {
    let {
      name
    } = _ref3;
    return !modifiers.some((m) => m.name === name);
  }).concat(modifiers);
};
function _extends$7() {
  _extends$7 = Object.assign || function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$7.apply(this, arguments);
}
const Popper = (_ref) => {
  let {
    children,
    className,
    dataTest,
    modifiers,
    observePopperResize,
    observeReferenceResize,
    onFirstUpdate,
    placement,
    reference: reference2,
    strategy
  } = _ref;
  const referenceElement = getReferenceElement(reference2);
  const [popperElement, setPopperElement] = reactExports.useState(null);
  const deduplicatedModifiers = reactExports.useMemo(() => deduplicateModifiers(modifiers, {
    observePopperResize,
    observeReferenceResize
  }), [modifiers, observePopperResize, observeReferenceResize]);
  const {
    styles: styles2,
    attributes
  } = usePopper(referenceElement, popperElement, {
    strategy,
    onFirstUpdate,
    placement,
    modifiers: deduplicatedModifiers
  });
  return /* @__PURE__ */ React.createElement("div", _extends$7({
    className,
    "data-test": dataTest,
    ref: setPopperElement,
    style: styles2.popper
  }, attributes.popper), children);
};
Popper.defaultProps = {
  dataTest: "dhis2-uicore-popper",
  modifiers: [],
  placement: "auto"
};
Popper.propTypes = {
  /** Content inside the Popper */
  children: PropTypes.node.isRequired,
  className: PropTypes.string,
  dataTest: PropTypes.string,
  /** A property of the `createPopper` options. See [popper docs](https://popper.js.org/docs/v2/constructors/) */
  modifiers: PropTypes.arrayOf(PropTypes.shape({
    name: PropTypes.string,
    options: PropTypes.object
  })),
  /** Makes the Popper update position when the **Popper content** changes size */
  observePopperResize: PropTypes.bool,
  /** Makes the Popper update position when the **reference element** changes size */
  observeReferenceResize: PropTypes.bool,
  /** A property of the `createPopper` options. See [popper docs](https://popper.js.org/docs/v2/constructors/) */
  placement: popperPlacementPropType,
  /** A React ref, DOM node, or [virtual element](https://popper.js.org/docs/v2/virtual-elements/) for the popper to position itself against */
  reference: popperReferencePropType,
  /** A property of the `createPopper` options. See [popper docs](https://popper.js.org/docs/v2/constructors/) */
  strategy: PropTypes.oneOf(["absolute", "fixed"]),
  // defaults to 'absolute'
  /** A property of the `createPopper` options. See [popper docs](https://popper.js.org/docs/v2/constructors/) */
  onFirstUpdate: PropTypes.func
};
var _extends$6 = Object.assign || function(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i];
    for (var key in source) {
      if (Object.prototype.hasOwnProperty.call(source, key)) {
        target[key] = source[key];
      }
    }
  }
  return target;
};
function _classCallCheck$9(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _toConsumableArray(arr) {
  if (Array.isArray(arr)) {
    for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) {
      arr2[i] = arr[i];
    }
    return arr2;
  } else {
    return Array.from(arr);
  }
}
var consoleLogger = {
  type: "logger",
  log: function log(args) {
    this.output("log", args);
  },
  warn: function warn(args) {
    this.output("warn", args);
  },
  error: function error(args) {
    this.output("error", args);
  },
  output: function output(type, args) {
    var _console;
    if (console && console[type])
      (_console = console)[type].apply(_console, _toConsumableArray(args));
  }
};
var Logger = function() {
  function Logger2(concreteLogger) {
    var options = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    _classCallCheck$9(this, Logger2);
    this.init(concreteLogger, options);
  }
  Logger2.prototype.init = function init(concreteLogger) {
    var options = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    this.prefix = options.prefix || "i18next:";
    this.logger = concreteLogger || consoleLogger;
    this.options = options;
    this.debug = options.debug;
  };
  Logger2.prototype.setDebug = function setDebug(bool) {
    this.debug = bool;
  };
  Logger2.prototype.log = function log2() {
    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }
    return this.forward(args, "log", "", true);
  };
  Logger2.prototype.warn = function warn2() {
    for (var _len2 = arguments.length, args = Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
      args[_key2] = arguments[_key2];
    }
    return this.forward(args, "warn", "", true);
  };
  Logger2.prototype.error = function error2() {
    for (var _len3 = arguments.length, args = Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
      args[_key3] = arguments[_key3];
    }
    return this.forward(args, "error", "");
  };
  Logger2.prototype.deprecate = function deprecate() {
    for (var _len4 = arguments.length, args = Array(_len4), _key4 = 0; _key4 < _len4; _key4++) {
      args[_key4] = arguments[_key4];
    }
    return this.forward(args, "warn", "WARNING DEPRECATED: ", true);
  };
  Logger2.prototype.forward = function forward(args, lvl, prefix, debugOnly) {
    if (debugOnly && !this.debug)
      return null;
    if (typeof args[0] === "string")
      args[0] = "" + prefix + this.prefix + " " + args[0];
    return this.logger[lvl](args);
  };
  Logger2.prototype.create = function create(moduleName) {
    return new Logger2(this.logger, _extends$6({ prefix: this.prefix + ":" + moduleName + ":" }, this.options));
  };
  return Logger2;
}();
const baseLogger = new Logger();
function _classCallCheck$8(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
var EventEmitter = function() {
  function EventEmitter2() {
    _classCallCheck$8(this, EventEmitter2);
    this.observers = {};
  }
  EventEmitter2.prototype.on = function on(events, listener) {
    var _this = this;
    events.split(" ").forEach(function(event) {
      _this.observers[event] = _this.observers[event] || [];
      _this.observers[event].push(listener);
    });
  };
  EventEmitter2.prototype.off = function off(event, listener) {
    var _this2 = this;
    if (!this.observers[event]) {
      return;
    }
    this.observers[event].forEach(function() {
      if (!listener) {
        delete _this2.observers[event];
      } else {
        var index2 = _this2.observers[event].indexOf(listener);
        if (index2 > -1) {
          _this2.observers[event].splice(index2, 1);
        }
      }
    });
  };
  EventEmitter2.prototype.emit = function emit(event) {
    for (var _len = arguments.length, args = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
      args[_key - 1] = arguments[_key];
    }
    if (this.observers[event]) {
      var cloned = [].concat(this.observers[event]);
      cloned.forEach(function(observer) {
        observer.apply(void 0, args);
      });
    }
    if (this.observers["*"]) {
      var _cloned = [].concat(this.observers["*"]);
      _cloned.forEach(function(observer) {
        var _ref;
        observer.apply(observer, (_ref = [event]).concat.apply(_ref, args));
      });
    }
  };
  return EventEmitter2;
}();
function makeString(object) {
  if (object == null)
    return "";
  return "" + object;
}
function copy(a, s, t) {
  a.forEach(function(m) {
    if (s[m])
      t[m] = s[m];
  });
}
function getLastOfPath(object, path, Empty) {
  function cleanKey(key2) {
    return key2 && key2.indexOf("###") > -1 ? key2.replace(/###/g, ".") : key2;
  }
  function canNotTraverseDeeper() {
    return !object || typeof object === "string";
  }
  var stack = typeof path !== "string" ? [].concat(path) : path.split(".");
  while (stack.length > 1) {
    if (canNotTraverseDeeper())
      return {};
    var key = cleanKey(stack.shift());
    if (!object[key] && Empty)
      object[key] = new Empty();
    object = object[key];
  }
  if (canNotTraverseDeeper())
    return {};
  return {
    obj: object,
    k: cleanKey(stack.shift())
  };
}
function setPath(object, path, newValue) {
  var _getLastOfPath = getLastOfPath(object, path, Object), obj = _getLastOfPath.obj, k = _getLastOfPath.k;
  obj[k] = newValue;
}
function pushPath(object, path, newValue, concat) {
  var _getLastOfPath2 = getLastOfPath(object, path, Object), obj = _getLastOfPath2.obj, k = _getLastOfPath2.k;
  obj[k] = obj[k] || [];
  if (concat)
    obj[k] = obj[k].concat(newValue);
  if (!concat)
    obj[k].push(newValue);
}
function getPath(object, path) {
  var _getLastOfPath3 = getLastOfPath(object, path), obj = _getLastOfPath3.obj, k = _getLastOfPath3.k;
  if (!obj)
    return void 0;
  return obj[k];
}
function deepExtend(target, source, overwrite) {
  for (var prop in source) {
    if (prop in target) {
      if (typeof target[prop] === "string" || target[prop] instanceof String || typeof source[prop] === "string" || source[prop] instanceof String) {
        if (overwrite)
          target[prop] = source[prop];
      } else {
        deepExtend(target[prop], source[prop], overwrite);
      }
    } else {
      target[prop] = source[prop];
    }
  }
  return target;
}
function regexEscape(str) {
  return str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
}
var _entityMap = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;",
  "/": "&#x2F;"
};
function escape(data) {
  if (typeof data === "string") {
    return data.replace(/[&<>"'\/]/g, function(s) {
      return _entityMap[s];
    });
  }
  return data;
}
var _extends$5 = Object.assign || function(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i];
    for (var key in source) {
      if (Object.prototype.hasOwnProperty.call(source, key)) {
        target[key] = source[key];
      }
    }
  }
  return target;
};
function _defaults$4(obj, defaults) {
  var keys = Object.getOwnPropertyNames(defaults);
  for (var i = 0; i < keys.length; i++) {
    var key = keys[i];
    var value = Object.getOwnPropertyDescriptor(defaults, key);
    if (value && value.configurable && obj[key] === void 0) {
      Object.defineProperty(obj, key, value);
    }
  }
  return obj;
}
function _classCallCheck$7(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn$4(self2, call) {
  if (!self2) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self2;
}
function _inherits$4(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : _defaults$4(subClass, superClass);
}
var ResourceStore = function(_EventEmitter) {
  _inherits$4(ResourceStore2, _EventEmitter);
  function ResourceStore2(data) {
    var options = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : { ns: ["translation"], defaultNS: "translation" };
    _classCallCheck$7(this, ResourceStore2);
    var _this = _possibleConstructorReturn$4(this, _EventEmitter.call(this));
    _this.data = data || {};
    _this.options = options;
    return _this;
  }
  ResourceStore2.prototype.addNamespaces = function addNamespaces(ns) {
    if (this.options.ns.indexOf(ns) < 0) {
      this.options.ns.push(ns);
    }
  };
  ResourceStore2.prototype.removeNamespaces = function removeNamespaces(ns) {
    var index2 = this.options.ns.indexOf(ns);
    if (index2 > -1) {
      this.options.ns.splice(index2, 1);
    }
  };
  ResourceStore2.prototype.getResource = function getResource(lng, ns, key) {
    var options = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : {};
    var keySeparator = options.keySeparator || this.options.keySeparator;
    if (keySeparator === void 0)
      keySeparator = ".";
    var path = [lng, ns];
    if (key && typeof key !== "string")
      path = path.concat(key);
    if (key && typeof key === "string")
      path = path.concat(keySeparator ? key.split(keySeparator) : key);
    if (lng.indexOf(".") > -1) {
      path = lng.split(".");
    }
    return getPath(this.data, path);
  };
  ResourceStore2.prototype.addResource = function addResource(lng, ns, key, value) {
    var options = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : { silent: false };
    var keySeparator = this.options.keySeparator;
    if (keySeparator === void 0)
      keySeparator = ".";
    var path = [lng, ns];
    if (key)
      path = path.concat(keySeparator ? key.split(keySeparator) : key);
    if (lng.indexOf(".") > -1) {
      path = lng.split(".");
      value = ns;
      ns = path[1];
    }
    this.addNamespaces(ns);
    setPath(this.data, path, value);
    if (!options.silent)
      this.emit("added", lng, ns, key, value);
  };
  ResourceStore2.prototype.addResources = function addResources(lng, ns, resources) {
    var options = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : { silent: false };
    for (var m in resources) {
      if (typeof resources[m] === "string")
        this.addResource(lng, ns, m, resources[m], { silent: true });
    }
    if (!options.silent)
      this.emit("added", lng, ns, resources);
  };
  ResourceStore2.prototype.addResourceBundle = function addResourceBundle(lng, ns, resources, deep, overwrite) {
    var options = arguments.length > 5 && arguments[5] !== void 0 ? arguments[5] : { silent: false };
    var path = [lng, ns];
    if (lng.indexOf(".") > -1) {
      path = lng.split(".");
      deep = resources;
      resources = ns;
      ns = path[1];
    }
    this.addNamespaces(ns);
    var pack = getPath(this.data, path) || {};
    if (deep) {
      deepExtend(pack, resources, overwrite);
    } else {
      pack = _extends$5({}, pack, resources);
    }
    setPath(this.data, path, pack);
    if (!options.silent)
      this.emit("added", lng, ns, resources);
  };
  ResourceStore2.prototype.removeResourceBundle = function removeResourceBundle(lng, ns) {
    if (this.hasResourceBundle(lng, ns)) {
      delete this.data[lng][ns];
    }
    this.removeNamespaces(ns);
    this.emit("removed", lng, ns);
  };
  ResourceStore2.prototype.hasResourceBundle = function hasResourceBundle(lng, ns) {
    return this.getResource(lng, ns) !== void 0;
  };
  ResourceStore2.prototype.getResourceBundle = function getResourceBundle(lng, ns) {
    if (!ns)
      ns = this.options.defaultNS;
    if (this.options.compatibilityAPI === "v1")
      return _extends$5({}, this.getResource(lng, ns));
    return this.getResource(lng, ns);
  };
  ResourceStore2.prototype.toJSON = function toJSON() {
    return this.data;
  };
  return ResourceStore2;
}(EventEmitter);
const postProcessor = {
  processors: {},
  addPostProcessor: function addPostProcessor(module) {
    this.processors[module.name] = module;
  },
  handle: function handle(processors, value, key, options, translator) {
    var _this = this;
    processors.forEach(function(processor) {
      if (_this.processors[processor])
        value = _this.processors[processor].process(value, key, options, translator);
    });
    return value;
  }
};
var _extends$4 = Object.assign || function(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i];
    for (var key in source) {
      if (Object.prototype.hasOwnProperty.call(source, key)) {
        target[key] = source[key];
      }
    }
  }
  return target;
};
var _typeof$1 = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function(obj) {
  return typeof obj;
} : function(obj) {
  return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
};
function _defaults$3(obj, defaults) {
  var keys = Object.getOwnPropertyNames(defaults);
  for (var i = 0; i < keys.length; i++) {
    var key = keys[i];
    var value = Object.getOwnPropertyDescriptor(defaults, key);
    if (value && value.configurable && obj[key] === void 0) {
      Object.defineProperty(obj, key, value);
    }
  }
  return obj;
}
function _classCallCheck$6(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn$3(self2, call) {
  if (!self2) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self2;
}
function _inherits$3(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : _defaults$3(subClass, superClass);
}
var Translator = function(_EventEmitter) {
  _inherits$3(Translator2, _EventEmitter);
  function Translator2(services) {
    var options = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    _classCallCheck$6(this, Translator2);
    var _this = _possibleConstructorReturn$3(this, _EventEmitter.call(this));
    copy(["resourceStore", "languageUtils", "pluralResolver", "interpolator", "backendConnector"], services, _this);
    _this.options = options;
    _this.logger = baseLogger.create("translator");
    return _this;
  }
  Translator2.prototype.changeLanguage = function changeLanguage(lng) {
    if (lng)
      this.language = lng;
  };
  Translator2.prototype.exists = function exists(key) {
    var options = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : { interpolation: {} };
    var resolved = this.resolve(key, options);
    return resolved && resolved.res !== void 0;
  };
  Translator2.prototype.extractFromKey = function extractFromKey(key, options) {
    var nsSeparator = options.nsSeparator || this.options.nsSeparator;
    if (nsSeparator === void 0)
      nsSeparator = ":";
    var keySeparator = options.keySeparator || this.options.keySeparator || ".";
    var namespaces = options.ns || this.options.defaultNS;
    if (nsSeparator && key.indexOf(nsSeparator) > -1) {
      var parts = key.split(nsSeparator);
      if (nsSeparator !== keySeparator || nsSeparator === keySeparator && this.options.ns.indexOf(parts[0]) > -1)
        namespaces = parts.shift();
      key = parts.join(keySeparator);
    }
    if (typeof namespaces === "string")
      namespaces = [namespaces];
    return {
      key,
      namespaces
    };
  };
  Translator2.prototype.translate = function translate(keys, options) {
    var _this2 = this;
    if ((typeof options === "undefined" ? "undefined" : _typeof$1(options)) !== "object" && this.options.overloadTranslationOptionHandler) {
      options = this.options.overloadTranslationOptionHandler(arguments);
    }
    if (!options)
      options = {};
    if (keys === void 0 || keys === null || keys === "")
      return "";
    if (typeof keys === "number")
      keys = String(keys);
    if (typeof keys === "string")
      keys = [keys];
    var keySeparator = options.keySeparator || this.options.keySeparator || ".";
    var _extractFromKey = this.extractFromKey(keys[keys.length - 1], options), key = _extractFromKey.key, namespaces = _extractFromKey.namespaces;
    var namespace2 = namespaces[namespaces.length - 1];
    var lng = options.lng || this.language;
    var appendNamespaceToCIMode = options.appendNamespaceToCIMode || this.options.appendNamespaceToCIMode;
    if (lng && lng.toLowerCase() === "cimode") {
      if (appendNamespaceToCIMode) {
        var nsSeparator = options.nsSeparator || this.options.nsSeparator;
        return namespace2 + nsSeparator + key;
      }
      return key;
    }
    var resolved = this.resolve(keys, options);
    var res = resolved && resolved.res;
    var resUsedKey = resolved && resolved.usedKey || key;
    var resType = Object.prototype.toString.apply(res);
    var noObject = ["[object Number]", "[object Function]", "[object RegExp]"];
    var joinArrays = options.joinArrays !== void 0 ? options.joinArrays : this.options.joinArrays;
    var handleAsObject = typeof res !== "string" && typeof res !== "boolean" && typeof res !== "number";
    if (res && handleAsObject && noObject.indexOf(resType) < 0 && !(joinArrays && resType === "[object Array]")) {
      if (!options.returnObjects && !this.options.returnObjects) {
        this.logger.warn("accessing an object - but returnObjects options is not enabled!");
        return this.options.returnedObjectHandler ? this.options.returnedObjectHandler(resUsedKey, res, options) : "key '" + key + " (" + this.language + ")' returned an object instead of string.";
      }
      if (options.keySeparator || this.options.keySeparator) {
        var copy2 = resType === "[object Array]" ? [] : {};
        for (var m in res) {
          if (Object.prototype.hasOwnProperty.call(res, m)) {
            var deepKey = "" + resUsedKey + keySeparator + m;
            copy2[m] = this.translate(deepKey, _extends$4({}, options, { joinArrays: false, ns: namespaces }));
            if (copy2[m] === deepKey)
              copy2[m] = res[m];
          }
        }
        res = copy2;
      }
    } else if (joinArrays && resType === "[object Array]") {
      res = res.join(joinArrays);
      if (res)
        res = this.extendTranslation(res, keys, options);
    } else {
      var usedDefault = false;
      var usedKey = false;
      if (!this.isValidLookup(res) && options.defaultValue !== void 0) {
        usedDefault = true;
        res = options.defaultValue;
      }
      if (!this.isValidLookup(res)) {
        usedKey = true;
        res = key;
      }
      var updateMissing = options.defaultValue && options.defaultValue !== res && this.options.updateMissing;
      if (usedKey || usedDefault || updateMissing) {
        this.logger.log(updateMissing ? "updateKey" : "missingKey", lng, namespace2, key, updateMissing ? options.defaultValue : res);
        var lngs = [];
        var fallbackLngs = this.languageUtils.getFallbackCodes(this.options.fallbackLng, options.lng || this.language);
        if (this.options.saveMissingTo === "fallback" && fallbackLngs && fallbackLngs[0]) {
          for (var i = 0; i < fallbackLngs.length; i++) {
            lngs.push(fallbackLngs[i]);
          }
        } else if (this.options.saveMissingTo === "all") {
          lngs = this.languageUtils.toResolveHierarchy(options.lng || this.language);
        } else {
          lngs.push(options.lng || this.language);
        }
        var send = function send2(l, k) {
          if (_this2.options.missingKeyHandler) {
            _this2.options.missingKeyHandler(l, namespace2, k, updateMissing ? options.defaultValue : res, updateMissing, options);
          } else if (_this2.backendConnector && _this2.backendConnector.saveMissing) {
            _this2.backendConnector.saveMissing(l, namespace2, k, updateMissing ? options.defaultValue : res, updateMissing, options);
          }
          _this2.emit("missingKey", l, namespace2, k, res);
        };
        if (this.options.saveMissing) {
          if (this.options.saveMissingPlurals && options.count) {
            lngs.forEach(function(l) {
              var plurals = _this2.pluralResolver.getPluralFormsOfKey(l, key);
              plurals.forEach(function(p) {
                return send([l], p);
              });
            });
          } else {
            send(lngs, key);
          }
        }
      }
      res = this.extendTranslation(res, keys, options);
      if (usedKey && res === key && this.options.appendNamespaceToMissingKey)
        res = namespace2 + ":" + key;
      if (usedKey && this.options.parseMissingKeyHandler)
        res = this.options.parseMissingKeyHandler(res);
    }
    return res;
  };
  Translator2.prototype.extendTranslation = function extendTranslation(res, key, options) {
    var _this3 = this;
    if (options.interpolation)
      this.interpolator.init(_extends$4({}, options, { interpolation: _extends$4({}, this.options.interpolation, options.interpolation) }));
    var data = options.replace && typeof options.replace !== "string" ? options.replace : options;
    if (this.options.interpolation.defaultVariables)
      data = _extends$4({}, this.options.interpolation.defaultVariables, data);
    res = this.interpolator.interpolate(res, data, options.lng || this.language);
    if (options.nest !== false)
      res = this.interpolator.nest(res, function() {
        return _this3.translate.apply(_this3, arguments);
      }, options);
    if (options.interpolation)
      this.interpolator.reset();
    var postProcess = options.postProcess || this.options.postProcess;
    var postProcessorNames = typeof postProcess === "string" ? [postProcess] : postProcess;
    if (res !== void 0 && res !== null && postProcessorNames && postProcessorNames.length && options.applyPostProcessor !== false) {
      res = postProcessor.handle(postProcessorNames, res, key, options, this);
    }
    return res;
  };
  Translator2.prototype.resolve = function resolve(keys) {
    var _this4 = this;
    var options = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    var found = void 0;
    var usedKey = void 0;
    if (typeof keys === "string")
      keys = [keys];
    keys.forEach(function(k) {
      if (_this4.isValidLookup(found))
        return;
      var extracted = _this4.extractFromKey(k, options);
      var key = extracted.key;
      usedKey = key;
      var namespaces = extracted.namespaces;
      if (_this4.options.fallbackNS)
        namespaces = namespaces.concat(_this4.options.fallbackNS);
      var needsPluralHandling = options.count !== void 0 && typeof options.count !== "string";
      var needsContextHandling = options.context !== void 0 && typeof options.context === "string" && options.context !== "";
      var codes = options.lngs ? options.lngs : _this4.languageUtils.toResolveHierarchy(options.lng || _this4.language);
      namespaces.forEach(function(ns) {
        if (_this4.isValidLookup(found))
          return;
        codes.forEach(function(code) {
          if (_this4.isValidLookup(found))
            return;
          var finalKey = key;
          var finalKeys = [finalKey];
          var pluralSuffix = void 0;
          if (needsPluralHandling)
            pluralSuffix = _this4.pluralResolver.getSuffix(code, options.count);
          if (needsPluralHandling && needsContextHandling)
            finalKeys.push(finalKey + pluralSuffix);
          if (needsContextHandling)
            finalKeys.push(finalKey += "" + _this4.options.contextSeparator + options.context);
          if (needsPluralHandling)
            finalKeys.push(finalKey += pluralSuffix);
          var possibleKey = void 0;
          while (possibleKey = finalKeys.pop()) {
            if (!_this4.isValidLookup(found)) {
              found = _this4.getResource(code, ns, possibleKey, options);
            }
          }
        });
      });
    });
    return { res: found, usedKey };
  };
  Translator2.prototype.isValidLookup = function isValidLookup(res) {
    return res !== void 0 && !(!this.options.returnNull && res === null) && !(!this.options.returnEmptyString && res === "");
  };
  Translator2.prototype.getResource = function getResource(code, ns, key) {
    var options = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : {};
    return this.resourceStore.getResource(code, ns, key, options);
  };
  return Translator2;
}(EventEmitter);
function _classCallCheck$5(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function capitalize(string) {
  return string.charAt(0).toUpperCase() + string.slice(1);
}
var LanguageUtil = function() {
  function LanguageUtil2(options) {
    _classCallCheck$5(this, LanguageUtil2);
    this.options = options;
    this.whitelist = this.options.whitelist || false;
    this.logger = baseLogger.create("languageUtils");
  }
  LanguageUtil2.prototype.getScriptPartFromCode = function getScriptPartFromCode(code) {
    if (!code || code.indexOf("-") < 0)
      return null;
    var p = code.split("-");
    if (p.length === 2)
      return null;
    p.pop();
    return this.formatLanguageCode(p.join("-"));
  };
  LanguageUtil2.prototype.getLanguagePartFromCode = function getLanguagePartFromCode(code) {
    if (!code || code.indexOf("-") < 0)
      return code;
    var p = code.split("-");
    return this.formatLanguageCode(p[0]);
  };
  LanguageUtil2.prototype.formatLanguageCode = function formatLanguageCode(code) {
    if (typeof code === "string" && code.indexOf("-") > -1) {
      var specialCases = ["hans", "hant", "latn", "cyrl", "cans", "mong", "arab"];
      var p = code.split("-");
      if (this.options.lowerCaseLng) {
        p = p.map(function(part) {
          return part.toLowerCase();
        });
      } else if (p.length === 2) {
        p[0] = p[0].toLowerCase();
        p[1] = p[1].toUpperCase();
        if (specialCases.indexOf(p[1].toLowerCase()) > -1)
          p[1] = capitalize(p[1].toLowerCase());
      } else if (p.length === 3) {
        p[0] = p[0].toLowerCase();
        if (p[1].length === 2)
          p[1] = p[1].toUpperCase();
        if (p[0] !== "sgn" && p[2].length === 2)
          p[2] = p[2].toUpperCase();
        if (specialCases.indexOf(p[1].toLowerCase()) > -1)
          p[1] = capitalize(p[1].toLowerCase());
        if (specialCases.indexOf(p[2].toLowerCase()) > -1)
          p[2] = capitalize(p[2].toLowerCase());
      }
      return p.join("-");
    }
    return this.options.cleanCode || this.options.lowerCaseLng ? code.toLowerCase() : code;
  };
  LanguageUtil2.prototype.isWhitelisted = function isWhitelisted(code) {
    if (this.options.load === "languageOnly" || this.options.nonExplicitWhitelist) {
      code = this.getLanguagePartFromCode(code);
    }
    return !this.whitelist || !this.whitelist.length || this.whitelist.indexOf(code) > -1;
  };
  LanguageUtil2.prototype.getFallbackCodes = function getFallbackCodes(fallbacks, code) {
    if (!fallbacks)
      return [];
    if (typeof fallbacks === "string")
      fallbacks = [fallbacks];
    if (Object.prototype.toString.apply(fallbacks) === "[object Array]")
      return fallbacks;
    if (!code)
      return fallbacks.default || [];
    var found = fallbacks[code];
    if (!found)
      found = fallbacks[this.getScriptPartFromCode(code)];
    if (!found)
      found = fallbacks[this.formatLanguageCode(code)];
    if (!found)
      found = fallbacks.default;
    return found || [];
  };
  LanguageUtil2.prototype.toResolveHierarchy = function toResolveHierarchy(code, fallbackCode) {
    var _this = this;
    var fallbackCodes = this.getFallbackCodes(fallbackCode || this.options.fallbackLng || [], code);
    var codes = [];
    var addCode = function addCode2(c) {
      if (!c)
        return;
      if (_this.isWhitelisted(c)) {
        codes.push(c);
      } else {
        _this.logger.warn("rejecting non-whitelisted language code: " + c);
      }
    };
    if (typeof code === "string" && code.indexOf("-") > -1) {
      if (this.options.load !== "languageOnly")
        addCode(this.formatLanguageCode(code));
      if (this.options.load !== "languageOnly" && this.options.load !== "currentOnly")
        addCode(this.getScriptPartFromCode(code));
      if (this.options.load !== "currentOnly")
        addCode(this.getLanguagePartFromCode(code));
    } else if (typeof code === "string") {
      addCode(this.formatLanguageCode(code));
    }
    fallbackCodes.forEach(function(fc) {
      if (codes.indexOf(fc) < 0)
        addCode(_this.formatLanguageCode(fc));
    });
    return codes;
  };
  return LanguageUtil2;
}();
function _classCallCheck$4(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
var sets = [{ lngs: ["ach", "ak", "am", "arn", "br", "fil", "gun", "ln", "mfe", "mg", "mi", "oc", "pt", "pt-BR", "tg", "ti", "tr", "uz", "wa"], nr: [1, 2], fc: 1 }, { lngs: ["af", "an", "ast", "az", "bg", "bn", "ca", "da", "de", "dev", "el", "en", "eo", "es", "et", "eu", "fi", "fo", "fur", "fy", "gl", "gu", "ha", "he", "hi", "hu", "hy", "ia", "it", "kn", "ku", "lb", "mai", "ml", "mn", "mr", "nah", "nap", "nb", "ne", "nl", "nn", "no", "nso", "pa", "pap", "pms", "ps", "pt-PT", "rm", "sco", "se", "si", "so", "son", "sq", "sv", "sw", "ta", "te", "tk", "ur", "yo"], nr: [1, 2], fc: 2 }, { lngs: ["ay", "bo", "cgg", "fa", "id", "ja", "jbo", "ka", "kk", "km", "ko", "ky", "lo", "ms", "sah", "su", "th", "tt", "ug", "vi", "wo", "zh"], nr: [1], fc: 3 }, { lngs: ["be", "bs", "dz", "hr", "ru", "sr", "uk"], nr: [1, 2, 5], fc: 4 }, { lngs: ["ar"], nr: [0, 1, 2, 3, 11, 100], fc: 5 }, { lngs: ["cs", "sk"], nr: [1, 2, 5], fc: 6 }, { lngs: ["csb", "pl"], nr: [1, 2, 5], fc: 7 }, { lngs: ["cy"], nr: [1, 2, 3, 8], fc: 8 }, { lngs: ["fr"], nr: [1, 2], fc: 9 }, { lngs: ["ga"], nr: [1, 2, 3, 7, 11], fc: 10 }, { lngs: ["gd"], nr: [1, 2, 3, 20], fc: 11 }, { lngs: ["is"], nr: [1, 2], fc: 12 }, { lngs: ["jv"], nr: [0, 1], fc: 13 }, { lngs: ["kw"], nr: [1, 2, 3, 4], fc: 14 }, { lngs: ["lt"], nr: [1, 2, 10], fc: 15 }, { lngs: ["lv"], nr: [1, 2, 0], fc: 16 }, { lngs: ["mk"], nr: [1, 2], fc: 17 }, { lngs: ["mnk"], nr: [0, 1, 2], fc: 18 }, { lngs: ["mt"], nr: [1, 2, 11, 20], fc: 19 }, { lngs: ["or"], nr: [2, 1], fc: 2 }, { lngs: ["ro"], nr: [1, 2, 20], fc: 20 }, { lngs: ["sl"], nr: [5, 1, 2, 3], fc: 21 }];
var _rulesPluralsTypes = {
  1: function _(n) {
    return Number(n > 1);
  },
  2: function _2(n) {
    return Number(n != 1);
  },
  3: function _3(n) {
    return 0;
  },
  4: function _4(n) {
    return Number(n % 10 == 1 && n % 100 != 11 ? 0 : n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 10 || n % 100 >= 20) ? 1 : 2);
  },
  5: function _5(n) {
    return Number(n === 0 ? 0 : n == 1 ? 1 : n == 2 ? 2 : n % 100 >= 3 && n % 100 <= 10 ? 3 : n % 100 >= 11 ? 4 : 5);
  },
  6: function _6(n) {
    return Number(n == 1 ? 0 : n >= 2 && n <= 4 ? 1 : 2);
  },
  7: function _7(n) {
    return Number(n == 1 ? 0 : n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 10 || n % 100 >= 20) ? 1 : 2);
  },
  8: function _8(n) {
    return Number(n == 1 ? 0 : n == 2 ? 1 : n != 8 && n != 11 ? 2 : 3);
  },
  9: function _9(n) {
    return Number(n >= 2);
  },
  10: function _10(n) {
    return Number(n == 1 ? 0 : n == 2 ? 1 : n < 7 ? 2 : n < 11 ? 3 : 4);
  },
  11: function _11(n) {
    return Number(n == 1 || n == 11 ? 0 : n == 2 || n == 12 ? 1 : n > 2 && n < 20 ? 2 : 3);
  },
  12: function _12(n) {
    return Number(n % 10 != 1 || n % 100 == 11);
  },
  13: function _13(n) {
    return Number(n !== 0);
  },
  14: function _14(n) {
    return Number(n == 1 ? 0 : n == 2 ? 1 : n == 3 ? 2 : 3);
  },
  15: function _15(n) {
    return Number(n % 10 == 1 && n % 100 != 11 ? 0 : n % 10 >= 2 && (n % 100 < 10 || n % 100 >= 20) ? 1 : 2);
  },
  16: function _16(n) {
    return Number(n % 10 == 1 && n % 100 != 11 ? 0 : n !== 0 ? 1 : 2);
  },
  17: function _17(n) {
    return Number(n == 1 || n % 10 == 1 ? 0 : 1);
  },
  18: function _18(n) {
    return Number(n == 0 ? 0 : n == 1 ? 1 : 2);
  },
  19: function _19(n) {
    return Number(n == 1 ? 0 : n === 0 || n % 100 > 1 && n % 100 < 11 ? 1 : n % 100 > 10 && n % 100 < 20 ? 2 : 3);
  },
  20: function _20(n) {
    return Number(n == 1 ? 0 : n === 0 || n % 100 > 0 && n % 100 < 20 ? 1 : 2);
  },
  21: function _21(n) {
    return Number(n % 100 == 1 ? 1 : n % 100 == 2 ? 2 : n % 100 == 3 || n % 100 == 4 ? 3 : 0);
  }
};
function createRules() {
  var rules = {};
  sets.forEach(function(set) {
    set.lngs.forEach(function(l) {
      rules[l] = {
        numbers: set.nr,
        plurals: _rulesPluralsTypes[set.fc]
      };
    });
  });
  return rules;
}
var PluralResolver = function() {
  function PluralResolver2(languageUtils) {
    var options = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    _classCallCheck$4(this, PluralResolver2);
    this.languageUtils = languageUtils;
    this.options = options;
    this.logger = baseLogger.create("pluralResolver");
    this.rules = createRules();
  }
  PluralResolver2.prototype.addRule = function addRule(lng, obj) {
    this.rules[lng] = obj;
  };
  PluralResolver2.prototype.getRule = function getRule(code) {
    return this.rules[code] || this.rules[this.languageUtils.getLanguagePartFromCode(code)];
  };
  PluralResolver2.prototype.needsPlural = function needsPlural(code) {
    var rule = this.getRule(code);
    return rule && rule.numbers.length > 1;
  };
  PluralResolver2.prototype.getPluralFormsOfKey = function getPluralFormsOfKey(code, key) {
    var _this = this;
    var ret = [];
    var rule = this.getRule(code);
    if (!rule)
      return ret;
    rule.numbers.forEach(function(n) {
      var suffix = _this.getSuffix(code, n);
      ret.push("" + key + suffix);
    });
    return ret;
  };
  PluralResolver2.prototype.getSuffix = function getSuffix(code, count) {
    var _this2 = this;
    var rule = this.getRule(code);
    if (rule) {
      var idx = rule.noAbs ? rule.plurals(count) : rule.plurals(Math.abs(count));
      var suffix = rule.numbers[idx];
      if (this.options.simplifyPluralSuffix && rule.numbers.length === 2 && rule.numbers[0] === 1) {
        if (suffix === 2) {
          suffix = "plural";
        } else if (suffix === 1) {
          suffix = "";
        }
      }
      var returnSuffix = function returnSuffix2() {
        return _this2.options.prepend && suffix.toString() ? _this2.options.prepend + suffix.toString() : suffix.toString();
      };
      if (this.options.compatibilityJSON === "v1") {
        if (suffix === 1)
          return "";
        if (typeof suffix === "number")
          return "_plural_" + suffix.toString();
        return returnSuffix();
      } else if (
        /* v2 */
        this.options.compatibilityJSON === "v2" || rule.numbers.length === 2 && rule.numbers[0] === 1
      ) {
        return returnSuffix();
      } else if (
        /* v3 - gettext index */
        rule.numbers.length === 2 && rule.numbers[0] === 1
      ) {
        return returnSuffix();
      }
      return this.options.prepend && idx.toString() ? this.options.prepend + idx.toString() : idx.toString();
    }
    this.logger.warn("no plural rule found for: " + code);
    return "";
  };
  return PluralResolver2;
}();
var _extends$3 = Object.assign || function(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i];
    for (var key in source) {
      if (Object.prototype.hasOwnProperty.call(source, key)) {
        target[key] = source[key];
      }
    }
  }
  return target;
};
function _classCallCheck$3(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
var Interpolator = function() {
  function Interpolator2() {
    var options = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    _classCallCheck$3(this, Interpolator2);
    this.logger = baseLogger.create("interpolator");
    this.init(options, true);
  }
  Interpolator2.prototype.init = function init() {
    var options = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    var reset = arguments[1];
    if (reset) {
      this.options = options;
      this.format = options.interpolation && options.interpolation.format || function(value) {
        return value;
      };
      this.escape = options.interpolation && options.interpolation.escape || escape;
    }
    if (!options.interpolation)
      options.interpolation = { escapeValue: true };
    var iOpts = options.interpolation;
    this.escapeValue = iOpts.escapeValue !== void 0 ? iOpts.escapeValue : true;
    this.prefix = iOpts.prefix ? regexEscape(iOpts.prefix) : iOpts.prefixEscaped || "{{";
    this.suffix = iOpts.suffix ? regexEscape(iOpts.suffix) : iOpts.suffixEscaped || "}}";
    this.formatSeparator = iOpts.formatSeparator ? iOpts.formatSeparator : iOpts.formatSeparator || ",";
    this.unescapePrefix = iOpts.unescapeSuffix ? "" : iOpts.unescapePrefix || "-";
    this.unescapeSuffix = this.unescapePrefix ? "" : iOpts.unescapeSuffix || "";
    this.nestingPrefix = iOpts.nestingPrefix ? regexEscape(iOpts.nestingPrefix) : iOpts.nestingPrefixEscaped || regexEscape("$t(");
    this.nestingSuffix = iOpts.nestingSuffix ? regexEscape(iOpts.nestingSuffix) : iOpts.nestingSuffixEscaped || regexEscape(")");
    this.maxReplaces = iOpts.maxReplaces ? iOpts.maxReplaces : 1e3;
    this.resetRegExp();
  };
  Interpolator2.prototype.reset = function reset() {
    if (this.options)
      this.init(this.options);
  };
  Interpolator2.prototype.resetRegExp = function resetRegExp() {
    var regexpStr = this.prefix + "(.+?)" + this.suffix;
    this.regexp = new RegExp(regexpStr, "g");
    var regexpUnescapeStr = "" + this.prefix + this.unescapePrefix + "(.+?)" + this.unescapeSuffix + this.suffix;
    this.regexpUnescape = new RegExp(regexpUnescapeStr, "g");
    var nestingRegexpStr = this.nestingPrefix + "(.+?)" + this.nestingSuffix;
    this.nestingRegexp = new RegExp(nestingRegexpStr, "g");
  };
  Interpolator2.prototype.interpolate = function interpolate(str, data, lng) {
    var _this = this;
    var match = void 0;
    var value = void 0;
    var replaces = void 0;
    function regexSafe(val) {
      return val.replace(/\$/g, "$$$$");
    }
    var handleFormat = function handleFormat2(key) {
      if (key.indexOf(_this.formatSeparator) < 0)
        return getPath(data, key);
      var p = key.split(_this.formatSeparator);
      var k = p.shift().trim();
      var f = p.join(_this.formatSeparator).trim();
      return _this.format(getPath(data, k), f, lng);
    };
    this.resetRegExp();
    replaces = 0;
    while (match = this.regexpUnescape.exec(str)) {
      value = handleFormat(match[1].trim());
      str = str.replace(match[0], value);
      this.regexpUnescape.lastIndex = 0;
      replaces++;
      if (replaces >= this.maxReplaces) {
        break;
      }
    }
    replaces = 0;
    while (match = this.regexp.exec(str)) {
      value = handleFormat(match[1].trim());
      if (typeof value !== "string")
        value = makeString(value);
      if (!value) {
        if (typeof this.options.missingInterpolationHandler === "function") {
          var temp = this.options.missingInterpolationHandler(str, match);
          value = typeof temp === "string" ? temp : "";
        } else {
          this.logger.warn("missed to pass in variable " + match[1] + " for interpolating " + str);
          value = "";
        }
      }
      value = this.escapeValue ? regexSafe(this.escape(value)) : regexSafe(value);
      str = str.replace(match[0], value);
      this.regexp.lastIndex = 0;
      replaces++;
      if (replaces >= this.maxReplaces) {
        break;
      }
    }
    return str;
  };
  Interpolator2.prototype.nest = function nest(str, fc) {
    var options = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
    var match = void 0;
    var value = void 0;
    var clonedOptions = _extends$3({}, options);
    clonedOptions.applyPostProcessor = false;
    function handleHasOptions(key, inheritedOptions) {
      if (key.indexOf(",") < 0)
        return key;
      var p = key.split(",");
      key = p.shift();
      var optionsString = p.join(",");
      optionsString = this.interpolate(optionsString, clonedOptions);
      optionsString = optionsString.replace(/'/g, '"');
      try {
        clonedOptions = JSON.parse(optionsString);
        if (inheritedOptions)
          clonedOptions = _extends$3({}, inheritedOptions, clonedOptions);
      } catch (e) {
        this.logger.error("failed parsing options string in nesting for key " + key, e);
      }
      return key;
    }
    while (match = this.nestingRegexp.exec(str)) {
      value = fc(handleHasOptions.call(this, match[1].trim(), clonedOptions), clonedOptions);
      if (value && match[0] === str && typeof value !== "string")
        return value;
      if (typeof value !== "string")
        value = makeString(value);
      if (!value) {
        this.logger.warn("missed to resolve " + match[1] + " for nesting " + str);
        value = "";
      }
      str = str.replace(match[0], value);
      this.regexp.lastIndex = 0;
    }
    return str;
  };
  return Interpolator2;
}();
var _extends$2 = Object.assign || function(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i];
    for (var key in source) {
      if (Object.prototype.hasOwnProperty.call(source, key)) {
        target[key] = source[key];
      }
    }
  }
  return target;
};
var _slicedToArray = /* @__PURE__ */ function() {
  function sliceIterator(arr, i) {
    var _arr = [];
    var _n = true;
    var _d = false;
    var _e = void 0;
    try {
      for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) {
        _arr.push(_s.value);
        if (i && _arr.length === i)
          break;
      }
    } catch (err) {
      _d = true;
      _e = err;
    } finally {
      try {
        if (!_n && _i["return"])
          _i["return"]();
      } finally {
        if (_d)
          throw _e;
      }
    }
    return _arr;
  }
  return function(arr, i) {
    if (Array.isArray(arr)) {
      return arr;
    } else if (Symbol.iterator in Object(arr)) {
      return sliceIterator(arr, i);
    } else {
      throw new TypeError("Invalid attempt to destructure non-iterable instance");
    }
  };
}();
function _defaults$2(obj, defaults) {
  var keys = Object.getOwnPropertyNames(defaults);
  for (var i = 0; i < keys.length; i++) {
    var key = keys[i];
    var value = Object.getOwnPropertyDescriptor(defaults, key);
    if (value && value.configurable && obj[key] === void 0) {
      Object.defineProperty(obj, key, value);
    }
  }
  return obj;
}
function _classCallCheck$2(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn$2(self2, call) {
  if (!self2) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self2;
}
function _inherits$2(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : _defaults$2(subClass, superClass);
}
function remove(arr, what) {
  var found = arr.indexOf(what);
  while (found !== -1) {
    arr.splice(found, 1);
    found = arr.indexOf(what);
  }
}
var Connector$1 = function(_EventEmitter) {
  _inherits$2(Connector2, _EventEmitter);
  function Connector2(backend, store, services) {
    var options = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : {};
    _classCallCheck$2(this, Connector2);
    var _this = _possibleConstructorReturn$2(this, _EventEmitter.call(this));
    _this.backend = backend;
    _this.store = store;
    _this.languageUtils = services.languageUtils;
    _this.options = options;
    _this.logger = baseLogger.create("backendConnector");
    _this.state = {};
    _this.queue = [];
    if (_this.backend && _this.backend.init) {
      _this.backend.init(services, options.backend, options);
    }
    return _this;
  }
  Connector2.prototype.queueLoad = function queueLoad(languages, namespaces, callback) {
    var _this2 = this;
    var toLoad = [];
    var pending = [];
    var toLoadLanguages = [];
    var toLoadNamespaces = [];
    languages.forEach(function(lng) {
      var hasAllNamespaces = true;
      namespaces.forEach(function(ns) {
        var name = lng + "|" + ns;
        if (_this2.store.hasResourceBundle(lng, ns)) {
          _this2.state[name] = 2;
        } else if (_this2.state[name] < 0)
          ;
        else if (_this2.state[name] === 1) {
          if (pending.indexOf(name) < 0)
            pending.push(name);
        } else {
          _this2.state[name] = 1;
          hasAllNamespaces = false;
          if (pending.indexOf(name) < 0)
            pending.push(name);
          if (toLoad.indexOf(name) < 0)
            toLoad.push(name);
          if (toLoadNamespaces.indexOf(ns) < 0)
            toLoadNamespaces.push(ns);
        }
      });
      if (!hasAllNamespaces)
        toLoadLanguages.push(lng);
    });
    if (toLoad.length || pending.length) {
      this.queue.push({
        pending,
        loaded: {},
        errors: [],
        callback
      });
    }
    return {
      toLoad,
      pending,
      toLoadLanguages,
      toLoadNamespaces
    };
  };
  Connector2.prototype.loaded = function loaded(name, err, data) {
    var _this3 = this;
    var _name$split = name.split("|"), _name$split2 = _slicedToArray(_name$split, 2), lng = _name$split2[0], ns = _name$split2[1];
    if (err)
      this.emit("failedLoading", lng, ns, err);
    if (data) {
      this.store.addResourceBundle(lng, ns, data);
    }
    this.state[name] = err ? -1 : 2;
    this.queue.forEach(function(q) {
      pushPath(q.loaded, [lng], ns);
      remove(q.pending, name);
      if (err)
        q.errors.push(err);
      if (q.pending.length === 0 && !q.done) {
        _this3.emit("loaded", q.loaded);
        q.done = true;
        if (q.errors.length) {
          q.callback(q.errors);
        } else {
          q.callback();
        }
      }
    });
    this.queue = this.queue.filter(function(q) {
      return !q.done;
    });
  };
  Connector2.prototype.read = function read2(lng, ns, fcName) {
    var tried = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : 0;
    var _this4 = this;
    var wait = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : 250;
    var callback = arguments[5];
    if (!lng.length)
      return callback(null, {});
    return this.backend[fcName](lng, ns, function(err, data) {
      if (err && data && tried < 5) {
        setTimeout(function() {
          _this4.read.call(_this4, lng, ns, fcName, tried + 1, wait * 2, callback);
        }, wait);
        return;
      }
      callback(err, data);
    });
  };
  Connector2.prototype.load = function load(languages, namespaces, callback) {
    var _this5 = this;
    if (!this.backend) {
      this.logger.warn("No backend was added via i18next.use. Will not load resources.");
      return callback && callback();
    }
    var options = _extends$2({}, this.backend.options, this.options.backend);
    if (typeof languages === "string")
      languages = this.languageUtils.toResolveHierarchy(languages);
    if (typeof namespaces === "string")
      namespaces = [namespaces];
    var toLoad = this.queueLoad(languages, namespaces, callback);
    if (!toLoad.toLoad.length) {
      if (!toLoad.pending.length)
        callback();
      return null;
    }
    if (options.allowMultiLoading && this.backend.readMulti) {
      this.read(toLoad.toLoadLanguages, toLoad.toLoadNamespaces, "readMulti", null, null, function(err, data) {
        if (err)
          _this5.logger.warn("loading namespaces " + toLoad.toLoadNamespaces.join(", ") + " for languages " + toLoad.toLoadLanguages.join(", ") + " via multiloading failed", err);
        if (!err && data)
          _this5.logger.log("successfully loaded namespaces " + toLoad.toLoadNamespaces.join(", ") + " for languages " + toLoad.toLoadLanguages.join(", ") + " via multiloading", data);
        toLoad.toLoad.forEach(function(name) {
          var _name$split3 = name.split("|"), _name$split4 = _slicedToArray(_name$split3, 2), l = _name$split4[0], n = _name$split4[1];
          var bundle = getPath(data, [l, n]);
          if (bundle) {
            _this5.loaded(name, err, bundle);
          } else {
            var error2 = "loading namespace " + n + " for language " + l + " via multiloading failed";
            _this5.loaded(name, error2);
            _this5.logger.error(error2);
          }
        });
      });
    } else {
      toLoad.toLoad.forEach(function(name) {
        _this5.loadOne(name);
      });
    }
  };
  Connector2.prototype.reload = function reload(languages, namespaces) {
    var _this6 = this;
    if (!this.backend) {
      this.logger.warn("No backend was added via i18next.use. Will not load resources.");
    }
    var options = _extends$2({}, this.backend.options, this.options.backend);
    if (typeof languages === "string")
      languages = this.languageUtils.toResolveHierarchy(languages);
    if (typeof namespaces === "string")
      namespaces = [namespaces];
    if (options.allowMultiLoading && this.backend.readMulti) {
      this.read(languages, namespaces, "readMulti", null, null, function(err, data) {
        if (err)
          _this6.logger.warn("reloading namespaces " + namespaces.join(", ") + " for languages " + languages.join(", ") + " via multiloading failed", err);
        if (!err && data)
          _this6.logger.log("successfully reloaded namespaces " + namespaces.join(", ") + " for languages " + languages.join(", ") + " via multiloading", data);
        languages.forEach(function(l) {
          namespaces.forEach(function(n) {
            var bundle = getPath(data, [l, n]);
            if (bundle) {
              _this6.loaded(l + "|" + n, err, bundle);
            } else {
              var error2 = "reloading namespace " + n + " for language " + l + " via multiloading failed";
              _this6.loaded(l + "|" + n, error2);
              _this6.logger.error(error2);
            }
          });
        });
      });
    } else {
      languages.forEach(function(l) {
        namespaces.forEach(function(n) {
          _this6.loadOne(l + "|" + n, "re");
        });
      });
    }
  };
  Connector2.prototype.loadOne = function loadOne(name) {
    var _this7 = this;
    var prefix = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "";
    var _name$split5 = name.split("|"), _name$split6 = _slicedToArray(_name$split5, 2), lng = _name$split6[0], ns = _name$split6[1];
    this.read(lng, ns, "read", null, null, function(err, data) {
      if (err)
        _this7.logger.warn(prefix + "loading namespace " + ns + " for language " + lng + " failed", err);
      if (!err && data)
        _this7.logger.log(prefix + "loaded namespace " + ns + " for language " + lng, data);
      _this7.loaded(name, err, data);
    });
  };
  Connector2.prototype.saveMissing = function saveMissing(languages, namespace2, key, fallbackValue, isUpdate) {
    var options = arguments.length > 5 && arguments[5] !== void 0 ? arguments[5] : {};
    if (this.backend && this.backend.create) {
      this.backend.create(languages, namespace2, key, fallbackValue, null, _extends$2({}, options, { isUpdate }));
    }
    if (!languages || !languages[0])
      return;
    this.store.addResource(languages[0], namespace2, key, fallbackValue);
  };
  return Connector2;
}(EventEmitter);
var _extends$1 = Object.assign || function(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i];
    for (var key in source) {
      if (Object.prototype.hasOwnProperty.call(source, key)) {
        target[key] = source[key];
      }
    }
  }
  return target;
};
function _defaults$1(obj, defaults) {
  var keys = Object.getOwnPropertyNames(defaults);
  for (var i = 0; i < keys.length; i++) {
    var key = keys[i];
    var value = Object.getOwnPropertyDescriptor(defaults, key);
    if (value && value.configurable && obj[key] === void 0) {
      Object.defineProperty(obj, key, value);
    }
  }
  return obj;
}
function _classCallCheck$1(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn$1(self2, call) {
  if (!self2) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self2;
}
function _inherits$1(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : _defaults$1(subClass, superClass);
}
var Connector = function(_EventEmitter) {
  _inherits$1(Connector2, _EventEmitter);
  function Connector2(cache, store, services) {
    var options = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : {};
    _classCallCheck$1(this, Connector2);
    var _this = _possibleConstructorReturn$1(this, _EventEmitter.call(this));
    _this.cache = cache;
    _this.store = store;
    _this.services = services;
    _this.options = options;
    _this.logger = baseLogger.create("cacheConnector");
    if (_this.cache && _this.cache.init)
      _this.cache.init(services, options.cache, options);
    return _this;
  }
  Connector2.prototype.load = function load(languages, namespaces, callback) {
    var _this2 = this;
    if (!this.cache)
      return callback && callback();
    var options = _extends$1({}, this.cache.options, this.options.cache);
    var loadLngs = typeof languages === "string" ? this.services.languageUtils.toResolveHierarchy(languages) : languages;
    if (options.enabled) {
      this.cache.load(loadLngs, function(err, data) {
        if (err)
          _this2.logger.error("loading languages " + loadLngs.join(", ") + " from cache failed", err);
        if (data) {
          for (var l in data) {
            if (Object.prototype.hasOwnProperty.call(data, l)) {
              for (var n in data[l]) {
                if (Object.prototype.hasOwnProperty.call(data[l], n)) {
                  if (n !== "i18nStamp") {
                    var bundle = data[l][n];
                    if (bundle)
                      _this2.store.addResourceBundle(l, n, bundle);
                  }
                }
              }
            }
          }
        }
        if (callback)
          callback();
      });
    } else if (callback) {
      callback();
    }
  };
  Connector2.prototype.save = function save() {
    if (this.cache && this.options.cache && this.options.cache.enabled)
      this.cache.save(this.store.data);
  };
  return Connector2;
}(EventEmitter);
function get() {
  return {
    debug: false,
    initImmediate: true,
    ns: ["translation"],
    defaultNS: ["translation"],
    fallbackLng: ["dev"],
    fallbackNS: false,
    // string or array of namespaces
    whitelist: false,
    // array with whitelisted languages
    nonExplicitWhitelist: false,
    load: "all",
    // | currentOnly | languageOnly
    preload: false,
    // array with preload languages
    simplifyPluralSuffix: true,
    keySeparator: ".",
    nsSeparator: ":",
    pluralSeparator: "_",
    contextSeparator: "_",
    saveMissing: false,
    // enable to send missing values
    updateMissing: false,
    // enable to update default values if different from translated value (only useful on initial development, or when keeping code as source of truth)
    saveMissingTo: "fallback",
    // 'current' || 'all'
    saveMissingPlurals: true,
    // will save all forms not only singular key
    missingKeyHandler: false,
    // function(lng, ns, key, fallbackValue) -> override if prefer on handling
    missingInterpolationHandler: false,
    // function(str, match)
    postProcess: false,
    // string or array of postProcessor names
    returnNull: true,
    // allows null value as valid translation
    returnEmptyString: true,
    // allows empty string value as valid translation
    returnObjects: false,
    joinArrays: false,
    // or string to join array
    returnedObjectHandler: function returnedObjectHandler() {
    },
    // function(key, value, options) triggered if key returns object but returnObjects is set to false
    parseMissingKeyHandler: false,
    // function(key) parsed a key that was not found in t() before returning
    appendNamespaceToMissingKey: false,
    appendNamespaceToCIMode: false,
    overloadTranslationOptionHandler: function handle2(args) {
      var ret = {};
      if (args[1])
        ret.defaultValue = args[1];
      if (args[2])
        ret.tDescription = args[2];
      return ret;
    },
    interpolation: {
      escapeValue: true,
      format: function format(value, _format, lng) {
        return value;
      },
      prefix: "{{",
      suffix: "}}",
      formatSeparator: ",",
      // prefixEscaped: '{{',
      // suffixEscaped: '}}',
      // unescapeSuffix: '',
      unescapePrefix: "-",
      nestingPrefix: "$t(",
      nestingSuffix: ")",
      // nestingPrefixEscaped: '$t(',
      // nestingSuffixEscaped: ')',
      // defaultVariables: undefined // object that can have values to interpolate on - extends passed in interpolation data
      maxReplaces: 1e3
      // max replaces to prevent endless loop
    }
  };
}
function transformOptions(options) {
  if (typeof options.ns === "string")
    options.ns = [options.ns];
  if (typeof options.fallbackLng === "string")
    options.fallbackLng = [options.fallbackLng];
  if (typeof options.fallbackNS === "string")
    options.fallbackNS = [options.fallbackNS];
  if (options.whitelist && options.whitelist.indexOf("cimode") < 0) {
    options.whitelist = options.whitelist.concat(["cimode"]);
  }
  return options;
}
var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function(obj) {
  return typeof obj;
} : function(obj) {
  return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
};
var _extends = Object.assign || function(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i];
    for (var key in source) {
      if (Object.prototype.hasOwnProperty.call(source, key)) {
        target[key] = source[key];
      }
    }
  }
  return target;
};
function _defaults(obj, defaults) {
  var keys = Object.getOwnPropertyNames(defaults);
  for (var i = 0; i < keys.length; i++) {
    var key = keys[i];
    var value = Object.getOwnPropertyDescriptor(defaults, key);
    if (value && value.configurable && obj[key] === void 0) {
      Object.defineProperty(obj, key, value);
    }
  }
  return obj;
}
function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn(self2, call) {
  if (!self2) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self2;
}
function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : _defaults(subClass, superClass);
}
function noop() {
}
var I18n = function(_EventEmitter) {
  _inherits(I18n2, _EventEmitter);
  function I18n2() {
    var options = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    var callback = arguments[1];
    _classCallCheck(this, I18n2);
    var _this = _possibleConstructorReturn(this, _EventEmitter.call(this));
    _this.options = transformOptions(options);
    _this.services = {};
    _this.logger = baseLogger;
    _this.modules = { external: [] };
    if (callback && !_this.isInitialized && !options.isClone) {
      var _ret;
      if (!_this.options.initImmediate)
        return _ret = _this.init(options, callback), _possibleConstructorReturn(_this, _ret);
      setTimeout(function() {
        _this.init(options, callback);
      }, 0);
    }
    return _this;
  }
  I18n2.prototype.init = function init() {
    var _this2 = this;
    var options = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    var callback = arguments[1];
    if (typeof options === "function") {
      callback = options;
      options = {};
    }
    this.options = _extends({}, get(), this.options, transformOptions(options));
    this.format = this.options.interpolation.format;
    if (!callback)
      callback = noop;
    function createClassOnDemand(ClassOrObject) {
      if (!ClassOrObject)
        return null;
      if (typeof ClassOrObject === "function")
        return new ClassOrObject();
      return ClassOrObject;
    }
    if (!this.options.isClone) {
      if (this.modules.logger) {
        baseLogger.init(createClassOnDemand(this.modules.logger), this.options);
      } else {
        baseLogger.init(null, this.options);
      }
      var lu = new LanguageUtil(this.options);
      this.store = new ResourceStore(this.options.resources, this.options);
      var s = this.services;
      s.logger = baseLogger;
      s.resourceStore = this.store;
      s.resourceStore.on("added removed", function(lng, ns) {
        s.cacheConnector.save();
      });
      s.languageUtils = lu;
      s.pluralResolver = new PluralResolver(lu, { prepend: this.options.pluralSeparator, compatibilityJSON: this.options.compatibilityJSON, simplifyPluralSuffix: this.options.simplifyPluralSuffix });
      s.interpolator = new Interpolator(this.options);
      s.backendConnector = new Connector$1(createClassOnDemand(this.modules.backend), s.resourceStore, s, this.options);
      s.backendConnector.on("*", function(event) {
        for (var _len = arguments.length, args = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
          args[_key - 1] = arguments[_key];
        }
        _this2.emit.apply(_this2, [event].concat(args));
      });
      s.backendConnector.on("loaded", function(loaded) {
        s.cacheConnector.save();
      });
      s.cacheConnector = new Connector(createClassOnDemand(this.modules.cache), s.resourceStore, s, this.options);
      s.cacheConnector.on("*", function(event) {
        for (var _len2 = arguments.length, args = Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
          args[_key2 - 1] = arguments[_key2];
        }
        _this2.emit.apply(_this2, [event].concat(args));
      });
      if (this.modules.languageDetector) {
        s.languageDetector = createClassOnDemand(this.modules.languageDetector);
        s.languageDetector.init(s, this.options.detection, this.options);
      }
      this.translator = new Translator(this.services, this.options);
      this.translator.on("*", function(event) {
        for (var _len3 = arguments.length, args = Array(_len3 > 1 ? _len3 - 1 : 0), _key3 = 1; _key3 < _len3; _key3++) {
          args[_key3 - 1] = arguments[_key3];
        }
        _this2.emit.apply(_this2, [event].concat(args));
      });
      this.modules.external.forEach(function(m) {
        if (m.init)
          m.init(_this2);
      });
    }
    var storeApi = ["getResource", "addResource", "addResources", "addResourceBundle", "removeResourceBundle", "hasResourceBundle", "getResourceBundle"];
    storeApi.forEach(function(fcName) {
      _this2[fcName] = function() {
        var _store;
        return (_store = _this2.store)[fcName].apply(_store, arguments);
      };
    });
    var load = function load2() {
      _this2.changeLanguage(_this2.options.lng, function(err, t) {
        _this2.isInitialized = true;
        _this2.logger.log("initialized", _this2.options);
        _this2.emit("initialized", _this2.options);
        callback(err, t);
      });
    };
    if (this.options.resources || !this.options.initImmediate) {
      load();
    } else {
      setTimeout(load, 0);
    }
    return this;
  };
  I18n2.prototype.loadResources = function loadResources() {
    var _this3 = this;
    var callback = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : noop;
    if (!this.options.resources) {
      if (this.language && this.language.toLowerCase() === "cimode")
        return callback();
      var toLoad = [];
      var append = function append2(lng) {
        if (!lng)
          return;
        var lngs = _this3.services.languageUtils.toResolveHierarchy(lng);
        lngs.forEach(function(l) {
          if (toLoad.indexOf(l) < 0)
            toLoad.push(l);
        });
      };
      if (!this.language) {
        var fallbacks = this.services.languageUtils.getFallbackCodes(this.options.fallbackLng);
        fallbacks.forEach(function(l) {
          return append(l);
        });
      } else {
        append(this.language);
      }
      if (this.options.preload) {
        this.options.preload.forEach(function(l) {
          return append(l);
        });
      }
      this.services.cacheConnector.load(toLoad, this.options.ns, function() {
        _this3.services.backendConnector.load(toLoad, _this3.options.ns, callback);
      });
    } else {
      callback(null);
    }
  };
  I18n2.prototype.reloadResources = function reloadResources(lngs, ns) {
    if (!lngs)
      lngs = this.languages;
    if (!ns)
      ns = this.options.ns;
    this.services.backendConnector.reload(lngs, ns);
  };
  I18n2.prototype.use = function use(module) {
    if (module.type === "backend") {
      this.modules.backend = module;
    }
    if (module.type === "cache") {
      this.modules.cache = module;
    }
    if (module.type === "logger" || module.log && module.warn && module.error) {
      this.modules.logger = module;
    }
    if (module.type === "languageDetector") {
      this.modules.languageDetector = module;
    }
    if (module.type === "postProcessor") {
      postProcessor.addPostProcessor(module);
    }
    if (module.type === "3rdParty") {
      this.modules.external.push(module);
    }
    return this;
  };
  I18n2.prototype.changeLanguage = function changeLanguage(lng, callback) {
    var _this4 = this;
    var done = function done2(err, l) {
      _this4.translator.changeLanguage(l);
      if (l) {
        _this4.emit("languageChanged", l);
        _this4.logger.log("languageChanged", l);
      }
      if (callback)
        callback(err, function() {
          return _this4.t.apply(_this4, arguments);
        });
    };
    var setLng = function setLng2(l) {
      if (l) {
        _this4.language = l;
        _this4.languages = _this4.services.languageUtils.toResolveHierarchy(l);
        if (!_this4.translator.language)
          _this4.translator.changeLanguage(l);
        if (_this4.services.languageDetector)
          _this4.services.languageDetector.cacheUserLanguage(l);
      }
      _this4.loadResources(function(err) {
        done(err, l);
      });
    };
    if (!lng && this.services.languageDetector && !this.services.languageDetector.async) {
      setLng(this.services.languageDetector.detect());
    } else if (!lng && this.services.languageDetector && this.services.languageDetector.async) {
      this.services.languageDetector.detect(setLng);
    } else {
      setLng(lng);
    }
  };
  I18n2.prototype.getFixedT = function getFixedT(lng, ns) {
    var _this5 = this;
    var fixedT = function fixedT2(key, opts) {
      for (var _len4 = arguments.length, rest = Array(_len4 > 2 ? _len4 - 2 : 0), _key4 = 2; _key4 < _len4; _key4++) {
        rest[_key4 - 2] = arguments[_key4];
      }
      var options = _extends({}, opts);
      if ((typeof opts === "undefined" ? "undefined" : _typeof(opts)) !== "object") {
        options = _this5.options.overloadTranslationOptionHandler([key, opts].concat(rest));
      }
      options.lng = options.lng || fixedT2.lng;
      options.lngs = options.lngs || fixedT2.lngs;
      options.ns = options.ns || fixedT2.ns;
      return _this5.t(key, options);
    };
    if (typeof lng === "string") {
      fixedT.lng = lng;
    } else {
      fixedT.lngs = lng;
    }
    fixedT.ns = ns;
    return fixedT;
  };
  I18n2.prototype.t = function t() {
    var _translator;
    return this.translator && (_translator = this.translator).translate.apply(_translator, arguments);
  };
  I18n2.prototype.exists = function exists() {
    var _translator2;
    return this.translator && (_translator2 = this.translator).exists.apply(_translator2, arguments);
  };
  I18n2.prototype.setDefaultNamespace = function setDefaultNamespace(ns) {
    this.options.defaultNS = ns;
  };
  I18n2.prototype.loadNamespaces = function loadNamespaces(ns, callback) {
    var _this6 = this;
    if (!this.options.ns)
      return callback && callback();
    if (typeof ns === "string")
      ns = [ns];
    ns.forEach(function(n) {
      if (_this6.options.ns.indexOf(n) < 0)
        _this6.options.ns.push(n);
    });
    this.loadResources(callback);
  };
  I18n2.prototype.loadLanguages = function loadLanguages(lngs, callback) {
    if (typeof lngs === "string")
      lngs = [lngs];
    var preloaded = this.options.preload || [];
    var newLngs = lngs.filter(function(lng) {
      return preloaded.indexOf(lng) < 0;
    });
    if (!newLngs.length)
      return callback();
    this.options.preload = preloaded.concat(newLngs);
    this.loadResources(callback);
  };
  I18n2.prototype.dir = function dir(lng) {
    if (!lng)
      lng = this.languages && this.languages.length > 0 ? this.languages[0] : this.language;
    if (!lng)
      return "rtl";
    var rtlLngs = ["ar", "shu", "sqr", "ssh", "xaa", "yhd", "yud", "aao", "abh", "abv", "acm", "acq", "acw", "acx", "acy", "adf", "ads", "aeb", "aec", "afb", "ajp", "apc", "apd", "arb", "arq", "ars", "ary", "arz", "auz", "avl", "ayh", "ayl", "ayn", "ayp", "bbz", "pga", "he", "iw", "ps", "pbt", "pbu", "pst", "prp", "prd", "ur", "ydd", "yds", "yih", "ji", "yi", "hbo", "men", "xmn", "fa", "jpr", "peo", "pes", "prs", "dv", "sam"];
    return rtlLngs.indexOf(this.services.languageUtils.getLanguagePartFromCode(lng)) >= 0 ? "rtl" : "ltr";
  };
  I18n2.prototype.createInstance = function createInstance() {
    var options = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    var callback = arguments[1];
    return new I18n2(options, callback);
  };
  I18n2.prototype.cloneInstance = function cloneInstance() {
    var _this7 = this;
    var options = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    var callback = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : noop;
    var mergedOptions = _extends({}, this.options, options, { isClone: true });
    var clone = new I18n2(mergedOptions);
    var membersToCopy = ["store", "services", "language"];
    membersToCopy.forEach(function(m) {
      clone[m] = _this7[m];
    });
    clone.translator = new Translator(clone.services, clone.options);
    clone.translator.on("*", function(event) {
      for (var _len5 = arguments.length, args = Array(_len5 > 1 ? _len5 - 1 : 0), _key5 = 1; _key5 < _len5; _key5++) {
        args[_key5 - 1] = arguments[_key5];
      }
      clone.emit.apply(clone, [event].concat(args));
    });
    clone.init(mergedOptions, callback);
    clone.translator.options = clone.options;
    return clone;
  };
  return I18n2;
}(EventEmitter);
const i18next = new I18n();
i18next.changeLanguage.bind(i18next);
i18next.cloneInstance.bind(i18next);
i18next.createInstance.bind(i18next);
i18next.dir.bind(i18next);
i18next.exists.bind(i18next);
i18next.getFixedT.bind(i18next);
i18next.init.bind(i18next);
i18next.loadLanguages.bind(i18next);
i18next.loadNamespaces.bind(i18next);
i18next.loadResources.bind(i18next);
i18next.off.bind(i18next);
i18next.on.bind(i18next);
i18next.setDefaultNamespace.bind(i18next);
i18next.t.bind(i18next);
i18next.use.bind(i18next);
if (!i18next.isInitialized) {
  i18next.init({
    resources: void 0,
    lng: "en",
    fallbackLng: "en",
    debug: false,
    ns: ["translation"],
    defaultNS: "translation",
    fallbackNS: false,
    nsSeparator: false,
    returnEmptyString: false,
    returnObjects: false,
    keySeparator: false,
    react: {
      wait: true
    }
  });
}
const StatusIcon = (_ref) => {
  let {
    error: error2,
    warning,
    valid,
    loading
  } = _ref;
  if (error2) {
    return /* @__PURE__ */ React.createElement(SvgErrorFilled24, {
      color: theme.error
    });
  }
  if (warning) {
    return /* @__PURE__ */ React.createElement(SvgWarningFilled24, {
      color: theme.warning
    });
  }
  if (valid) {
    return /* @__PURE__ */ React.createElement(SvgCheckmark24, {
      color: theme.valid
    });
  }
  if (loading) {
    return /* @__PURE__ */ React.createElement(CircularLoader, {
      small: true
    });
  }
  return null;
};
StatusIcon.propTypes = {
  error: PropTypes.bool,
  loading: PropTypes.bool,
  valid: PropTypes.bool,
  warning: PropTypes.bool
};
function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, { value, enumerable: true, configurable: true, writable: true });
  } else {
    obj[key] = value;
  }
  return obj;
}
const styles$2 = [".input.jsx-31445346{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;gap:".concat(spacers.dp8, ";}"), "input.jsx-31445346{box-sizing:border-box;font-size:14px;line-height:16px;-webkit-user-select:text;-moz-user-select:text;-ms-user-select:text;user-select:text;color:".concat(colors.grey900, ";background-color:white;padding:11px 12px;max-height:40px;outline:0;border:1px solid ").concat(colors.grey500, ";border-radius:3px;box-shadow:inset 0 0 1px 0 rgba(48,54,60,0.1);text-overflow:ellipsis;}"), "input.dense.jsx-31445346{max-height:32px;padding:7px 8px;}", "input.jsx-31445346:focus{outline:none;box-shadow:inset 0 0 0 2px ".concat(theme.focus, ";border-color:").concat(theme.focus, ";}"), "input.jsx-31445346::-webkit-input-placeholder{color:".concat(colors.grey600, ";opacity:1;}"), "input.jsx-31445346::-moz-placeholder{color:".concat(colors.grey600, ";opacity:1;}"), "input.jsx-31445346:-ms-input-placeholder{color:".concat(colors.grey600, ";opacity:1;}"), "input.jsx-31445346::placeholder{color:".concat(colors.grey600, ";opacity:1;}"), "input[type='date'].jsx-31445346::-webkit-inner-spin-button,input[type='date'].jsx-31445346::-webkit-calendar-picker-indicator,input[type='time'].jsx-31445346::-webkit-inner-spin-button,input[type='time'].jsx-31445346::-webkit-calendar-picker-indicator,input[type='datetime-local'].jsx-31445346::-webkit-inner-spin-button,input[type='datetime-local'].jsx-31445346::-webkit-calendar-picker-indicator{height:14px;padding-top:1px;padding-bottom:1px;}", "input[type='date'].jsx-31445346::-webkit-datetime-edit-fields-wrapper,input[type='datetime-local'].jsx-31445346::-webkit-datetime-edit-fields-wrapper,input[type='time'].jsx-31445346::-webkit-datetime-edit-fields-wrapper{padding:0;}", "input.warning.jsx-31445346{border-color:".concat(theme.warning, ";}"), "input.error.jsx-31445346{border-color:".concat(theme.error, ";}"), "input.read-only.jsx-31445346{background-color:".concat(colors.grey050, ";border-color:").concat(colors.grey300, ";box-shadow:none;cursor:text;}"), "input.disabled.jsx-31445346{background-color:".concat(colors.grey100, ";border-color:").concat(colors.grey500, ";color:").concat(theme.disabled, ";cursor:not-allowed;}")];
styles$2.__hash = "31445346";
class Input extends reactExports.Component {
  constructor() {
    super(...arguments);
    _defineProperty(this, "inputRef", /* @__PURE__ */ React.createRef());
    _defineProperty(this, "handleChange", (e) => {
      if (this.props.onChange) {
        this.props.onChange(this.createHandlerPayload(e), e);
      }
    });
    _defineProperty(this, "handleBlur", (e) => {
      if (this.props.onBlur) {
        this.props.onBlur(this.createHandlerPayload(e), e);
      }
    });
    _defineProperty(this, "handleFocus", (e) => {
      if (this.props.onFocus) {
        this.props.onFocus(this.createHandlerPayload(e), e);
      }
    });
    _defineProperty(this, "handleKeyDown", (e) => {
      if (this.props.onKeyDown) {
        this.props.onKeyDown(this.createHandlerPayload(e), e);
      }
    });
  }
  componentDidMount() {
    if (this.props.initialFocus) {
      this.inputRef.current.focus();
    }
  }
  createHandlerPayload(e) {
    return {
      value: e.target.value,
      name: this.props.name
    };
  }
  render() {
    const {
      role,
      className,
      type,
      dense,
      disabled,
      readOnly,
      placeholder: placeholder2,
      name,
      valid,
      error: error2,
      warning,
      loading,
      value,
      tabIndex,
      max: max2,
      min: min2,
      step,
      autoComplete,
      dataTest
    } = this.props;
    return /* @__PURE__ */ React.createElement("div", {
      "data-test": dataTest,
      className: "jsx-3353877153 " + "jsx-".concat(styles$2.__hash) + " " + (cx("input", className) || "")
    }, /* @__PURE__ */ React.createElement("input", {
      role,
      id: name,
      name,
      placeholder: placeholder2,
      ref: this.inputRef,
      type,
      value,
      max: max2,
      min: min2,
      step,
      disabled,
      readOnly,
      tabIndex,
      autoComplete,
      onFocus: this.handleFocus,
      onBlur: this.handleBlur,
      onChange: this.handleChange,
      onKeyDown: this.handleKeyDown,
      className: "jsx-3353877153 " + "jsx-".concat(styles$2.__hash) + " " + (cx({
        dense,
        disabled,
        error: error2,
        valid,
        warning,
        "read-only": readOnly
      }) || "")
    }), /* @__PURE__ */ React.createElement(StatusIcon, {
      error: error2,
      valid,
      loading,
      warning
    }), /* @__PURE__ */ React.createElement(_JSXStyle, {
      id: styles$2.__hash
    }, styles$2), /* @__PURE__ */ React.createElement(_JSXStyle, {
      id: "3353877153"
    }, ["input.jsx-3353877153{width:100%;}"]));
  }
}
Input.defaultProps = {
  type: "text",
  dataTest: "dhis2-uicore-input"
};
Input.propTypes = {
  /** The [native `autocomplete` attribute](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input#attr-autocomplete) */
  autoComplete: PropTypes.string,
  className: PropTypes.string,
  dataTest: PropTypes.string,
  /** Makes the input smaller */
  dense: PropTypes.bool,
  /** Disables the input */
  disabled: PropTypes.bool,
  /** Applies 'error' appearance for validation feedback. Mutually exclusive with `valid` and `warning` props */
  error: statusPropType,
  /** The input grabs initial focus on the page */
  initialFocus: PropTypes.bool,
  /** Adds a loading indicator beside the input */
  loading: PropTypes.bool,
  /** The [native `max` attribute](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input#attr-max), for use when `type` is `'number'` */
  max: PropTypes.string,
  /** The [native `min` attribute](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input#attr-min), for use when `type` is `'number'` */
  min: PropTypes.string,
  /** Name associated with the input. Passed to event handler callbacks in object */
  name: PropTypes.string,
  /** Placeholder text for the input */
  placeholder: PropTypes.string,
  /** Makes the input read-only */
  readOnly: PropTypes.bool,
  /** Sets a role attribute on the input */
  role: PropTypes.string,
  /** The [native `step` attribute](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input#attr-step), for use when `type` is `'number'` */
  step: PropTypes.string,
  tabIndex: PropTypes.string,
  /** The native input `type` attribute */
  type: PropTypes.oneOf(["text", "number", "password", "email", "url", "tel", "date", "datetime", "datetime-local", "month", "week", "time", "search"]),
  /** Applies 'valid' appearance for validation feedback. Mutually exclusive with `error` and `warning` props */
  valid: statusPropType,
  /** Value in the input. Can be used to control the component (recommended). Passed to event handler callbacks in object */
  value: PropTypes.string,
  /** Applies 'warning' appearance for validation feedback. Mutually exclusive with `valid` and `error` props */
  warning: statusPropType,
  /** Called with signature `({ name: string, value: string }, event)` */
  onBlur: PropTypes.func,
  /** Called with signature `({ name: string, value: string }, event)` */
  onChange: PropTypes.func,
  /** Called with signature `({ name: string, value: string }, event)` */
  onFocus: PropTypes.func,
  /** Called with signature `({ name: string, value: string }, event)` */
  onKeyDown: PropTypes.func
};
class InputField extends React.Component {
  render() {
    const {
      className,
      onChange,
      onFocus,
      onKeyDown,
      onBlur,
      initialFocus,
      type,
      dense,
      required,
      label,
      disabled,
      readOnly,
      placeholder: placeholder2,
      name,
      max: max2,
      min: min2,
      step,
      valid,
      error: error2,
      warning,
      loading,
      value,
      tabIndex,
      helpText,
      validationText,
      inputWidth,
      autoComplete,
      dataTest
    } = this.props;
    return /* @__PURE__ */ React.createElement(Field, {
      className,
      dataTest,
      error: error2,
      warning,
      valid,
      helpText,
      validationText,
      label,
      name,
      disabled,
      required
    }, /* @__PURE__ */ React.createElement(Box, {
      width: inputWidth,
      minWidth: "72px"
    }, /* @__PURE__ */ React.createElement(Input, {
      onFocus,
      onKeyDown,
      onBlur,
      onChange,
      name,
      type,
      value: value || "",
      placeholder: placeholder2,
      disabled,
      max: max2,
      min: min2,
      step,
      valid,
      warning,
      error: error2,
      loading,
      dense,
      tabIndex,
      initialFocus,
      readOnly,
      autoComplete
    })));
  }
}
InputField.defaultProps = {
  dataTest: "dhis2-uiwidgets-inputfield"
};
const InputFieldProps = {
  /** The [native `autocomplete` attribute](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input#attr-autocomplete) */
  autoComplete: PropTypes.string,
  className: PropTypes.string,
  dataTest: PropTypes.string,
  /** Makes the input smaller */
  dense: PropTypes.bool,
  /** Disables the input */
  disabled: PropTypes.bool,
  /** Applies 'error' appearance for validation feedback. Mutually exclusive with `valid` and `warning` props */
  error: statusPropType,
  /** Guiding text for how to use this input */
  helpText: PropTypes.string,
  /** The input grabs initial focus on the page */
  initialFocus: PropTypes.bool,
  /** Defines the width of the input. Can be any valid CSS measurement */
  inputWidth: PropTypes.string,
  /** Label text for the input */
  label: PropTypes.string,
  /** Adds a loading indicator beside the input */
  loading: PropTypes.bool,
  /** The [native `max` attribute](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input#attr-max), for use when `type` is `'number'` */
  max: PropTypes.string,
  /** The [native `min` attribute](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input#attr-min), for use when `type` is `'number'` */
  min: PropTypes.string,
  /** Name associated with the input. Passed to event handler callbacks in object */
  name: PropTypes.string,
  /** Placeholder text for the input */
  placeholder: PropTypes.string,
  /** Makes the input read-only */
  readOnly: PropTypes.bool,
  /** Indicates this input is required */
  required: PropTypes.bool,
  /** The [native `step` attribute](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input#attr-step), for use when `type` is `'number'` */
  step: PropTypes.string,
  tabIndex: PropTypes.string,
  /** Type of input */
  type: Input.propTypes.type,
  /** Applies 'valid' appearance for validation feedback. Mutually exclusive with `error` and `warning` props */
  valid: statusPropType,
  /** Text below input for validation feedback. Receives styles depending on validation status */
  validationText: PropTypes.string,
  /** Value in the input. Can be used to control the component (recommended). Passed to event handler callbacks in object */
  value: PropTypes.string,
  /** Applies 'warning' appearance for validation feedback. Mutually exclusive with `valid` and `error` props */
  warning: statusPropType,
  /** Called with signature `({ name: string, value: string }, event)` */
  onBlur: PropTypes.func,
  /** Called with signature `({ name: string, value: string }, event)` */
  onChange: PropTypes.func,
  /** Called with signature `({ name: string, value: string }, event)` */
  onFocus: PropTypes.func,
  /** Called with signature `({ name: string, value: string }, event)` */
  onKeyDown: PropTypes.func
};
InputField.propTypes = InputFieldProps;
const Card = (_ref) => {
  let {
    className,
    children,
    dataTest
  } = _ref;
  return /* @__PURE__ */ React.createElement("div", {
    "data-test": dataTest,
    className: _JSXStyle.dynamic([["3454125090", [colors.white, elevations.e100]]]) + " " + (cx(className) || "")
  }, children, /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "3454125090",
    dynamic: [colors.white, elevations.e100]
  }, ["div.__jsx-style-dynamic-selector{display:inline-block;position:relative;width:100%;height:100%;border-radius:3px;background:".concat(colors.white, ";box-shadow:").concat(elevations.e100, ";}")]));
};
Card.defaultProps = {
  dataTest: "dhis2-uicore-card"
};
Card.propTypes = {
  children: PropTypes.node,
  className: PropTypes.string,
  dataTest: PropTypes.string
};
const Center = /* @__PURE__ */ reactExports.forwardRef((_ref, ref) => {
  let {
    className,
    dataTest,
    children,
    position
  } = _ref;
  return /* @__PURE__ */ React.createElement("div", {
    "data-test": dataTest,
    ref,
    className: "jsx-498096601 " + (cx("center", className, position) || "")
  }, /* @__PURE__ */ React.createElement("div", {
    className: "jsx-498096601 center-inner-content"
  }, children), /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "498096601"
  }, [".center.jsx-498096601{width:100%;height:100%;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-pack:space-around;-webkit-justify-content:space-around;-ms-flex-pack:space-around;justify-content:space-around;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;pointer-events:none;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;}", ".center.top.jsx-498096601{-webkit-align-items:flex-start;-webkit-box-align:flex-start;-ms-flex-align:flex-start;align-items:flex-start;}", ".center.bottom.jsx-498096601{-webkit-align-items:flex-end;-webkit-box-align:flex-end;-ms-flex-align:flex-end;align-items:flex-end;}", ".center-inner-content.jsx-498096601{pointer-events:all;}"]));
});
Center.displayName = "Center";
Center.defaultProps = {
  dataTest: "dhis2-uicore-centeredcontent",
  position: "middle"
};
Center.propTypes = {
  children: PropTypes.node,
  className: PropTypes.string,
  dataTest: PropTypes.string,
  /** Vertical alignment */
  position: PropTypes.oneOf(["top", "middle", "bottom"])
};
const Divider = (_ref) => {
  let {
    className,
    dataTest,
    dense,
    margin
  } = _ref;
  return /* @__PURE__ */ React.createElement("div", {
    "data-test": dataTest,
    className: _JSXStyle.dynamic([["3889267139", [colors.grey300]], ["3486645161", [dense ? "".concat(spacers.dp4, " 0") : margin]]]) + " " + (className || "")
  }, /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "3889267139",
    dynamic: [colors.grey300]
  }, ["div.__jsx-style-dynamic-selector{display:inline-block;width:100%;height:1px;background-color:".concat(colors.grey300, ";}")]), /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "3486645161",
    dynamic: [dense ? "".concat(spacers.dp4, " 0") : margin]
  }, ["div.__jsx-style-dynamic-selector{margin:".concat(dense ? "".concat(spacers.dp4, " 0") : margin, ";}")]));
};
Divider.defaultProps = {
  dataTest: "dhis2-uicore-divider",
  margin: "".concat(spacers.dp8, " 0")
};
Divider.propTypes = {
  className: PropTypes.string,
  dataTest: PropTypes.string,
  dense: PropTypes.bool,
  margin: PropTypes.string
};
const joinPath = function() {
  for (var _len = arguments.length, parts = new Array(_len), _key = 0; _key < _len; _key++) {
    parts[_key] = arguments[_key];
  }
  const realParts = parts.filter((part) => !!part);
  return realParts.map((part) => part.replace(/^\/+|\/+$/g, "")).join("/");
};
const Close$w = "إغلاق";
const Online$y = "متصل";
const Offline$y = "غير متصل";
const Settings$y = "الإعدادات";
const Account$y = "الحساب";
const Help$y = "مساعدة";
const Logout$y = "تسجيل الخروج";
const arTranslations = {
  "Search apps": "البحث في التطبيقات",
  "DHIS2 {{dhis2Version}}": "",
  "DHIS2 version unknown": "",
  "{{appName}} version unknown": "",
  "App {{appVersion}}": "",
  "App version unknown": "",
  "Debug info": "",
  Close: Close$w,
  "Copy debug info": "",
  "Last online {{relativeTime}}": "",
  Online: Online$y,
  Offline: Offline$y,
  "Edit profile": "تعديل ملف التعريف",
  Settings: Settings$y,
  Account: Account$y,
  Help: Help$y,
  "About DHIS2": "حول DHIS2",
  Logout: Logout$y,
  "New {{appName}} version available": "",
  "New app version available": "",
  "Click to reload": ""
};
const Close$v = "إغلاق";
const Online$x = "متصل";
const Offline$x = "غير متصل";
const Settings$x = "";
const Account$x = "";
const Help$x = "";
const Logout$x = "";
const ar_IQTranslations = {
  "Search apps": "",
  "DHIS2 {{dhis2Version}}": "",
  "DHIS2 version unknown": "",
  "{{appName}} version unknown": "",
  "App {{appVersion}}": "",
  "App version unknown": "",
  "Debug info": "",
  Close: Close$v,
  "Copy debug info": "",
  "Last online {{relativeTime}}": "",
  Online: Online$x,
  Offline: Offline$x,
  "Edit profile": "",
  Settings: Settings$x,
  Account: Account$x,
  Help: Help$x,
  "About DHIS2": "",
  Logout: Logout$x,
  "New {{appName}} version available": "",
  "New app version available": "",
  "Click to reload": ""
};
const Online$w = "";
const Offline$w = "";
const Settings$w = "";
const Account$w = "";
const Help$w = "";
const Logout$w = "";
const bnTranslations = {
  "Search apps": "",
  "Last online {{relativeTime}}": "",
  Online: Online$w,
  Offline: Offline$w,
  "Edit profile": "প্রোফাইল সম্পাদন করুন",
  Settings: Settings$w,
  Account: Account$w,
  Help: Help$w,
  "About DHIS2": "",
  Logout: Logout$w
};
const Close$u = "داخستن";
const Online$v = "ئۆنڵاین";
const Offline$v = "ئۆفڵاین";
const Settings$v = "ريكخستن";
const Account$v = "";
const Help$v = "هاوكاري";
const Logout$v = "";
const ckbTranslations = {
  "Search apps": "",
  "DHIS2 {{dhis2Version}}": "",
  "DHIS2 version unknown": "",
  "{{appName}} version unknown": "",
  "App {{appVersion}}": "",
  "App version unknown": "",
  "Debug info": "",
  Close: Close$u,
  "Copy debug info": "",
  "Last online {{relativeTime}}": "",
  Online: Online$v,
  Offline: Offline$v,
  "Edit profile": "",
  Settings: Settings$v,
  Account: Account$v,
  Help: Help$v,
  "About DHIS2": "",
  Logout: Logout$v,
  "New {{appName}} version available": "",
  "New app version available": "",
  "Click to reload": ""
};
const Close$t = "Zavřít";
const Online$u = "Online";
const Offline$u = "Offline";
const Settings$u = "Nastavení";
const Account$u = "Účet";
const Help$u = "Nápověda";
const Logout$u = "Odhlásit";
const csTranslations = {
  "Search apps": "Hledat aplikace",
  "DHIS2 {{dhis2Version}}": "DHIS2 {{dhis2Version}}",
  "DHIS2 version unknown": "Verze DHIS2 neznámá",
  "{{appName}} version unknown": "Neznámá verze aplikace {{appName}}",
  "App {{appVersion}}": "Aplikace {{appVersion}}",
  "App version unknown": "Verze aplikace neznámá",
  "Debug info": "Informace o ladění",
  Close: Close$t,
  "Copy debug info": "Zkopírovat informace o ladění",
  Online: Online$u,
  Offline: Offline$u,
  "Edit profile": "Upravit profil",
  Settings: Settings$u,
  Account: Account$u,
  Help: Help$u,
  "About DHIS2": "O DHIS2",
  Logout: Logout$u,
  "New {{appName}} version available": "K dispozici je nová verze aplikace {{appName}}",
  "New app version available": "K dispozici nová verze aplikace",
  "Click to reload": "Kliknutím znovu načtete"
};
const Close$s = "Close";
const Online$t = "Online";
const Offline$t = "Offline";
const Settings$t = "Settings";
const Account$t = "Account";
const Help$t = "Help";
const Logout$t = "";
const daTranslations = {
  "Search apps": "Search apps",
  "DHIS2 {{dhis2Version}}": "",
  "DHIS2 version unknown": "",
  "{{appName}} version unknown": "",
  "App {{appVersion}}": "",
  "App version unknown": "",
  "Debug info": "",
  Close: Close$s,
  "Copy debug info": "",
  "Last online {{relativeTime}}": "",
  Online: Online$t,
  Offline: Offline$t,
  "Edit profile": "",
  Settings: Settings$t,
  Account: Account$t,
  Help: Help$t,
  "About DHIS2": "",
  Logout: Logout$t,
  "New {{appName}} version available": "",
  "New app version available": "",
  "Click to reload": ""
};
const Close$r = "Close";
const Online$s = "Online";
const Offline$s = "Offline";
const Settings$s = "Settings";
const Account$s = "Account";
const Help$s = "Help";
const Logout$s = "Logout";
const enTranslations = {
  "Search apps": "Search apps",
  "DHIS2 {{dhis2Version}}": "DHIS2 {{dhis2Version}}",
  "DHIS2 version unknown": "DHIS2 version unknown",
  "{{appName}} version unknown": "{{appName}} version unknown",
  "App {{appVersion}}": "App {{appVersion}}",
  "App version unknown": "App version unknown",
  "Debug info": "Debug info",
  Close: Close$r,
  "Copy debug info": "Copy debug info",
  Online: Online$s,
  Offline: Offline$s,
  "Edit profile": "Edit profile",
  Settings: Settings$s,
  Account: Account$s,
  Help: Help$s,
  "About DHIS2": "About DHIS2",
  Logout: Logout$s,
  "New {{appName}} version available": "New {{appName}} version available",
  "New app version available": "New app version available",
  "Click to reload": "Click to reload"
};
const Close$q = "Cerrar";
const Online$r = "Conectado";
const Offline$r = "Desconectado";
const Settings$r = "Configuración";
const Account$r = "Cuenta";
const Help$r = "Ayuda";
const Logout$r = "Cerrar sesión";
const esTranslations = {
  "Search apps": "Buscar una aplicación",
  "DHIS2 {{dhis2Version}}": "DHIS2 {{dhis2Version}}",
  "DHIS2 version unknown": "Versión desconocida de DHIS2",
  "{{appName}} version unknown": "{{appName}} versión desconocida",
  "App {{appVersion}}": "App {{appVersion}}",
  "App version unknown": "Versión desconocida de la aplicación",
  "Debug info": "Información de depuración",
  Close: Close$q,
  "Copy debug info": "Copiar la información de depuración",
  Online: Online$r,
  Offline: Offline$r,
  "Edit profile": "Editar perfil",
  Settings: Settings$r,
  Account: Account$r,
  Help: Help$r,
  "About DHIS2": "Sobre DHIS2",
  Logout: Logout$r,
  "New {{appName}} version available": "Nueva versión de {{appName}} disponible",
  "New app version available": "Nueva versión de la aplicación disponible",
  "Click to reload": "Clic para recargar"
};
const Close$p = "Cerrar";
const Online$q = "En línea";
const Offline$q = "Offline";
const Settings$q = "Configuración";
const Account$q = "";
const Help$q = "";
const Logout$q = "";
const es_419Translations = {
  "Search apps": "",
  "DHIS2 {{dhis2Version}}": "",
  "DHIS2 version unknown": "",
  "{{appName}} version unknown": "",
  "App {{appVersion}}": "",
  "App version unknown": "",
  "Debug info": "",
  Close: Close$p,
  "Copy debug info": "",
  Online: Online$q,
  Offline: Offline$q,
  "Edit profile": "",
  Settings: Settings$q,
  Account: Account$q,
  Help: Help$q,
  "About DHIS2": "",
  Logout: Logout$q,
  "New {{appName}} version available": "",
  "New app version available": "",
  "Click to reload": ""
};
const Close$o = "Fermer";
const Online$p = "En ligne";
const Offline$p = "Hors ligne";
const Settings$p = "Paramètres";
const Account$p = "Compte";
const Help$p = "Aide";
const Logout$p = "Déconnexion";
const frTranslations = {
  "Search apps": "Chercher applis",
  "DHIS2 {{dhis2Version}}": "",
  "DHIS2 version unknown": "",
  "{{appName}} version unknown": "",
  "App {{appVersion}}": "",
  "App version unknown": "",
  "Debug info": "",
  Close: Close$o,
  "Copy debug info": "",
  "Last online {{relativeTime}}": "",
  Online: Online$p,
  Offline: Offline$p,
  "Edit profile": "Modifier profil",
  Settings: Settings$p,
  Account: Account$p,
  Help: Help$p,
  "About DHIS2": "A propos de DHIS2",
  Logout: Logout$p,
  "New {{appName}} version available": "",
  "New app version available": "",
  "Click to reload": ""
};
const Close$n = "Tutup";
const Online$o = "Online";
const Offline$o = "Offline";
const Settings$o = "Setting";
const Account$o = "Akun";
const Help$o = "Bantuan";
const Logout$o = "Keluar";
const idTranslations = {
  "Search apps": "Cari app",
  "DHIS2 {{dhis2Version}}": "",
  "DHIS2 version unknown": "Versi DHIS2 tidak diketahui",
  "{{appName}} version unknown": "{{appName}} versi tidak diketahui",
  "App {{appVersion}}": "",
  "App version unknown": "",
  "Debug info": "",
  Close: Close$n,
  "Copy debug info": "",
  Online: Online$o,
  Offline: Offline$o,
  "Edit profile": "Edit profil",
  Settings: Settings$o,
  Account: Account$o,
  Help: Help$o,
  "About DHIS2": "Tentang DHIS2",
  Logout: Logout$o,
  "New {{appName}} version available": "Baru {{appName}} Versi tersedia",
  "New app version available": "Tersedia aplikasi versi baru",
  "Click to reload": "Klik untuk mengunggah ulang"
};
const Close$m = "បិទ";
const Online$n = "លើបណ្ដាញអិនធឺរណែត";
const Offline$n = "ក្រៅ​បណ្ដាញអិនធឺរណែត";
const Settings$n = "ការ​កំណត់";
const Account$n = "គណនី";
const Help$n = "ជំនួយ​";
const Logout$n = "";
const kmTranslations = {
  "Search apps": "ស្វែងរកកម្មវិធី",
  "DHIS2 {{dhis2Version}}": "",
  "DHIS2 version unknown": "",
  "{{appName}} version unknown": "",
  "App {{appVersion}}": "",
  "App version unknown": "",
  "Debug info": "",
  Close: Close$m,
  "Copy debug info": "",
  Online: Online$n,
  Offline: Offline$n,
  "Edit profile": "កែសម្រួល​​ជីវប្រវត្តិ",
  Settings: Settings$n,
  Account: Account$n,
  Help: Help$n,
  "About DHIS2": "",
  Logout: Logout$n,
  "New {{appName}} version available": "",
  "New app version available": "",
  "Click to reload": ""
};
const Close$l = "ປິດ";
const Online$m = "ມີການເຊື່ອມຕໍ່";
const Offline$m = "ບໍ່ມີການເຊື່ອມຕໍ່";
const Settings$m = "ຕັ້ງຄ່າ";
const Account$m = "ບັນຊີ";
const Help$m = "ຊ່ວຍ";
const Logout$m = "";
const loTranslations = {
  "Search apps": "ຄົ້ນຫາແອັບ",
  "DHIS2 {{dhis2Version}}": "",
  "DHIS2 version unknown": "",
  "{{appName}} version unknown": "",
  "App {{appVersion}}": "",
  "App version unknown": "",
  "Debug info": "",
  Close: Close$l,
  "Copy debug info": "",
  "Last online {{relativeTime}}": "",
  Online: Online$m,
  Offline: Offline$m,
  "Edit profile": "ແກ້ໄຂຂໍ້ມູນ",
  Settings: Settings$m,
  Account: Account$m,
  Help: Help$m,
  "About DHIS2": "",
  Logout: Logout$m,
  "New {{appName}} version available": "",
  "New app version available": "",
  "Click to reload": ""
};
const Close$k = "ပိတ်သည်";
const Online$l = "အင်တာနက်နှင့်ချိတ်ဆက်ထားသည်";
const Offline$l = "အင်တာနက်နှင့်မချိတ်ဆက်ထားပါ";
const Settings$l = "တည်ဆောက်ထားသည့်အနေအထား";
const Account$l = "စာရင်း";
const Help$l = "အကူအညီတောင်းခံရန်";
const Logout$l = "";
const myTranslations = {
  "Search apps": "Search apps",
  "DHIS2 {{dhis2Version}}": "",
  "DHIS2 version unknown": "",
  "{{appName}} version unknown": "",
  "App {{appVersion}}": "",
  "App version unknown": "",
  "Debug info": "",
  Close: Close$k,
  "Copy debug info": "",
  "Last online {{relativeTime}}": "",
  Online: Online$l,
  Offline: Offline$l,
  "Edit profile": "အတ္ထုပ္ပတ္တိအကျဉ်းကိုပြင်ဆင်ခြင်း",
  Settings: Settings$l,
  Account: Account$l,
  Help: Help$l,
  "About DHIS2": "",
  Logout: Logout$l,
  "New {{appName}} version available": "",
  "New app version available": "",
  "Click to reload": ""
};
const Close$j = "Lukk";
const Online$k = "Påkoblet";
const Offline$k = "Frakoblet";
const Settings$k = "Innstillinger";
const Account$k = "Brukerkonto";
const Help$k = "Hjelp";
const Logout$k = "Logg ut";
const nbTranslations = {
  "Search apps": "Søk etter apper",
  "DHIS2 {{dhis2Version}}": "DHIS2 {{dhis2Version}}",
  "DHIS2 version unknown": "DHIS2-versjon ukjent",
  "{{appName}} version unknown": "{{appName}} versjon ukjent",
  "App {{appVersion}}": "App {{appVersion}}",
  "App version unknown": "Appversjon ukjent",
  "Debug info": "Feilsøkingsinformasjon",
  Close: Close$j,
  "Copy debug info": "Kopier feilsøkingsinformasjon",
  Online: Online$k,
  Offline: Offline$k,
  "Edit profile": "Rediger profil",
  Settings: Settings$k,
  Account: Account$k,
  Help: Help$k,
  "About DHIS2": "Om DHIS2",
  Logout: Logout$k,
  "New {{appName}} version available": "Ny {{appName}}versjon tilgjengelig",
  "New app version available": "Ny appversjon tilgjengelig",
  "Click to reload": "Klikk for å laste inn på nytt"
};
const Close$i = "Sluit";
const Online$j = "Online";
const Offline$j = "offline";
const Settings$j = "Instellingen";
const Account$j = "Account";
const Help$j = "Hulp";
const Logout$j = "Uitloggen";
const nlTranslations = {
  "Search apps": "Zoek apps",
  "DHIS2 {{dhis2Version}}": "DHIS2 {{dhis2Versie}}",
  "DHIS2 version unknown": "DHIS2-versie onbekend",
  "{{appName}} version unknown": "{{appName}} versie onbekend",
  "App {{appVersion}}": "App {{appVersion}}",
  "App version unknown": "App-versie onbekend",
  "Debug info": "Foutopsporingsinformatie",
  Close: Close$i,
  "Copy debug info": "Foutopsporingsinformatie kopiëren",
  Online: Online$j,
  Offline: Offline$j,
  "Edit profile": "Bewerk profiel",
  Settings: Settings$j,
  Account: Account$j,
  Help: Help$j,
  "About DHIS2": "Over DHIS2",
  Logout: Logout$j,
  "New {{appName}} version available": "Nieuwe {{appName}}-versie beschikbaar",
  "New app version available": "Nieuwe app-versie beschikbaar",
  "Click to reload": "Klik om te herladen"
};
const Online$i = "";
const Offline$i = "";
const Settings$i = "";
const Account$i = "";
const Help$i = "ସହାୟତା";
const Logout$i = "";
const orTranslations = {
  "Search apps": "",
  "Last online {{relativeTime}}": "",
  Online: Online$i,
  Offline: Offline$i,
  "Edit profile": "",
  Settings: Settings$i,
  Account: Account$i,
  Help: Help$i,
  "About DHIS2": "",
  Logout: Logout$i
};
const Close$h = "بستن";
const Online$h = "آنلاین";
const Offline$h = "آفلاین";
const Settings$h = "تنظیمات";
const Account$h = "حساب";
const Help$h = "کمک";
const Logout$h = "";
const prsTranslations = {
  "Search apps": "جستجوی برنامه ها",
  "DHIS2 {{dhis2Version}}": "",
  "DHIS2 version unknown": "",
  "{{appName}} version unknown": "",
  "App {{appVersion}}": "",
  "App version unknown": "",
  "Debug info": "",
  Close: Close$h,
  "Copy debug info": "",
  "Last online {{relativeTime}}": "",
  Online: Online$h,
  Offline: Offline$h,
  "Edit profile": "ویرایش پروفایل",
  Settings: Settings$h,
  Account: Account$h,
  Help: Help$h,
  "About DHIS2": "",
  Logout: Logout$h,
  "New {{appName}} version available": "",
  "New app version available": "",
  "Click to reload": ""
};
const Close$g = "بند یې کړئ";
const Online$g = "په لیکه کې دی";
const Offline$g = "په لیکه کې نشته";
const Settings$g = "تنظیمات";
const Account$g = "حساب";
const Help$g = "مرسته";
const Logout$g = "";
const psTranslations = {
  "Search apps": "د پلټنې اپلیکېشنونه",
  "DHIS2 {{dhis2Version}}": "",
  "DHIS2 version unknown": "",
  "{{appName}} version unknown": "",
  "App {{appVersion}}": "",
  "App version unknown": "",
  "Debug info": "",
  Close: Close$g,
  "Copy debug info": "",
  "Last online {{relativeTime}}": "",
  Online: Online$g,
  Offline: Offline$g,
  "Edit profile": "د مالوماتو یا ځانګړتیاوو تصحیح",
  Settings: Settings$g,
  Account: Account$g,
  Help: Help$g,
  "About DHIS2": "",
  Logout: Logout$g,
  "New {{appName}} version available": "",
  "New app version available": "",
  "Click to reload": ""
};
const Close$f = "Fechar";
const Online$f = "Ligado";
const Offline$f = "Desligado";
const Settings$f = "Configuração";
const Account$f = "Conta";
const Help$f = "Ajuda";
const Logout$f = "";
const ptTranslations = {
  "Search apps": "Pesquisar aplicações",
  "DHIS2 {{dhis2Version}}": "",
  "DHIS2 version unknown": "",
  "{{appName}} version unknown": "",
  "App {{appVersion}}": "",
  "App version unknown": "",
  "Debug info": "",
  Close: Close$f,
  "Copy debug info": "",
  "Last online {{relativeTime}}": "",
  Online: Online$f,
  Offline: Offline$f,
  "Edit profile": "Editar Perfil",
  Settings: Settings$f,
  Account: Account$f,
  Help: Help$f,
  "About DHIS2": "Sobre DHIS2",
  Logout: Logout$f,
  "New {{appName}} version available": "",
  "New app version available": "",
  "Click to reload": ""
};
const Close$e = "Fechar";
const Online$e = "Ligado";
const Offline$e = "Desligado";
const Settings$e = "Configurações";
const Account$e = "Conta";
const Help$e = "Ajuda";
const Logout$e = "";
const pt_BRTranslations = {
  "Search apps": "",
  "DHIS2 {{dhis2Version}}": "",
  "DHIS2 version unknown": "",
  "{{appName}} version unknown": "",
  "App {{appVersion}}": "",
  "App version unknown": "",
  "Debug info": "",
  Close: Close$e,
  "Copy debug info": "",
  "Last online {{relativeTime}}": "",
  Online: Online$e,
  Offline: Offline$e,
  "Edit profile": "Editar Perfil",
  Settings: Settings$e,
  Account: Account$e,
  Help: Help$e,
  "About DHIS2": "",
  Logout: Logout$e,
  "New {{appName}} version available": "",
  "New app version available": "",
  "Click to reload": ""
};
const Close$d = "Închidere";
const Online$d = "Online";
const Offline$d = "Offline";
const Settings$d = "";
const Account$d = "";
const Help$d = "";
const Logout$d = "";
const roTranslations = {
  "Search apps": "",
  "DHIS2 {{dhis2Version}}": "",
  "DHIS2 version unknown": "",
  "{{appName}} version unknown": "",
  "App {{appVersion}}": "",
  "App version unknown": "",
  "Debug info": "",
  Close: Close$d,
  "Copy debug info": "",
  "Last online {{relativeTime}}": "",
  Online: Online$d,
  Offline: Offline$d,
  "Edit profile": "",
  Settings: Settings$d,
  Account: Account$d,
  Help: Help$d,
  "About DHIS2": "",
  Logout: Logout$d,
  "New {{appName}} version available": "",
  "New app version available": "",
  "Click to reload": ""
};
const Close$c = "Закрыть";
const Online$c = "Онлайн";
const Offline$c = "Офлайн";
const Settings$c = "Настройки";
const Account$c = "Учетная запись";
const Help$c = "Помощь";
const Logout$c = "";
const ruTranslations = {
  "Search apps": "Поиск приложений",
  "DHIS2 {{dhis2Version}}": "",
  "DHIS2 version unknown": "",
  "{{appName}} version unknown": "",
  "App {{appVersion}}": "",
  "App version unknown": "",
  "Debug info": "",
  Close: Close$c,
  "Copy debug info": "",
  "Last online {{relativeTime}}": "",
  Online: Online$c,
  Offline: Offline$c,
  "Edit profile": "Редактировать профиль",
  Settings: Settings$c,
  Account: Account$c,
  Help: Help$c,
  "About DHIS2": "",
  Logout: Logout$c,
  "New {{appName}} version available": "",
  "New app version available": "",
  "Click to reload": ""
};
const Close$b = "වසන්න";
const Online$b = "";
const Offline$b = "";
const Settings$b = "";
const Account$b = "";
const Help$b = "උදවු";
const Logout$b = "";
const siTranslations = {
  "Search apps": "",
  "DHIS2 {{dhis2Version}}": "",
  "DHIS2 version unknown": "",
  "{{appName}} version unknown": "",
  "App {{appVersion}}": "",
  "App version unknown": "",
  "Debug info": "",
  Close: Close$b,
  "Copy debug info": "",
  Online: Online$b,
  Offline: Offline$b,
  "Edit profile": "",
  Settings: Settings$b,
  Account: Account$b,
  Help: Help$b,
  "About DHIS2": "",
  Logout: Logout$b,
  "New {{appName}} version available": "",
  "New app version available": "",
  "Click to reload": ""
};
const Close$a = "Stänga";
const Online$a = "Uppkopplad";
const Offline$a = "Off-line";
const Settings$a = "Inställningar";
const Account$a = "Konto";
const Help$a = "Hjälp";
const Logout$a = "";
const svTranslations = {
  "Search apps": "Sök program",
  "DHIS2 {{dhis2Version}}": "",
  "DHIS2 version unknown": "",
  "{{appName}} version unknown": "",
  "App {{appVersion}}": "",
  "App version unknown": "",
  "Debug info": "",
  Close: Close$a,
  "Copy debug info": "",
  "Last online {{relativeTime}}": "",
  Online: Online$a,
  Offline: Offline$a,
  "Edit profile": "Redigera profil",
  Settings: Settings$a,
  Account: Account$a,
  Help: Help$a,
  "About DHIS2": "",
  Logout: Logout$a,
  "New {{appName}} version available": "",
  "New app version available": "",
  "Click to reload": ""
};
const Close$9 = "Taka";
const Online$9 = "Online";
const Offline$9 = "Offline";
const Settings$9 = "Konfigurasaun";
const Account$9 = "Konta";
const Help$9 = "Ajuda";
const Logout$9 = "";
const tetTranslations = {
  "Search apps": "Buka aplikasoens",
  "DHIS2 {{dhis2Version}}": "",
  "DHIS2 version unknown": "",
  "{{appName}} version unknown": "",
  "App {{appVersion}}": "",
  "App version unknown": "",
  "Debug info": "",
  Close: Close$9,
  "Copy debug info": "",
  "Last online {{relativeTime}}": "",
  Online: Online$9,
  Offline: Offline$9,
  "Edit profile": "Edita perfil",
  Settings: Settings$9,
  Account: Account$9,
  Help: Help$9,
  "About DHIS2": "",
  Logout: Logout$9,
  "New {{appName}} version available": "",
  "New app version available": "",
  "Click to reload": ""
};
const Close$8 = "Пӯшидан";
const Online$8 = "Онлайн";
const Offline$8 = "Офлайн";
const Settings$8 = "Танзимот";
const Account$8 = "Ҳисоб";
const Help$8 = "Кӯмак";
const Logout$8 = "";
const tgTranslations = {
  "Search apps": "",
  "DHIS2 {{dhis2Version}}": "",
  "DHIS2 version unknown": "",
  "{{appName}} version unknown": "",
  "App {{appVersion}}": "",
  "App version unknown": "",
  "Debug info": "",
  Close: Close$8,
  "Copy debug info": "",
  "Last online {{relativeTime}}": "",
  Online: Online$8,
  Offline: Offline$8,
  "Edit profile": "Таҳрири профил",
  Settings: Settings$8,
  Account: Account$8,
  Help: Help$8,
  "About DHIS2": "",
  Logout: Logout$8,
  "New {{appName}} version available": "",
  "New app version available": "",
  "Click to reload": ""
};
const Close$7 = "Закрити";
const Online$7 = "Онлайн";
const Offline$7 = "Офлайн";
const Settings$7 = "Налаштування";
const Account$7 = "Обліковий запис";
const Help$7 = "Довідка";
const Logout$7 = "Вийти";
const ukTranslations = {
  "Search apps": "Пошук додатків",
  "DHIS2 {{dhis2Version}}": "",
  "DHIS2 version unknown": "",
  "{{appName}} version unknown": "",
  "App {{appVersion}}": "",
  "App version unknown": "",
  "Debug info": "",
  Close: Close$7,
  "Copy debug info": "",
  Online: Online$7,
  Offline: Offline$7,
  "Edit profile": "Редагувати профіль",
  Settings: Settings$7,
  Account: Account$7,
  Help: Help$7,
  "About DHIS2": "Про DHIS2",
  Logout: Logout$7,
  "New {{appName}} version available": "",
  "New app version available": "",
  "Click to reload": ""
};
const Close$6 = "بند";
const Online$6 = "آن لائن";
const Offline$6 = "آف لائن";
const Settings$6 = "ØªØ±ØªÛØ¨Ø§Øª";
const Account$6 = "اکاؤنٹ";
const Help$6 = "مدد";
const Logout$6 = "";
const urTranslations = {
  "Search apps": "ایپس تلاش کریں",
  "DHIS2 {{dhis2Version}}": "",
  "DHIS2 version unknown": "",
  "{{appName}} version unknown": "",
  "App {{appVersion}}": "",
  "App version unknown": "",
  "Debug info": "",
  Close: Close$6,
  "Copy debug info": "",
  "Last online {{relativeTime}}": "",
  Online: Online$6,
  Offline: Offline$6,
  "Edit profile": "معلومات بدلو",
  Settings: Settings$6,
  Account: Account$6,
  Help: Help$6,
  "About DHIS2": "",
  Logout: Logout$6,
  "New {{appName}} version available": "",
  "New app version available": "",
  "Click to reload": ""
};
const Close$5 = "Yopmoq";
const Online$5 = "Onlayn";
const Offline$5 = "Offlayn";
const Settings$5 = "Sozlamalar";
const Account$5 = "Raqami";
const Help$5 = "Yordam";
const Logout$5 = "Chiqib ketish";
const uz_LatnTranslations = {
  "Search apps": "Ilovalarni qidirish",
  "DHIS2 {{dhis2Version}}": "",
  "DHIS2 version unknown": "",
  "{{appName}} version unknown": "",
  "App {{appVersion}}": "",
  "App version unknown": "",
  "Debug info": "",
  Close: Close$5,
  "Copy debug info": "",
  "Last online {{relativeTime}}": "",
  Online: Online$5,
  Offline: Offline$5,
  "Edit profile": "Profilni tahrir qilish",
  Settings: Settings$5,
  Account: Account$5,
  Help: Help$5,
  "About DHIS2": "DHIS2 Haqida",
  Logout: Logout$5,
  "New {{appName}} version available": "",
  "New app version available": "",
  "Click to reload": ""
};
const Close$4 = "Ёпиш";
const Online$4 = "Онлайн";
const Offline$4 = "Оффлайн";
const Settings$4 = "Созламалар";
const Account$4 = "Рақами";
const Help$4 = "Ёрдам";
const Logout$4 = "Чиқиб кетиш";
const uz_UZ_CyrlTranslations = {
  "Search apps": "Иловаларни қидириш",
  "DHIS2 {{dhis2Version}}": "",
  "DHIS2 version unknown": "",
  "{{appName}} version unknown": "",
  "App {{appVersion}}": "",
  "App version unknown": "",
  "Debug info": "",
  Close: Close$4,
  "Copy debug info": "",
  Online: Online$4,
  Offline: Offline$4,
  "Edit profile": "Профилни таҳрир қилиш",
  Settings: Settings$4,
  Account: Account$4,
  Help: Help$4,
  "About DHIS2": "DHIS2 Ҳақида",
  Logout: Logout$4,
  "New {{appName}} version available": "",
  "New app version available": "",
  "Click to reload": ""
};
const Close$3 = "Yopmoq";
const Online$3 = "Onlayn";
const Offline$3 = "Offlayn";
const Settings$3 = "Sozlamalar";
const Account$3 = "Raqami";
const Help$3 = "Yordam";
const Logout$3 = "Chiqib ketish";
const uz_UZ_LatnTranslations = {
  "Search apps": "Ilovalarni qidirish",
  "DHIS2 {{dhis2Version}}": "",
  "DHIS2 version unknown": "",
  "{{appName}} version unknown": "",
  "App {{appVersion}}": "",
  "App version unknown": "",
  "Debug info": "",
  Close: Close$3,
  "Copy debug info": "",
  Online: Online$3,
  Offline: Offline$3,
  "Edit profile": "Profilni tahrir qilish",
  Settings: Settings$3,
  Account: Account$3,
  Help: Help$3,
  "About DHIS2": "DHIS2 Haqida",
  Logout: Logout$3,
  "New {{appName}} version available": "",
  "New app version available": "",
  "Click to reload": ""
};
const Close$2 = "Đóng";
const Online$2 = "Trực tuyến";
const Offline$2 = "Ngoại tuyến";
const Settings$2 = "Cài đặt";
const Account$2 = "Tài khoản";
const Help$2 = "Giúp đỡ";
const Logout$2 = "Đăng xuất";
const viTranslations = {
  "Search apps": "Tìm kiếm ứng dụng",
  "DHIS2 {{dhis2Version}}": "",
  "DHIS2 version unknown": "",
  "{{appName}} version unknown": "",
  "App {{appVersion}}": "",
  "App version unknown": "",
  "Debug info": "",
  Close: Close$2,
  "Copy debug info": "",
  "Last online {{relativeTime}}": "",
  Online: Online$2,
  Offline: Offline$2,
  "Edit profile": "Chỉnh sửa hồ sơ",
  Settings: Settings$2,
  Account: Account$2,
  Help: Help$2,
  "About DHIS2": "Giới thiệu DHIS2",
  Logout: Logout$2,
  "New {{appName}} version available": "",
  "New app version available": "",
  "Click to reload": ""
};
const Close$1 = "关闭";
const Online$1 = "在线";
const Offline$1 = "离线";
const Settings$1 = "设置";
const Account$1 = "账号";
const Help$1 = "帮助";
const Logout$1 = "退出";
const zhTranslations = {
  "Search apps": "搜索 apps",
  "DHIS2 {{dhis2Version}}": "DHIS2 {{dhis2Version}}",
  "DHIS2 version unknown": "DHIS2 版本未知",
  "{{appName}} version unknown": "{{appName}} 版本未知",
  "App {{appVersion}}": "应用 {{appVersion}}",
  "App version unknown": "应用版本未知",
  "Debug info": "调试信息",
  Close: Close$1,
  "Copy debug info": "复制调试信息",
  Online: Online$1,
  Offline: Offline$1,
  "Edit profile": "编辑简历",
  Settings: Settings$1,
  Account: Account$1,
  Help: Help$1,
  "About DHIS2": "关于DHIS2",
  Logout: Logout$1,
  "New {{appName}} version available": "新的 {{appName}} 版本可用",
  "New app version available": "新的应用程序版本可用",
  "Click to reload": "点击重新加载"
};
const Close = "关闭";
const Online = "在线";
const Offline = "离线";
const Settings = "设置";
const Account = "账户";
const Help = "帮助";
const Logout = "退出";
const zh_CNTranslations = {
  "Search apps": "搜索 apps",
  "DHIS2 {{dhis2Version}}": "",
  "DHIS2 version unknown": "",
  "{{appName}} version unknown": "",
  "App {{appVersion}}": "",
  "App version unknown": "",
  "Debug info": "",
  Close,
  "Copy debug info": "",
  "Last online {{relativeTime}}": "",
  Online,
  Offline,
  "Edit profile": "编辑个人基本信息",
  Settings,
  Account,
  Help,
  "About DHIS2": "关于DHIS2",
  Logout,
  "New {{appName}} version available": "",
  "New app version available": "",
  "Click to reload": ""
};
const namespace = "default";
i18next.addResources("ar", namespace, arTranslations);
i18next.addResources("ar_IQ", namespace, ar_IQTranslations);
i18next.addResources("bn", namespace, bnTranslations);
i18next.addResources("ckb", namespace, ckbTranslations);
i18next.addResources("cs", namespace, csTranslations);
i18next.addResources("da", namespace, daTranslations);
i18next.addResources("en", namespace, enTranslations);
i18next.addResources("es", namespace, esTranslations);
i18next.addResources("es_419", namespace, es_419Translations);
i18next.addResources("fr", namespace, frTranslations);
i18next.addResources("id", namespace, idTranslations);
i18next.addResources("km", namespace, kmTranslations);
i18next.addResources("lo", namespace, loTranslations);
i18next.addResources("my", namespace, myTranslations);
i18next.addResources("nb", namespace, nbTranslations);
i18next.addResources("nl", namespace, nlTranslations);
i18next.addResources("or", namespace, orTranslations);
i18next.addResources("prs", namespace, prsTranslations);
i18next.addResources("ps", namespace, psTranslations);
i18next.addResources("pt", namespace, ptTranslations);
i18next.addResources("pt_BR", namespace, pt_BRTranslations);
i18next.addResources("ro", namespace, roTranslations);
i18next.addResources("ru", namespace, ruTranslations);
i18next.addResources("si", namespace, siTranslations);
i18next.addResources("sv", namespace, svTranslations);
i18next.addResources("tet", namespace, tetTranslations);
i18next.addResources("tg", namespace, tgTranslations);
i18next.addResources("uk", namespace, ukTranslations);
i18next.addResources("ur", namespace, urTranslations);
i18next.addResources("uz_Latn", namespace, uz_LatnTranslations);
i18next.addResources("uz_UZ_Cyrl", namespace, uz_UZ_CyrlTranslations);
i18next.addResources("uz_UZ_Latn", namespace, uz_UZ_LatnTranslations);
i18next.addResources("vi", namespace, viTranslations);
i18next.addResources("zh", namespace, zhTranslations);
i18next.addResources("zh_CN", namespace, zh_CNTranslations);
function escapeRegExpCharacters(text) {
  return text.replace(/[/.*+?^${}()|[\]\\]/g, "\\$&");
}
function Search(_ref) {
  let {
    value,
    onChange
  } = _ref;
  const {
    baseUrl
  } = useConfig();
  return /* @__PURE__ */ React.createElement("div", {
    className: "jsx-4264724627"
  }, /* @__PURE__ */ React.createElement("span", {
    className: "jsx-4264724627"
  }, /* @__PURE__ */ React.createElement(InputField, {
    value,
    name: "filter",
    placeholder: i18next.t("Search apps"),
    onChange,
    initialFocus: true
  })), /* @__PURE__ */ React.createElement("span", {
    className: "jsx-4264724627"
  }, /* @__PURE__ */ React.createElement("a", {
    href: joinPath(baseUrl, "dhis-web-menu-management"),
    className: "jsx-4264724627"
  }, /* @__PURE__ */ React.createElement(SvgSettings24, {
    color: colors.grey700
  }))), /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "4264724627"
  }, ["div.jsx-4264724627{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;-webkit-flex-wrap:nowrap;-ms-flex-wrap:nowrap;flex-wrap:nowrap;height:52px;margin:8px;}", "span.jsx-4264724627{-webkit-flex:1 100%;-ms-flex:1 100%;flex:1 100%;}", "span.jsx-4264724627:last-child{-webkit-flex:1 auto;-ms-flex:1 auto;flex:1 auto;margin:8px;}"]));
}
Search.propTypes = {
  value: PropTypes.string.isRequired,
  onChange: PropTypes.func.isRequired
};
function Item(_ref2) {
  let {
    name,
    path,
    img
  } = _ref2;
  return /* @__PURE__ */ React.createElement("a", {
    href: path,
    className: _JSXStyle.dynamic([["1412616027", [theme.primary050]]])
  }, /* @__PURE__ */ React.createElement("img", {
    src: img,
    alt: "app logo",
    className: _JSXStyle.dynamic([["1412616027", [theme.primary050]]])
  }), /* @__PURE__ */ React.createElement("div", {
    className: _JSXStyle.dynamic([["1412616027", [theme.primary050]]])
  }, name), /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "1412616027",
    dynamic: [theme.primary050]
  }, ["a.__jsx-style-dynamic-selector{display:inline-block;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;width:96px;margin:8px;border-radius:12px;-webkit-text-decoration:none;text-decoration:none;cursor:pointer;}", "a.__jsx-style-dynamic-selector:hover,a.__jsx-style-dynamic-selector:focus{background-color:".concat(theme.primary050, ";cursor:pointer;}"), "a.__jsx-style-dynamic-selector:hover>div.__jsx-style-dynamic-selector{font-weight:500;cursor:pointer;}", "img.__jsx-style-dynamic-selector{width:48px;height:48px;margin:8px;cursor:pointer;}", "div.__jsx-style-dynamic-selector{overflow-wrap:anywhere;margin-top:14px;color:rgba(0,0,0,0.87);font-size:12px;-webkit-letter-spacing:0.01em;-moz-letter-spacing:0.01em;-ms-letter-spacing:0.01em;letter-spacing:0.01em;line-height:14px;text-align:center;cursor:pointer;}"]));
}
Item.propTypes = {
  img: PropTypes.string,
  name: PropTypes.string,
  path: PropTypes.string
};
function List(_ref3) {
  let {
    apps,
    filter
  } = _ref3;
  return /* @__PURE__ */ React.createElement("div", {
    "data-test": "headerbar-apps-menu-list",
    className: "jsx-2076871745"
  }, apps.filter((_ref4) => {
    let {
      displayName,
      name
    } = _ref4;
    const appName = displayName || name;
    const formattedAppName = appName.toLowerCase();
    const formattedFilter = escapeRegExpCharacters(filter).toLowerCase();
    return filter.length > 0 ? formattedAppName.match(formattedFilter) : true;
  }).map((_ref5, idx) => {
    let {
      displayName,
      name,
      defaultAction,
      icon: icon2
    } = _ref5;
    return /* @__PURE__ */ React.createElement(Item, {
      key: "app-".concat(name, "-").concat(idx),
      name: displayName || name,
      path: defaultAction,
      img: icon2
    });
  }), /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "2076871745"
  }, ["div.jsx-2076871745{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;-webkit-flex-wrap:wrap;-ms-flex-wrap:wrap;flex-wrap:wrap;-webkit-align-content:flex-start;-ms-flex-line-pack:start;align-content:flex-start;-webkit-align-items:flex-start;-webkit-box-align:flex-start;-ms-flex-align:flex-start;align-items:flex-start;-webkit-box-pack:start;-webkit-justify-content:flex-start;-ms-flex-pack:start;justify-content:flex-start;width:30vw;min-width:300px;max-width:560px;min-height:200px;max-height:465px;margin:0 8px 8px 8px;overflow:auto;overflow-x:hidden;}"]));
}
List.propTypes = {
  apps: PropTypes.array,
  filter: PropTypes.string
};
const AppMenu = (_ref6) => {
  let {
    apps,
    filter,
    onFilterChange
  } = _ref6;
  return /* @__PURE__ */ React.createElement("div", {
    "data-test": "headerbar-apps-menu",
    className: "jsx-105953480"
  }, /* @__PURE__ */ React.createElement(Card, null, /* @__PURE__ */ React.createElement(Search, {
    value: filter,
    onChange: onFilterChange
  }), /* @__PURE__ */ React.createElement(List, {
    apps,
    filter
  })), /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "105953480"
  }, ["div.jsx-105953480{z-index:10000;position:absolute;right:-4px;}"]));
};
AppMenu.propTypes = {
  apps: PropTypes.array.isRequired,
  onFilterChange: PropTypes.func.isRequired,
  filter: PropTypes.string
};
const Apps = (_ref7) => {
  let {
    apps
  } = _ref7;
  const [show, setShow] = reactExports.useState(false);
  const [filter, setFilter] = reactExports.useState("");
  const handleVisibilityToggle = reactExports.useCallback(() => setShow(!show), [show]);
  const handleFilterChange = reactExports.useCallback((_ref8) => {
    let {
      value
    } = _ref8;
    return setFilter(value);
  }, []);
  const containerEl = reactExports.useRef(null);
  const onDocClick = reactExports.useCallback((evt) => {
    if (containerEl.current && !containerEl.current.contains(evt.target)) {
      setShow(false);
    }
  }, []);
  reactExports.useEffect(() => {
    document.addEventListener("click", onDocClick);
    return () => document.removeEventListener("click", onDocClick);
  }, [onDocClick]);
  return /* @__PURE__ */ React.createElement("div", {
    ref: containerEl,
    "data-test": "headerbar-apps",
    className: _JSXStyle.dynamic([["2891838412", [spacers.dp4, spacers.dp12]]])
  }, /* @__PURE__ */ React.createElement("button", {
    onClick: handleVisibilityToggle,
    "data-test": "headerbar-apps-icon",
    className: _JSXStyle.dynamic([["2891838412", [spacers.dp4, spacers.dp12]]])
  }, /* @__PURE__ */ React.createElement(SvgApps24, {
    color: colors.white
  })), show ? /* @__PURE__ */ React.createElement(AppMenu, {
    apps,
    filter,
    onFilterChange: handleFilterChange
  }) : null, /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "2891838412",
    dynamic: [spacers.dp4, spacers.dp12]
  }, ["button.__jsx-style-dynamic-selector{display:block;background:transparent;padding:".concat(spacers.dp4, " ").concat(spacers.dp12, " 0;border:0;cursor:pointer;height:100%;}"), "button.__jsx-style-dynamic-selector:focus{outline:2px solid white;outline-offset:-2px;}", "button.__jsx-style-dynamic-selector:focus.__jsx-style-dynamic-selector:not(:focus-visible){outline:none;}", "button.__jsx-style-dynamic-selector:hover{background:#1a557f;}", "button.__jsx-style-dynamic-selector:active{background:#104067;}", "div.__jsx-style-dynamic-selector{position:relative;height:100%;}"]));
};
Apps.propTypes = {
  apps: PropTypes.array.isRequired
};
const Apps$1 = Apps;
const headerBarContext = /* @__PURE__ */ reactExports.createContext({
  updateAvailable: false,
  onApplyAvailableUpdate: () => {
  }
});
const HeaderBarContextProvider = (_ref) => {
  let {
    updateAvailable,
    onApplyAvailableUpdate,
    children
  } = _ref;
  return /* @__PURE__ */ React.createElement(headerBarContext.Provider, {
    value: {
      updateAvailable,
      onApplyAvailableUpdate
    }
  }, children);
};
HeaderBarContextProvider.propTypes = {
  children: PropTypes.node,
  updateAvailable: PropTypes.bool,
  onApplyAvailableUpdate: PropTypes.func
};
const useHeaderBarContext = () => reactExports.useContext(headerBarContext);
function LogoIconSvg(_ref) {
  let {
    iconColor,
    className,
    dataTest
  } = _ref;
  return /* @__PURE__ */ React.createElement("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 200 182",
    className,
    "data-test": dataTest
  }, /* @__PURE__ */ React.createElement("defs", null), /* @__PURE__ */ React.createElement("path", {
    fill: iconColor,
    d: "M191.73,60,109,6.34a19.73,19.73,0,0,0-20.32,0L8.31,58.43a12,12,0,0,0-.25,20.63L88.6,134a19.37,19.37,0,0,0,20.37.25l82.76-53.65a11.88,11.88,0,0,0,0-20.59Zm-91,61.45a4.29,4.29,0,0,1-3.49-.05l-77-52.49L97,19.13a4.76,4.76,0,0,1,3.74,0L179.6,70.28Z"
  }), /* @__PURE__ */ React.createElement("path", {
    fill: iconColor,
    d: "M88.66,47.82,45.1,76.06l13.61,9.33L97,60.61a4.76,4.76,0,0,1,3.74,0l39.37,25.52,14-9.06L109,47.82A19.76,19.76,0,0,0,88.66,47.82Z"
  }), /* @__PURE__ */ React.createElement("path", {
    fill: iconColor,
    d: "M191.73,101.46l-8.62-5.59-14.05,9.06,10.53,6.83-78.91,51.15a4.37,4.37,0,0,1-3.49,0l-77-52.5,10-6.47L16.55,94.57,8.31,99.91a12,12,0,0,0-.25,20.63L88.6,175.46a19.34,19.34,0,0,0,20.37.24l82.75-53.65a11.88,11.88,0,0,0,0-20.59Z"
  }));
}
LogoIconSvg.propTypes = {
  iconColor: PropTypes.string.isRequired,
  className: PropTypes.string,
  dataTest: PropTypes.string
};
const white = "#ffffff";
({
  className: PropTypes.string,
  dataTest: PropTypes.string
});
const LogoIconWhite = (_ref2) => {
  let {
    className,
    dataTest
  } = _ref2;
  return /* @__PURE__ */ React.createElement(LogoIconSvg, {
    iconColor: white,
    className,
    dataTest
  });
};
LogoIconWhite.defaultProps = {
  dataTest: "dhis2-uicore-logoiconwhite"
};
LogoIconWhite.propTypes = {
  className: PropTypes.string,
  dataTest: PropTypes.string
};
({
  className: PropTypes.string,
  dataTest: PropTypes.string
});
({
  className: PropTypes.string,
  dataTest: PropTypes.string
});
const logoStyles = {
  styles: /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "3467673193"
  }, ["svg.jsx-3467673193{height:25px;width:27px;}", "img.jsx-3467673193{max-height:100%;min-height:auto;width:auto;}"]),
  className: "jsx-3467673193"
};
const query$1 = {
  customLogo: {
    resource: "staticContent/logo_banner"
  }
};
const pathExists = (data) => data && data.customLogo && data.customLogo.images && data.customLogo.images.png;
const LogoImage = () => {
  const {
    loading,
    error: error2,
    data
  } = useDataQuery(query$1);
  if (loading) {
    return null;
  }
  let Logo2;
  if (!error2 && pathExists(data)) {
    Logo2 = /* @__PURE__ */ React.createElement("img", {
      alt: "Headerbar Logo",
      src: data.customLogo.images.png,
      className: logoStyles.className
    });
  } else {
    Logo2 = /* @__PURE__ */ React.createElement(LogoIconWhite, {
      className: logoStyles.className
    });
  }
  return /* @__PURE__ */ React.createElement("div", {
    className: "jsx-3930434724"
  }, Logo2, logoStyles.styles, /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "3930434724"
  }, ["div.jsx-3930434724{padding:4px;min-width:48px;max-width:250px;height:48px;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;overflow:hidden;}"]));
};
const Logo = () => {
  const {
    baseUrl
  } = useConfig();
  return /* @__PURE__ */ React.createElement("div", {
    "data-test": "headerbar-logo",
    className: "jsx-2077637423"
  }, /* @__PURE__ */ React.createElement("a", {
    href: baseUrl,
    className: "jsx-2077637423"
  }, /* @__PURE__ */ React.createElement(LogoImage, null)), /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "2077637423"
  }, ["div.jsx-2077637423{box-sizing:border-box;min-width:49px;max-height:48px;margin:0 12px 0 0;border-right:1px solid rgba(32,32,32,0.15);}", "div.jsx-2077637423:hover{background-color:#1a557f;}", "a.jsx-2077637423,a.jsx-2077637423:hover,a.jsx-2077637423:focus,a.jsx-2077637423:active,a.jsx-2077637423:visited{-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;}", "a.jsx-2077637423:focus{outline:2px solid white;outline-offset:-2px;}", "a.jsx-2077637423:focus.jsx-2077637423:not(:focus-visible){outline:none;}"]));
};
function icon(kind) {
  if (kind === "message") {
    return /* @__PURE__ */ React.createElement(SvgMessages24, {
      color: colors.white
    });
  } else {
    return /* @__PURE__ */ React.createElement(SvgMail24, {
      color: colors.white
    });
  }
}
const NotificationIcon = (_ref) => {
  let {
    count,
    href,
    kind,
    dataTestId
  } = _ref;
  return /* @__PURE__ */ React.createElement("a", {
    href,
    "data-test": dataTestId,
    className: _JSXStyle.dynamic([["2752984221", [spacers.dp12, spacers.dp12, theme.secondary500, colors.white, spacers.dp4]]]) + " " + (kind || "")
  }, icon(kind), count > 0 && /* @__PURE__ */ React.createElement("span", {
    "data-test": "".concat(dataTestId, "-count"),
    className: _JSXStyle.dynamic([["2752984221", [spacers.dp12, spacers.dp12, theme.secondary500, colors.white, spacers.dp4]]])
  }, count), /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "2752984221",
    dynamic: [spacers.dp12, spacers.dp12, theme.secondary500, colors.white, spacers.dp4]
  }, ["a.__jsx-style-dynamic-selector{position:relative;margin:0;cursor:pointer;padding:0 ".concat(spacers.dp12, ";height:100%;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;}"), "a.__jsx-style-dynamic-selector:focus{outline:2px solid white;outline-offset:-2px;}", "a.__jsx-style-dynamic-selector:focus.__jsx-style-dynamic-selector:not(:focus-visible){outline:none;}", "a.__jsx-style-dynamic-selector:hover{background:#1a557f;}", "a.__jsx-style-dynamic-selector:active{background:#104067;}", "span.__jsx-style-dynamic-selector{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;z-index:1;position:absolute;top:3px;right:2px;min-width:18px;min-height:18px;border-radius:".concat(spacers.dp12, ";box-shadow:0 1px 3px 0 rgba(0,0,0,0.1), 0 1px 2px 0 rgba(0,0,0,0.06);background-color:").concat(theme.secondary500, ";color:").concat(colors.white, ";font-size:13px;font-weight:600;line-height:15px;text-align:center;cursor:inherit;padding:0 ").concat(spacers.dp4, ";}")]));
};
NotificationIcon.defaultProps = {
  count: 0
};
NotificationIcon.propTypes = {
  href: PropTypes.string.isRequired,
  count: PropTypes.number,
  dataTestId: PropTypes.string,
  kind: PropTypes.oneOf(["interpretation", "message"])
};
const hasAuthority = (userAuthorities, authId) => Array.isArray(userAuthorities) && userAuthorities.some((userAuthId) => userAuthId === "ALL" || userAuthId === authId);
const Notifications = (_ref) => {
  let {
    interpretations,
    messages,
    userAuthorities
  } = _ref;
  const {
    baseUrl
  } = useConfig();
  return /* @__PURE__ */ React.createElement("div", {
    "data-test": "headerbar-notifications",
    className: "jsx-55705730"
  }, hasAuthority(userAuthorities, "M_dhis-web-interpretation") && /* @__PURE__ */ React.createElement(NotificationIcon, {
    count: interpretations,
    href: joinPath(baseUrl, "dhis-web-interpretation"),
    kind: "message",
    dataTestId: "headerbar-interpretations"
  }), hasAuthority(userAuthorities, "M_dhis-web-messaging") && /* @__PURE__ */ React.createElement(NotificationIcon, {
    message: "email",
    count: messages,
    href: joinPath(baseUrl, "dhis-web-messaging"),
    kind: "interpretation",
    dataTestId: "headerbar-messages"
  }), /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "55705730"
  }, ["div.jsx-55705730{-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;height:100%;}"]));
};
Notifications.propTypes = {
  interpretations: PropTypes.number,
  messages: PropTypes.number,
  userAuthorities: PropTypes.arrayOf(PropTypes.string)
};
const _defaultExport$1 = [".container.jsx-3029616205{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;background-color:#104167;-webkit-flex-shrink:0;-ms-flex-negative:0;flex-shrink:0;color:".concat(colors.grey100, ";}"), ".container.badge.jsx-3029616205{margin-right:".concat(spacers.dp8, ";padding:").concat(spacers.dp8, ";border-radius:5px;font-size:14px;}"), ".container.bar.jsx-3029616205{display:none;padding:0px ".concat(spacers.dp4, ";min-height:24px;font-size:13px;}"), "@media (max-width:480px){.container.badge.jsx-3029616205{display:none;}.container.bar.jsx-3029616205{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;}}", ".unselectable.jsx-3029616205{cursor:default;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;}", ".info.jsx-3029616205{margin-right:".concat(spacers.dp16, ";}"), ".info-dense.jsx-3029616205{margin-left:".concat(spacers.dp12, ";font-size:12px;}"), ".icon.jsx-3029616205{width:8px;min-width:8px;height:8px;border-radius:8px;margin-right:".concat(spacers.dp4, ";}"), ".icon.online.jsx-3029616205{background-color:".concat(colors.teal400, ";}"), ".icon.offline.jsx-3029616205{background-color:transparent;border:1px solid ".concat(colors.yellow300, ";}"), ".icon.reconnecting.jsx-3029616205{background:".concat(colors.grey300, ";-webkit-animation:fadeinout 2s linear infinite;-webkit-animation:fadeinout-jsx-3029616205 2s linear infinite;animation:fadeinout-jsx-3029616205 2s linear infinite;opacity:0;}"), "@-webkit-keyframes fadeinout{50%.jsx-3029616205{opacity:1;}}", "@-webkit-keyframes fadeinout-jsx-3029616205{50%{opacity:1;}}", "@keyframes fadeinout-jsx-3029616205{50%{opacity:1;}}", ".label.jsx-3029616205{-webkit-letter-spacing:0.5px;-moz-letter-spacing:0.5px;-ms-letter-spacing:0.5px;letter-spacing:0.5px;}"];
_defaultExport$1.__hash = "3029616205";
const styles$1 = _defaultExport$1;
function OnlineStatus(_ref) {
  let {
    dense
  } = _ref;
  const {
    isConnected: online
  } = useDhis2ConnectionStatus();
  const {
    onlineStatusMessage
  } = useOnlineStatusMessage();
  const displayStatus = online ? i18next.t("Online") : i18next.t("Offline");
  return /* @__PURE__ */ React.createElement("div", {
    "data-test": "headerbar-online-status",
    className: "jsx-".concat(styles$1.__hash) + " " + (cx("container", dense ? "bar" : "badge") || "")
  }, onlineStatusMessage && !dense && /* @__PURE__ */ React.createElement("span", {
    className: "jsx-".concat(styles$1.__hash) + " info unselectable"
  }, onlineStatusMessage), /* @__PURE__ */ React.createElement("div", {
    className: "jsx-".concat(styles$1.__hash) + " " + (cx("icon", online ? "online" : "offline") || "")
  }), /* @__PURE__ */ React.createElement("span", {
    className: "jsx-".concat(styles$1.__hash) + " label unselectable"
  }, displayStatus), onlineStatusMessage && dense && /* @__PURE__ */ React.createElement("span", {
    className: "jsx-".concat(styles$1.__hash) + " info-dense unselectable"
  }, onlineStatusMessage), /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: styles$1.__hash
  }, styles$1));
}
OnlineStatus.propTypes = {
  /** If true, displays as a sub-bar instead of a badge */
  dense: PropTypes.bool
};
const useAvatarImgSrc = (avatarId) => {
  const {
    baseUrl
  } = useConfig();
  return avatarId ? [baseUrl, "api/fileResources", avatarId, "data"].filter((part) => !!part).map((part) => part.replace(/^\/+|\/+$/g, "")).join("/") : null;
};
const ImageAvatar = (_ref) => {
  let {
    avatarId,
    dataTest
  } = _ref;
  const src = useAvatarImgSrc(avatarId);
  return /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("img", {
    src,
    alt: "user avatar",
    "data-test": dataTest,
    className: "jsx-3329187909"
  }), /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "3329187909"
  }, ["img.jsx-3329187909{width:100%;height:100%;border-radius:50%;object-fit:cover;}"]));
};
ImageAvatar.propTypes = {
  avatarId: PropTypes.string.isRequired,
  dataTest: PropTypes.string
};
const getInitials = (name) => {
  const nameParts = name.split(" ");
  let initials = nameParts.shift().charAt(0);
  if (nameParts.length) {
    initials += nameParts.pop().charAt(0);
  }
  return initials;
};
const TextAvatar = (_ref) => {
  let {
    name,
    dataTest,
    extralarge,
    extrasmall,
    large,
    medium,
    small
  } = _ref;
  return /* @__PURE__ */ React.createElement("div", {
    "data-test": dataTest,
    className: _JSXStyle.dynamic([["1018031843", [colors.grey800, colors.grey050]]]) + " text-avatar"
  }, /* @__PURE__ */ React.createElement("div", {
    className: _JSXStyle.dynamic([["1018031843", [colors.grey800, colors.grey050]]]) + " " + (cx("text-avatar-initials", {
      extrasmall,
      small,
      medium,
      large,
      extralarge
    }) || "")
  }, getInitials(name)), /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "1018031843",
    dynamic: [colors.grey800, colors.grey050]
  }, [".text-avatar.__jsx-style-dynamic-selector{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;width:100%;height:100%;overflow:hidden;border-radius:50%;background-color:".concat(colors.grey800, "cc;color:").concat(colors.grey050, ";cursor:pointer;}"), ".text-avatar-initials.__jsx-style-dynamic-selector{font-size:80%;font-weight:500;-webkit-letter-spacing:1px;-moz-letter-spacing:1px;-ms-letter-spacing:1px;letter-spacing:1px;text-align:center;text-transform:uppercase;}", ".text-avatar-initials.extrasmall.__jsx-style-dynamic-selector{font-size:7px;}", ".text-avatar-initials.small.__jsx-style-dynamic-selector{font-size:9px;}", ".text-avatar-initials.medium.__jsx-style-dynamic-selector{font-size:14px;}", ".text-avatar-initials.large.__jsx-style-dynamic-selector{font-size:22px;}", ".text-avatar-initials.extralarge.__jsx-style-dynamic-selector{font-size:32px;}"]));
};
TextAvatar.defaultProps = {
  dataTest: "dhis2-uicore-textavatar"
};
TextAvatar.propTypes = {
  name: PropTypes.string.isRequired,
  dataTest: PropTypes.string,
  extralarge: sizePropType,
  extrasmall: sizePropType,
  large: sizePropType,
  medium: sizePropType,
  small: sizePropType
};
const UserAvatar = (_ref) => {
  let {
    name,
    avatarId,
    className,
    dataTest,
    extralarge,
    extrasmall,
    large,
    medium,
    small
  } = _ref;
  return /* @__PURE__ */ React.createElement("div", {
    "data-test": dataTest,
    className: "jsx-3366500546 " + (cx(className, {
      extrasmall,
      small,
      medium,
      large,
      extralarge
    }) || "")
  }, avatarId ? /* @__PURE__ */ React.createElement(ImageAvatar, {
    avatarId,
    dataTest: "".concat(dataTest, "-image")
  }) : /* @__PURE__ */ React.createElement(TextAvatar, {
    name,
    dataTest: "".concat(dataTest, "-text"),
    extrasmall,
    small,
    medium,
    large,
    extralarge
  }), /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "3366500546"
  }, ["div.jsx-3366500546{display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;}", "div.extrasmall.jsx-3366500546{height:16px;width:16px;}", "div.small.jsx-3366500546{height:24px;width:24px;}", "div.jsx-3366500546,div.medium.jsx-3366500546{height:36px;width:36px;}", "div.large.jsx-3366500546{height:48px;width:48px;}", "div.extralarge.jsx-3366500546{height:72px;width:72px;}"]));
};
UserAvatar.defaultProps = {
  dataTest: "dhis2-uicore-useravatar"
};
UserAvatar.propTypes = {
  // Name could stop being required if we implement an
  // SVG fallback with a `IconUser24`.
  // This has been discussed and deferred
  name: PropTypes.string.isRequired,
  avatarId: PropTypes.string,
  className: PropTypes.string,
  dataTest: PropTypes.string,
  extralarge: sizePropType,
  extrasmall: sizePropType,
  large: sizePropType,
  medium: sizePropType,
  small: sizePropType
};
const createClickHandler = (onClick) => (event) => {
  onClick({}, event);
};
const CloseButton = (_ref) => {
  let {
    onClick
  } = _ref;
  return /* @__PURE__ */ React.createElement("button", {
    "data-test": "dhis2-modal-close-button",
    onClick: createClickHandler(onClick),
    className: _JSXStyle.dynamic([["3281559950", [colors.grey700, colors.grey200, colors.grey900, colors.grey200, theme.focus, colors.grey300]]])
  }, /* @__PURE__ */ React.createElement(SvgCross16, null), /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "3281559950",
    dynamic: [colors.grey700, colors.grey200, colors.grey900, colors.grey200, theme.focus, colors.grey300]
  }, ["button.__jsx-style-dynamic-selector{background-color:transparent;color:".concat(colors.grey700, ";border:none;outline:none;padding:4px 4px 0px;border-radius:3px;position:absolute;top:0px;right:0px;}"), "button.__jsx-style-dynamic-selector:hover{background-color:".concat(colors.grey200, ";color:").concat(colors.grey900, ";}"), "button.__jsx-style-dynamic-selector:focus{background-color:".concat(colors.grey200, ";outline:3px solid ").concat(theme.focus, ";}"), "button.__jsx-style-dynamic-selector:focus.__jsx-style-dynamic-selector:not(:focus-visible){outline:none;}", "button.__jsx-style-dynamic-selector:active{background-color:".concat(colors.grey300, ";}")]));
};
CloseButton.propTypes = {
  onClick: PropTypes.func
};
const resolveLayerStyles = (hide2) => ({
  styles: /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "1884450060",
    dynamic: [spacers.dp64, hide2 ? "none" : "block"]
  }, ["div.__jsx-style-dynamic-selector{padding:".concat(spacers.dp64, ";display:").concat(hide2 ? "none" : "block", ";}")]),
  className: _JSXStyle.dynamic([["1884450060", [spacers.dp64, hide2 ? "none" : "block"]]])
});
const Modal = (_ref) => {
  let {
    children,
    className,
    dataTest,
    hide: hide2,
    fluid,
    large,
    onClose,
    position,
    small
  } = _ref;
  const layerStyles = resolveLayerStyles(hide2);
  return /* @__PURE__ */ React.createElement(Layer, {
    onBackdropClick: onClose,
    className: layerStyles.className,
    translucent: !hide2
  }, /* @__PURE__ */ React.createElement(Center, {
    position
  }, /* @__PURE__ */ React.createElement("aside", {
    role: "dialog",
    "aria-modal": "true",
    "data-test": dataTest,
    className: _JSXStyle.dynamic([["3655640549", [2 * spacersNum.dp64, 2 * spacersNum.dp64, 2 * spacersNum.dp64, 2 * spacersNum.dp64]]]) + " " + (cx(className, {
      small,
      large,
      fluid
    }) || "")
  }, /* @__PURE__ */ React.createElement(Card, null, onClose && /* @__PURE__ */ React.createElement(CloseButton, {
    onClick: onClose
  }), /* @__PURE__ */ React.createElement("div", {
    className: _JSXStyle.dynamic([["3655640549", [2 * spacersNum.dp64, 2 * spacersNum.dp64, 2 * spacersNum.dp64, 2 * spacersNum.dp64]]])
  }, children))), layerStyles.styles), /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "3655640549",
    dynamic: [2 * spacersNum.dp64, 2 * spacersNum.dp64, 2 * spacersNum.dp64, 2 * spacersNum.dp64]
  }, ["aside.__jsx-style-dynamic-selector{height:auto;width:600px;max-width:calc(100vw - ".concat(2 * spacersNum.dp64, "px);max-height:calc(100vh - ").concat(2 * spacersNum.dp64, "px);}"), "aside.small.__jsx-style-dynamic-selector{width:400px;}", "aside.large.__jsx-style-dynamic-selector{width:800px;}", "aside.fluid.__jsx-style-dynamic-selector{width:auto;}", "div.__jsx-style-dynamic-selector{padding:24px;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-flow:column;-ms-flex-flow:column;flex-flow:column;max-width:calc(100vw - ".concat(2 * spacersNum.dp64, "px);max-height:calc(100vh - ").concat(2 * spacersNum.dp64, "px);}")]));
};
Modal.defaultProps = {
  dataTest: "dhis2-uicore-modal",
  position: "top"
};
Modal.propTypes = {
  children: PropTypes.node,
  className: PropTypes.string,
  dataTest: PropTypes.string,
  fluid: PropTypes.bool,
  hide: PropTypes.bool,
  large: sizePropType,
  position: insideAlignmentPropType,
  small: sizePropType,
  /** Callback used when the Modal closes */
  onClose: PropTypes.func
};
const ModalActions = (_ref) => {
  let {
    children,
    dataTest
  } = _ref;
  return /* @__PURE__ */ React.createElement("div", {
    "data-test": dataTest,
    className: _JSXStyle.dynamic([["2674552674", [spacers.dp16]]])
  }, children, /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "2674552674",
    dynamic: [spacers.dp16]
  }, ["div.__jsx-style-dynamic-selector{-webkit-order:3;-ms-flex-order:3;order:3;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-pack:end;-webkit-justify-content:flex-end;-ms-flex-pack:end;justify-content:flex-end;-webkit-align-self:flex-end;-ms-flex-item-align:end;align-self:flex-end;margin:".concat(spacers.dp16, " 0 0;}")]));
};
ModalActions.defaultProps = {
  dataTest: "dhis2-uicore-modalactions"
};
ModalActions.propTypes = {
  children: PropTypes.node,
  dataTest: PropTypes.string
};
const ModalContent = (_ref) => {
  let {
    children,
    className,
    dataTest
  } = _ref;
  return /* @__PURE__ */ React.createElement("div", {
    "data-test": dataTest,
    className: "jsx-3719215021 " + (className || "")
  }, children, /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "3719215021"
  }, ["div.jsx-3719215021{-webkit-order:2;-ms-flex-order:2;order:2;-webkit-box-flex:2;-webkit-flex-grow:2;-ms-flex-positive:2;flex-grow:2;overflow-y:auto;}"]));
};
ModalContent.defaultProps = {
  dataTest: "dhis2-uicore-modalcontent"
};
ModalContent.propTypes = {
  children: PropTypes.node,
  className: PropTypes.string,
  dataTest: PropTypes.string
};
const ModalTitle = (_ref) => {
  let {
    children,
    dataTest
  } = _ref;
  return /* @__PURE__ */ React.createElement("h1", {
    "data-test": dataTest,
    className: _JSXStyle.dynamic([["4169842822", [colors.grey900, spacers.dp12]]]) + " " + (cx("title") || "")
  }, children, /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "4169842822",
    dynamic: [colors.grey900, spacers.dp12]
  }, ["h1.__jsx-style-dynamic-selector{-webkit-order:1;-ms-flex-order:1;order:1;-webkit-align-self:flex-start;-ms-flex-item-align:start;align-self:flex-start;color:".concat(colors.grey900, ";font-size:20px;font-weight:500;line-height:24px;margin:0 0 ").concat(spacers.dp12, ";}")]));
};
ModalTitle.defaultProps = {
  dataTest: "dhis2-uicore-modaltitle"
};
ModalTitle.propTypes = {
  children: PropTypes.string,
  dataTest: PropTypes.string
};
const useDebugInfo = () => {
  const {
    appName,
    appVersion,
    systemInfo
  } = useConfig();
  return {
    app_name: appName || null,
    app_version: (appVersion === null || appVersion === void 0 ? void 0 : appVersion.full) || null,
    dhis2_version: (systemInfo === null || systemInfo === void 0 ? void 0 : systemInfo.version) || null,
    dhis2_revision: (systemInfo === null || systemInfo === void 0 ? void 0 : systemInfo.revision) || null
  };
};
const useFormattedDebugInfo = () => JSON.stringify(useDebugInfo(), void 0, 2);
const formatDebugInfoKey = (key) => {
  const tokens = key.split("_");
  return tokens.map((token) => {
    if (token.toLowerCase() === "dhis2") {
      return "DHIS2";
    } else {
      return token[0].toUpperCase() + token.substr(1).toLowerCase();
    }
  }).join(" ");
};
function DebugInfoTable() {
  const debugInfo = useDebugInfo();
  return /* @__PURE__ */ React.createElement("table", {
    "data-test": "dhis2-ui-headerbar-debuginfotable",
    className: _JSXStyle.dynamic([["865651843", [colors.grey700]]])
  }, /* @__PURE__ */ React.createElement("tbody", {
    className: _JSXStyle.dynamic([["865651843", [colors.grey700]]])
  }, Object.keys(debugInfo).map((key) => /* @__PURE__ */ React.createElement("tr", {
    key,
    className: _JSXStyle.dynamic([["865651843", [colors.grey700]]])
  }, /* @__PURE__ */ React.createElement("td", {
    className: _JSXStyle.dynamic([["865651843", [colors.grey700]]]) + " debug-info-key"
  }, formatDebugInfoKey(key)), /* @__PURE__ */ React.createElement("td", {
    className: _JSXStyle.dynamic([["865651843", [colors.grey700]]])
  }, debugInfo[key])))), /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "865651843",
    dynamic: [colors.grey700]
  }, ["table.__jsx-style-dynamic-selector{white-space:pre-wrap;font-size:14px;line-height:1.2;color:".concat(colors.grey700, ";font-famile:Menlo,Courier,monospace !important;}"), "td.__jsx-style-dynamic-selector{padding:3px 16px 3px 0;}", ".debug-info-key.__jsx-style-dynamic-selector{font-weight:bold;}"]));
}
function DebugInfoModal(_ref) {
  let {
    onClose
  } = _ref;
  const debugInfo = useFormattedDebugInfo();
  const {
    show: showClipboardAlert
  } = useAlert("Debug information copied to clipboard", {
    duration: 3e3
  });
  const copyDebugInfo = () => {
    navigator.clipboard.writeText(debugInfo);
    onClose();
    showClipboardAlert();
  };
  return /* @__PURE__ */ React.createElement(Modal, {
    position: "middle",
    dataTest: "dhis2-ui-headerbar-debuginfomodal"
  }, /* @__PURE__ */ React.createElement(ModalTitle, null, i18next.t("Debug info")), /* @__PURE__ */ React.createElement(ModalContent, null, /* @__PURE__ */ React.createElement(DebugInfoTable, null)), /* @__PURE__ */ React.createElement(ModalActions, null, /* @__PURE__ */ React.createElement(ButtonStrip, {
    end: true
  }, /* @__PURE__ */ React.createElement(Button, {
    onClick: () => onClose()
  }, i18next.t("Close")), /* @__PURE__ */ React.createElement(Button, {
    primary: true,
    onClick: copyDebugInfo,
    dataTest: "dhis2-ui-headerbar-debuginfomodal-copybutton"
  }, i18next.t("Copy debug info")))));
}
DebugInfoModal.propTypes = {
  onClose: PropTypes.func.isRequired
};
const MenuDivider = (_ref) => {
  let {
    className,
    dataTest,
    dense
  } = _ref;
  return /* @__PURE__ */ React.createElement("li", {
    "data-test": dataTest,
    className: _JSXStyle.dynamic([["591815244", [colors.white]]]) + " " + (className || "")
  }, /* @__PURE__ */ React.createElement(Divider, {
    dense
  }), /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "591815244",
    dynamic: [colors.white]
  }, ["li.__jsx-style-dynamic-selector{list-style:none;background-color:".concat(colors.white, ";-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;padding:0;line-height:0;}")]));
};
MenuDivider.defaultProps = {
  dataTest: "dhis2-uicore-menudivider"
};
MenuDivider.propTypes = {
  className: PropTypes.string,
  dataTest: PropTypes.string,
  dense: PropTypes.bool
};
const _defaultExport = ["li.jsx-1930534478{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:stretch;-webkit-box-align:stretch;-ms-flex-align:stretch;align-items:stretch;padding:0;cursor:pointer;list-style:none;background-color:".concat(colors.white, ";color:").concat(colors.grey900, ";fill:").concat(colors.grey900, ";font-size:14px;line-height:16px;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;}"), "li.jsx-1930534478:hover{background-color:".concat(colors.grey200, ";}"), "li.jsx-1930534478:active,li.active.jsx-1930534478{background-color:".concat(colors.grey300, ";}"), "li.destructive.jsx-1930534478{color:".concat(colors.red700, ";fill:").concat(colors.red600, ";}"), "li.destructive.jsx-1930534478:hover{background-color:".concat(colors.red050, ";}"), "li.destructive.jsx-1930534478:active,li.destructive.active.jsx-1930534478{background-color:".concat(colors.red100, ";}"), "li.disabled.jsx-1930534478{cursor:not-allowed;color:".concat(colors.grey500, ";fill:").concat(colors.grey500, ";}"), "li.disabled.jsx-1930534478:hover{background-color:".concat(colors.white, ";}"), "a.jsx-1930534478{display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;-webkit-box-flex:1;-webkit-flex-grow:1;-ms-flex-positive:1;flex-grow:1;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;padding:0 ".concat(spacers.dp16, ";min-height:40px;-webkit-text-decoration:none;text-decoration:none;color:inherit;}"), "a.jsx-1930534478:focus{outline:3px solid ".concat(theme.focus, ";outline-offset:-3px;}"), "a.jsx-1930534478:focus.jsx-1930534478:not(:focus-visible){outline:none;}", "li.with-chevron.jsx-1930534478 a.jsx-1930534478{padding-right:".concat(spacers.dp8, ";}"), "li.dense.jsx-1930534478 a.jsx-1930534478{padding:0 ".concat(spacers.dp12, ";min-height:32px;}"), "li.with-chevron.dense.jsx-1930534478 a.jsx-1930534478{padding-right:".concat(spacers.dp4, ";}"), ".label.jsx-1930534478{-webkit-box-flex:1;-webkit-flex-grow:1;-ms-flex-positive:1;flex-grow:1;padding:".concat(spacers.dp12, " 0;}"), "li.dense.jsx-1930534478 .label.jsx-1930534478{padding:".concat(spacers.dp8, " 0;}"), ".icon.jsx-1930534478{-webkit-box-flex:0;-webkit-flex-grow:0;-ms-flex-positive:0;flex-grow:0;margin-right:".concat(spacers.dp12, ";width:24px;height:24px;}"), ".suffix.jsx-1930534478{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;margin-left:".concat(spacers.dp8, ";}"), ".chevron.jsx-1930534478{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-flex:0;-webkit-flex-grow:0;-ms-flex-positive:0;flex-grow:0;margin-left:".concat(spacers.dp24, ";}"), "li.dense.jsx-1930534478 .icon.jsx-1930534478{margin-right:".concat(spacers.dp8, ";width:16px;height:16px;}"), "li.jsx-1930534478 .icon.jsx-1930534478>svg{width:24px;height:24px;}", "li.dense.jsx-1930534478 .icon.jsx-1930534478>svg,li.jsx-1930534478 .chevron.jsx-1930534478>svg{width:16px;height:16px;}"];
_defaultExport.__hash = "1930534478";
const styles = _defaultExport;
const isModifiedEvent = (evt) => evt.metaKey || evt.altKey || evt.ctrlKey || evt.shiftKey;
const createOnClickHandler = (_ref) => {
  let {
    onClick,
    toggleSubMenu,
    isLink,
    value
  } = _ref;
  return (evt) => {
    if (isLink && isModifiedEvent(evt) || !(onClick || toggleSubMenu)) {
      return;
    }
    evt.preventDefault();
    evt.stopPropagation();
    onClick && onClick({
      value
    }, evt);
    toggleSubMenu && toggleSubMenu();
  };
};
const MenuItem = (_ref2) => {
  let {
    href,
    onClick,
    children,
    target,
    icon: icon2,
    className,
    destructive,
    disabled,
    dense,
    active,
    dataTest,
    chevron,
    value,
    label,
    showSubMenu,
    toggleSubMenu,
    suffix
  } = _ref2;
  const menuItemRef = reactExports.useRef();
  return /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("li", {
    ref: menuItemRef,
    "data-test": dataTest,
    className: "jsx-".concat(styles.__hash) + " " + (cx(className, {
      destructive,
      disabled,
      dense,
      active: active || showSubMenu,
      "with-chevron": children || chevron
    }) || "")
  }, /* @__PURE__ */ React.createElement("a", {
    target,
    href: !disabled && href ? href : void 0,
    onClick: !disabled ? createOnClickHandler({
      onClick,
      toggleSubMenu,
      isLink: !!href,
      value
    }) : void 0,
    className: "jsx-".concat(styles.__hash)
  }, icon2 && /* @__PURE__ */ React.createElement("span", {
    className: "jsx-".concat(styles.__hash) + " icon"
  }, icon2), /* @__PURE__ */ React.createElement("span", {
    className: "jsx-".concat(styles.__hash) + " label"
  }, label), suffix && /* @__PURE__ */ React.createElement("span", {
    className: "jsx-".concat(styles.__hash) + " suffix"
  }, suffix), (chevron || children) && /* @__PURE__ */ React.createElement("span", {
    className: "jsx-".concat(styles.__hash) + " chevron"
  }, /* @__PURE__ */ React.createElement(SvgChevronRight24, null))), /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: styles.__hash
  }, styles)), children && showSubMenu && /* @__PURE__ */ React.createElement(Portal, null, /* @__PURE__ */ React.createElement(Popper, {
    placement: "right-start",
    reference: menuItemRef
  }, /* @__PURE__ */ React.createElement(FlyoutMenu, {
    dense
  }, children))));
};
MenuItem.defaultProps = {
  dataTest: "dhis2-uicore-menuitem"
};
MenuItem.propTypes = {
  active: PropTypes.bool,
  chevron: PropTypes.bool,
  /**
   * Nested menu items can become submenus.
   * See `showSubMenu` and `toggleSubMenu` props, and 'Children' demo
   */
  children: PropTypes.node,
  className: PropTypes.string,
  dataTest: PropTypes.string,
  dense: PropTypes.bool,
  destructive: PropTypes.bool,
  disabled: PropTypes.bool,
  /** For using menu item as a link */
  href: PropTypes.string,
  /** An icon for the left side of the menu item */
  icon: PropTypes.node,
  /** Text in the menu item */
  label: PropTypes.node,
  /** When true, nested menu items are shown in a Popper */
  showSubMenu: PropTypes.bool,
  /** A supporting element shown at the end of the menu item */
  suffix: PropTypes.node,
  /** For using menu item as a link */
  target: PropTypes.string,
  /** On click, this function is called (without args) */
  toggleSubMenu: PropTypes.func,
  /** Value associated with item. Passed as an argument to onClick handler. */
  value: PropTypes.string,
  /** Click handler called with signature `({ value: string }, event)` */
  onClick: PropTypes.func
};
const Menu = (_ref) => {
  let {
    children,
    className,
    dataTest,
    dense
  } = _ref;
  return /* @__PURE__ */ React.createElement("ul", {
    "data-test": dataTest,
    className: "jsx-3549878755 " + (className || "")
  }, reactExports.Children.map(children, (child, index2) => /* @__PURE__ */ reactExports.isValidElement(child) ? /* @__PURE__ */ reactExports.cloneElement(child, {
    dense: typeof child.props.dense === "boolean" ? child.props.dense : dense,
    hideDivider: typeof child.props.hideDivider !== "boolean" && index2 === 0 ? true : child.props.hideDivider
  }) : child), /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "3549878755"
  }, ["ul.jsx-3549878755{display:block;position:relative;width:100%;margin:0;padding:0;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;}"]));
};
Menu.defaultProps = {
  dataTest: "dhis2-uicore-menulist"
};
Menu.propTypes = {
  /** Typically `MenuItem`, `MenuDivider`, and `MenuSectionHeader` */
  children: PropTypes.node,
  className: PropTypes.string,
  dataTest: PropTypes.string,
  /** Applies `dense` property to all child components unless already specified */
  dense: PropTypes.bool
};
const FlyoutMenu = (_ref) => {
  let {
    children,
    className,
    dataTest,
    dense,
    maxHeight,
    maxWidth
  } = _ref;
  const [openedSubMenu, setOpenedSubMenu] = reactExports.useState(null);
  const toggleSubMenu = (index2) => {
    const toggleValue = index2 === openedSubMenu ? null : index2;
    setOpenedSubMenu(toggleValue);
  };
  return /* @__PURE__ */ React.createElement("div", {
    "data-test": dataTest,
    className: _JSXStyle.dynamic([["3833750986", [colors.white, colors.grey200, elevations.e300, dense ? "128" : "180", maxWidth, maxHeight, spacers.dp4]]]) + " " + (className || "")
  }, /* @__PURE__ */ React.createElement(Menu, {
    dense
  }, reactExports.Children.map(children, (child, index2) => /* @__PURE__ */ reactExports.isValidElement(child) ? /* @__PURE__ */ reactExports.cloneElement(child, {
    showSubMenu: openedSubMenu === index2,
    toggleSubMenu: toggleSubMenu.bind(void 0, index2)
  }) : child)), /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "3833750986",
    dynamic: [colors.white, colors.grey200, elevations.e300, dense ? "128" : "180", maxWidth, maxHeight, spacers.dp4]
  }, ["div.__jsx-style-dynamic-selector{background:".concat(colors.white, ";border:1px solid ").concat(colors.grey200, ";border-radius:3px;box-shadow:").concat(elevations.e300, ";display:inline-block;min-width:").concat(dense ? "128" : "180", "px;max-width:").concat(maxWidth, ";max-height:").concat(maxHeight, ";padding:").concat(spacers.dp4, " 0;overflow:auto;}")]));
};
FlyoutMenu.defaultProps = {
  dataTest: "dhis2-uicore-menu",
  maxWidth: "380px",
  maxHeight: "auto"
};
FlyoutMenu.propTypes = {
  /** Typically, but not limited to, `MenuItem` components */
  children: PropTypes.node,
  className: PropTypes.string,
  dataTest: PropTypes.string,
  /** Menu uses smaller dimensions */
  dense: PropTypes.bool,
  maxHeight: PropTypes.string,
  maxWidth: PropTypes.string
};
const DebugInfoMenuItem = (_ref) => {
  let {
    hideProfileMenu,
    showDebugInfoModal
  } = _ref;
  const debugInfo = useDebugInfo();
  const openDebugModal = () => {
    hideProfileMenu();
    showDebugInfoModal();
  };
  const debugInfoLabel = /* @__PURE__ */ React.createElement("div", {
    className: _JSXStyle.dynamic([["3534786758", [colors.grey700]]]) + " root"
  }, /* @__PURE__ */ React.createElement("div", {
    "data-test": "dhis2-ui-headerbar-instanceinfo",
    className: _JSXStyle.dynamic([["3534786758", [colors.grey700]]]) + " instance-info version"
  }, debugInfo.dhis2_version ? i18next.t("DHIS2 {{dhis2Version}}", {
    dhis2Version: debugInfo.dhis2_version
  }) : i18next.t("DHIS2 version unknown")), /* @__PURE__ */ React.createElement("div", {
    "data-test": "dhis2-ui-headerbar-appinfo",
    className: _JSXStyle.dynamic([["3534786758", [colors.grey700]]]) + " version"
  }, debugInfo.app_name ? debugInfo.app_version ? "".concat(debugInfo.app_name, " ").concat(debugInfo.app_version) : i18next.t("{{appName}} version unknown", {
    appName: debugInfo.app_name
  }) : debugInfo.app_version ? i18next.t("App {{appVersion}}", {
    appVersion: debugInfo.app_version
  }) : i18next.t("App version unknown")), /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "3534786758",
    dynamic: [colors.grey700]
  }, [".root.__jsx-style-dynamic-selector{color:".concat(colors.grey700, ";font-style:italic;font-size:14px;line-height:17px;}"), ".instance-info.__jsx-style-dynamic-selector{margin-bottom:4px;}", ".version.__jsx-style-dynamic-selector{white-space:no-wrap;}"]));
  return /* @__PURE__ */ React.createElement(MenuItem, {
    dense: true,
    onClick: openDebugModal,
    label: debugInfoLabel,
    dataTest: "dhis2-ui-headerbar-debuginfo"
  });
};
DebugInfoMenuItem.propTypes = {
  hideProfileMenu: PropTypes.func.isRequired,
  showDebugInfoModal: PropTypes.func.isRequired
};
const ProfileName = (_ref) => {
  let {
    children
  } = _ref;
  return /* @__PURE__ */ React.createElement("div", {
    "data-test": "headerbar-profile-username",
    className: "jsx-2223023701"
  }, children, /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "2223023701"
  }, ["div.jsx-2223023701{margin-bottom:3px;font-size:16px;line-height:19px;}"]));
};
ProfileName.propTypes = {
  children: PropTypes.string
};
const ProfileEmail = (_ref2) => {
  let {
    children
  } = _ref2;
  return /* @__PURE__ */ React.createElement("div", {
    "data-test": "headerbar-profile-user-email",
    className: "jsx-1072768994"
  }, children, /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "1072768994"
  }, ["div.jsx-1072768994{margin-bottom:6px;font-size:14px;line-height:16px;}"]));
};
ProfileEmail.propTypes = {
  children: PropTypes.string
};
const ProfileEdit = (_ref3) => {
  let {
    children
  } = _ref3;
  const {
    baseUrl
  } = useConfig();
  return /* @__PURE__ */ React.createElement("a", {
    href: joinPath(baseUrl, "dhis-web-user-profile/#/profile"),
    "data-test": "headerbar-profile-edit-profile-link",
    className: "jsx-233684196"
  }, children, /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "233684196"
  }, ["a.jsx-233684196{color:rgba(0,0,0,0.87);font-size:12px;line-height:14px;-webkit-text-decoration:underline;text-decoration:underline;cursor:pointer;}"]));
};
ProfileEdit.propTypes = {
  children: PropTypes.string
};
const ProfileDetails = (_ref4) => {
  let {
    name,
    email
  } = _ref4;
  return /* @__PURE__ */ React.createElement("div", {
    className: "jsx-3814112749"
  }, /* @__PURE__ */ React.createElement(ProfileName, null, name), /* @__PURE__ */ React.createElement(ProfileEmail, null, email), /* @__PURE__ */ React.createElement(ProfileEdit, null, i18next.t("Edit profile")), /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "3814112749"
  }, ["div.jsx-3814112749{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;margin-left:20px;color:#000;font-size:14px;font-weight:400;}"]));
};
ProfileDetails.propTypes = {
  email: PropTypes.string,
  name: PropTypes.string
};
const ProfileHeader = (_ref5) => {
  let {
    name,
    email,
    avatarId
  } = _ref5;
  return /* @__PURE__ */ React.createElement("div", {
    className: "jsx-3625287538"
  }, /* @__PURE__ */ React.createElement(UserAvatar, {
    avatarId,
    name,
    dataTest: "headerbar-profile-menu-icon",
    large: true
  }), /* @__PURE__ */ React.createElement(ProfileDetails, {
    name,
    email
  }), /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "3625287538"
  }, ["div.jsx-3625287538{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;margin-left:24px;padding-top:20px;}"]));
};
ProfileHeader.propTypes = {
  avatarId: PropTypes.string,
  email: PropTypes.string,
  name: PropTypes.string
};
function UpdateNotification(_ref) {
  let {
    hideProfileMenu
  } = _ref;
  const {
    appName
  } = useConfig();
  const {
    updateAvailable,
    onApplyAvailableUpdate
  } = useHeaderBarContext();
  const onClick = () => {
    hideProfileMenu();
    onApplyAvailableUpdate === null || onApplyAvailableUpdate === void 0 ? void 0 : onApplyAvailableUpdate();
  };
  const updateNotificationLabel = /* @__PURE__ */ React.createElement("div", {
    className: _JSXStyle.dynamic([["4135170305", [colors.blue600]]]) + " root"
  }, /* @__PURE__ */ React.createElement("div", {
    className: _JSXStyle.dynamic([["4135170305", [colors.blue600]]]) + " badge"
  }), /* @__PURE__ */ React.createElement("div", {
    className: _JSXStyle.dynamic([["4135170305", [colors.blue600]]]) + " spacer"
  }), /* @__PURE__ */ React.createElement("div", {
    className: _JSXStyle.dynamic([["4135170305", [colors.blue600]]]) + " message"
  }, appName ? i18next.t("New {{appName}} version available", {
    appName
  }) : i18next.t("New app version available"), /* @__PURE__ */ React.createElement("br", {
    className: _JSXStyle.dynamic([["4135170305", [colors.blue600]]])
  }), i18next.t("Click to reload")), /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "4135170305",
    dynamic: [colors.blue600]
  }, [".root.__jsx-style-dynamic-selector{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;font-size:14px;line-height:17px;}", ".badge.__jsx-style-dynamic-selector{display:inline-block;width:12px;height:12px;margin:0 8px;border-radius:6px;background-color:".concat(colors.blue600, ";}"), ".spacer.__jsx-style-dynamic-selector{display:inline-block;width:8px;}", ".message.__jsx-style-dynamic-selector{display:inline-block;}"]));
  return updateAvailable ? /* @__PURE__ */ React.createElement(MenuItem, {
    dense: true,
    onClick,
    label: updateNotificationLabel,
    dataTest: "dhis2-ui-headerbar-updatenotification"
  }) : null;
}
UpdateNotification.propTypes = {
  hideProfileMenu: PropTypes.func.isRequired
};
const LoadingMask = () => /* @__PURE__ */ React.createElement(Layer, {
  translucent: true,
  disablePortal: true,
  dataTest: "headerbar-profile-menu-loading-mask"
}, /* @__PURE__ */ React.createElement(Center, null, /* @__PURE__ */ React.createElement(CircularLoader, null)));
const ProfileContents = (_ref) => {
  let {
    name,
    email,
    avatarId,
    helpUrl,
    hideProfileMenu,
    showDebugInfoModal
  } = _ref;
  const {
    baseUrl
  } = useConfig();
  const [loading, setLoading] = reactExports.useState(false);
  return /* @__PURE__ */ React.createElement(Card, null, /* @__PURE__ */ React.createElement("div", {
    className: "jsx-2099675810"
  }, /* @__PURE__ */ React.createElement(ProfileHeader, {
    name,
    email,
    avatarId
  }), /* @__PURE__ */ React.createElement(Divider, {
    margin: "13px 0 7px 0"
  }), /* @__PURE__ */ React.createElement("ul", {
    "data-test": "headerbar-profile-menu",
    className: "jsx-2099675810"
  }, /* @__PURE__ */ React.createElement(MenuItem, {
    href: joinPath(baseUrl, "dhis-web-user-profile/#/settings"),
    label: i18next.t("Settings"),
    value: "settings",
    icon: /* @__PURE__ */ React.createElement(SvgSettings24, {
      color: colors.grey700
    })
  }), /* @__PURE__ */ React.createElement(MenuItem, {
    href: joinPath(baseUrl, "dhis-web-user-profile/#/account"),
    label: i18next.t("Account"),
    value: "account",
    icon: /* @__PURE__ */ React.createElement(SvgUser24, {
      color: colors.grey700
    })
  }), helpUrl && /* @__PURE__ */ React.createElement(MenuItem, {
    href: helpUrl,
    label: i18next.t("Help"),
    value: "help",
    icon: /* @__PURE__ */ React.createElement(SvgQuestion24, {
      color: colors.grey700
    })
  }), /* @__PURE__ */ React.createElement(MenuItem, {
    href: joinPath(baseUrl, "dhis-web-user-profile/#/aboutPage"),
    label: i18next.t("About DHIS2"),
    value: "about",
    icon: /* @__PURE__ */ React.createElement(SvgInfo24, {
      color: colors.grey700
    })
  }), /* @__PURE__ */ React.createElement(MenuItem, {
    href: joinPath(baseUrl, "dhis-web-commons-security/logout.action"),
    onClick: async () => {
      setLoading(true);
      await clearSensitiveCaches();
      setLoading(false);
      window.location.assign(joinPath(baseUrl, "dhis-web-commons-security/logout.action"));
    },
    label: i18next.t("Logout"),
    value: "logout",
    icon: /* @__PURE__ */ React.createElement(SvgLogOut24, {
      color: colors.grey700
    })
  }), /* @__PURE__ */ React.createElement(MenuDivider, {
    dense: true
  }), /* @__PURE__ */ React.createElement(DebugInfoMenuItem, {
    hideProfileMenu,
    showDebugInfoModal
  }), /* @__PURE__ */ React.createElement(UpdateNotification, {
    hideProfileMenu
  }))), loading && /* @__PURE__ */ React.createElement(LoadingMask, null), /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "2099675810"
  }, ["div.jsx-2099675810{width:100%;padding:0;}", "ul.jsx-2099675810{padding:0;margin:0;}", "a.jsx-2099675810,a.jsx-2099675810:hover,a.jsx-2099675810:focus,a.jsx-2099675810:active,a.jsx-2099675810:visited{-webkit-text-decoration:none;text-decoration:none;display:block;}"]));
};
ProfileContents.propTypes = {
  hideProfileMenu: PropTypes.func.isRequired,
  showDebugInfoModal: PropTypes.func.isRequired,
  avatarId: PropTypes.string,
  email: PropTypes.string,
  helpUrl: PropTypes.string,
  name: PropTypes.string
};
const ProfileMenu = (_ref2) => {
  let {
    ...props
  } = _ref2;
  return /* @__PURE__ */ React.createElement("div", {
    "data-test": "headerbar-profile-menu",
    className: "jsx-2907613216"
  }, /* @__PURE__ */ React.createElement(ProfileContents, props), /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "2907613216"
  }, ["div.jsx-2907613216{z-index:10000;position:absolute;right:4px;width:320px;}"]));
};
ProfileMenu.propTypes = {
  hideProfileMenu: PropTypes.func.isRequired,
  showDebugInfoModal: PropTypes.func.isRequired,
  avatarId: PropTypes.string,
  email: PropTypes.string,
  helpUrl: PropTypes.string,
  name: PropTypes.string
};
const useOnDocClick = (containerRef, hide2) => {
  const onDocClick = reactExports.useMemo(() => {
    return (evt) => {
      if (!containerRef.current) {
        return null;
      }
      if (!containerRef.current.contains(evt.target)) {
        hide2();
      }
    };
  }, [containerRef, hide2]);
  reactExports.useEffect(() => {
    document.addEventListener("click", onDocClick);
    return () => {
      document.removeEventListener("click", onDocClick);
    };
  }, [onDocClick]);
};
const Profile = (_ref) => {
  let {
    name,
    email,
    avatarId,
    helpUrl
  } = _ref;
  const [showProfileMenu, setShowProfileMenu] = reactExports.useState(false);
  const [showDebugInfoModal, setShowDebugInfoModal] = reactExports.useState(false);
  const hideProfileMenu = reactExports.useCallback(() => setShowProfileMenu(false), [setShowProfileMenu]);
  const toggleProfileMenu = reactExports.useCallback(() => setShowProfileMenu((show) => !show), [setShowProfileMenu]);
  const containerRef = reactExports.useRef(null);
  useOnDocClick(containerRef, hideProfileMenu);
  return /* @__PURE__ */ React.createElement("div", {
    ref: containerRef,
    "data-test": "headerbar-profile",
    className: "jsx-3442481507 headerbar-profile"
  }, /* @__PURE__ */ React.createElement("button", {
    onClick: toggleProfileMenu,
    className: "jsx-3442481507 headerbar-profile-btn"
  }, /* @__PURE__ */ React.createElement(UserAvatar, {
    avatarId,
    name,
    dataTest: "headerbar-profile-icon",
    medium: true
  })), showProfileMenu && /* @__PURE__ */ React.createElement(ProfileMenu, {
    avatarId,
    name,
    email,
    helpUrl,
    hideProfileMenu,
    showDebugInfoModal: () => {
      setShowDebugInfoModal(true);
    }
  }), showDebugInfoModal && /* @__PURE__ */ React.createElement(DebugInfoModal, {
    onClose: () => {
      setShowDebugInfoModal(false);
    }
  }), /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "3442481507"
  }, [".headerbar-profile.jsx-3442481507{position:relative;height:100%;}", ".headerbar-profile-btn.jsx-3442481507{background:transparent;padding:6px;border:0;cursor:pointer;}", ".headerbar-profile-btn.jsx-3442481507:focus{outline:2px solid white;outline-offset:-2px;}", ".headerbar-profile-btn.jsx-3442481507:focus.jsx-3442481507:not(:focus-visible){outline:none;}", ".headerbar-profile-btn.jsx-3442481507:hover{background:#1a557f;}", ".headerbar-profile-btn.jsx-3442481507:active{background:#104067;}"]));
};
Profile.propTypes = {
  name: PropTypes.string.isRequired,
  avatarId: PropTypes.string,
  email: PropTypes.string,
  helpUrl: PropTypes.string
};
const Profile$1 = Profile;
const Title = (_ref) => {
  let {
    app,
    instance
  } = _ref;
  return /* @__PURE__ */ React.createElement("div", {
    "data-test": "headerbar-title",
    className: "jsx-2721515324"
  }, app ? "".concat(instance, " - ").concat(app) : "".concat(instance), /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "2721515324"
  }, ["div.jsx-2721515324{overflow:hidden;text-overflow:ellipsis;font-size:14px;font-weight:500;-webkit-letter-spacing:0.01em;-moz-letter-spacing:0.01em;-ms-letter-spacing:0.01em;letter-spacing:0.01em;white-space:nowrap;}"]));
};
Title.propTypes = {
  app: PropTypes.string,
  instance: PropTypes.string
};
const query = {
  title: {
    resource: "systemSettings/applicationTitle"
  },
  help: {
    resource: "systemSettings/helpPageLink"
  },
  user: {
    resource: "me",
    params: {
      fields: ["authorities", "avatar", "email", "name", "settings"]
    }
  },
  apps: {
    resource: "action::menu/getModules"
  },
  notifications: {
    resource: "me/dashboard"
  }
};
const HeaderBar = (_ref) => {
  var _data$user$avatar;
  let {
    appName,
    className,
    updateAvailable,
    onApplyAvailableUpdate
  } = _ref;
  const {
    appName: configAppName,
    baseUrl,
    pwaEnabled
  } = useConfig();
  const {
    loading,
    error: error2,
    data
  } = useDataQuery(query);
  const apps = reactExports.useMemo(() => {
    const getPath2 = (path) => path.startsWith("http:") || path.startsWith("https:") ? path : joinPath(baseUrl, "api", path);
    return data === null || data === void 0 ? void 0 : data.apps.modules.map((app) => ({
      ...app,
      icon: getPath2(app.icon),
      defaultAction: getPath2(app.defaultAction)
    }));
  }, [data, baseUrl]);
  if (!loading && !error2) {
    const locale = data.user.settings.keyUiLocale || "en";
    i18next.setDefaultNamespace("default");
    i18next.changeLanguage(locale);
  }
  return /* @__PURE__ */ React.createElement(HeaderBarContextProvider, {
    updateAvailable,
    onApplyAvailableUpdate
  }, /* @__PURE__ */ React.createElement("header", {
    className: _JSXStyle.dynamic([["2211918310", [colors.white]]]) + " " + (className || "")
  }, /* @__PURE__ */ React.createElement("div", {
    className: _JSXStyle.dynamic([["2211918310", [colors.white]]]) + " main"
  }, !loading && !error2 && /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement(Logo, null), /* @__PURE__ */ React.createElement(Title, {
    app: appName || configAppName,
    instance: data.title.applicationTitle
  }), /* @__PURE__ */ React.createElement("div", {
    className: _JSXStyle.dynamic([["2211918310", [colors.white]]]) + " right-control-spacer"
  }), pwaEnabled && /* @__PURE__ */ React.createElement(OnlineStatus, null), /* @__PURE__ */ React.createElement(Notifications, {
    interpretations: data.notifications.unreadInterpretations,
    messages: data.notifications.unreadMessageConversations,
    userAuthorities: data.user.authorities
  }), /* @__PURE__ */ React.createElement(Apps$1, {
    apps
  }), /* @__PURE__ */ React.createElement(Profile$1, {
    name: data.user.name,
    email: data.user.email,
    avatarId: (_data$user$avatar = data.user.avatar) === null || _data$user$avatar === void 0 ? void 0 : _data$user$avatar.id,
    helpUrl: data.help.helpPageLink
  }))), pwaEnabled && !loading && !error2 && /* @__PURE__ */ React.createElement(OnlineStatus, {
    dense: true
  }), /* @__PURE__ */ React.createElement(_JSXStyle, {
    id: "2211918310",
    dynamic: [colors.white]
  }, [".main.__jsx-style-dynamic-selector{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;background-color:#2c6693;color:".concat(colors.white, ";height:48px;}"), ".right-control-spacer.__jsx-style-dynamic-selector{margin-left:auto;}"])));
};
HeaderBar.propTypes = {
  appName: PropTypes.string,
  className: PropTypes.string,
  updateAvailable: PropTypes.bool,
  onApplyAvailableUpdate: PropTypes.func
};
const dhis2ProviderConfig = {
  baseUrl: "/",
  apiVersion: 40,
  appName: "Approvals",
  appVersion: {
    full: "2.3.0",
    major: 2,
    minor: 3
  },
  systemInfo: {
    version: "2.40.2.1",
    contextPath: "/",
    serverTimeZoneId: "UTC"
  }
};
function Dhis2Header({}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Provider, { config: dhis2ProviderConfig, children: /* @__PURE__ */ jsxRuntimeExports.jsx(HeaderBar, {}) });
}
export {
  Dhis2Header
};
