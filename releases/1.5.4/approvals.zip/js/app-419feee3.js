/* global jQuery */
angular.module('PEPFAR.approvals', [
    'restangular',
    'd2-recordtable',
    'd2-translate',
    'ui.select',
    'ui.bootstrap.tpls',
    'ui.bootstrap.tabs',
    'ui.bootstrap.typeahead',
    'ui.bootstrap.progressbar',
    'ngCacheBuster',
    'rx'
]);
angular.module('PEPFAR.approvals').controller('appController', appController);
angular.module('PEPFAR.approvals').controller('tableViewController', tableViewController);
angular.module('PEPFAR.approvals').controller('acceptTableViewController', acceptTableViewController);
angular.module('PEPFAR.approvals').controller('acceptedTableViewController', acceptedTableViewController);
angular.module('PEPFAR.approvals').controller('submittedTableViewController', submittedTableViewController);
angular.module('PEPFAR.approvals').controller('viewTableViewController', viewTableViewController);

angular.module('PEPFAR.approvals')
    .config(['uiSelectConfig', function (uiSelectConfig) {
        uiSelectConfig.theme = 'bootstrap';
    }])
    .config(['httpRequestInterceptorCacheBusterProvider', function (httpRequestInterceptorCacheBusterProvider) {
        httpRequestInterceptorCacheBusterProvider.setMatchlist([/.*\.html.*/]);
    }]);

//jshint maxstatements: 46
function appController(periodService, $scope, currentUser, mechanismsService,
                       approvalLevelsService, toastr, AppManifest,
                       systemSettings, $translate, userApprovalLevels$,
                       organisationunitsService, $log, rx, workflowService, dataSetGroupService) {
    var self = this;
    var vm = this;
    var organisationUnit$ = new rx.ReplaySubject(1);
    var mechanisms$ = new rx.ReplaySubject(1);

    vm.infoBox = {
        isShowing: false,
        showBox: function () {
            this.isShowing = !this.isShowing;
        }
    };

    this.loading = true;
    this.actionItems = 0;
    this.state = {};
    this.showData = false;
    this.tabs = {
        accept: {
            access: false,
            name: ['Accept'],
            state: false,
            action: []
        },
        submit: {
            access: false,
            name: ['Submit'],
            state: false,
            action: []
        },
        unsubmit: {
            access: false,
            name: ['Recall submission'],
            state: false,
            action: []
        },
        view: {
            access: true,
            name: 'View',
            state: false,
            action: ['view']
        }
    };

    this.currentUser = {};
    this.text = {};

    this.headerBar = {
        logo: AppManifest.activities.dhis.href + '/dhis-web-commons/css/light_blue/logo_banner.png',
        title: systemSettings.applicationTitle,
        link: AppManifest.activities.dhis.href
    };

    this.hasTableDetails = function () {
        if (mechanismsService.categories.length > 0 &&
            mechanismsService.dataSetIds.length > 0 &&
            mechanismsService.organisationUnit && mechanismsService.organisationUnit !== '' &&
            angular.isString(mechanismsService.period)) {
            return true;
        }
        return false;
    };

    function setInfoBoxLevels() {
        vm.infoBox.levelAbove = getNextApprovalLevel() && getNextApprovalLevel().displayName;
        vm.infoBox.levelBelow = getPreviousApprovalLevel() && getPreviousApprovalLevel().displayName;
    }

    var usersAndAllApprovalLevels$ = rx.Observable.combineLatest(
        userApprovalLevels$,
        approvalLevelsService,
        function (userApprovalLevel, approvalLevels) {
            return [userApprovalLevel, approvalLevels];
        }
    );

    rx.Observable.combineLatest(
        usersAndAllApprovalLevels$,
        mechanisms$,
        organisationUnit$,
        function (approvalLevels, mechanisms, organisationUnit) {
            return {
                approvalLevels: approvalLevels,
                mechanisms: mechanisms
                    .filter(function (mechanism) {
                        // When you are a global user and global is selected as an organisationUnit you should see everything
                        if (organisationUnit.name === 'Global') {
                            return true;
                        }

                        return mechanism.country === organisationUnit.name;
                    })
            };
        }
    )
        .subscribe(function (data) {
            var mechanisms = data.mechanisms;
            var actionMechanisms = [];

            setInfoBoxLevels();

            _.each(mechanisms, function (mechanism) {
                var previousApprovalLevel = getPreviousApprovalLevel() || {};

                if (mechanism.mayApprove && (mechanism.level === previousApprovalLevel.level)) {
                    actionMechanisms.push(mechanism.id);
                }

                if (mechanism.mayAccept && (mechanism.level === previousApprovalLevel.level)) {
                    actionMechanisms.push(mechanism.id);
                }
            });

            actionMechanisms = actionMechanisms.reduce(function (actionMechanisms, mechanismId) {
                if (actionMechanisms.indexOf(mechanismId) === -1) {
                    actionMechanisms.push(mechanismId);
                }
                return actionMechanisms;
            }, []);

            self.actionItems = actionMechanisms.length;
            self.setStatus();

            $scope.$broadcast('MECHANISMS.updated', mechanisms);
        });

    this.getTableData = function () {
        if (self.hasTableDetails()) {
            $translate('Loading...').then(function (translation) {
                self.status = translation;
            });

            self.loading = true;
            mechanismsService.getMechanisms()
                .take(1)
                .subscribe(function (mechanisms) {
                    mechanisms$.onNext(mechanisms);
                    self.loading = false;
                });

        }
    };

    this.setStatus = function () {
        if (this.actionItems === 0) {
            $translate('No action required').then(function (translations) {
                self.status = translations;
            });
        } else {
            $translate(this.actionItems > 1 ? 'mechanisms require action' : 'mechanism requires action').then(function (translation) {
                self.status = ' ' + translation;
            });
        }
    };

    this.getStatus = function () {
        if (this.status) {
            return this.status;
        }
    };

    this.hasAllDetails = function () {
        if ($scope.details.period &&
            ($scope.details.currentSelection.length > 0 &&
            $scope.details.dataSets &&
            $scope.details.orgUnit &&
            this.getActiveTab())) {

            return true;
        }
        return false;
    };

    this.updateDataView = function () {
        function generateActions() {
            var actions = {
                approve: [],
                unapprove: [],
                accept: [],
                unaccept: []
            };
            _.each($scope.details.currentSelection, function (mechanism) {
                if (mechanism.mayApprove === true) {
                    actions.approve.push(mechanism.id);
                }
                if (mechanism.mayUnapprove === true) {
                    actions.unapprove.push(mechanism.id);
                }
                if (mechanism.mayAccept === true) {
                    actions.accept.push(mechanism.id);
                }
                if (mechanism.mayUnaccept === true) {
                    actions.unaccept.push(mechanism.id);
                }
            });

            return actions;
        }

        if (this.getActiveTab().name === 'View') {
            $scope.details.actions = {};
        } else {
            $scope.details.actions = generateActions();
        }

        if (this.hasAllDetails()) {
            $scope.$broadcast('DATAVIEW.update', $scope.details);
            this.showData = true;
        }
    };

    this.setActive = function (tabName, isActive) {
        var active = _.filter(this.state, function (item) {
            if (item === true) {
                return true;
            }
            return false;
        });

        if (active.length === 0) {
            _.each(this.state, function (item) {
                if (item !== tabName) {
                    item = false;
                }
            });
            this.state[tabName] = isActive;
        }
    };

    this.getActiveTab = function () {
        return _.find(this.tabs, {state: true});
    };

    this.deSelect = function (tabName) {
        if (this.tabs[tabName]) {
            this.tabs[tabName].state = false;
        }
        $scope.details.currentSelection = [];
        this.updateViewButton();
        $scope.$broadcast('RECORDTABLE.selection.clear');
    };

    $scope.approvalLevel = {};

    $translate(['View/Act on', 'mechanism(s)']).then(function (translations) {
        self.text.viewAct = [translations['View/Act on'], 0, translations['mechanism(s)']].join(' ');
    });

    currentUser.permissions.then(function (permissions) { //jshint maxcomplexity:7
        permissions = _(permissions);

        if (permissions.includes('ALL')) {
            self.tabs.accept.access = true;
            self.tabs.accept.name = ['Accept'];
            self.tabs.accept.action = ['accept'];
            self.tabs.submit.access = true;
            self.tabs.submit.name = ['Submit', 'Return submission'];
            self.tabs.submit.action = ['approve'];
            self.tabs.unsubmit.access = true;
            self.tabs.unsubmit.name = ['Recall submission'];
            self.tabs.unsubmit.action = ['unapprove'];
            return;
        }

        if (permissions.includes('F_ACCEPT_DATA_LOWER_LEVELS')) {
            if ((permissions.includes('F_APPROVE_DATA') || permissions.includes('F_APPROVE_DATA_LOWER_LEVELS'))) {
                //All permissions
                self.tabs.accept.access = true;
                self.tabs.accept.name = ['Accept'];
                self.tabs.accept.action = ['accept'];
                self.tabs.submit.access = true;
                self.tabs.submit.name = ['Submit', 'Return submission'];
                self.tabs.submit.action = ['approve'];
                self.tabs.unsubmit.access = true;
                self.tabs.unsubmit.name = ['Recall submission'];
                self.tabs.unsubmit.action = ['unapprove'];
            } else {
                //Only accept lower levels
                self.tabs.accept.access = true;
                self.tabs.accept.name = ['Accept', 'Return submission'];
                self.tabs.accept.action = ['accept'];
                self.tabs.submit.access = false;
                self.tabs.submit.name = ['Unaccept'];
                self.tabs.submit.action = ['unaccept'];
                self.tabs.unsubmit.access = true;
                self.tabs.unsubmit.name = ['Return submission'];
                self.tabs.unsubmit.action = ['unaccept'];
            }
        } else {
            if ((permissions.includes('F_APPROVE_DATA') || permissions.includes('F_APPROVE_DATA_LOWER_LEVELS'))) {
                //Only approve
                self.tabs.submit.access = true;
                self.tabs.submit.name = ['Submit'];
                self.tabs.submit.action = ['approve'];
                self.tabs.unsubmit.access = true;
                self.tabs.unsubmit.name = ['Recall submission'];
                self.tabs.unsubmit.action = ['unapprove'];
            }
        }
    });

    $scope.details = {
        orgUnit: undefined,
        period: undefined,
        dataSets: undefined,
        currentSelection: []
    };

    this.updateTitle = function () {
        var title = [];

        if ($scope.approvalLevel && $scope.approvalLevel.categoryOptionGroupSet && $scope.approvalLevel.categoryOptionGroupSet.name) {
            title.push($scope.approvalLevel.categoryOptionGroupSet.name);
        }

        if (self.currentUser.orgUnit && self.currentUser.orgUnit.name) {
            title.push(self.currentUser.orgUnit.name);
        }

        title.push($translate.instant('Data approval'));

        self.title = title.join(' - ');
    };

    this.updateViewButton = function () {
        var actionText = 'View/Act';
        var activeTab = _.find(this.tabs, {state: true});

        if (activeTab) {
            if (Array.isArray(activeTab.name)) {
                actionText = $translate.instant(activeTab.name.join(' or '));
            }
            if (angular.isString(activeTab.name)) {
                actionText = $translate.instant(activeTab.name);
            }
        }

        this.text.viewAct = [
            $translate.instant(actionText),
            $scope.details.currentSelection.length,
            $translate.instant('mechanism(s)')
        ].join(' ');
    };

    //Get the users org unit off the user
    currentUser.then(function () {
        var orgUnit;

        if (Array.isArray(currentUser.valueFor('dataViewOrganisationUnits')) &&
            currentUser.valueFor('dataViewOrganisationUnits').length >= 1) {
            orgUnit = currentUser.valueFor('dataViewOrganisationUnits')[0];
        } else {
            if (currentUser.valueFor('organisationUnits').length >= 1) {
                orgUnit = currentUser.valueFor('organisationUnits')[0];
            } else {
                if (window.console && window.console.error) {
                    window.console.error('No orgunit found for the current user');
                }
            }
        }

        $scope.details.orgUnit = orgUnit.id;
        self.currentUser.orgUnit = orgUnit;

        organisationunitsService.currentOrganisationUnit = orgUnit;

        self.updateTitle();

        function userApprovalLevelsLoaded(approvalLevel) {
            $scope.approvalLevel = $scope.details.approvalLevel = approvalLevel[0];
            if ($scope.approvalLevel.categoryOptionGroupSet) {
                self.updateTitle();
            }
            organisationunitsService.currentOrganisationUnit.level = $scope.approvalLevel.level;
        }

        function userApprovalLevelsFailed() {
            toastr.error('Unable to load your Data Approval Levels. (Please submit a ticket)');
        }

        userApprovalLevels$.subscribe(userApprovalLevelsLoaded, userApprovalLevelsFailed);

    });

    //TODO: This might be confusing as this is changing the tabs in a different place.
    usersAndAllApprovalLevels$
        .subscribe(function (result) {
            if ($scope.approvalLevel.level === result[1].length) {
                self.tabs.accept.access = false;
                self.tabs.accept.state = false;
                self.tabs.submit.access = true;
                self.tabs.submit.state = true;
                self.tabs.submit.name = ['Submit'];
            }
        }, function () {
            toastr.error('Unable to load Data Approval levels, yours or all. (Please submit a ticket)');
        });

    workflowService
        .currentWorkflow$
        .subscribe(function (workflow) {
            $scope.currentWorkflow = workflow;
            $log.info('Current workflow', workflow);
        });

    function getNextApprovalLevel() {
        if ($scope.currentWorkflow) {
            try {
                var nextApprovalLevel = $scope.currentWorkflow.getApprovalLevelBeforeLevel($scope.approvalLevel.id);
                return nextApprovalLevel;
            } catch (e) {}
        }

        return {};
    }

    function getPreviousApprovalLevel() {
        if ($scope.currentWorkflow) {
            try {
                var previousApprovalLevel = $scope.currentWorkflow.getApprovalLevelBelowLevel($scope.approvalLevel.id);
                return previousApprovalLevel;
            } catch (e) {}
        }

        return {};
    }

    //When the dataset group is changed update the filter types and the datasets
    dataSetGroupService.currentDataSetGroup$
        .subscribe(function (dataSets) {
            // Grab the period types from the Workflow
            workflowService.setCurrentWorkflow(dataSets.get()[0].workflow);

            $scope.details.dataSets = dataSets.get();
            mechanismsService.categories = dataSets.getCategoryIds();
            mechanismsService.dataSetIds = dataSets.getIds();
            mechanismsService.dataSets = dataSets.get();

            // Reset the selection
            $scope.details.currentSelection = [];

            // When the details are available load the mechanisms for the table
            if (self.hasTableDetails()) {
                self.showData = false;
                self.deSelect();
            }

            self.updateViewButton();
        });

    function setOrganisationUnit() {
        if (organisationunitsService.currentOrganisationUnit.name === 'Global') {
            if (!$scope.globalUser) {
                $scope.globalUser = {
                    isGlobalUser: true,
                    globalOUId: organisationunitsService.currentOrganisationUnit.id
                };
                $log.info('User is concidered a global user');
                $log.info($scope.globalUser);
            }
            mechanismsService.isGlobal = true;
        } else {
            mechanismsService.isGlobal = false;
        }

        mechanismsService.organisationUnit = organisationunitsService.currentOrganisationUnit.id;
        organisationUnit$.onNext(organisationunitsService.currentOrganisationUnit);
    }

    $scope.$on('RECORDTABLE.selection.changed', function (event, selection) {
        $scope.details.currentSelection = selection;

        self.updateViewButton();
    });

    $scope.$on('APP.submit.success', function (event, mechanisms) {
        var successMessage = [
            mechanisms.action[0].toUpperCase(),
            mechanisms.action.substr(1),
            ' successful for ',
            mechanisms.mechanisms.length,
            ' mechanism(s)'
        ];
        if (mechanisms.mechanisms.length < 10) {
            //FIXME: Html in controller :( Bad practice
            successMessage.push('<ul>');
            angular.forEach(mechanisms.mechanisms, function (mechanism) {
                successMessage.push('<li>' + mechanism.mechanism + '</li>');
            });
            successMessage.push('</ul>');
        }
        toastr.success(successMessage.join(''), undefined, {timeOut: 4000, extendedTimeOut: 2500});
        if (self.hasTableDetails()) {
            self.showData = false;
            self.getTableData();
            self.deSelect();
        }
    });

    $scope.$on('APP.errorhandler.error', function () {
        self.loading = false;
    });

    $scope.$on('APP.submit.error', function (event, message) {
        toastr.error(message);
        if (self.hasTableDetails()) {
            self.showData = false;
            self.getTableData();
            self.deSelect();
        }
    });

    periodService.period$
        .subscribe(function (period) {
            // $log.info('Period changed to',  period);
            $scope.details.period = period.id;
            if(period.hasOwnProperty('datasets')){$scope.details.validDataSets = period.datasets}else{$scope.details.validDataSets=[]} //TOM (2018-01-08)(for Global ticket #3332)
            mechanismsService.period = $scope.details.period;

            //TODO: See if we can resolve this a bit more clever (It's duplicate with other stuff)
            $scope.details.currentSelection = [];
            self.updateViewButton();
        });

    $scope.$watch(function () {
        return mechanismsService.period;
    }, function (newVal, oldVal) {
        if (newVal !== oldVal) {
            if (self.hasTableDetails()) {
                self.showData = false;
                self.getTableData();
            }
        }
    });

    $scope.$watch(function () {
        if (currentUser.organisationUnits) {
            return currentUser.organisationUnits[0].id;
        }
    }, function (newVal, oldVal) {
        if (newVal !== oldVal) {
            $scope.details.orgUnit = newVal;
            setOrganisationUnit();
        }
    });

    $scope.$watch(function () {
        return organisationunitsService.currentOrganisationUnit;
    }, function (newVal) {
        if (newVal && newVal.name) {
            organisationUnit$.onNext(newVal);
        }
    });
}
appController.$inject = ['periodService', '$scope', 'currentUser', 'mechanismsService', 'approvalLevelsService', 'toastr', 'AppManifest', 'systemSettings', '$translate', 'userApprovalLevels$', 'organisationunitsService', '$log', 'rx', 'workflowService', 'dataSetGroupService'];

function tableViewController($scope) {
    this.approvalTableConfig = {
        columns: [
            {name: 'mechanism', sortable: true, searchable: true},
            {name: 'country', sortable: true, searchable: true},
            {name: 'agency', sortable: true, searchable: true},
            {name: 'partner', sortable: true, searchable: true},
            {name: 'status', sortable: true, searchable: true},
            {name: 'actions', sortable: true, searchable: true}
        ],
        select: true,
        headerInputClass: 'form-control'
    };

    this.approvalTableDataSource = [];

    //TODO: Perhaps take setActive out of this method as it's called a lot of times this way
    this.hasItems = function (appCtrl, tabName) {
        appCtrl.setActive(tabName, ((!!this.approvalTableData.length) && appCtrl.tabs[tabName] && appCtrl.tabs[tabName].access));

        return !!this.approvalTableData.length;
    };

    this.actionsToFilterOn = [];
    this.filterData = function (data) {
        var result = [];

        _.each(this.actionsToFilterOn, function (filter) {
            result = result.concat(_.filter(data, filter));
        });

        return _.uniq(result);
    };

    this.getPreviousApprovalLevel = function () {
        if ($scope.currentWorkflow) {
            try {
                var previousApprovalLevel = $scope.currentWorkflow.getApprovalLevelBelowLevel($scope.approvalLevel.id);
                return previousApprovalLevel;
            } catch (e) {}
        }

        return {};
    };
}
tableViewController.$inject = ['$scope'];

function acceptTableViewController($scope, $controller) {
    jQuery.extend(this, $controller('tableViewController', {$scope: $scope}));

    var filterBelowUserLevel = function (item) {
        if ($scope.approvalLevel && item.level > $scope.approvalLevel.level && item.mayAccept === true) {
            return true;
        }
        return false;
    }.bind(this);

    this.actionsToFilterOn = [{mayAccept: true}, filterBelowUserLevel];
    this.approvalTableData = this.filterData(this.approvalTableDataSource);

    $scope.$on('MECHANISMS.updated', function (event, mechanisms) {
        this.approvalTableData = this.filterData(mechanisms);
        this.hasActionItems = !!_.filter(this.approvalTableData, {
            mayAccept: true,
            level: this.getPreviousApprovalLevel().level
        }).length;
    }.bind(this));
}
acceptTableViewController.$inject = ['$scope', '$controller'];

function acceptedTableViewController($scope, $controller) {
    jQuery.extend(this, $controller('tableViewController', {$scope: $scope}));

    this.actionsToFilterOn = [{mayApprove: true}, {mayUnaccept: true}];
    this.approvalTableData = this.filterData(this.approvalTableDataSource);

    $scope.$on('MECHANISMS.updated', function (event, mechanisms) {
        this.approvalTableData = this.filterData(mechanisms);
        this.hasActionItems = !!_.filter(this.approvalTableData, {
            mayApprove: true,
            level: this.getPreviousApprovalLevel().level
        }).length;
    }.bind(this));
}
acceptedTableViewController.$inject = ['$scope', '$controller'];

function submittedTableViewController($scope, $controller) {
    jQuery.extend(this, $controller('tableViewController', {$scope: $scope}));

    var filterOnLevel = function (item) {
        // User does not have an approval level so, everything is false
        if (!$scope.approvalLevel) {
            return false;
        }

        var onLowerLevelAndAccepted = ((parseInt(item.level, 10) === this.getPreviousApprovalLevel().level) && item.accepted);

        if (((item.level === $scope.approvalLevel.level)  || onLowerLevelAndAccepted)  && item.mayUnapprove === true) {
            return true;
        }
        return false;
    }.bind(this);

    this.actionsToFilterOn = [filterOnLevel];
    this.approvalTableData = this.filterData(this.approvalTableDataSource);

    $scope.$on('MECHANISMS.updated', function (event, mechanisms) {
        this.approvalTableData = this.filterData(mechanisms);
    }.bind(this));
}
submittedTableViewController.$inject = ['$scope', '$controller'];

function viewTableViewController($scope, $controller) {
    jQuery.extend(this, $controller('tableViewController', {$scope: $scope}));

    //The filter always returns true.
    this.filterData = function (data) {
        return _.filter(data, function () {
            return true;
        }, this);
    };
    this.approvalTableData = this.filterData();

    $scope.$on('MECHANISMS.updated', function (event, mechanisms) {
        this.approvalTableData = this.filterData(mechanisms);
    }.bind(this));
}
viewTableViewController.$inject = ['$scope', '$controller'];

function dataViewController($scope, approvalsService, $translate, $log) {
    var self = this;

    this.filteredDataSets = [];
    this.details = $scope.details;
    this.getMechanismsByIds = function (ids) {
        var idsLodash = _(ids);
        return _.filter(this.details.currentSelection, function (mechanism) {
            return idsLodash.includes(mechanism.id);
        });
    };

    this.isLocked = false;

    this.getActionTextFor = function (type) {
        function ucFirst(value) {
            return value.replace(/^./, function (value) {
                return value.toUpperCase();
            });
        }

        if (type === 'unapprove') {
            var isReturn = (this.details.currentSelection || []).reduce(function (isReturn, mechanism) {
                return (isReturn && /Return submission/.test(mechanism.actions));
            }, true);

            if (isReturn) {
                return $translate.instant('Return submission for {{count}} mechanism(s)', {count: this.details.actions[type].length});
            }
        }

        if (this.details.actions && this.details.actions[type]) {
            return $translate.instant(ucFirst(type) + ' {{count}} mechanism(s)', {count: this.details.actions[type].length});
        }
    };

    this.getPeriod = function () {
        return this.details.period;
    };

    this.getDataSetIds = function () {
        if (angular.isArray(this.details.dataSets)) {
            return _.map(this.details.dataSets, 'id');
        }
        return [];
    };

    this.getApprovalLevelId = function () {
        if (this.details.approvalLevel) {
            return this.details.approvalLevel.id;
        }
    };

    this.getParamsForMechanism = function () {
        var params = {};

        if (angular.isString(this.getPeriod()) && this.getPeriod().length > 0) {
            params.pe = this.getPeriod();
        }

        if (angular.isArray(this.getDataSetIds()) && this.getDataSetIds().length > 0) {
            params.ds = this.getDataSetIds();
        }

        return params;
    };

    this.isParamsComplete = function () {
        var params = this.getParamsForMechanism();

        if (angular.isObject(params) &&
            angular.isString(params.pe) && params.pe.length > 0 &&
            angular.isArray(params.ds) && params.ds.length > 0) {
            return true;
        }
        return false;
    };

    function getActionCallBackFor(actionName, mechanisms) {
        return function () {
            self.isLocked = false;
            $scope.$emit('APP.submit.success', {action: actionName, mechanisms: mechanisms});
        };
    }

    function actionErrorCallBack(message) {
        var resultMessage;

        self.isLocked = false;

        if (!/<[a-z][\s\S]*>/.test(message.data) && angular.isString(message.data)) {
            resultMessage = message.data;
        } else {
            resultMessage = (message.status ? message.status + ': ' : '') + message.statusText;
        }

        $scope.$emit('APP.submit.error', $translate.instant(resultMessage));
    }

    function prepareApprovalServiceParams(params, mechanisms, action) {
        var approvalParams = {};

        approvalParams.approvals = _.map(mechanisms, function (mechanism) {
            return {
                aoc: mechanism.catComboId,
                ou: determineOu(mechanism, action)
            };
        });
        approvalParams.pe = [params.pe];
        approvalParams.ds = params.ds;

        return approvalParams;

        function determineOu(mechanism, action) {
            if (isGlobal()) {
                //Adjust the mechanisms ou for any actions that happen on the global level
                if (mechanism.level === 1 || mechanism.level === 2) {
                    //Adjust the mechanisms ou for any actions that happen on the global level
                    $log.info(mechanism, 'is on level 1 therefore we replace the ou with', $scope.globalUser.globalOUId);
                    return $scope.globalUser.globalOUId;
                }
                if ((mechanism.nextLevel === 1 || mechanism.nextLevel === 2)
                    && mechanism.accepted === true && action === 'submit') {
                        $log.info(mechanism, 'is about to be submitted from level 2 and is accepted therefore we replace the ou with', $scope.globalUser.globalOUId);
                        return $scope.globalUser.globalOUId;
                }
            }

            return mechanism.organisationUnit;
        }

        function isGlobal() {
            return !!($scope.globalUser && $scope.globalUser.isGlobalUser && $scope.globalUser.globalOUId);
        }
    }

    this.submit = function (ids) {
        var params = this.getParamsForMechanism();
        var mechanisms = this.getMechanismsByIds(ids);
        var approvalParams;

        this.isLocked = true;

        if (this.isParamsComplete()) {
            approvalParams = prepareApprovalServiceParams(params, mechanisms, 'submit');

            if (approvalParams.approvals.length > 0) {
                approvalsService.approve(approvalParams).then(getActionCallBackFor('submit', mechanisms), actionErrorCallBack);
            }
        }
    };

    this.accept = function (ids) {
        var params = this.getParamsForMechanism();
        var mechanisms = this.getMechanismsByIds(ids);
        var approvalParams;

        this.isLocked = true;

        if (this.isParamsComplete()) {
            approvalParams = prepareApprovalServiceParams(params, mechanisms, 'accept');

            if (approvalParams.approvals.length > 0) {
                approvalsService.accept(approvalParams).then(getActionCallBackFor('accept', mechanisms), actionErrorCallBack);
            }
        }
    };

    this.unapprove = function (ids) {
        var params = this.getParamsForMechanism();
        var mechanisms = this.getMechanismsByIds(ids);
        var approvalParams;

        this.isLocked = true;

        if (this.isParamsComplete()) {
            approvalParams = prepareApprovalServiceParams(params, mechanisms, 'unapprove');

            if (approvalParams.approvals.length > 0) {
                approvalsService.unapprove(approvalParams).then(getActionCallBackFor('unsubmit', mechanisms), actionErrorCallBack);
            }
        }
    };

    this.unaccept = function (ids) {
        var params = this.getParamsForMechanism();
        var mechanisms = this.getMechanismsByIds(ids);
        var approvalParams;

        this.isLocked = true;

        if (this.isParamsComplete()) {
            approvalParams = prepareApprovalServiceParams(params, mechanisms, 'unaccept');

            if (approvalParams.approvals.length > 0) {
                approvalsService.unaccept(approvalParams).then(getActionCallBackFor('unaccept', mechanisms), actionErrorCallBack);
            }
        }
    };
}
dataViewController.$inject = ['$scope', 'approvalsService', '$translate', '$log'];

angular.module('PEPFAR.approvals').controller('dataViewController', dataViewController);

angular.module('PEPFAR.approvals').directive('analyticsStatus', analyticsStatusDirective);

function analyticsStatusDirective() {
    var UPDATE_INTERVAL = 60000;
    analyticsStatusCtrl.$inject = ['analyticsStatus', '$timeout'];
    return {
        restrict: 'E',
        scope: true,
        template: '<div class="analytics-status-update" ng-bind="analyticsStatusCtrl.getStatusText()"></div>',
        controller: analyticsStatusCtrl,
        controllerAs: 'analyticsStatusCtrl',
        bindToController: true
    };

    function analyticsStatusCtrl(analyticsStatus, $timeout) {
        var vm = this;
        var analyticsUpdateInterval;

        vm.getStatusText = getStatusText;

        initialise();
        function initialise() {
            getStatusUpdate();
        }

        function getStatusUpdate() {
            analyticsStatus.getIntervalSinceLastAnalyticsTableSuccess()
                .then(function (intervalSinceLastAnalyticsTableSuccess) {

                    analyticsUpdateInterval = [
                        'Data was updated',
                        intervalSinceLastAnalyticsTableSuccess,
                        'ago'
                    ].join(' ');
                })
                .catch(function (message) {
                    analyticsUpdateInterval = message;
                    $timeout(getStatusUpdate, UPDATE_INTERVAL);
                })
                .finally(function () {
                    $timeout(getStatusUpdate, UPDATE_INTERVAL);
                });
        }

        function getStatusText() {
            return analyticsUpdateInterval;
        }
    }
}

angular.module('PEPFAR.approvals').factory('analyticsStatus', analyticsStatus);

function analyticsStatus(Restangular, errorHandler, $q) {
    return {
        getIntervalSinceLastAnalyticsTableSuccess: getIntervalSinceLastAnalyticsTableSuccess
    };

    function getIntervalSinceLastAnalyticsTableSuccess() {
        var NOT_FOUND_MESSAGE = 'Unable to find last updated time';

        return Restangular.all('system').get('info')
            .then(function (systemInfo) {
                if (systemInfo.intervalSinceLastAnalyticsTableSuccess) {
                    return systemInfo.intervalSinceLastAnalyticsTableSuccess;
                }
                return $q.reject(NOT_FOUND_MESSAGE);
            })
            .catch(function () {
                return $q.reject(NOT_FOUND_MESSAGE);
            });
    }
}
analyticsStatus.$inject = ['Restangular', 'errorHandler', '$q'];

function approvalLevelsService($q, Restangular, rx, $log, $rootScope) {
    var deferred = $q.defer();

    var organisationUnitLevelsRequest = Restangular
        .all('organisationUnitLevels')
        .getList({
            fields: 'level,displayName',
            paging: false
        });

    var dataApprovalLevelsRequest = Restangular
        .all('dataApprovalLevels')
        .getList({
            fields: 'id,name,displayName,orgUnitLevel,level,categoryOptionGroupSet[id,name]',
            paging: false
        });

    var organisationUnitLevels$ = rx.Observable.fromPromise(organisationUnitLevelsRequest);
    var dataApprovalLevels$ = rx.Observable.fromPromise(dataApprovalLevelsRequest);

    /**
     * Create an ordered list of approvalLevels
     *
     * @param {Array} organisationUnitLevels List of organisation unit levels as returned by the DHIS2 API.
     * @returns {Array} An array of organisation units with level numbers as indexes [1: Global, 2: Country, 3: Agency]
     */
    // TODO: It might be better to return an object that uses numbers as keys, as now an array with empty holes will occur
    function getOrganisationUnitLevelNamesByLevelNumber(organisationUnitLevels) {
        return organisationUnitLevels
                .reduce(function (acc, organisationUnitLevel) {
                    acc[organisationUnitLevel.level] = organisationUnitLevel.displayName;
                    return acc;
                }, []);
    }

    var approvalLevels$ = rx.Observable.combineLatest(
        organisationUnitLevels$,
        dataApprovalLevels$,
        function (organisationUnitLevels, dataApprovalLevels) {
            var organisationUnitLevelNamesByLevelIndex = getOrganisationUnitLevelNamesByLevelNumber(organisationUnitLevels);

            var approvalLevelsWithLevelName = dataApprovalLevels
                // Add the levelName property to the approvalLevel object, based on the categoryOptionGroupSet name or fall back to the organisationUnit name.
                .map(function (approvalLevel) {
                    if (approvalLevel.categoryOptionGroupSet) {
                        approvalLevel.levelName = approvalLevel.categoryOptionGroupSet.name;
                    } else {
                        approvalLevel.levelName = organisationUnitLevelNamesByLevelIndex[approvalLevel.orgUnitLevel];
                    }

                    return approvalLevel;
                });

            // TODO: This function looks a bit like a hack and is only called once. Can perhaps be solved differently.
            approvalLevelsWithLevelName.getCategoryOptionGroupSetIdsForLevels = function () {
                return _.map(_.filter(approvalLevelsWithLevelName, 'categoryOptionGroupSet'), function (level) {
                    if (level.categoryOptionGroupSet) {
                        return {
                            name: level.name,
                            level: level.level,
                            cogsId: level.categoryOptionGroupSet.id
                        };
                    }
                });
            };
            return approvalLevelsWithLevelName;
        }
    ).safeApply($rootScope);

    function success(approvalLevels) {
        deferred.resolve(approvalLevels);
    }

    function failure(error) {
        $log.error('Failed to load dataApprovalLevels', error);
    }

    approvalLevels$.subscribe(success, failure);

    function approvalLevelPromiseGetter() {
        return deferred.promise;
    }

    approvalLevels$.get = approvalLevelPromiseGetter;

    return approvalLevels$;
}
approvalLevelsService.$inject = ['$q', 'Restangular', 'rx', '$log', '$rootScope'];

angular.module('PEPFAR.approvals').factory('approvalLevelsService', approvalLevelsService);

function approvalsService($q, Restangular) {

    //TODO rework this to not by default return true
    function checkApprovalData(approvalData) {
        if (!angular.isObject(approvalData)) {
            return 'The parameters for approvals are missing';
        }

        try {
            hasValidPeriod(approvalData);
            hasValidDataSet(approvalData);
            hasValidCategoryOptionCombo(approvalData);
        } catch (errorMessage) {
            return errorMessage;
        }

        return true;
    }

    function hasValidPeriod(approvalData) {
        if (!angular.isArray(approvalData.pe) || approvalData.pe.length === 0) {
            throw 'Period parameter (pe) is missing or empty';
        }
    }

    function hasValidDataSet(approvalData) {
        if (!angular.isArray(approvalData.ds) || approvalData.ds.length === 0) {
            throw 'Dataset id parameter (ds) is missing or empty';
        }
    }

    function hasValidCategoryOptionCombo(approvalData) {
        if (!angular.isArray(approvalData.approvals) || approvalData.approvals.length === 0) {
            throw 'Category option combo parameter is missing or empty';
        }
    }

    this.approve = function (approvalData) {
        var approvalStatus = checkApprovalData(approvalData);

        if (approvalStatus === true) {
            // First parameter is undefined because we do not post a body but
            // the data is in the query params in the second parameter.
            return Restangular.all('dataApprovals/approvals').post(approvalData);
        }
        return $q.reject({statusText: approvalStatus});
    };

    this.unapprove = function (approvalData) {
        var approvalStatus = checkApprovalData(approvalData);

        if (approvalStatus === true) {
            return Restangular.all('dataApprovals/unapprovals').post(approvalData);
        }
        return $q.reject({statusText: approvalStatus});
    };

    this.accept = function (approvalData) {
        var approvalStatus = checkApprovalData(approvalData);

        if (approvalStatus === true) {
            return Restangular.all('dataAcceptances/acceptances').post(approvalData);
        }
        return $q.reject({statusText: approvalStatus});
    };

    this.unaccept = function (approvalData) {
        var approvalStatus = checkApprovalData(approvalData);

        if (approvalStatus === true) {
            return Restangular.all('dataAcceptances/unacceptances').post(approvalData);
        }
        return $q.reject({statusText: approvalStatus});
    };
}
approvalsService.$inject = ['$q', 'Restangular'];

angular.module('PEPFAR.approvals').service('approvalsService', approvalsService);

function userApprovalLevelsService(Restangular, rx) {
    var userApprovalLevelPromise = Restangular
        .all('me')
        .get('dataApprovalLevels');

    return rx.Observable.fromPromise(userApprovalLevelPromise);
}
userApprovalLevelsService.$inject = ['Restangular', 'rx'];

angular.module('PEPFAR.approvals').factory('userApprovalLevels$', userApprovalLevelsService);

function workflowService(rx, Restangular, $q) {
    var currentWorkflow$ = new rx.ReplaySubject(1);
    var workflows$ = requestWorkflowsFromApi();

    function getApprovalLevelById(uid) {
        if (!this || !Array.isArray(this.dataApprovalLevels)) {
            throw new Error('This workflow does not have any approval levels');
        }

        return _.find(this.dataApprovalLevels, function (dataApprovalLevel) {
            return dataApprovalLevel.id === uid;
        });
    }

    // TODO: Rename to a better fitting name that reflects `AboveLevel`
    function getApprovalLevelBeforeLevel(uid) {
        if (!this || !Array.isArray(this.dataApprovalLevels)) {
            throw new Error('This workflow does not have any approval levels');
        }

        var levelsOrderedByLevelNr = _.sortBy(this.dataApprovalLevels, 'level');

        var indexOfTheLevelToFind = _.findIndex(levelsOrderedByLevelNr, function (dataApprovalLevel) {
            return dataApprovalLevel.id === uid;
        });

        if ((indexOfTheLevelToFind - 1) >= 0) {
            return levelsOrderedByLevelNr[indexOfTheLevelToFind - 1];
        }

        throw new Error('There is no level above this level');
    }

    function getApprovalLevelBelowLevel(uid) {
        if (!this || !Array.isArray(this.dataApprovalLevels)) {
            throw new Error('This workflow does not have any approval levels');
        }

        var levelsOrderedByLevelNr = _.sortBy(this.dataApprovalLevels, 'level');

        var indexOfTheLevelToFind = _.findIndex(levelsOrderedByLevelNr, function (dataApprovalLevel) {
            return dataApprovalLevel.id === uid;
        });

        if ((indexOfTheLevelToFind + 1) < levelsOrderedByLevelNr.length) {
            return levelsOrderedByLevelNr[indexOfTheLevelToFind + 1];
        }

        throw new Error('There is no level below this level');
    }

    function setCurrentWorkflow(workflowToFind) {
        workflows$
            .flatMap(rx.helpers.identity)
            .filter(function (workflow) {
                return workflow && workflowToFind && (workflow.id === workflowToFind.id);
            })
            .take(1)
            .map(function (workflow) {
                // TODO: Rewrite helper methods to functional helpers
                // Add helper methods
                workflow.getApprovalLevelById = getApprovalLevelById;
                workflow.getApprovalLevelBeforeLevel = getApprovalLevelBeforeLevel;
                workflow.getApprovalLevelBelowLevel = getApprovalLevelBelowLevel;

                return workflow;
            })
            .subscribe(function (workflowWithHelperMethods) {
                currentWorkflow$.onNext(workflowWithHelperMethods);
            });
    }

    function setDefaultsWhenMissing(workflow) {
        if (!workflow.dataSets) {
            workflow.dataSets = [];
        }
                    
        return workflow;
    }

    function requestWorkflowsFromApi() {
        var workflowRequest = Restangular.all('dataApprovalWorkflows')
            .withHttpConfig({cache: true})
            .getList({
                fields: 'id,name,displayName,periodType,dataApprovalLevels[displayName,id,level],dataSets[name,shortName,id,periodType,workflow[id,periodType],categoryCombo[id,name,categories[id]]]',
                paging: false
            })
            .then(function (workflows) {
                return _.map(workflows, setDefaultsWhenMissing);
            })
            .then(function (workflows) {
                return $q.all(workflows.map(function (workflow) {
                    if (workflow && workflow.dataSets) {
                        return loadCategoryOptionCombosForDataSets(workflow.dataSets)
                            .then(function () {
                                return workflow;
                            });
                    } else {
                        return $q.when(workflow);
                    }
                }));
            })
            .catch(function (response) {
                return $q.reject(new Error(response.data));
            });

        var workflow$ = rx.Observable
            .fromPromise(workflowRequest)
            .publishLast();

        workflow$.connect();

        return workflow$;
    }

    function loadCategoryOptionCombosForDataSets(dataSets) {
        var categoryCombosForDataSets = _.map(dataSets, function (dataSet) {
            return Restangular
                .all('categoryCombos')
                .withHttpConfig({cache: true})
                .get(dataSet.categoryCombo.id, {fields: 'id,categoryOptionCombos[id,name]'})
                .then(function (categoryCombo) {
                    dataSet.categoryCombo.categoryOptionCombos = categoryCombo.categoryOptionCombos;
                });
        });

        return $q.all(categoryCombosForDataSets)
            .then(function () {
                return dataSets;
            });
    }

    return {
        currentWorkflow$: currentWorkflow$,
        workflows$: workflows$,
        setCurrentWorkflow: setCurrentWorkflow
    };
}
workflowService.$inject = ['rx', 'Restangular', '$q'];

angular.module('PEPFAR.approvals').factory('workflowService', workflowService);

function dataStore(Restangular, errorHandler) {
    var periodSettings;

    function getPeriodSettings() {
        if (periodSettings) {
            return periodSettings;
        }

        periodSettings = Restangular
            .all('dataStore')
            .all('approvals')
            .get('periodSettings')
            .then(function (response) {
                return response.plain();
            })
            .catch(function () {
                errorHandler.error('Could not load the period settings from the dataStore.', true);
            });

        return periodSettings;
    }

    return {
        getPeriodSettings: getPeriodSettings
    };
}
dataStore.$inject = ['Restangular', 'errorHandler'];

angular.module('PEPFAR.approvals').factory('dataStore', dataStore);

angular.module('PEPFAR.approvals').factory('errorHandler', ['toastr', '$rootScope', function (toastr, $rootScope) {
    var service = this;

    return {
        error: error,
        warning: warning
    };

    function error(message, broadcast) {
        return handleError('error', message, broadcast);
    }

    function warning(message, broadcast) {
        return handleError('warning', message, broadcast);
    }

    function handleError(type, message, broadcast) {
        toastr[type]([message]);

        if (broadcast) {
            broadcastErrorEvent(message);
        }

        return service;
    }

    function broadcastErrorEvent(message) {
        $rootScope.$broadcast('APP.errorhandler.error', message);
    }
}]);

function currentUser(Restangular, $q) {
    var user;

    function loadPermissions() {
        var permissionPromise = Restangular
            .one('me/authorization')
            .get();

        function hasPermission(permissionToCheck) {
            return permissionPromise.then(function (permissions) {
                if (permissions.indexOf(permissionToCheck) > 0) {
                    return true;
                } else {
                    return $q.reject('User does not have this permission');
                }
            });
        }

        permissionPromise.hasPermission = hasPermission;
        return permissionPromise;
    }

    /**
     * Loading of the user profile
     */
    user = Restangular
        .one('me')
        .get({
            fields: 'id,name,displayName,surname,firstName,organisationUnits[id,name,displayName],dataViewOrganisationUnits[id,name,displayName]'
        });

    user = angular.extend(user, {
        valueFor: function (valueKey) {
            if (this[valueKey]) {
                return this[valueKey];
            } else {
                return undefined;
            }
        },
        permissions: loadPermissions()
    });

    user.then(function (response) {
        angular.extend(user, response);
    });

    return user;
}
currentUser.$inject = ['Restangular', '$q'];

angular.module('PEPFAR.approvals').factory('currentUser', currentUser);

function dataSetGroupService($rootScope, $q, periodService, Restangular, workflowService, rx, errorHandler) {
    var dataSetGroups$;
    var currentDataSetGroup$ = new rx.ReplaySubject(1);

    dataSetGroups$ = workflowService.workflows$
        .flatMap(function (workflows) {
            return rx.Observable
                .fromArray(workflows)
                .flatMap(function (workflow) {
                    return rx.Observable.combineLatest(
                        rx.Observable.just(workflow),
                        periodService.getPeriodsForWorkflow(workflow),
                        function (workflow, periodsForWorkflow) {
                            return {
                                workflow: workflow,
                                periods: periodsForWorkflow
                            };
                        }
                    );
                })
                .safeApply($rootScope);
        })
        // Only use workflows that actually have periods
        .filter(function (workflowAndPeriods) {
            return workflowAndPeriods.periods.length && workflowAndPeriods.workflow;
        })
        // Combine the workflows back into an array
        .reduce(function (acc, value) {
            return acc.concat(value.workflow);
        }, [])
        .tap(function (workflows) {
            // Show an error when there are no available workflows
            if (workflows.length === 0) {
                errorHandler.error('Could not not find any workflows (Data Streams)');
            }
        });

    return {
        setCurrentDataSetGroup: setCurrentDataSetGroup,
        dataSetGroups$: dataSetGroups$,
        currentDataSetGroup$: currentDataSetGroup$,
    };

    function setCurrentDataSetGroup(workflow) {
        var dataSetGroup = dataSetGroupFactory(workflow.dataSets);

        currentDataSetGroup$.onNext(dataSetGroup);
    }
}
dataSetGroupService.$inject = ['$rootScope', '$q', 'periodService', 'Restangular', 'workflowService', 'rx', 'errorHandler'];

function dataSetGroupFactory(dataSets) {
    return {
        get: function () {
            return dataSets;
        },
        getIds: function () {
            return _.map(dataSets, 'id');
        },
        getPeriodTypes: function () {
            return _.uniq(_.map(dataSets, 'periodType'));
        },
        getCategoryIds: function () {
            var categoriesFromCategoryCombos;

            categoriesFromCategoryCombos = _.map(_.map(dataSets, 'categoryCombo'), 'categories');
            categoriesFromCategoryCombos = _.flatten(categoriesFromCategoryCombos);
            categoriesFromCategoryCombos = _.map(categoriesFromCategoryCombos, 'id');

            return _.uniq(categoriesFromCategoryCombos);
        }
    };
}

angular.module('PEPFAR.approvals').factory('dataSetGroupService', dataSetGroupService);

// TODO: Rename to workflow selector
function dataSetGroupSelectorDirective(dataSetGroupService) {
    return {
        restrict: 'E',
        replace: true,
        scope: {},
        templateUrl: 'datasets/datasetgroupselector-357d9662.html',
        link: function (scope) {
            scope.dataset = {
                groups: undefined,
                selectedDataSetGroup: undefined
            };

            scope.onChange = function ($item) {
                // Set scope to keep dropdown in sync with dropdown
                scope.dataset.selectedDataSetGroup = $item;
                dataSetGroupService.setCurrentDataSetGroup($item);
            };

            dataSetGroupService
                .dataSetGroups$
                .take(1)
                .map(function (datasetGroups) {
                    if (angular.isArray(datasetGroups) && datasetGroups.length) {
                        scope.dataset.groups = datasetGroups;

                        // Fire onChange to set to the first group
                        scope.onChange(scope.dataset.groups[0]);
                    }
                })
                .safeApply(scope)
                .subscribe();
        }
    };
}
dataSetGroupSelectorDirective.$inject = ['dataSetGroupService'];

angular.module('PEPFAR.approvals').directive('datasetGroupSelector', dataSetGroupSelectorDirective);

/* global jQuery, dhis2 */
function datasetViewDirective(AppManifest, $translate, workflowService) {
    var dataSetReportWrapSelector = '.dataset-report-wrap';

    /**
     * Creates the events as they exist in data entry so they can be subscribed to.
     * This is needed so that subscriptions to these events in custom forms do not cause the
     * form to behave differently between reports and approvals.
     */
    (function createDataEntryEvents() {
        window.dhis2 = window.dhis2 || {};
        dhis2.de = dhis2.de || {};

        dhis2.de.event = {
            // Fired
            formLoaded        : 'dhis2.de.event.formLoaded',
            dataValuesLoaded  : 'dhis2.de.event.dataValuesLoaded',
            formReady         : 'dhis2.de.event.formReady',
            // Never fired in approvals (but can be subscribed to in custom form)
            dataValueSaved    : 'dhis2.de.event.dataValueSaved',
            completed         : 'dhis2.de.event.completed',
            uncompleted       : 'dhis2.de.event.uncompleted',
            validationSucces  : 'dhis2.de.event.validationSuccess',
            validationError   : 'dhis2.de.event.validationError'
        };
    }());

    /**
     * Fire a subset of the data entry events, just like in Data Set Report.
     */
    function fireDataEntryEvents() {
        var $document = jQuery(document);

        $document.trigger(dhis2.de.event.formLoaded);
        $document.trigger(dhis2.de.event.dataValuesLoaded);
        $document.trigger(dhis2.de.event.formReady);
    }

    function loadDataSetReport(details, ds, element, scope) {
        var dataSetReportUrl = AppManifest.activities.dhis.href + '/dhis-web-reporting/generateDataSetReport.action';
        var params = {
            ds: ds.id,
            pe: details.period,
            ou: details.orgUnit
        };

        //Dimensions should be based on the mechanisms that are assigned
        //The category should be based on the result of the selection that is done
        //Leave off the dimension if the category is `default`
        //If the dataset has a category(or multiple, in this case one) get the currentSelection items that have that category
        //If the dataset has the category default don't add the dimension
        var datasetCOCNames = _.map(ds.categoryCombo.categoryOptionCombos, 'name');
        var hasDefaultCOC = _.includes(datasetCOCNames, '(default)');
        var datasetCOCIds;

        var COsForReport;
        if (!hasDefaultCOC) {
            datasetCOCIds = _.map(ds.categoryCombo.categoryOptionCombos, 'id');
            //Filter out the ones that have default as COG
            COsForReport = _.filter(details.currentSelection, function (mechanism) {
                if (_.includes(datasetCOCIds, mechanism.catComboId)) {
                    return true;
                }
                return false;
            });
            // TODO: This picks the first category and assumes that all the other COs have the same category
            // which might not be true
            params.dimension = COsForReport[0].category + ':' + _.map(COsForReport, 'id').join(';');
        }

        jQuery.post(dataSetReportUrl, params).success(function (data) {
            scope.$apply(function () {
                scope.details.loaded += 1;
            });
            var reportElement = jQuery('<div class="dataset-view"></div>').append(data);

            var h3Elements = reportElement.find('h3');
            var toRemoveElements = [];

            h3Elements.first().html(ds.name)
                .attr('id', ds.id);

            if (h3Elements.length > 1) {
                h3Elements.each(function (index, element) {
                    if (index > 0) {
                        toRemoveElements.push(element);
                    }
                });
            }

            _.each(toRemoveElements, function (element) {
                jQuery(element).remove();
            });

            //Remove the hidden input fields
            reportElement.find('input[type="hidden"]').remove();

            //Remove the userinfo field
            reportElement.find('div#userInfo').remove();

            //Remove empty p element
            //reportElement.find('div.cde p:last-child').remove();

            //Remove the share form
            reportElement.find('div#shareForm').remove();

            //Remove the comment boxes for EA forms
            reportElement.find('.ea-comment').parentsUntil('div').remove();

            //Remove the background and color inline styles and add a class to the items that had a background
            //reportElement.find('[style*="background"]').css('background', '').addClass('dataset-view-highlight');
            //reportElement.find('[style*="color"]').css('color', '');

            scope.reportView[ds.id].content = reportElement;
            scope.updateCurrentViewIfNeeded(ds);
        });
    }

    //TODO: Take this into it's own directive (could be usable for reuse
    function addBackToTop(translation) {
        var backToTop = jQuery('<div class="back-to-top"><i class="fa fa-angle-double-up"></i><span>&nbsp;' + translation + '</span></div>');

        backToTop.on('click', function () {
            window.scrollTo(0, 0);
        });

        jQuery('.view-wrap').append(backToTop);
    }

    return {
        restrict: 'E',
        replace: true,
        templateUrl: 'datasets/datasetsview-d31d0380.html',
        scope: {},
        link: function (scope, element) {
            scope.reportView = {
                actions: {
                    approve: {count: 0},
                    unapprove: {count: 0},
                    accept: {count: 0},
                    unaccept: {count: 0}
                }
            };

            scope.$on('DATAVIEW.update', function (event, details) {
                scope.details = details;
                scope.checkValues();
            });

            var currentWorkflow$disposable;
            scope.checkValues = function () {
                var details = scope.details;

                // Clean up old subscription
                if (currentWorkflow$disposable && currentWorkflow$disposable.dispose) {
                    currentWorkflow$disposable.dispose();
                }

                workflowService.currentWorkflow$
                    .subscribe(function (workflow) {
                            if (details.orgUnit &&
                                details.period &&
                                details.dataSets &&
                                details.currentSelection &&
                                details.actions) {

                                scope.loadReports(workflow);

                        }
                    });
            };

            scope.hasUnreadableMechanisms = 0;
            scope.loadReports = function (workflow) {
                var details = scope.details;

                // Reset the report section to empty
                jQuery(dataSetReportWrapSelector).html('');

                // Reviewing SIMS workflow items this can only be done in the Genie. Therefore display a message for the
                // data to be reviewed in the genie.
                if (workflow.name === 'SIMS') {
                    // SIMS Reports / Redirect to Genie
                    var simsReviewHtml = angular.element(
                        '<div class="report-loading-message">' +
                        'Please review the SIMS data in the Genie at <a href="https://www.datim.org/api/apps/Genie_v1.1.7/index.html?v=1.0.0#/" target="_blank">https://www.datim.org/api/apps/Genie_v1.1.7/index.html?v=1.0.0#/</a></span>' +
                        '</div>');

                    // Set the amount of loaded items to one to hide the loading message.
                    scope.details.loaded += 1;

                    // Append the created message to the reports element
                    element.find(dataSetReportWrapSelector).append(simsReviewHtml);
                    return;
                }

                scope.details.dataSetsFilteredByMechanisms = _.filter(details.dataSets, function (dataSet) {
                    var result = false;
                    var categoryOptionComboIds;
                    if(details.validDataSets.length>0){ //TOM (2018-01-08)(for Global ticket #3332)
                    if(details.validDataSets.indexOf(dataSet.id)<0){return false}} //TOM (2018-01-08)(for Global ticket #3332)

                    if (!dataSet.categoryCombo || !angular.isArray(dataSet.categoryCombo.categoryOptionCombos)) {
                        return false;
                    }

                    categoryOptionComboIds = _.map(dataSet.categoryCombo.categoryOptionCombos, 'id');

                    _.each(scope.details.currentSelection, function (mechanism) {
                        if (mechanism.mayReadData === false) {
                            scope.hasUnreadableMechanisms += 1;
                        }

                        if (_.includes(categoryOptionComboIds, mechanism.catComboId)) {
                            result = true;
                        }
                    });
                    return result;
                });

                scope.details.dataSetsFilteredByMechanisms.sort((a,b) => (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0)); //TOM (2018-11-09)(for Global ticket #3332, datim-approvals #7)

                $translate('Go to top').then(function (translation) {
                    addBackToTop(translation);
                });

                scope.details.loaded = 0;
                scope.reportView.currentDataSet = scope.details.dataSetsFilteredByMechanisms[0];
                scope.details.dataSetsFilteredByMechanisms.forEach(function (item) {
                    loadDataSetReport(scope.details, item, element.find(dataSetReportWrapSelector), scope);
                    scope.reportView[item.id] = {};
                    scope.reportView[item.id].content = angular.element(
                        '<div class="report-loading-message">' +
                        '<i class="fa fa-circle-o-notch fa-spin"></i> Loading report: <span class="report-name">' + item.name + '</span>' +
                        '</div>');
                });

                // When reports are available add the first element to the screen
                if (scope.reportView &&
                    angular.isArray(scope.details.dataSetsFilteredByMechanisms) &&
                    scope.details.dataSetsFilteredByMechanisms.length > 0 &&
                    scope.reportView[scope.details.dataSetsFilteredByMechanisms[0]]) {
                    element.find(dataSetReportWrapSelector).append(scope.reportView[scope.details.dataSetsFilteredByMechanisms[0].id].content);
                }
            };

            scope.onChange = function ($event, $item) {
                try {
                    if (scope.reportView[$item.id].content) {
                        if (element.find(dataSetReportWrapSelector).children().length > 0) {
                            element.find(dataSetReportWrapSelector).children().replaceWith(scope.reportView[$item.id].content);
                        } else {
                            element.find(dataSetReportWrapSelector).append(scope.reportView[$item.id].content);
                        }

                        fireDataEntryEvents();
                    }
                } catch (e) {
                    if (window.console && window.console.error) {
                        window.console.error(e);
                    }
                }
            };

            scope.updateCurrentViewIfNeeded = function (dataSet) {
                if (scope.reportView.currentDataSet &&
                    scope.reportView.currentDataSet.id === dataSet.id) {
                    scope.onChange({}, dataSet);
                }
            };
        }
    };
}
datasetViewDirective.$inject = ['AppManifest', '$translate', 'workflowService'];

angular.module('PEPFAR.approvals').directive('datasetView', datasetViewDirective);

function mechanismsService(Restangular, $log, $q, approvalLevelsService, workflowService, categoriesService, rx) {
    var self = this;
    var AGENCY_LEVEL = 'Funding Agency';
    var PARTNER_LEVEL = 'Implementing Partner';

    var period;
    var dataSetIds = [];
    var categories = [];
    var organisationUnit = '';

    var mechanisms = [];

    var orgUnitCache = {};
    var categoryCache = {};

    this.isGlobal = false;

    Object.defineProperty(this, 'period', {
        set: function (value) {
            if (!angular.isString(value)) {
                $log.error('Mechanism Service: Period should be a string');
                return;
            }
            period = value;
        },
        get: function () {
            return period;
        }
    });

    Object.defineProperty(this, 'dataSetIds', {
        set: function (value) {
            if (!angular.isArray(value)) {
                $log.error('Mechanism Service: DataSets should be a string');
                return;
            }
            dataSetIds = value;
        },
        get: function () {
            return dataSetIds;
        }
    });

    Object.defineProperty(this, 'categories', {
        set: function (value) {
            if (!angular.isArray(value)) {
                $log.error('Mechanism Service: Categories should be an array');
                return;
            }
            categories = value;
        },
        get: function () {
            return categories;
        }
    });

    Object.defineProperty(this, 'organisationUnit', {
        set: function (value) {
            if (!angular.isString(value)) {
                $log.error('Mechanism Service: OrganisationUnit should be a string');
                return;
            }
            organisationUnit = value;
        },
        get: function () {
            return organisationUnit;
        }
    });

    this.getMechanisms = function () {
        function parseData(categories, cogsIdsForLevels) {
            var data;

            var agencyCOGSId = _.find(cogsIdsForLevels, function (cogsIdsForLevel) {
                if (cogsIdsForLevel.name === AGENCY_LEVEL) {
                    return true;
                }
                return false;
            }).cogsId;

            var parterCOGSId = _.find(cogsIdsForLevels, function (cogsIdsForLevel) {
                if (cogsIdsForLevel.name === PARTNER_LEVEL) {
                    return true;
                }
                return false;
            }).cogsId;

            data = _(categories).map(function (category) {
                return _.map(filterCategoryOptions(category.categoryOptions), function (categoryOption) {
                    var mechanism = {
                        id: categoryOption.id,
                        mechanism: categoryOption.name,
                        country: getCountryFromCategoryOption(categoryOption),
                        agency: getAgencyFromCategoryOption(categoryOption.categoryOptionGroups || [], agencyCOGSId),
                        partner: getPartnerFromCategoryOption(categoryOption.categoryOptionGroups || [], parterCOGSId),
                        status: '',
                        actions: '',
                        category: category.id,
                        catComboId: categoryOption.categoryOptionCombos[0].id //FIXME: Hacked for pepfar to always be the first
                    };
                    return mechanism;
                });
            }).flatten();

            return data.value();
        }

        function filterCategoryOptions(categoryOptions) {
            var filteredCategoryOptions;
            filteredCategoryOptions = filterCategoryOptionsWithCategoryOptionCombo(categoryOptions);
            filteredCategoryOptions = filterOrganisationUnits(filteredCategoryOptions);
            return filteredCategoryOptions;
        }

        function filterCategoryOptionsWithCategoryOptionCombo(categoryOptions) {
            return _.filter(categoryOptions, function (categoryOption) {
                if (angular.isArray(categoryOption.categoryOptionCombos) &&
                    categoryOption.categoryOptionCombos.length > 0) {
                    return true;
                }
                return false;
            });
        }

        function filterOrganisationUnits(categoryOptions) {
            return categoryOptions.filter(function (categoryOption) {
                if (angular.isArray(categoryOption.organisationUnits) &&
                    categoryOption.organisationUnits.length > 0) {
                    return true;
                }
                return false;
            });
        }

        function getCountryFromCategoryOption(categoryOption) {
            if (categoryOption.organisationUnits[0]) {
                orgUnitCache[categoryOption.organisationUnits[0].id] = categoryOption.organisationUnits[0].name;
            }

            return categoryOption.organisationUnits[0] ? categoryOption.organisationUnits[0].name : '';
        }

        function getPartnerFromCategoryOption(categoryOptionGroups, parterCOGSId) {
            var partner = _.find(categoryOptionGroups, function (categoryOptionGroup) {
                if (categoryOptionGroup.groupSets &&
                    categoryOptionGroup.groupSets[0] &&
                    categoryOptionGroup.groupSets[0].id &&
                    categoryOptionGroup.groupSets[0].id === parterCOGSId) {
                    return true;
                }
                return false;
            });

            if (partner) {
                return partner.name;
            }
            return '';
        }

        function getAgencyFromCategoryOption(categoryOptionGroups, agencyCOGSId) {
            var agency = _.find(categoryOptionGroups, function (categoryOptionGroup) {
                if (categoryOptionGroup.groupSets &&
                    categoryOptionGroup.groupSets[0] &&
                    categoryOptionGroup.groupSets[0].id &&
                    categoryOptionGroup.groupSets[0].id === agencyCOGSId) {
                    return true;
                }
                return false;
            });

            if (agency) {
                return agency.name;
            }
            return '';
        }

        function getCategoriesAndReplaceDefaults() {
            var deferred = $q.defer();

            //Load categories from cache
            if (categoryCache[categories.join('_')]) {
                deferred.resolve(categoryCache[categories.join('_')]);
                return deferred.promise;
            }

            self.getData().then(function (data) {
                _.each(data, function (category) {
                    _.each(self.dataSets, replaceMechanismNameWithDataSetNameForDefaultCategoryComboNameDefault);

                    function replaceMechanismNameWithDataSetNameForDefaultCategoryComboNameDefault(dataSet) {
                        if (dataSet.categoryCombo.name === 'default' && dataSet.categoryCombo.categories[0].id === category.id) {
                            _.each(category.categoryOptions, function (mechanism) {
                                if (mechanism.name === 'default') {
                                    mechanism.name = dataSet.name;
                                }
                            });
                        }
                    }
                });
                categoryCache[categories.join('_')] = data;
                deferred.resolve(data);

            }, function () {
                deferred.reject('Error loading category data');
            });

            return deferred.promise;
        }

        return rx.Observable.combineLatest(
                rx.Observable.fromPromise(getCategoriesAndReplaceDefaults()),
                approvalLevelsService,
                rx.Observable.fromPromise(this.getStatuses()),
                workflowService.currentWorkflow$,
                function (categories, approvalLevels, statuses, workflow) {
                    return [categories, approvalLevels, statuses, workflow];
                })
                .map(function (data) {
                    var categories = data[0];
                    var approvalLevels = data[1];
                    var workflow = data[3];

                    var parsedData = parseData(categories, approvalLevels.getCategoryOptionGroupSetIdsForLevels());

                    self.filterMechanisms(data[2], parsedData, data[1], workflow);

                    return mechanisms;
                }, function () {
                    $log.error('Mechanism Service: Unable to parse the mechanisms');
                });
    };

    this.filterMechanisms = function (mechanismsStatuses, parsedData, approvalLevels, workflow) {
        mechanisms = [];

        //TODO: Refactor this function
        //jshint maxcomplexity:16, maxstatements:43
        _.each(mechanismsStatuses, function (mechanismStatus) {
            var actions = [];
            var status = [];
            var approvalLevel;
            var mechanism = angular.copy(_.find(parsedData, {catComboId: mechanismStatus.id}));

            if (!mechanism) {
                return;
            }

            if (mechanismStatus.level && mechanismStatus.level.id) {
                // console.log('Current level', workflow.getApprovalLevelById(mechanismStatus.level.id));
                // approvalLevel = _.find(approvalLevels, {id: mechanismStatus.level.id});
                approvalLevel = workflow.getApprovalLevelById(mechanismStatus.level.id);
            }

            if (mechanismStatus.permissions.mayApprove === true) {
                mechanism.mayApprove = true;
                actions.push('Submit');
            }
            if (mechanismStatus.permissions.mayUnapprove === true) {
                mechanism.mayUnapprove = true;
                if (mechanismStatus.permissions.mayAccept || mechanismStatus.permissions.mayUnaccept) {
                    actions.push('Return submission');
                } else {
                    actions.push('Recall submission');
                }
            }
            if (mechanismStatus.permissions.mayUnaccept === true) {
                mechanism.mayUnaccept = false; //Since 0.1.8 Unaccept is not allowed anymore
                //mechanism.mayUnaccept = true;
                //actions.push('Unaccept');
            }
            if (mechanismStatus.permissions.mayAccept === true) {
                mechanism.mayAccept = true;
                actions.push('Accept');
            }

            if (mechanismStatus.permissions.mayReadData === true) {
                mechanism.mayReadData = true;
            } else {
                mechanism.mayReadData = false;
            }

            mechanism.accepted = false;
            if (approvalLevel) {
                if (mechanismStatus.accepted === true) {
                    mechanism.accepted = true;
                    status.push('Accepted');
                    if (mechanismStatus.level && mechanismStatus.level.level) {
                        // approvalLevel = _.find(approvalLevels, {level: (parseInt(mechanismStatus.level.level) - 1)});
                        approvalLevel = workflow.getApprovalLevelBeforeLevel(mechanismStatus.level.id);
                        status.push(approvalLevel.displayName);
                    }
                } else {
                    status.push('Submitted');
                    status.push(approvalLevel.displayName);
                }
            } else {
                status.push('Pending');
            }

            mechanism.status = status.join(' by ');
            mechanism.actions = actions.join(', ');
            mechanism.organisationUnit = mechanismStatus.ou;

            mechanism.level = mechanismStatus.level && parseInt(mechanismStatus.level.level, 10) || undefined;

            try {
                mechanism.nextLevel = workflow.getApprovalLevelBeforeLevel(mechanismStatus.level.id).level;
            } catch(e) {}

            mechanisms.push(mechanism);
        });
    };
    //jshint maxcomplexity:6, maxstatements:30

    this.getData = function () {
        return categoriesService.getCategories(categories);
    };

    this.getStatuses = function () {
        return Restangular.all('dataApprovals/categoryOptionCombos').getList({
            pe: period,
            ds: dataSetIds,
            ou: self.isGlobal ? undefined : organisationUnit //Don't pass the org unit id when the org unit is global
        }).catch(function (e) {
            $log.error('Failed to get statuses');
            return $q.reject(e);
        });
    };
}
mechanismsService.$inject = ['Restangular', '$log', '$q', 'approvalLevelsService', 'workflowService', 'categoriesService', 'rx'];

angular.module('PEPFAR.approvals').service('mechanismsService', mechanismsService);

/**********************************************************************************/
angular.module('PEPFAR.approvals').factory('categoriesService', categoriesService);
function categoriesService(request, $q, $log) {
    return {
        getCategories: getCategories
    };

    function getCategories(categoryIds) {
        var categoriesUrl = ['api', 'categories.json'].join('/');
        var fields = 'fields=id,name';
        var filters;
        var queryParams;
        var categoryOptionsPromises;
        var categoriesPromise;

        if (!areParamsCorrect(categoryIds)) {
            return $q.reject('Not all required params are set');
        }

        filters = [encodeURI(['id:in:[', categoryIds.join(','), ']'].join(''))];
        queryParams = ['paging=false', createFilterQueryParamFrom(filters), fields];

        categoryOptionsPromises = categoryIds
            .map(function (categoryId) {
                return requestCategoryOptionsByCategoryId(categoryId)
                    .then(function (response) {
                        response.categoryId = categoryId;
                        return response;
                    });
            });

        categoriesPromise = request(categoriesUrl, queryParams)
            .then(extractCategories)
            .catch(function () {
                return $q.reject('Request for categories failed');
            });

        return $q.all([categoriesPromise].concat(categoryOptionsPromises))
            .then(function (responses) {
                var categories = responses.shift();
                var categoryOptionsForCategories = responses;

                categoryOptionsForCategories.forEach(function (categoryOptions) {
                    categories.forEach(function (category) {
                        if (categoryOptions.categoryId === category.id) {
                            category.categoryOptions = categoryOptions.categoryOptions;
                        }
                    });
                });

                return categories;
            });
    }

    function requestCategoryOptionsByCategoryId(categoryId) {
        return request('api/categoryOptions', [
            'paging=false',
            'filter=categories.id:eq:' + categoryId,
            'fields=' + encodeURI('id,name,organisationUnits[id,name],categoryOptionCombos[id,name],categoryOptionGroups[id,name,groupSets[id]]')
        ]);
    }

    function extractCategories(data) {
        if (data && data.categories && data.categories.length) {
            $log.log('Loaded categories using $http');
            return data.categories;
        }
        return [];
    }

    function createFilterQueryParamFrom(filters) {
        return filters.map(function (filterText) {
            return 'filter=' + filterText;
        }).join('&');
    }

    function areParamsCorrect(filters) {
        if (filters.length <= 0) {
            $log.error('Categories Service (getCategories): Ids should be provided when trying to request mechanisms');
            return false;
        }
        return true;
    }
}
categoriesService.$inject = ['request', '$q', '$log'];

/**********************************************************************************/
angular.module('PEPFAR.approvals').factory('request', requestProvider);
function requestProvider($http, $q, AppManifest) {

    return request;

    /**
     * Does an ajax GET request using $http
     *
     * @param {String} url Url to request from
     * @param {Object} queryParams Query params that should be added to the url.
     * @returns {Promise}
     */
    function request(url, queryParams) {
        return $http.get([AppManifest.activities.dhis.href, url].join('/') + '?' + queryParams.join('&'))
            .then(function (response) {
                return response.data;
            })
            .catch(function (response) {
                return $q.reject(response.statusText);
            });
    }
}
requestProvider.$inject = ['$http', '$q', 'AppManifest'];

function organisationunitSelectorDirective(organisationunitsService, $log) {
    return {
        restrict: 'E',
        replace: true,
        scope: true,
        templateUrl: 'organisationunits/organisationunitselector-f5b4de15.html',
        link: function (scope) {
            scope.organisationUnit = {
                selected: undefined,
                organisationUnits: [],
                currentOrganisationUnit: {}
            };

            scope.$watch(function () {
                return organisationunitsService.currentOrganisationUnit;
            }, function (newVal, oldVal) {
                var levelToGet;

                if (newVal === oldVal) { return; }

                if (organisationunitsService.currentOrganisationUnit && organisationunitsService.currentOrganisationUnit.level &&
                    organisationunitsService.currentOrganisationUnit.id) {
                    levelToGet = organisationunitsService.currentOrganisationUnit.level + 1;

                    //Only display this option for global users
                    if (organisationunitsService.currentOrganisationUnit.level !== 1) { return; }

                    organisationunitsService.requestOrganisationUnitsForLevel(organisationunitsService.currentOrganisationUnit.id, levelToGet)
                        .subscribe(function (dataList) {
                            var thisOrgUnit = {
                                id: organisationunitsService.currentOrganisationUnit.id,
                                name: organisationunitsService.currentOrganisationUnit.displayName
                            };
                            dataList = _.sortBy(dataList, 'displayName');
                            scope.organisationUnit.organisationUnits = [thisOrgUnit].concat(dataList);
                            scope.organisationUnit.selected = scope.organisationUnit.organisationUnits[0];
                        }, function () {
                            $log.error('Could not load organisation units for level: ' + levelToGet);
                        });
                }
            }, true);

            scope.changeOrganisationUnit = function ($item) {
                organisationunitsService.currentOrganisationUnit = $item;
            };
        }
    };
}
organisationunitSelectorDirective.$inject = ['organisationunitsService', '$log'];

angular.module('PEPFAR.approvals').directive('organisationunitSelector', organisationunitSelectorDirective);

function organisationunitsService(Restangular, rx) {
    function requestOrganisationUnitsForLevel(orgUnitId, orgUnitLevel) {
        var queryParams = {
            fields: 'id,name,displayName',
            level: orgUnitLevel,
            paging: 'false'
        };

        var organisationUnitRequest = Restangular
            .all('organisationUnits')
            .get(orgUnitId, queryParams)
            .then(function (organisationUnitData) {
                return organisationUnitData.organisationUnits;
            });

        return rx.Observable.fromPromise(organisationUnitRequest);
    }

    return {
        currentOrganisationUnit: {},
        requestOrganisationUnitsForLevel: requestOrganisationUnitsForLevel
    };
}
organisationunitsService.$inject = ['Restangular', 'rx'];

angular.module('PEPFAR.approvals').factory('organisationunitsService', organisationunitsService);

angular.module('PEPFAR.approvals').factory('periodService', periodService);

function periodService(dataStore, rx, $rootScope) {
    var period$ = new rx.ReplaySubject(1);

    return {
        period$: period$,
        getPeriodsForWorkflow: getPeriodsForWorkflow,
        setPeriod: setPeriod
    };

    ///////////////////////////////////////////////////////////////////////
    function getPeriodsForWorkflow(workflow) {
        return rx.Observable.fromPromise(dataStore.getPeriodSettings())
            .map(onlyPeriodsForWorkflow(workflow))
            .map(periodSettingsToArray)
            .map(onlyOpenPeriods)
            .map(onlyNameAndIdProperties)
            .safeApply($rootScope);
    }

    function setPeriod(newPeriod) {
        period$.onNext(newPeriod);
    }

    function onlyPeriodsForWorkflow(workflow) {
        return function (periodSettings) {
            return periodSettings[workflow.name];
        };
    }

    function onlyOpenPeriods(periods) {
        return periods
            .filter(function (period) {
                return todayIsBetweenDates(period.start, period.end);
            });
    }

    function todayIsBetweenDates(startDate, endDate) {
        var start = Date.parse(startDate);
        var end = Date.parse(endDate);
        var now = Date.now();

        if (isNumber(start) && isNumber(end)) {
            return (start < now) && (now < end);
        }

        return false;
    }

    function isNumber(value) {
        return typeof value === 'number' && !isNaN(value);
    }

    function periodSettingsToArray(periodSettings) {
        return Object.keys(periodSettings || {})
            .reduce(function (acc, periodKey) {
                return acc.concat([ _.extend({ id: periodKey }, periodSettings[periodKey]) ]);
            }, []);
    }

    function onlyNameAndIdProperties(periods) {
        return _.map(periods, pickIdAndNameFromPeriod);
    }

    function pickIdAndNameFromPeriod(period) { 
        return _.pick(period, ['id', 'name','datasets']); //TOM (2018-01-08)(for Global ticket #3332)
    }
}
periodService.$inject = ['dataStore', 'rx', '$rootScope'];

function periodSelectorDirective(periodService, workflowService, $log) {
    return {
        restrict: 'E',
        replace: true,
        scope: true,
        templateUrl: 'period/periodselector-3b860571.html',
        link: function (scope) {
            scope.period = {
                selectedPeriod: undefined,
                periods: []
            };

            scope.changePeriod = function ($item) {
                if ($item === undefined) {
                    return;
                }

                periodService.setPeriod($item);
            };

            // When the workflow is updated we'll need to update the periods
            workflowService.currentWorkflow$
                .flatMap(function (workflow) {
                    return periodService.getPeriodsForWorkflow(workflow);
                })
                .map(function (periods) {
                    // Set retrieved periods onto the scope so they show up in the dropdown
                    scope.period.periods = periods;

                    // If we have at least 1 period we'll change the selected period to the first one in the list
                    if (periods.length > 0) {
                        $log.info('Set selected period to ', periods[0]);
                        scope.period.selectedPeriod = periods[0];
                        scope.changePeriod(periods[0]);
                    }
                })
                .safeApply(scope)
                .subscribe();
        }
    };
}
periodSelectorDirective.$inject = ['periodService', 'workflowService', '$log'];

angular.module('PEPFAR.approvals').directive('periodSelector', periodSelectorDirective);

angular.module('PEPFAR.approvals').factory('toastr', function () {
    var toastrOptions;

    if (window.toastr) {
        toastrOptions = window.toastr.options;
        toastrOptions.positionClass = 'toast-top-right';
        toastrOptions.timeOut = 0;
        toastrOptions.extendedTimeOut = 0;
        toastrOptions.closeButton = true;
        toastrOptions.tapToDismiss = false;

        return window.toastr;
    }
    throw Error('Toastr.js library does not seem to be loaded.');
});
